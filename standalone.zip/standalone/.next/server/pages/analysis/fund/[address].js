"use strict";
(() => {
var exports = {};
exports.id = 7197;
exports.ids = [7197];
exports.modules = {

/***/ 60674:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/fundLoading.284c556c.png","height":540,"width":960,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 50988:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57182);
/* harmony import */ var private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13162);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44178);
/* harmony import */ var private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(31738);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/analysis/fund/[address]",
        pathname: "/analysis/fund/[address]",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_analysis_fund_address_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 31738:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(42451);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(25572);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(62881);
/* harmony import */ var _contents_analysis__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(45634);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(25622);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(30675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var antd_lib_radio__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(27386);
/* harmony import */ var antd_lib_radio__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(antd_lib_radio__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _store_modules_analysis__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(56854);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _assets_images_fundLoading_png__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(60674);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7947);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(23495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_5__, _contents_analysis__WEBPACK_IMPORTED_MODULE_6__, _packages_segmented__WEBPACK_IMPORTED_MODULE_7__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_10__, _utils__WEBPACK_IMPORTED_MODULE_15__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_5__, _contents_analysis__WEBPACK_IMPORTED_MODULE_6__, _packages_segmented__WEBPACK_IMPORTED_MODULE_7__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_10__, _utils__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const Fund = next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(null, {
    loadableGenerated: {
        modules: [
            "analysis/fund/[address].tsx -> " + "@/src/analysis/fund"
        ]
    },
    ssr: false
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_11__.observer)(()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { address } = router.query;
    const { fundInfo, fundTrans } = _store_modules_analysis__WEBPACK_IMPORTED_MODULE_10__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_5__/* .Translation */ .W)({
        ns: "analysis"
    });
    const [showCard, setShowCard] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("transaction_volume");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);
    const [inputValue, setInputValue] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        _store_modules_filscan__WEBPACK_IMPORTED_MODULE_3__["default"].setTheme("dark");
        return ()=>{
            const lastTheme = localStorage.getItem("theme");
            _store_modules_filscan__WEBPACK_IMPORTED_MODULE_3__["default"].setTheme(lastTheme);
        };
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        load();
        const infoPayload = {
            address,
            interval: "7d"
        };
        _store_modules_analysis__WEBPACK_IMPORTED_MODULE_10__["default"].getFundAddrInfo(infoPayload);
        loadTrans(address);
    }, [
        address
    ]);
    const load = async (value)=>{
        const payload = {
            address,
            type: value || showCard
        };
        await _store_modules_analysis__WEBPACK_IMPORTED_MODULE_10__["default"].getFundAddress(payload);
        setLoading(false);
    };
    const loadTrans = (address)=>{
        _store_modules_analysis__WEBPACK_IMPORTED_MODULE_10__["default"].getFundTransaction(address);
    };
    const renderItem = (data, type)=>{
        const showData = type === "card" ? fundTrans : fundInfo;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_main),
            children: data.map((item, index)=>{
                const { title, dataIndex, render, options, defaultValue } = item;
                const value = showData && showData[dataIndex] || "";
                let showValue = render ? render(value, showData) : value;
                if (options) {
                    let flag = "";
                    let className = "";
                    if (Number(showValue)) {
                        if (Number(showValue) > 0) {
                            className = "text_green";
                            flag = "+";
                        } else if (Number(showValue) < 0) {
                            className = "text_red";
                            flag = "";
                        }
                    }
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_item),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_item_title),
                                children: tr(title)
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_item_value),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_radio__WEBPACK_IMPORTED_MODULE_9___default().Group), {
                                        className: "custom_radio_group",
                                        defaultValue: defaultValue || "",
                                        children: options.map((option)=>{
                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_radio__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                value: option.dataIndex,
                                                disabled: option.disabled,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_item_base),
                                                    children: [
                                                        tr(option.title),
                                                        option.sufIcon
                                                    ]
                                                })
                                            }, option.dataIndex);
                                        })
                                    }),
                                    dataIndex === "balance_increase" && showValue && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_item_value_otherValue)} ${className}`,
                                        children: [
                                            flag,
                                            (0,_utils__WEBPACK_IMPORTED_MODULE_15__/* .formatFilNum */ .Nm)(showValue)
                                        ]
                                    })
                                ]
                            })
                        ]
                    }, index);
                }
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_item),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_item_title),
                            children: tr(title)
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_item_value),
                            children: showValue
                        })
                    ]
                }, index);
            })
        });
    };
    const cardData = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return showCard === "transaction_volume" ? (0,_contents_analysis__WEBPACK_IMPORTED_MODULE_6__/* .fund_card */ .ZI)("volume") : (0,_contents_analysis__WEBPACK_IMPORTED_MODULE_6__/* .fund_card */ .ZI)("count");
    }, [
        showCard
    ]);
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund)} main_contain ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_loading)}`,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_13___default()), {
                src: _assets_images_fundLoading_png__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z,
                alt: "",
                width: 600
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund)} main_contain`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_title),
                children: tr("fund_analysis")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_contain),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_contain_left),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_topBorder)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_bottomBorder)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_after)
                                    }),
                                    renderItem(_contents_analysis__WEBPACK_IMPORTED_MODULE_6__/* .fund_list */ .uE),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_hr)
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_main),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_item),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_item_title),
                                                        children: tr("related_way")
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_item_value),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                            data: _contents_analysis__WEBPACK_IMPORTED_MODULE_6__/* .related_options */ .En,
                                                            defaultValue: "transaction_volume",
                                                            ns: "analysis",
                                                            isHash: false,
                                                            onChange: (value)=>{
                                                                load(value);
                                                                setShowCard(value);
                                                            }
                                                        })
                                                    })
                                                ]
                                            }),
                                            renderItem(_contents_analysis__WEBPACK_IMPORTED_MODULE_6__/* .related_list */ .Sc)
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_topBorder)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_bottomBorder)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_card_after)
                                    }),
                                    renderItem(cardData, "card")
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_contain_chart),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_8___default()), {
                                    value: inputValue,
                                    onChange: (e)=>{
                                        setInputValue(e.target.value);
                                    },
                                    onPressEnter: (e)=>{
                                        if (e.target.value) {
                                            router.push(`/analysis/fund/${e.target.value}`);
                                        }
                                    },
                                    suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_contain_chart_icon),
                                        onClick: ()=>{
                                            if (inputValue && inputValue.length > 0) {
                                                router.push(`/analysis/fund/${inputValue}`);
                                            }
                                        },
                                        children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_14__/* .getSvgIcon */ .a)("search")
                                    }),
                                    className: `custom_input ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().fund_contain_chart_input)}`,
                                    placeholder: tr("fund_placeholder")
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Fund, {
                                showCard: showCard
                            })
                        ]
                    })
                ]
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 52727:
/***/ ((module) => {

module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ 77529:
/***/ ((module) => {

module.exports = require("@ant-design/icons/lib/icons/LoadingOutlined");

/***/ }),

/***/ 53800:
/***/ ((module) => {

module.exports = require("antd/lib/button");

/***/ }),

/***/ 92616:
/***/ ((module) => {

module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 30675:
/***/ ((module) => {

module.exports = require("antd/lib/input");

/***/ }),

/***/ 4946:
/***/ ((module) => {

module.exports = require("antd/lib/locale/en_US");

/***/ }),

/***/ 79353:
/***/ ((module) => {

module.exports = require("antd/lib/locale/zh_CN");

/***/ }),

/***/ 10274:
/***/ ((module) => {

module.exports = require("antd/lib/menu");

/***/ }),

/***/ 17369:
/***/ ((module) => {

module.exports = require("antd/lib/message");

/***/ }),

/***/ 76418:
/***/ ((module) => {

module.exports = require("antd/lib/modal");

/***/ }),

/***/ 76429:
/***/ ((module) => {

module.exports = require("antd/lib/progress");

/***/ }),

/***/ 27386:
/***/ ((module) => {

module.exports = require("antd/lib/radio");

/***/ }),

/***/ 32024:
/***/ ((module) => {

module.exports = require("antd/lib/switch");

/***/ }),

/***/ 86653:
/***/ ((module) => {

module.exports = require("antd/lib/theme");

/***/ }),

/***/ 69348:
/***/ ((module) => {

module.exports = require("antd/lib/tooltip");

/***/ }),

/***/ 59003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 68887:
/***/ ((module) => {

module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 7276:
/***/ ((module) => {

module.exports = require("html2canvas");

/***/ }),

/***/ 59591:
/***/ ((module) => {

module.exports = require("lodash/cloneDeep");

/***/ }),

/***/ 93908:
/***/ ((module) => {

module.exports = require("lodash/debounce");

/***/ }),

/***/ 1712:
/***/ ((module) => {

module.exports = require("lodash/get");

/***/ }),

/***/ 36211:
/***/ ((module) => {

module.exports = require("mobx");

/***/ }),

/***/ 22062:
/***/ ((module) => {

module.exports = require("mobx-react");

/***/ }),

/***/ 16641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 43076:
/***/ ((module) => {

module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 35132:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 18743:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 95832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 93431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1121:
/***/ ((module) => {

module.exports = require("qrcode");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 66405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 94612:
/***/ ((module) => {

module.exports = require("use-deep-compare-effect");

/***/ }),

/***/ 99648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 49766:
/***/ ((module) => {

module.exports = import("bignumber.js");;

/***/ }),

/***/ 22021:
/***/ ((module) => {

module.exports = import("i18next");;

/***/ }),

/***/ 57987:
/***/ ((module) => {

module.exports = import("react-i18next");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8355,5152,1163,5174,5622,5634,2451], () => (__webpack_exec__(50988)));
module.exports = __webpack_exports__;

})();
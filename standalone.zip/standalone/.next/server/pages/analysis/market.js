(() => {
var exports = {};
exports.id = 2831;
exports.ids = [2831];
exports.modules = {

/***/ 11529:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgCycle = function SvgCycle(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#000",
    fillRule: "nonzero",
    d: "m21.573 11.517 1.858 3.183a4.176 4.176 0 0 1-1.554 5.737 4.28 4.28 0 0 1-2.122.563h-2.501v3l-6.064-4.2 6.064-4.2v3h2.5c.32 0 .634-.083.91-.241a1.79 1.79 0 0 0 .666-2.459l-1.857-3.183 2.1-1.2ZM6.708 7.961l.644 7.296-2.626-1.5-1.25 2.143c-.16.274-.244.584-.244.9 0 .994.814 1.8 1.82 1.8h3.714V21H5.05C2.707 21 .807 19.12.807 16.8c0-.737.196-1.461.568-2.1l1.25-2.144L0 11.057l6.708-3.096ZM14.525.563a4.222 4.222 0 0 1 1.554 1.538l1.25 2.142 2.626-1.5-.644 7.297-6.708-3.096 2.625-1.501-1.25-2.142a1.83 1.83 0 0 0-3.15 0L8.97 6.484l-2.1-1.2L8.727 2.1C9.899.09 12.495-.596 14.525.563Z",
    opacity: 0.1
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgCycle);

/***/ }),

/***/ 99347:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgFilDown = function SvgFilDown(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 14 8"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#E15252",
    fillRule: "nonzero",
    d: "M12.327 8c.87 0 1.584-.704 1.665-1.604L14 6.225v-2.33c0-.326-.25-.591-.558-.591a.568.568 0 0 0-.548.485l-.01.107.002 2.27a.618.618 0 0 0-.114-.321l-.073-.085-3.32-3.348a1.862 1.862 0 0 0-2.487-.092l-.14.129-.817.836a.62.62 0 0 1-.728.118l-.098-.063L1.003.132a.62.62 0 0 0-.846.9l.081.077 4.106 3.21c.698.544 1.675.519 2.34-.04l.139-.127.817-.836a.62.62 0 0 1 .789-.082l.087.07 3.32 3.347a.618.618 0 0 0 .335.168l-2.063-.003c-.308 0-.558.265-.558.592 0 .29.197.532.457.582l.1.01h2.22Z"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgFilDown);

/***/ }),

/***/ 67890:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgFilUp = function SvgFilUp(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 14 8"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#40A291",
    fillRule: "nonzero",
    d: "M12.327 0c.87 0 1.584.704 1.665 1.604l.008.171v2.33c0 .326-.25.591-.558.591a.568.568 0 0 1-.548-.485l-.01-.107.002-2.27a.618.618 0 0 1-.114.321l-.073.085-3.32 3.348a1.862 1.862 0 0 1-2.487.092l-.14-.129-.817-.836a.62.62 0 0 0-.728-.118l-.098.063-4.106 3.208a.62.62 0 0 1-.846-.9l.081-.077 4.106-3.21a1.862 1.862 0 0 1 2.34.04l.139.127.817.836a.62.62 0 0 0 .789.082l.087-.07 3.32-3.347a.618.618 0 0 1 .335-.168l-2.063.003c-.308 0-.558-.265-.558-.592 0-.29.197-.532.457-.582l.1-.01h2.22Z"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgFilUp);

/***/ }),

/***/ 64806:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "loading_wrap__xYdnG"
};


/***/ }),

/***/ 32393:
/***/ ((module) => {

// Exports
module.exports = {
	"market": "market_market__GCoAu"
};


/***/ }),

/***/ 92368:
/***/ ((module) => {

// Exports
module.exports = {
	"release": "activeList_release__kNjqz",
	"release_title": "activeList_release_title__miW9Q",
	"release_title_text": "activeList_release_title_text__fvMFw"
};


/***/ }),

/***/ 5705:
/***/ ((module) => {

// Exports
module.exports = {
	"chart_content": "chart_chart_content__6xgGA",
	"chart_main": "chart_chart_main__X3Xf_",
	"chart_main_top": "chart_chart_main_top__61yg1",
	"chart_list": "chart_chart_list__7GsEb",
	"klineChart": "chart_klineChart__XBuK5",
	"klineChart_top": "chart_klineChart_top__VOYeN",
	"klineChart_top_left": "chart_klineChart_top_left__ulx_B",
	"klineChart_top_left_rate": "chart_klineChart_top_left_rate__ezmUH",
	"klineChart_top_left_rate_value": "chart_klineChart_top_left_rate_value__9K_Hr",
	"klineChart_top_left_title": "chart_klineChart_top_left_title__QWBZG",
	"klineChart_top_right": "chart_klineChart_top_right__CaTI9",
	"klineChart_top_right_ul": "chart_klineChart_top_right_ul__ehPLM",
	"klineChart_top_right_ul_active": "chart_klineChart_top_right_ul_active__ysc_z",
	"klineChart_content": "chart_klineChart_content__SJX7s",
	"trendChart": "chart_trendChart__Qhoj9",
	"trendChart_loading": "chart_trendChart_loading__ACZ67",
	"trendChart_legend": "chart_trendChart_legend__vTrzS",
	"trendChart_legend_li": "chart_trendChart_legend_li__7cLMi",
	"trendChart_left": "chart_trendChart_left__tIoSb",
	"trendChart_right": "chart_trendChart_right__cwwPk",
	"trendChart_right_item": "chart_trendChart_right_item__SkKJt",
	"trendChart_right_item_title": "chart_trendChart_right_item_title__hiqJO",
	"trendChart_right_item_value": "chart_trendChart_right_item_value__z_gA8",
	"trendChart_right_title": "chart_trendChart_right_title__MKkc_"
};


/***/ }),

/***/ 80101:
/***/ ((module) => {

// Exports
module.exports = {
	"liquidity": "liquidity_liquidity__aNuac",
	"liquidity_header": "liquidity_liquidity_header__m5d5K",
	"liquidity_title": "liquidity_liquidity_title__AOcLJ",
	"liquidity_title_text": "liquidity_liquidity_title_text__XJjve",
	"liquidity_top": "liquidity_liquidity_top___jjB0",
	"liquidity_top_label": "liquidity_liquidity_top_label__f5MCD",
	"liquidity_top_value": "liquidity_liquidity_top_value__H4Az9",
	"liquidity_top_value_text": "liquidity_liquidity_top_value_text__jUcuy",
	"liquidity_center": "liquidity_liquidity_center__uSaDP",
	"liquidity_content": "liquidity_liquidity_content__oS3b2",
	"liquidity_left": "liquidity_liquidity_left__ppAUm",
	"liquidity_left_main": "liquidity_liquidity_left_main__nWjks",
	"liquidity_left_item": "liquidity_liquidity_left_item__0Ftgz",
	"liquidity_left_item_title": "liquidity_liquidity_left_item_title__G5bYP",
	"liquidity_left_item_value": "liquidity_liquidity_left_item_value__QOIIC",
	"liquidity_left_item_mainValue": "liquidity_liquidity_left_item_mainValue__k9CAp",
	"liquidity_left_left": "liquidity_liquidity_left_left__KwKAJ",
	"liquidity_right": "liquidity_liquidity_right__Y7o4Z",
	"liquidity_right_content": "liquidity_liquidity_right_content__ltREC",
	"liquidity_right_left": "liquidity_liquidity_right_left___N3F1",
	"liquidity_right_item": "liquidity_liquidity_right_item__ocLku",
	"liquidity_right_item_title": "liquidity_liquidity_right_item_title__WHJAf",
	"liquidity_right_item_value": "liquidity_liquidity_right_item_value__dhcWC",
	"liquidity_change": "liquidity_liquidity_change__NU97n",
	"liquidity_chart": "liquidity_liquidity_chart__HSh8I",
	"liquidity_chart_tabs": "liquidity_liquidity_chart_tabs__K1D91",
	"liquidity_chart_legend": "liquidity_liquidity_chart_legend__7eLHn",
	"liquidity_chart_content": "liquidity_liquidity_chart_content__r5Y2d"
};


/***/ }),

/***/ 87864:
/***/ ((module) => {

// Exports
module.exports = {
	"market": "market_market__3jljj",
	"market_left": "market_market_left__3FEeT",
	"market_left_top": "market_market_left_top___rM25",
	"market_left_top_left": "market_market_left_top_left__sRb1h",
	"market_left_top_des": "market_market_left_top_des__muM6R",
	"market_left_top_rank": "market_market_left_top_rank__RH_61",
	"market_left_main": "market_market_left_main__AJu7o",
	"market_left_main_des": "market_market_left_main_des__h0_tH",
	"market_left_main_price": "market_market_left_main_price__Ksse0",
	"market_left_main_price_rmb": "market_market_left_main_price_rmb__qsBRi",
	"market_left_main_rate": "market_market_left_main_rate__cgjrY",
	"market_left_links": "market_market_left_links__7cfJv",
	"market_left_links_icon": "market_market_left_links_icon__hrpu0",
	"market_right": "market_market_right__laPDy",
	"market_right_tip": "market_market_right_tip__tFAoQ",
	"market_right_ul": "market_market_right_ul__A3hm2",
	"market_right_item": "market_market_right_item__orcLs",
	"market_right_item_title": "market_market_right_item_title__muEHp"
};


/***/ }),

/***/ 34588:
/***/ ((module) => {

// Exports
module.exports = {
	"release": "releaseList_release__4m08o",
	"release_title": "releaseList_release_title__YjX4_"
};


/***/ }),

/***/ 29475:
/***/ ((module) => {

// Exports
module.exports = {
	"token": "token_token__WWz4I",
	"token_head": "token_token_head__gPPu6",
	"token_title": "token_token_title__rImMQ",
	"token_title_text": "token_token_title_text__Jleqi",
	"token_header": "token_token_header__J5y9N",
	"token_header_item": "token_token_header_item__J5jwB",
	"token_header_item_pie": "token_token_header_item_pie__kiOyv",
	"token_header_right": "token_token_header_right__ar47K",
	"token_header_main": "token_token_header_main__aX2aX",
	"token_header_content": "token_token_header_content__g_2pY",
	"token_header_title": "token_token_header_title__6cL85",
	"token_header_value": "token_token_header_value__pLs9N",
	"token_chart": "token_token_chart__ptUSU",
	"token_chart_tabs": "token_token_chart_tabs__X9m5D",
	"token_chart_legend": "token_token_chart_legend__gto_L",
	"token_chart_content": "token_token_chart_content__H1n9K"
};


/***/ }),

/***/ 20291:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/f_logo.56dd643e.png","height":200,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA10lEQVR42iWPPUpDQRSFb0QQRcS/QsEFvOc6xNbODbgGGzcQJBrnaaUgWFgGG1HERl+6BEJIkypbSPpJ8Z3cm1wYhjtnznc4tpwHTtcS3f2KubWYbyf+7Z7CT4iU64mZ37Imuu6g9g8qn5j6XpiLdYjHFfnqHX0OkLXJhxXy9z/bTY69QxevqB6j/gRdviHHa89NtpXIQTh5RL8j9D1E5y+rDzthDkyIdkvu9NDZM7IWeTMREbX5UhxVTJtf6OYDRdzBKn9midJilpW8WlTccGw4Gy42ErYAOOCeJcwxvIgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 76104:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/freed.e62b5a99.png","height":84,"width":110,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAwUlEQVR42k2OK2tCcRxA/8U21laWXVhzze0DbHMs2Q2iKAYtPrgKvuEqPoIGkYtyk+Aj+0oGg4hiFD+GySB4fioaPPnAOWq+w5Lu8eOsoNsSbL4SHKwBjk9uSupKqstvxCQeNVhpBvKXQz415NWLvHgoKJ+BvzSgOl2COUIyJlijnD5CyLObvXI18LXH1IcLZLJEwk14j3GyBe9Cpocj2ELTO6wDNeQ/j9gfE7Mtlmyfb0cR3Z68TMY5vN0my0opdQYaSXkFgp+qhgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 5461:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/pledge.d1caf459.png","height":84,"width":110,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAw0lEQVR42h3Bu2rCUACA4T/piRcaaGmhRUu1U5Fu1ewKCuLmazg6KPgWOjm5Orno7Ca6OGXQRRHEK4kS8QZC9Ah+n1Lv3LS1Q7I7Ij5zSPshMt8grAtloCgWW1I1k7/sF/GAh//eEoJvcLYouJKrGNuE8jHCugfjRYdnL7IxQn76USdHcurQwTV+Cf4E0F51bt/vgARF4UEkQiybfUzVJbw/YQxs+NBQpjvwqlRFJkq71cc1V/isA08+ScTeIfZXKkDpDqmIQHWn8s7CAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 86757:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57182);
/* harmony import */ var private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13162);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44178);
/* harmony import */ var private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(92233);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/analysis/market",
        pathname: "/analysis/market",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_analysis_market_index_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 73337:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_images_loading_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48443);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ width, height })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
        src: _assets_images_loading_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
        width: width || 260,
        height: height || 260,
        alt: ""
    });
});


/***/ }),

/***/ 41493:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_images_loading_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48443);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(64806);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ width, height })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("main_contain !mt-12 flex items-center justify-center ", (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().wrap)),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
            src: _assets_images_loading_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
            width: width || 260,
            height: height || 260,
            alt: ""
        })
    });
});


/***/ }),

/***/ 92233:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _src_analysis_market__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(58193);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(32393);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _src_analysis_chart__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97662);
/* harmony import */ var _src_analysis_liquidity__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9912);
/* harmony import */ var _src_analysis_releaseList__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97070);
/* harmony import */ var _src_analysis_token__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(24428);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _store_modules_analysis__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(56854);
/* harmony import */ var _src_analysis_activeList__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57684);
/* harmony import */ var _components_loading__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(41493);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_analysis_market__WEBPACK_IMPORTED_MODULE_1__, _src_analysis_chart__WEBPACK_IMPORTED_MODULE_2__, _src_analysis_liquidity__WEBPACK_IMPORTED_MODULE_3__, _src_analysis_releaseList__WEBPACK_IMPORTED_MODULE_4__, _src_analysis_token__WEBPACK_IMPORTED_MODULE_5__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_7__, _src_analysis_activeList__WEBPACK_IMPORTED_MODULE_8__]);
([_src_analysis_market__WEBPACK_IMPORTED_MODULE_1__, _src_analysis_chart__WEBPACK_IMPORTED_MODULE_2__, _src_analysis_liquidity__WEBPACK_IMPORTED_MODULE_3__, _src_analysis_releaseList__WEBPACK_IMPORTED_MODULE_4__, _src_analysis_token__WEBPACK_IMPORTED_MODULE_5__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_7__, _src_analysis_activeList__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        load();
        _store_modules_analysis__WEBPACK_IMPORTED_MODULE_7__["default"].getNetWork();
        _store_modules_analysis__WEBPACK_IMPORTED_MODULE_7__["default"].getReleaseDate();
        _store_modules_analysis__WEBPACK_IMPORTED_MODULE_7__["default"].getTokens();
        _store_modules_analysis__WEBPACK_IMPORTED_MODULE_7__["default"].getActiveList();
    }, []);
    const load = async ()=>{
        await _store_modules_analysis__WEBPACK_IMPORTED_MODULE_7__["default"].getFilBase();
        setLoading(false);
    };
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loading__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
            width: 180
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `main_contain ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().market)}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_analysis_market__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_analysis_chart__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_analysis_liquidity__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_analysis_releaseList__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_analysis_token__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_analysis_activeList__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 57684:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _contents_analysis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45634);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(70430);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(92368);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _store_modules_analysis__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(56854);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(72305);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_analysis__WEBPACK_IMPORTED_MODULE_2__, _packages_Table__WEBPACK_IMPORTED_MODULE_3__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_6__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_analysis__WEBPACK_IMPORTED_MODULE_2__, _packages_Table__WEBPACK_IMPORTED_MODULE_3__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_5__.observer)(()=>{
    const { fileActiveList } = _store_modules_analysis__WEBPACK_IMPORTED_MODULE_6__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "analysis"
    });
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        return _contents_analysis__WEBPACK_IMPORTED_MODULE_2__/* .activeList */ .yN.map((v)=>{
            return {
                ...v,
                title: tr(v.title)
            };
        });
    }, [
        tr
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().release_title),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().release_title_text),
                        children: tr("top_active_address")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        context: tr("top_active_address_tip")
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().release),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    data: fileActiveList,
                    columns: columns,
                    loading: false
                })
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 86054:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _contents_analysis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45634);
/* harmony import */ var _store_modules_analysis__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(56854);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5705);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _trend__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(75033);
/* harmony import */ var _components_ComLoading__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(73337);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_analysis__WEBPACK_IMPORTED_MODULE_2__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_3__, _trend__WEBPACK_IMPORTED_MODULE_6__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_analysis__WEBPACK_IMPORTED_MODULE_2__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_3__, _trend__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_4__.observer)(()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "analysis"
    });
    const { filValueList } = _store_modules_analysis__WEBPACK_IMPORTED_MODULE_3__["default"];
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        _store_modules_analysis__WEBPACK_IMPORTED_MODULE_3__["default"].getFilValues();
        handleLoad();
    }, []);
    const handleLoad = async (value)=>{
        setLoading(true);
        const payload = {
            code: "filecoinnew",
            webp: 1,
            type: value || "all"
        };
        await _store_modules_analysis__WEBPACK_IMPORTED_MODULE_3__["default"].getFilTrend(payload);
        setLoading(false);
    };
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().trendChart),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().trendChart_loading),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ComLoading__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    width: 160
                })
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().trendChart),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().trendChart_left),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_trend__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().trendChart_right),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().trendChart_right_item)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().trendChart_right_title)}`,
                        children: tr("fil_title")
                    }),
                    _contents_analysis__WEBPACK_IMPORTED_MODULE_2__/* .fil_list */ .F1.map((v)=>{
                        const value = filValueList[v.dataIndex] && Number(filValueList[v.dataIndex]);
                        let newClassName = "";
                        let flag = "";
                        if (value !== 0) {
                            flag = value > 0 ? "+" : "";
                            newClassName = value > 0 ? "text_green" : "text_red";
                        }
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().trendChart_right_item),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().trendChart_right_item_title),
                                    onClick: ()=>{
                                        handleLoad(v.value);
                                    },
                                    children: tr(v.title)
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().trendChart_right_item_value)} ${newClassName}`,
                                    children: [
                                        flag,
                                        value,
                                        "%"
                                    ]
                                })
                            ]
                        }, v.dataIndex);
                    })
                ]
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 97662:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5705);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25622);
/* harmony import */ var _contents_analysis__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45634);
/* harmony import */ var _kLineChart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(29239);
/* harmony import */ var _TrendChart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(86054);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_packages_segmented__WEBPACK_IMPORTED_MODULE_2__, _contents_analysis__WEBPACK_IMPORTED_MODULE_3__, _kLineChart__WEBPACK_IMPORTED_MODULE_4__, _TrendChart__WEBPACK_IMPORTED_MODULE_5__]);
([_packages_segmented__WEBPACK_IMPORTED_MODULE_2__, _contents_analysis__WEBPACK_IMPORTED_MODULE_3__, _kLineChart__WEBPACK_IMPORTED_MODULE_4__, _TrendChart__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("k_chart");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().chart_content),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                data: _contents_analysis__WEBPACK_IMPORTED_MODULE_3__/* .tabList_chart */ ._Q,
                ns: "analysis",
                defaultValue: active,
                defaultActive: "growth",
                isHash: false,
                onChange: (value)=>{
                    setActive(value);
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().chart_list),
                children: [
                    active === "k_chart" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_kLineChart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                    active === "trend_chart" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TrendChart__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 29239:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5705);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _contents_analysis__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45634);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(25572);
/* harmony import */ var _packages_selects__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(60869);
/* harmony import */ var _store_modules_analysis__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(56854);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(23495);
/* harmony import */ var _assets_images_filUp_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(67890);
/* harmony import */ var _assets_images_filDown_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(99347);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_analysis__WEBPACK_IMPORTED_MODULE_5__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_analysis__WEBPACK_IMPORTED_MODULE_5__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const KLineChart = next_dynamic__WEBPACK_IMPORTED_MODULE_4___default()(null, {
    loadableGenerated: {
        modules: [
            "../src/analysis/chart/kLineChart.tsx -> " + "./kline"
        ]
    },
    ssr: false
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_2__.observer)(()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "analysis"
    });
    const { theme, lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_6__["default"];
    const { marketData } = _store_modules_analysis__WEBPACK_IMPORTED_MODULE_8__["default"];
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("5");
    const listOptions = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return _contents_analysis__WEBPACK_IMPORTED_MODULE_5__/* .kline_options */ .bW.map((v)=>{
            return {
                ...v,
                label: tr(v.title)
            };
        });
    }, [
        theme,
        tr
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        loadData();
    }, []);
    const loadData = (value, time, type)=>{
        const period = value || active;
        const payload = {
            tickerid: "binance_fil_usdt",
            period: Number(period),
            reach: time ? Number(time) : Math.floor(new Date().getTime() / 1000),
            utc: 0,
            webp: 1,
            since: "",
            refer: !!time,
            update: !!type
        };
        _store_modules_analysis__WEBPACK_IMPORTED_MODULE_8__["default"].getKline(payload);
    };
    const handleChange = (value)=>{
        setActive(value);
        loadData(value);
    //todo req
    };
    const renderRate = (value)=>{
        let className = "";
        if (Number(value) !== 0) {
            className = value > 0 ? "text_green" : "text_red";
        }
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
            className: `${className} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().klineChart_top_left_rate)}`,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().klineChart_top_left_rate_value),
                    children: [
                        "$",
                        (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatNumber */ .uf)(marketData.price, 2)
                    ]
                }),
                className && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: value > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_filUp_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_filDown_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    children: [
                        " ",
                        (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatNumber */ .uf)(value, 2),
                        "%"
                    ]
                })
            ]
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().klineChart)}`,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().klineChart_top),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().klineChart_top_left),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "FIL/USDT"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().klineChart_top_left_title),
                                children: tr("fil_origin")
                            }),
                            renderRate(marketData.price_change_rate)
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().klineChart_top_right),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                size: "small",
                                style: {
                                    width: 120
                                },
                                value: active,
                                options: listOptions,
                                onChange: handleChange,
                                bordered: false,
                                showSearch: false
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().klineChart_top_right_ul),
                                children: listOptions.map((v)=>{
                                    if (!v.select) {
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            onClick: ()=>{
                                                handleChange(v.value);
                                            },
                                            className: active === v.value ? (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().klineChart_top_right_ul_active) : "",
                                            children: v.label
                                        }, v.value);
                                    }
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().klineChart_content),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(KLineChart, {
                    active: active,
                    loadData: (active, time)=>{
                        loadData(active, time);
                    }
                })
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 75033:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62881);
/* harmony import */ var _contents_analysis__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45634);
/* harmony import */ var _store_modules_analysis__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(56854);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(25572);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7355);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(59591);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5705);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7947);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_analysis__WEBPACK_IMPORTED_MODULE_3__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_4__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_analysis__WEBPACK_IMPORTED_MODULE_3__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_8__.observer)(()=>{
    const { filTrend } = _store_modules_analysis__WEBPACK_IMPORTED_MODULE_4__["default"];
    const { theme } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_5__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "analysis"
    });
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({});
    const Colors = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        return {
            grid: [
                {
                    top: -1,
                    right: 0,
                    left: 0,
                    height: "60%",
                    border: Colors.splitLine
                },
                {
                    right: 0,
                    left: 0,
                    bottom: 0,
                    top: "60%",
                    height: 130,
                    border: Colors.splitLine
                }
            ],
            yAxis: [
                {
                    type: "value",
                    position: "right",
                    scale: true,
                    offset: -40,
                    nameTextStyle: {
                        color: Colors.textStyle
                    },
                    splitNumber: 3,
                    axisLabel: {
                        formatter: (value, index)=>{
                            if (Number(value) === 0 || index === 4) {
                                return "";
                            }
                            return "$" + value;
                        },
                        textStyle: {
                            color: Colors.labelColor
                        }
                    },
                    axisPointer: {
                        label: {
                            show: true,
                            backgroundColor: Colors.labelColor
                        }
                    },
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        show: true,
                        lineStyle: {
                            type: "dashed",
                            color: Colors.splitLine
                        }
                    }
                },
                {
                    type: "value",
                    position: "left",
                    scale: true,
                    axisPointer: {
                        label: {
                            show: false
                        }
                    },
                    nameTextStyle: {
                        color: Colors.textStyle
                    },
                    axisLabel: {
                        show: false,
                        textStyle: {
                            color: Colors.labelColor
                        }
                    },
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        show: false,
                        lineStyle: {
                            type: "dashed",
                            color: Colors.splitLine
                        }
                    }
                },
                {
                    type: "value",
                    position: "right",
                    scale: true,
                    offset: -50,
                    gridIndex: 1,
                    splitNumber: 2,
                    nameTextStyle: {
                        color: Colors.textStyle
                    },
                    axisLabel: {
                        formatter: (value, index)=>{
                            if (Number(value) === 0 || index === 3) {
                                return "";
                            }
                            return "$" + value + "亿";
                        },
                        textStyle: {
                            color: Colors.labelColor
                        }
                    },
                    axisPointer: {
                        label: {
                            show: true,
                            backgroundColor: Colors.labelColor
                        }
                    },
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        show: true,
                        lineStyle: {
                            type: "dashed",
                            color: Colors.splitLine
                        }
                    }
                }
            ],
            xAxis: [
                {
                    type: "category",
                    axisLabel: {
                        show: false
                    },
                    axisPointer: {
                        label: {
                            show: false
                        }
                    },
                    axisLine: {
                        show: false,
                        lineStyle: {
                            color: Colors.splitLine
                        }
                    },
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        show: true,
                        lineStyle: {
                            type: "dashed",
                            color: Colors.splitLine
                        }
                    },
                    data: []
                },
                {
                    type: "category",
                    axisLabel: {
                        color: Colors.labelColor
                    },
                    axisPointer: {
                        label: {
                            show: true,
                            backgroundColor: Colors.labelColor
                        }
                    },
                    gridIndex: 1,
                    axisLine: {
                        lineStyle: {
                            color: Colors.splitLine
                        }
                    },
                    lightStyle: {
                        color: Colors.lineStyle
                    },
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        show: true,
                        lineStyle: {
                            type: "dashed",
                            color: Colors.splitLine
                        }
                    },
                    data: []
                }
            ],
            tooltip: {
                show: true,
                trigger: "axis",
                axisPointer: {
                    type: "cross"
                }
            },
            axisPointer: {
                link: [
                    {
                        xAxisIndex: [
                            0,
                            1
                        ]
                    }
                ]
            },
            legend: {
                show: false
            },
            dataZoom: [
                {
                    type: "slider",
                    xAxisIndex: [
                        0,
                        1
                    ],
                    realtime: false,
                    start: 0,
                    end: 100,
                    bottom: 10,
                    height: 20,
                    handleIcon: "path://M10.7,11.9H9.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4h1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z",
                    handleSize: "120%"
                },
                {
                    type: "inside",
                    xAxisIndex: [
                        0,
                        1
                    ],
                    start: 40,
                    end: 70,
                    height: 20
                }
            ]
        };
    }, [
        Colors
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .get_xAxis */ .Fs)(theme, false);
    }, [
        theme
    ]);
    const options = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        const { categoryData } = filTrend;
        const series = [];
        _contents_analysis__WEBPACK_IMPORTED_MODULE_3__/* .fil_trend */ .xL.forEach((item)=>{
            if (!noShow[item?.name]) {
                series.push({
                    type: item.type,
                    data: filTrend[item.dataIndex],
                    key: item.dataIndex,
                    name: item.dataIndex,
                    symbol: "none",
                    smooth: true,
                    yAxisIndex: item.yIndex,
                    xAxisIndex: item.xIndex,
                    connectNulls: true,
                    itemStyle: {
                        color: item.color
                    },
                    lineStyle: {
                        width: 1
                    },
                    barMaxWidth: "30"
                });
            }
        });
        const newOptions = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_7___default()(defaultOptions);
        newOptions.xAxis.map((v)=>{
            v.data = categoryData || [];
            return v;
        });
        newOptions.series = series;
        return newOptions;
    }, [
        defaultOptions,
        filTrend,
        noShow,
        default_xAxis
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().trendChart_legend),
                children: _contents_analysis__WEBPACK_IMPORTED_MODULE_3__/* .fil_trend */ .xL.map((v)=>{
                    if (!noShow[v.name]) {}
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().trendChart_legend_li),
                        onClick: ()=>{
                            setNoShow({
                                ...noShow,
                                [v.name]: !noShow[v.name]
                            });
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                style: {
                                    color: noShow[v.name] ? "#d1d5db" : v.color
                                },
                                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_10__/* .getSvgIcon */ .a)(v.type === "bar" ? "barLegend" : "legendIcon")
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    " ",
                                    tr(v.title)
                                ]
                            })
                        ]
                    }, v.dataIndex);
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                options: {
                    ...options
                }
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 48399:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62881);
/* harmony import */ var _contents_analysis__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45634);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(25572);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7947);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(80101);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store_modules_analysis__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(56854);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_analysis__WEBPACK_IMPORTED_MODULE_3__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_9__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_analysis__WEBPACK_IMPORTED_MODULE_3__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_8__.observer)(()=>{
    const { theme } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_4__["default"];
    const { fileNetworkTrend } = _store_modules_analysis__WEBPACK_IMPORTED_MODULE_9__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "analysis"
    });
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const color = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .getColor */ .Lq)(theme);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .get_xAxis */ .Fs)(theme, false);
    }, [
        theme
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        let options = {
            grid: {
                top: 30,
                left: 80,
                right: 20,
                bottom: 20
            },
            yAxis: [
                {
                    type: "value",
                    position: "left",
                    scale: true,
                    nameTextStyle: {
                        color: color.textStyle
                    },
                    // splitNumber: 6,
                    axisLabel: {
                        formatter: "{value}",
                        textStyle: {
                            color: color.labelColor
                        }
                    },
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        show: true,
                        lineStyle: {
                            type: "dashed",
                            color: color.splitLine
                        }
                    }
                }
            ],
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.value + " FIL";
                        }
                    });
                    return result;
                }
            }
        };
        return options;
    }, [
        theme
    ]);
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        const seriesObj = fileNetworkTrend.seriesObj;
        const series = [];
        if (fileNetworkTrend.date && fileNetworkTrend.date.length > 0) {
            _contents_analysis__WEBPACK_IMPORTED_MODULE_3__/* .liquidity_chart */ .DO.forEach((item)=>{
                if (!noShow[item.dataIndex]) {
                    series.push({
                        type: "line",
                        data: seriesObj[item.dataIndex],
                        key: item.dataIndex,
                        name: item.title,
                        symbol: "circle",
                        smooth: true,
                        itemStyle: {
                            color: item.color
                        }
                    });
                }
            });
        }
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: fileNetworkTrend.date || []
            },
            series
        };
    }, [
        defaultOptions,
        fileNetworkTrend,
        noShow
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().liquidity_chart_legend),
                children: _contents_analysis__WEBPACK_IMPORTED_MODULE_3__/* .liquidity_chart */ .DO.map((v)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        onClick: ()=>{
                            setNoShow({
                                ...noShow,
                                [v.dataIndex]: !noShow[v.dataIndex]
                            });
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                style: {
                                    color: noShow[v.dataIndex] ? "#d1d5db" : v.color
                                },
                                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_5__/* .getSvgIcon */ .a)(v.type === "bar" ? "barLegend" : "legendIcon")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: tr(v.title)
                            })
                        ]
                    }, v.dataIndex);
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                options: newOptions
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9912:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(80101);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(72305);
/* harmony import */ var _assets_images_filUp_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(67890);
/* harmony import */ var _assets_images_filDown_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99347);
/* harmony import */ var _assets_images_freed_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(76104);
/* harmony import */ var _assets_images_pledge_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5461);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _contents_analysis__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(45634);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(23495);
/* harmony import */ var _assets_images_cycle_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(11529);
/* harmony import */ var _chart__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(48399);
/* harmony import */ var _assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(53309);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(25622);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _store_modules_analysis__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(56854);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_17__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_analysis__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__, _chart__WEBPACK_IMPORTED_MODULE_11__, _packages_segmented__WEBPACK_IMPORTED_MODULE_14__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_16__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_analysis__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__, _chart__WEBPACK_IMPORTED_MODULE_11__, _packages_segmented__WEBPACK_IMPORTED_MODULE_14__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_15__.observer)(()=>{
    const { fileNetwork } = _store_modules_analysis__WEBPACK_IMPORTED_MODULE_16__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "analysis"
    });
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)("30d");
    (0,react__WEBPACK_IMPORTED_MODULE_13__.useEffect)(()=>{
        load();
    }, []);
    const load = ()=>{
        _store_modules_analysis__WEBPACK_IMPORTED_MODULE_16__["default"].getNetWorkTrend(active);
    };
    const renderChange = (value)=>{
        let className = "";
        if (Number(value) !== 0) {
            className = value > 0 ? "text_green" : "text_red";
        }
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
            className: `${className} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_change)}`,
            children: [
                className && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: value > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_filUp_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_filDown_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                }),
                (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatNumber */ .uf)((0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatFil */ .Uk)(value), 2)
            ]
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_header),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_title),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_title_text),
                                children: tr("liquidity_watch")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                context: tr("liquidity_watch_tip")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_title),
                        children: [
                            tr("liquidity_watch_fil"),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_17___default()), {
                                href: `/statistics/charts/#fil_overview`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                    className: "cursor-pointer",
                                    width: 18,
                                    height: 18
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_top),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_top_label),
                                children: tr("liquidity_total_24")
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_top_value),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_top_value_text),
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatNumber */ .uf)((0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatFil */ .Uk)(fileNetwork["circulation"] || ""), 2)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: renderChange(fileNetwork[`circulation_24h`] || "")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_content),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_left),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                src: _assets_images_freed_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                                alt: "",
                                                width: 55,
                                                height: 42
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item)
                                            }),
                                            " ",
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item_value)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item_mainValue)}`,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatNumber */ .uf)((0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatFil */ .Uk)(fileNetwork["fil_produce"] || ""), 2)
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: renderChange(fileNetwork[`fil_produce_24h`] || "")
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item_title),
                                                children: tr("liquidity_freed_24")
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_main),
                                        children: _contents_analysis__WEBPACK_IMPORTED_MODULE_8__/* .liquidity */ .sO.left.map((item)=>{
                                            const { title, dataIndex, render, tip } = item;
                                            const value = fileNetwork[dataIndex] || "";
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item),
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item_value),
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatNumber */ .uf)((0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatFil */ .Uk)(value), 2)
                                                            }),
                                                            renderChange(fileNetwork[`${dataIndex}_24h`])
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item_title),
                                                        children: [
                                                            tr(title),
                                                            tip && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                context: tr(tip)
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }, title);
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_center),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_cycle_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    width: 30,
                                    height: 30
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_right)}`,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_right_content)}`,
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_right_left),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                        src: _assets_images_pledge_png__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                                                        alt: "",
                                                        width: 55,
                                                        height: 42
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item)
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item_value)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item_mainValue)}`,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatNumber */ .uf)((0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatFil */ .Uk)(fileNetwork["locked"]), 2)
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: renderChange(fileNetwork[`locked_24h`])
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item_title),
                                                        children: tr("liquidity_pledge_24")
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_main),
                                                children: _contents_analysis__WEBPACK_IMPORTED_MODULE_8__/* .liquidity */ .sO.right.map((item)=>{
                                                    const { title, dataIndex, render, tip } = item;
                                                    const value = fileNetwork[dataIndex];
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item),
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item_value),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatNumber */ .uf)((0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatFil */ .Uk)(value), 2)
                                                                    }),
                                                                    renderChange(fileNetwork[`${dataIndex}_24h`])
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_left_item_title),
                                                                children: [
                                                                    tr(title),
                                                                    tip && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                        context: tr(tip)
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }, title);
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_right_item)}`,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_right_item_title)}`,
                                                children: tr("liquidity_destruction_24")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_right_item_value)}`,
                                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatNumber */ .uf)((0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatFil */ .Uk)(fileNetwork["burn"]), 2)
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: renderChange(fileNetwork["burn_24h"])
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_chart),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_chart_tabs),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                    data: _contents_analysis__WEBPACK_IMPORTED_MODULE_8__/* .time_options */ .AX,
                                    ns: "analysis",
                                    defaultValue: active,
                                    isHash: false,
                                    onChange: (value)=>{
                                        setActive(value);
                                    }
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_18___default().liquidity_chart_content),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chart__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                            })
                        ]
                    })
                ]
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 58193:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(87864);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _contents_analysis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45634);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_modules_analysis__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(56854);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(72305);
/* harmony import */ var _assets_images_f_logo_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(20291);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23495);
/* harmony import */ var _assets_images_filUp_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(67890);
/* harmony import */ var _assets_images_filDown_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(99347);
/* harmony import */ var _assets_images_twitter_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(52117);
/* harmony import */ var _assets_images_network_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4183);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7947);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_analysis__WEBPACK_IMPORTED_MODULE_2__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_analysis__WEBPACK_IMPORTED_MODULE_2__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_3__.observer)(()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "analysis"
    });
    const { marketData } = _store_modules_analysis__WEBPACK_IMPORTED_MODULE_4__["default"];
    const renderRate = (value)=>{
        let className = "";
        if (Number(value) !== 0) {
            className = value > 0 ? "text_green" : "text_red";
        }
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
            className: `${className} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_left_main_rate)}`,
            children: [
                className && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: value > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_filUp_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_filDown_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                }),
                (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .formatNumber */ .uf)(value, 2),
                "%"
            ]
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market)}`,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_left),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_left_top),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_left_top_left),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        src: _assets_images_f_logo_png__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                                        alt: "",
                                        height: 30
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "FIL"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_left_top_des),
                                        children: "filecoin"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_left_top_rank),
                                children: [
                                    "NO.",
                                    marketData.rank
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_left_main),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_left_main_price),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .formatNumber */ .uf)(marketData?.price)
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_left_main_price_rmb),
                                                children: `≈  ¥${(0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .formatNumber */ .uf)(marketData.rmb_price, 2)}`
                                            })
                                        ]
                                    }),
                                    renderRate(marketData.price_change_rate)
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_left_main_des),
                                children: tr("price_origin")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_left_links),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_left_links_icon),
                                onClick: ()=>{
                                    window.open("https://twitter.com/Filecoin");
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_twitter_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_left_links_icon),
                                onClick: ()=>{
                                    window.open("https://filecoin.io/");
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_network_svg__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_right),
                children: [
                    _contents_analysis__WEBPACK_IMPORTED_MODULE_2__/* .overviewList */ .q2.map((itemList, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_right_ul)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default())[`market_right_${index}`]}`,
                            children: itemList.map((item)=>{
                                const { title, render, dataIndex, tip } = item;
                                let value = render ? render(marketData[dataIndex], marketData) : marketData[dataIndex];
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_right_item),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_right_item_title),
                                            children: [
                                                tr(title),
                                                " ",
                                                tip && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                    context: tr(tip)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: value
                                        })
                                    ]
                                }, item.dataIndex);
                            })
                        }, index);
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().market_right_tip),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "cursor-pointer",
                                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_13__/* .getSvgIcon */ .a)("tip")
                            }),
                            tr("market_tip")
                        ]
                    })
                ]
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 97070:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _contents_analysis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45634);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(70430);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(34588);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _store_modules_analysis__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(56854);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23495);
/* harmony import */ var _components_trendModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9035);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_analysis__WEBPACK_IMPORTED_MODULE_2__, _packages_Table__WEBPACK_IMPORTED_MODULE_3__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_6__, _utils__WEBPACK_IMPORTED_MODULE_7__, _components_trendModal__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_analysis__WEBPACK_IMPORTED_MODULE_2__, _packages_Table__WEBPACK_IMPORTED_MODULE_3__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_6__, _utils__WEBPACK_IMPORTED_MODULE_7__, _components_trendModal__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_5__.observer)(()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "analysis"
    });
    const { releaseData } = _store_modules_analysis__WEBPACK_IMPORTED_MODULE_6__["default"];
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        return (0,_contents_analysis__WEBPACK_IMPORTED_MODULE_2__/* .releaseList */ .Vj)(tr).map((v)=>{
            const obj = {
                ...v
            };
            if (v.title === "balance_change_7") {
                obj.render = (text, record)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex items-center gap-x-1",
                        children: [
                            (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatNumber */ .uf)(Number(text), 0),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_trendModal__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                account: record.account_id
                            })
                        ]
                    });
                };
            }
            return {
                ...obj,
                title: tr(v.title)
            };
        });
    }, [
        tr
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().release_title),
                children: tr("release_Calendar")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().release),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    data: [
                        ...releaseData
                    ],
                    total: releaseData.length,
                    limit: 5,
                    columns: columns,
                    loading: false
                })
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 64722:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62881);
/* harmony import */ var _contents_analysis__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45634);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(25572);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7947);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(29475);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store_modules_analysis__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(56854);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_analysis__WEBPACK_IMPORTED_MODULE_3__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_9__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_analysis__WEBPACK_IMPORTED_MODULE_3__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_8__.observer)(()=>{
    const { theme } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_4__["default"];
    const { fileTokensTrend } = _store_modules_analysis__WEBPACK_IMPORTED_MODULE_9__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "analysis"
    });
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const color = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .getColor */ .Lq)(theme);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .get_xAxis */ .Fs)(theme, false);
    }, [
        theme
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        let options = {
            grid: {
                top: 30,
                left: 30,
                right: 20,
                bottom: 20
            },
            yAxis: [
                {
                    type: "value",
                    position: "left",
                    scale: true,
                    nameTextStyle: {
                        color: color.textStyle
                    },
                    // splitNumber: 6,
                    axisLabel: {
                        formatter: "{value}",
                        textStyle: {
                            color: color.labelColor
                        }
                    },
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        show: true,
                        lineStyle: {
                            type: "dashed",
                            color: color.splitLine
                        }
                    }
                }
            ],
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.value + "%" + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
        return options;
    }, [
        theme
    ]);
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        const seriesObj = fileTokensTrend.seriesObj;
        const series = [];
        if (fileTokensTrend.date && fileTokensTrend.date.length > 0) {
            _contents_analysis__WEBPACK_IMPORTED_MODULE_3__/* .token_list */ .FG.forEach((item)=>{
                if (!noShow[item.dataIndex]) {
                    series.push({
                        type: "line",
                        data: seriesObj[item.dataIndex],
                        key: item.dataIndex,
                        name: item.title,
                        symbol: "circle",
                        smooth: true,
                        itemStyle: {
                            color: item.color
                        }
                    });
                }
            });
        }
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: fileTokensTrend.date || []
            },
            series
        };
    }, [
        defaultOptions,
        fileTokensTrend,
        noShow
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().token_chart_legend),
                children: _contents_analysis__WEBPACK_IMPORTED_MODULE_3__/* .token_list */ .FG.map((v)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        onClick: ()=>{
                            setNoShow({
                                ...noShow,
                                [v.dataIndex]: !noShow[v.dataIndex]
                            });
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                style: {
                                    color: noShow[v.dataIndex] ? "#d1d5db" : v.color
                                },
                                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_5__/* .getSvgIcon */ .a)("legendIcon")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: tr(v.title)
                            })
                        ]
                    }, v.dataIndex);
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                options: newOptions
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 24428:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(29475);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(23495);
/* harmony import */ var _contents_analysis__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45634);
/* harmony import */ var _pieChart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(76053);
/* harmony import */ var _chart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(64722);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(25622);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_modules_analysis__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(56854);
/* harmony import */ var _assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(53309);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(72305);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_2__, _contents_analysis__WEBPACK_IMPORTED_MODULE_3__, _chart__WEBPACK_IMPORTED_MODULE_5__, _packages_segmented__WEBPACK_IMPORTED_MODULE_6__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_2__, _contents_analysis__WEBPACK_IMPORTED_MODULE_3__, _chart__WEBPACK_IMPORTED_MODULE_5__, _packages_segmented__WEBPACK_IMPORTED_MODULE_6__, _store_modules_analysis__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_10__.observer)(()=>{
    const { fileTokens } = _store_modules_analysis__WEBPACK_IMPORTED_MODULE_8__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "analysis"
    });
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("30d");
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        loadTrend();
    }, []);
    const loadTrend = (interval)=>{
        const inter = interval || active;
        _store_modules_analysis__WEBPACK_IMPORTED_MODULE_8__["default"].getTokensTrend(inter);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_head),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_title),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_title_text),
                                children: tr("token_list")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                context: tr("token_list_tip")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_title),
                        children: [
                            tr("token_list_address"),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_11___default()), {
                                href: `/tipset/address-list/`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    className: "cursor-pointer",
                                    width: 18,
                                    height: 18
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_header),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_header_main)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_header_content)}`,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_header_title),
                                        children: tr("token_address_total")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_header_value),
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(fileTokens?.addrcount || "")
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_header_right),
                                children: _contents_analysis__WEBPACK_IMPORTED_MODULE_3__/* .token_list */ .FG.map((v)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_header_item),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_header_content),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_header_title),
                                                        children: tr(v.title)
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_header_value),
                                                        children: [
                                                            fileTokens[v.dataIndex],
                                                            "%"
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_header_item_pie),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pieChart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                    value: fileTokens[v.dataIndex]
                                                })
                                            })
                                        ]
                                    }, v.dataIndex);
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_chart),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_chart_tabs),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    data: _contents_analysis__WEBPACK_IMPORTED_MODULE_3__/* .time_options */ .AX,
                                    ns: "analysis",
                                    defaultValue: active,
                                    isHash: false,
                                    onChange: (value)=>{
                                        setActive(value);
                                        loadTrend(value);
                                    }
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().token_chart_content),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chart__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                            })
                        ]
                    })
                ]
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 76053:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13778);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { value } = props;
    const option = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return {
            //       tooltip: {
            //         trigger: 'item',
            //       },
            //       legend: {
            //         top: '5%',
            //         left: 'center',
            //       },
            series: [
                {
                    animation: true,
                    name: "Access From",
                    type: "pie",
                    radius: [
                        "40%",
                        "70%"
                    ],
                    avoidLabelOverlap: false,
                    label: {
                        show: false,
                        position: "center"
                    },
                    emphasis: {
                        label: {
                            show: true,
                            fontSize: 40,
                            fontWeight: "bold"
                        }
                    },
                    labelLine: {
                        show: false
                    },
                    data: [
                        {
                            value: value,
                            name: "",
                            itemStyle: {
                                color: "rgba(28, 106, 253, 1)"
                            }
                        },
                        {
                            value: Number(100 - Number(value)),
                            name: "",
                            itemStyle: {
                                color: "rgba(176, 203, 254, 1)"
                            }
                        }
                    ]
                }
            ]
        };
    }, [
        value
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        options: option
    });
});


/***/ }),

/***/ 52727:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ 77529:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LoadingOutlined");

/***/ }),

/***/ 53800:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/button");

/***/ }),

/***/ 92616:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 1788:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/dropdown");

/***/ }),

/***/ 30675:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input");

/***/ }),

/***/ 4946:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/en_US");

/***/ }),

/***/ 79353:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/zh_CN");

/***/ }),

/***/ 10274:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/menu");

/***/ }),

/***/ 17369:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/message");

/***/ }),

/***/ 76418:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/modal");

/***/ }),

/***/ 14528:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/pagination");

/***/ }),

/***/ 76429:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/progress");

/***/ }),

/***/ 53526:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/select");

/***/ }),

/***/ 71030:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/skeleton");

/***/ }),

/***/ 32024:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/switch");

/***/ }),

/***/ 74285:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/table");

/***/ }),

/***/ 86653:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/theme");

/***/ }),

/***/ 69348:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/tooltip");

/***/ }),

/***/ 59003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 68887:
/***/ ((module) => {

"use strict";
module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 29201:
/***/ ((module) => {

"use strict";
module.exports = require("echarts");

/***/ }),

/***/ 7276:
/***/ ((module) => {

"use strict";
module.exports = require("html2canvas");

/***/ }),

/***/ 59591:
/***/ ((module) => {

"use strict";
module.exports = require("lodash/cloneDeep");

/***/ }),

/***/ 93908:
/***/ ((module) => {

"use strict";
module.exports = require("lodash/debounce");

/***/ }),

/***/ 1712:
/***/ ((module) => {

"use strict";
module.exports = require("lodash/get");

/***/ }),

/***/ 36211:
/***/ ((module) => {

"use strict";
module.exports = require("mobx");

/***/ }),

/***/ 22062:
/***/ ((module) => {

"use strict";
module.exports = require("mobx-react");

/***/ }),

/***/ 16641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 43076:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 35132:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 18743:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 95832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 93431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 71853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 1121:
/***/ ((module) => {

"use strict";
module.exports = require("qrcode");

/***/ }),

/***/ 16689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 66405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 94612:
/***/ ((module) => {

"use strict";
module.exports = require("use-deep-compare-effect");

/***/ }),

/***/ 99648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 49766:
/***/ ((module) => {

"use strict";
module.exports = import("bignumber.js");;

/***/ }),

/***/ 22021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 57987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8355,5152,1163,5174,4928,430,5622,8817,3469,6735,869,9035,3309,5492,5634], () => (__webpack_exec__(86757)));
module.exports = __webpack_exports__;

})();
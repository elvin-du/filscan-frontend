(() => {
var exports = {};
exports.id = 9915;
exports.ids = [9915];
exports.modules = {

/***/ 64806:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "loading_wrap__xYdnG"
};


/***/ }),

/***/ 50985:
/***/ ((module) => {

// Exports
module.exports = {
	"address": "address_address__DMdbc",
	"content": "address_content__mESNv",
	"address-row": "address_address-row__aoe9d",
	"label": "address_label__vBTbw",
	"text": "address_text__1T07U"
};


/***/ }),

/***/ 68371:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57182);
/* harmony import */ var private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13162);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44178);
/* harmony import */ var private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1028);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/address/[address]",
        pathname: "/address/[address]",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_address_address_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 41493:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_images_loading_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48443);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(64806);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ width, height })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("main_contain !mt-12 flex items-center justify-center ", (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().wrap)),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
            src: _assets_images_loading_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
            width: width || 260,
            height: height || 260,
            alt: ""
        })
    });
});


/***/ }),

/***/ 1028:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(25174);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62881);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8054);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(29745);
/* harmony import */ var _packages_content__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(55586);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(25622);
/* harmony import */ var _src_detail_accountChange__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16735);
/* harmony import */ var _src_detail_list__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(31830);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(68108);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(50985);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(29676);
/* harmony import */ var _assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(45903);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(23495);
/* harmony import */ var _packages_image__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(92964);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(7947);
/* harmony import */ var _components_loading__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(41493);
/* harmony import */ var _src_detail_list_PendingMsg__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(70606);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_4__, _packages_content__WEBPACK_IMPORTED_MODULE_5__, _packages_segmented__WEBPACK_IMPORTED_MODULE_6__, _src_detail_accountChange__WEBPACK_IMPORTED_MODULE_7__, _src_detail_list__WEBPACK_IMPORTED_MODULE_8__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__, _utils__WEBPACK_IMPORTED_MODULE_15__, _src_detail_list_PendingMsg__WEBPACK_IMPORTED_MODULE_20__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_4__, _packages_content__WEBPACK_IMPORTED_MODULE_5__, _packages_segmented__WEBPACK_IMPORTED_MODULE_6__, _src_detail_accountChange__WEBPACK_IMPORTED_MODULE_7__, _src_detail_list__WEBPACK_IMPORTED_MODULE_8__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__, _utils__WEBPACK_IMPORTED_MODULE_15__, _src_detail_list_PendingMsg__WEBPACK_IMPORTED_MODULE_20__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 





















/** @format */ /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const { address } = router.query;
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "detail"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)({});
    const [tokenList, setTokenList] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)([]);
    const [verifyData, setVerifyData] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)({});
    const [accountType, setAccountType] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)("");
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)("1m");
    const [methodOptions, setMethodOptions] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)([]);
    const [transOptions, setTransOptions] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)([]);
    const [tokenOptions, setTokenOptions] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)([]);
    const [pendingData, setPendingData] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)({});
    const [actorId, setActorId] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)("");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(false);
    const [domains, setDomains] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)({});
    (0,react__WEBPACK_IMPORTED_MODULE_11__.useEffect)(()=>{
        setActorId("");
        setMethodOptions([]);
        setInterval("1m");
        setAccountType("");
        if (address) {
            loadMethod();
            load();
            loadFnsDomain(address);
        }
    }, [
        address
    ]);
    const loadMethod = async ()=>{
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl */ .JW.detail_list_method, {
            account_id: address
        }, {
            isCancel: false
        });
        const newMethod = [
            {
                label: "all",
                value: "all"
            }
        ];
        Object.keys(result?.method_name_list || {}).forEach((li)=>{
            newMethod.push({
                label: li,
                dataIndex: li,
                value: li
            });
        });
        setMethodOptions(newMethod);
        const result1 = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .TransMethod */ .a1, {
            account_id: address
        }, {
            isCancel: false
        });
        const newTransMethod = [
            {
                label: "all",
                value: "all"
            }
        ];
        (result1?.method_name_list || [])?.forEach((li)=>{
            newTransMethod.push({
                label: li,
                dataIndex: li,
                value: li
            });
        });
        setTransOptions(newTransMethod);
        const result2 = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .tokenName */ .vA, {
            address
        }, {
            isCancel: false
        });
        const newTokenMethod = [
            {
                label: "all_token",
                value: "all"
            }
        ];
        (result2?.token_names || [])?.forEach((li)=>{
            newTokenMethod.push({
                label: li,
                dataIndex: li,
                value: li
            });
        });
        setTokenOptions(newTokenMethod);
    };
    const load = async ()=>{
        setLoading(true);
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl */ .JW.detail_account, {
            account_id: address
        }, {
            isCancel: false
        });
        setLoading(false);
        let baseResult = {};
        const mainType = result?.account_type || "";
        if (result?.account_info[`account_${mainType}`]) {
            baseResult = result?.account_info[`account_${mainType}`];
        } else {
            baseResult = result?.account_info;
        }
        setData(baseResult);
        setAccountType(result?.account_type || "");
        if (result?.account_info?.account_basic?.account_id) {
            setActorId(result.account_info.account_basic.account_id);
        }
        if (baseResult?.account_basic?.account_id) {
            // 已被验证合约
            loadVerify(baseResult?.account_basic?.account_id);
        }
        if (typeof address === "string") {
            // 增加代币列表
            let showErc20 = "";
            if (address.startsWith("0x")) {
                showErc20 = address;
            } else if (baseResult?.account_basic?.eth_address?.startsWith("0x")) {
                showErc20 = baseResult?.account_basic?.eth_address;
            } else {
                showErc20 = baseResult?.account_basic?.account_id;
            }
            loadERC20TokenList(showErc20);
        }
    };
    //合约
    const loadVerify = async (id)=>{
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl */ .JW.contract_verify_des, {
            input_address: id
        }, {
            isCancel: false
        });
        setVerifyData({
            ...result
        });
    };
    const loadERC20TokenList = async (id)=>{
        const tokenList = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl */ .JW.contract_ERC20TokenList, {
            address: id
        });
        const items = [];
        if (tokenList && Object.keys(tokenList).length > 0 && tokenList?.items?.length > 0) {
            const objTotal = {
                title: `$${(0,_utils__WEBPACK_IMPORTED_MODULE_15__/* .formatNumber */ .uf)(tokenList?.total_value, 4)} (${tokenList?.total} Tokens)`,
                value: `$${tokenList?.total_value} (${tokenList?.total})`
            };
            tokenList?.items?.forEach((t)=>{
                if (t.amount) {
                    const obj = {
                        ...t,
                        key: t.contract_id,
                        value: t.contract_id,
                        title: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mt-2.5 flex w-full cursor-pointer justify-between gap-x-2",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center gap-x-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                            src: t.icon_url,
                                            alt: "",
                                            width: 36,
                                            height: 36
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "flex flex-col items-start",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: t.token_name
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    children: [
                                                        " ",
                                                        (0,_utils__WEBPACK_IMPORTED_MODULE_15__/* .formatNumber */ .uf)(t.amount, 4),
                                                        " "
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_15__/* .get$Number */ .Uy)(t.value, 4)
                                })
                            ]
                        })
                    };
                    items.push(obj);
                }
            });
            setTokenList([
                objTotal,
                ...items
            ]);
        }
    };
    const loadFnsDomain = async (addr)=>{
        const result = await axiosData(`${_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl */ .JW.contract_fnsUrl}`, {
            addresses: [
                addr
            ]
        }, {
            isCancel: false
        });
        setDomains(result);
    };
    const contentList = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(()=>{
        return _contents_detail__WEBPACK_IMPORTED_MODULE_4__/* .address_detail */ .Tt.content(accountType);
    }, [
        accountType
    ]);
    const tabsList = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(()=>{
        let defaultOpt = [];
        _contents_detail__WEBPACK_IMPORTED_MODULE_4__/* .address_tabs */ .gm.forEach((v)=>{
            if (v?.optionsUrl === "AllMethodByAccountID") {
                v.headerOptions = methodOptions;
            }
            if (v?.optionsUrl === "TransferMethodByAccountID") {
                v.headerOptions = transOptions;
            }
            if (v?.optionsUrl === "ERC20AddrTransfersTokenTypes") {
                v.headerOptions = tokenOptions;
            }
            defaultOpt.push({
                ...v
            });
        });
        let evmList = [];
        if (verifyData && verifyData.source_file) {
            evmList = [
                {
                    title: verifyData?.compiled_file && Object.keys(verifyData?.compiled_file || {}).length > 0 ? ()=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex items-center gap-x-2",
                            children: [
                                (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_18__/* .getSvgIcon */ .a)("successIcon"),
                                tr("contract_verify")
                            ]
                        });
                    } : tr("contract_verify"),
                    dataIndex: "contract_verify"
                },
                {
                    title: "event_log",
                    dataIndex: "event_log"
                }
            ];
        }
        return [
            ...defaultOpt,
            ...evmList
        ];
    }, [
        methodOptions,
        transOptions,
        tokenOptions,
        verifyData
    ]);
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loading__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {});
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_12___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_21___default().address), "main_contain"),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_12___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_21___default()["address-row"]), "HarmonyOS_Medium mb-2.5 ml-2.5 flex items-center text-lg font-medium"),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_21___default().label),
                        children: [
                            tr("account_title"),
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_13__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "copy-row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "normal-text",
                                    children: address
                                }),
                                address && typeof address === "string" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    text: address,
                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {}),
                                    className: "copy-lg"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_13__/* .BrowserView */ .I, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_12___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_21___default().text), "ml-4 flex items-center gap-x-1"),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: address || ""
                                    }),
                                    address && typeof address === "string" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        text: address
                                    })
                                ]
                            }),
                            typeof address === "string" && domains?.domains && domains?.domains[address] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_17___default()), {
                                className: "ml-2",
                                href: `/domain/${domains?.domains[address]}?provider=${domains.provider}`,
                                children: [
                                    "(",
                                    domains?.domains[address],
                                    ")"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_12___default()("card_shadow border_color flex items-center rounded-xl border p-7", (_index_module_scss__WEBPACK_IMPORTED_MODULE_21___default().content)),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_13__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_content__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            contents: contentList,
                            ns: "detail",
                            columns: 2,
                            data: {
                                ...data,
                                tokenList
                            }
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_13__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_content__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            contents: contentList,
                            ns: "detail",
                            columns: 1,
                            data: {
                                ...data,
                                tokenList
                            }
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_detail_accountChange__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                header: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mx-2.5 mb-2.5 mt-5 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "HarmonyOS_Medium text-lg  font-medium",
                            children: tr("account_change")
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            data: _contents_detail__WEBPACK_IMPORTED_MODULE_4__/* .address_detail */ .Tt.account_change.tabsList || [],
                            ns: "detail",
                            defaultValue: interval,
                            isHash: false,
                            onChange: (value)=>{
                                setInterval(value);
                            }
                        })
                    ]
                }, "detail_account_change"),
                accountId: address,
                interval: interval,
                list: _contents_detail__WEBPACK_IMPORTED_MODULE_4__/* .address_detail */ .Tt.account_change.list
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_detail_list_PendingMsg__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                account_id: data?.account_basic?.account_id,
                account_address: data?.account_basic?.account_address
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_detail_list__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                tabList: tabsList,
                defaultActive: "traces_list",
                accountId: address,
                actorId: actorId,
                verifyData: verifyData
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 52727:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ 77529:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LoadingOutlined");

/***/ }),

/***/ 53800:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/button");

/***/ }),

/***/ 92616:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 1788:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/dropdown");

/***/ }),

/***/ 30675:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input");

/***/ }),

/***/ 4946:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/en_US");

/***/ }),

/***/ 79353:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/zh_CN");

/***/ }),

/***/ 10274:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/menu");

/***/ }),

/***/ 17369:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/message");

/***/ }),

/***/ 76418:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/modal");

/***/ }),

/***/ 14528:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/pagination");

/***/ }),

/***/ 53526:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/select");

/***/ }),

/***/ 71030:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/skeleton");

/***/ }),

/***/ 32024:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/switch");

/***/ }),

/***/ 74285:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/table");

/***/ }),

/***/ 86653:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/theme");

/***/ }),

/***/ 69348:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/tooltip");

/***/ }),

/***/ 59003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 68887:
/***/ ((module) => {

"use strict";
module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 29201:
/***/ ((module) => {

"use strict";
module.exports = require("echarts");

/***/ }),

/***/ 7276:
/***/ ((module) => {

"use strict";
module.exports = require("html2canvas");

/***/ }),

/***/ 59591:
/***/ ((module) => {

"use strict";
module.exports = require("lodash/cloneDeep");

/***/ }),

/***/ 93908:
/***/ ((module) => {

"use strict";
module.exports = require("lodash/debounce");

/***/ }),

/***/ 1712:
/***/ ((module) => {

"use strict";
module.exports = require("lodash/get");

/***/ }),

/***/ 36211:
/***/ ((module) => {

"use strict";
module.exports = require("mobx");

/***/ }),

/***/ 22062:
/***/ ((module) => {

"use strict";
module.exports = require("mobx-react");

/***/ }),

/***/ 45944:
/***/ ((module) => {

"use strict";
module.exports = require("mobx-react-lite");

/***/ }),

/***/ 16641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 43076:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 35132:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 18743:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 95832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 93431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 71853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 1121:
/***/ ((module) => {

"use strict";
module.exports = require("qrcode");

/***/ }),

/***/ 16689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 66405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 94612:
/***/ ((module) => {

"use strict";
module.exports = require("use-deep-compare-effect");

/***/ }),

/***/ 99648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 49766:
/***/ ((module) => {

"use strict";
module.exports = import("bignumber.js");;

/***/ }),

/***/ 22021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 57987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ }),

/***/ 34325:
/***/ ((module) => {

"use strict";
module.exports = import("web3");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8355,5152,1163,5174,4928,430,5622,8817,3469,8087,5509,5586,6735,1921,869,162], () => (__webpack_exec__(68371)));
module.exports = __webpack_exports__;

})();
"use strict";
(() => {
var exports = {};
exports.id = 1065;
exports.ids = [1065];
exports.modules = {

/***/ 4209:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57182);
/* harmony import */ var private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13162);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44178);
/* harmony import */ var private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(74563);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/statistics/charts/index1",
        pathname: "/statistics/charts/index1",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_statistics_charts_index1_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 74563:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(38087);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(24852);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7947);
/* harmony import */ var _src_statistics_Trend__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(71538);
/* harmony import */ var _src_statistics_BlockRewardTrend__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(658);
/* harmony import */ var _src_statistics_BlockRewardPer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(68297);
/* harmony import */ var _src_statistics_ActiveNodeTrend__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(60883);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _src_statistics_FilChart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(41340);
/* harmony import */ var _src_statistics_Charts__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(67320);
/* harmony import */ var _src_statistics_DCCTrend__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(27927);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(29676);
/* harmony import */ var _src_statistics_Meta__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1004);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(92976);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _src_statistics_ContractTrend__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(64313);
/* harmony import */ var _src_statistics_contractGas__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(52832);
/* harmony import */ var _src_statistics_contractAddr__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(10860);
/* harmony import */ var _src_statistics_contractCon__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(77995);
/* harmony import */ var _src_statistics_ContractBanlace__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(53950);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_statistic__WEBPACK_IMPORTED_MODULE_3__, _src_statistics_Trend__WEBPACK_IMPORTED_MODULE_5__, _src_statistics_BlockRewardTrend__WEBPACK_IMPORTED_MODULE_6__, _src_statistics_BlockRewardPer__WEBPACK_IMPORTED_MODULE_7__, _src_statistics_ActiveNodeTrend__WEBPACK_IMPORTED_MODULE_8__, _src_statistics_FilChart__WEBPACK_IMPORTED_MODULE_10__, _src_statistics_Charts__WEBPACK_IMPORTED_MODULE_11__, _src_statistics_DCCTrend__WEBPACK_IMPORTED_MODULE_12__, _src_statistics_Meta__WEBPACK_IMPORTED_MODULE_15__, _src_statistics_ContractTrend__WEBPACK_IMPORTED_MODULE_16__, _src_statistics_contractGas__WEBPACK_IMPORTED_MODULE_17__, _src_statistics_contractAddr__WEBPACK_IMPORTED_MODULE_18__, _src_statistics_contractCon__WEBPACK_IMPORTED_MODULE_19__, _src_statistics_ContractBanlace__WEBPACK_IMPORTED_MODULE_20__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_statistic__WEBPACK_IMPORTED_MODULE_3__, _src_statistics_Trend__WEBPACK_IMPORTED_MODULE_5__, _src_statistics_BlockRewardTrend__WEBPACK_IMPORTED_MODULE_6__, _src_statistics_BlockRewardPer__WEBPACK_IMPORTED_MODULE_7__, _src_statistics_ActiveNodeTrend__WEBPACK_IMPORTED_MODULE_8__, _src_statistics_FilChart__WEBPACK_IMPORTED_MODULE_10__, _src_statistics_Charts__WEBPACK_IMPORTED_MODULE_11__, _src_statistics_DCCTrend__WEBPACK_IMPORTED_MODULE_12__, _src_statistics_Meta__WEBPACK_IMPORTED_MODULE_15__, _src_statistics_ContractTrend__WEBPACK_IMPORTED_MODULE_16__, _src_statistics_contractGas__WEBPACK_IMPORTED_MODULE_17__, _src_statistics_contractAddr__WEBPACK_IMPORTED_MODULE_18__, _src_statistics_contractCon__WEBPACK_IMPORTED_MODULE_19__, _src_statistics_ContractBanlace__WEBPACK_IMPORTED_MODULE_20__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "static"
    });
    const { hash } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_2__/* .useHash */ .H)();
    // const [show, setShow] = useState(true);
    // const [lastScrollTop, setLastScrollTop] = useState(0);
    // useEffect(() => {
    //   const handleScroll = () => {
    //     // const ele = document.getElementsByClassName('header-fade-in');
    //     // console.log('---33', ele)
    //     // if (ele && ele.length > 0) {
    //     //   setShow(true)
    //     // } else {
    //     //   setShow(false)
    //     // }
    //     let st = window.pageYOffset || document.documentElement.scrollTop;
    //     console.log('99999ee', st, document.documentElement.scrollHeight, document.documentElement.clientHeight)
    //     let show = true;
    //     if (st > lastScrollTop) {
    //       show= false
    //     }
    //     setShow(show);
    //     if (show) {
    //       document.documentElement.scrollTop = st - 110;
    //     }
    //     setLastScrollTop(st <= 0 ? 0 : st);
    //   };
    //   window.addEventListener('scroll', handleScroll);
    //   return () => window.removeEventListener('scroll', handleScroll);
    // }, [lastScrollTop]);
    const renderNavChildren = (itemChildren)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            className: "flex w-full flex-col",
            children: itemChildren.map((child)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                    href: `/statistics/charts#${child.key}`,
                    scroll: false,
                    className: `text_des text_color flex w-full items-center gap-x-2 rounded-[5px] p-2 pl-10 hover:!text-primary ${hash === child.key ? "bg-bg_hover !text-primary" : ""}`,
                    children: tr(child?.title || child.key)
                }, child.key);
            })
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_13___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_21___default()["statistics-charts"]), "main_contain !overflow-auto"),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_13___default()("flex gap-x-5", (_index_module_scss__WEBPACK_IMPORTED_MODULE_21___default().content)),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_14__/* .BrowserView */ .I, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_21___default()["static-menu"])}`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mx-2.5 mb-2.5 flex h-10 flex-col justify-center gap-y-2.5 text-lg font-medium",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: tr("static_overview")
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: "card_shadow border_color flex h-fit cursor-pointer flex-col rounded-xl border py-4",
                                children: _contents_statistic__WEBPACK_IMPORTED_MODULE_3__/* .chartsNav */ .k2.map((item)=>{
                                    const { preIcon, title, key } = item;
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "relative flex w-full flex-col items-center px-4 font-HarmonyOS_Medium",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                href: `/statistics/charts#${item.key}`,
                                                scroll: false,
                                                className: `text_color flex h-10 w-full items-center gap-x-2 rounded-[5px] px-2.5 hover:bg-bg_hover ${hash === item.key ? "bg-bg_hover text-primary" : ""}`,
                                                children: [
                                                    preIcon && (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)(preIcon),
                                                    tr(title || key)
                                                ]
                                            }, item.key),
                                            item.children && renderNavChildren(item.children)
                                        ]
                                    }, item.key);
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_14__/* .MobileView */ .$, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_21___default()["nav-wrap"]),
                        children: _contents_statistic__WEBPACK_IMPORTED_MODULE_3__/* .chartsNav */ .k2.map((value, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                className: hash === value.key || hash === "" && index == 0 ? (_index_module_scss__WEBPACK_IMPORTED_MODULE_21___default().active) : "",
                                href: `/statistics/charts#${value.key}`,
                                children: tr(value.title || value.key)
                            }, value.key);
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_13___default()("flex flex-1 flex-col gap-y-6", (_index_module_scss__WEBPACK_IMPORTED_MODULE_21___default()["tab-content"])),
                    children: [
                        !hash && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_Meta__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {}),
                        hash === "networks" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_Meta__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {}),
                        hash.includes("fevm") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    id: "fevm_trend",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_ContractTrend__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    id: "fevm_con",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_contractCon__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    id: "fevm_addr",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_contractAddr__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    id: "fevm_gas",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_contractGas__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    id: "fevm_balance",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_ContractBanlace__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {})
                                })
                            ]
                        }),
                        hash.includes("blockChain") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    id: "blockChain_power",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_Trend__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    id: "blockChain_cc_dc_power",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_DCCTrend__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    id: "blockChain_trend",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_BlockRewardTrend__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    id: "blockChain_reward_per",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_BlockRewardPer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    id: "blockChain_nodes",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_ActiveNodeTrend__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                                })
                            ]
                        }),
                        hash === "fil_overview" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_FilChart__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_Charts__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                            ]
                        })
                    ]
                })
            ]
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 52727:
/***/ ((module) => {

module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ 77529:
/***/ ((module) => {

module.exports = require("@ant-design/icons/lib/icons/LoadingOutlined");

/***/ }),

/***/ 53800:
/***/ ((module) => {

module.exports = require("antd/lib/button");

/***/ }),

/***/ 92616:
/***/ ((module) => {

module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 30675:
/***/ ((module) => {

module.exports = require("antd/lib/input");

/***/ }),

/***/ 4946:
/***/ ((module) => {

module.exports = require("antd/lib/locale/en_US");

/***/ }),

/***/ 79353:
/***/ ((module) => {

module.exports = require("antd/lib/locale/zh_CN");

/***/ }),

/***/ 10274:
/***/ ((module) => {

module.exports = require("antd/lib/menu");

/***/ }),

/***/ 17369:
/***/ ((module) => {

module.exports = require("antd/lib/message");

/***/ }),

/***/ 76418:
/***/ ((module) => {

module.exports = require("antd/lib/modal");

/***/ }),

/***/ 32024:
/***/ ((module) => {

module.exports = require("antd/lib/switch");

/***/ }),

/***/ 86653:
/***/ ((module) => {

module.exports = require("antd/lib/theme");

/***/ }),

/***/ 69348:
/***/ ((module) => {

module.exports = require("antd/lib/tooltip");

/***/ }),

/***/ 59003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 68887:
/***/ ((module) => {

module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 29201:
/***/ ((module) => {

module.exports = require("echarts");

/***/ }),

/***/ 7276:
/***/ ((module) => {

module.exports = require("html2canvas");

/***/ }),

/***/ 59591:
/***/ ((module) => {

module.exports = require("lodash/cloneDeep");

/***/ }),

/***/ 93908:
/***/ ((module) => {

module.exports = require("lodash/debounce");

/***/ }),

/***/ 1712:
/***/ ((module) => {

module.exports = require("lodash/get");

/***/ }),

/***/ 36211:
/***/ ((module) => {

module.exports = require("mobx");

/***/ }),

/***/ 22062:
/***/ ((module) => {

module.exports = require("mobx-react");

/***/ }),

/***/ 16641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 43076:
/***/ ((module) => {

module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 35132:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 18743:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 93431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1121:
/***/ ((module) => {

module.exports = require("qrcode");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 66405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 94612:
/***/ ((module) => {

module.exports = require("use-deep-compare-effect");

/***/ }),

/***/ 99648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 49766:
/***/ ((module) => {

module.exports = import("bignumber.js");;

/***/ }),

/***/ 22021:
/***/ ((module) => {

module.exports = import("i18next");;

/***/ }),

/***/ 57987:
/***/ ((module) => {

module.exports = import("react-i18next");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8355,1163,8087,5622,3469,3309,4852,9729,1538,4313,2387], () => (__webpack_exec__(4209)));
module.exports = __webpack_exports__;

})();
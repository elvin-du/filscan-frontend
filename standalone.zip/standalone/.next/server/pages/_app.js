(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 3904:
/***/ ((module) => {

// Exports
module.exports = {
	"head": "Header_head__fdYAG",
	"top": "Header_top__G0l11",
	"top_content": "Header_top_content__AtyRO",
	"top_content_left": "Header_top_content_left__GS9Me",
	"logo": "Header_logo__vA21C",
	"logo_title": "Header_logo_title__XWYEz",
	"top_content_right": "Header_top_content_right__ZMED4",
	"top_content_right_old": "Header_top_content_right_old__fWFrA",
	"top_content_right_icon": "Header_top_content_right_icon__E3LQ7",
	"bottom": "Header_bottom__cudrP",
	"bottom_content": "Header_bottom_content__9RSUe",
	"nav_menu": "Header_nav_menu__XejX2",
	"ant-menu-item": "Header_ant-menu-item__7tj6I",
	"nav_menu_submenu": "Header_nav_menu_submenu__r3l5v",
	"nav_menu_submenu_title": "Header_nav_menu_submenu_title__jLxnl",
	"nav_menu_item_title": "Header_nav_menu_item_title__d9wl9",
	"ant-menu-item-only-child": "Header_ant-menu-item-only-child___QJ8r",
	"ant-menu-title-content": "Header_ant-menu-title-content__hWmQ1",
	"navMenu": "Header_navMenu__1Q4fv",
	"navMenu_item": "Header_navMenu_item__UYMzf",
	"navMenu_wrap": "Header_navMenu_wrap__1TGC1",
	"navMenu_wrap_cont": "Header_navMenu_wrap_cont__9nOL3",
	"navMenu_wrap_icon": "Header_navMenu_wrap_icon__JTK8J",
	"icon": "Header_icon__9WNTn",
	"select": "Header_select__qoSAh",
	"search": "Header_search__ujXhG",
	"search_input": "Header_search_input__xCarv",
	"search_input_svg": "Header_search_input_svg__mH73Y"
};


/***/ }),

/***/ 2684:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "footer_footer__pOtN3",
	"footer_top": "footer_footer_top__qm86m",
	"footer_bottom": "footer_footer_bottom__RRyDx",
	"footer_header": "footer_footer_header__4aXzc",
	"footer_header_logo": "footer_footer_header_logo__gNh__",
	"footer_header_title": "footer_footer_header_title__Wt_Gg",
	"footer_header_text": "footer_footer_header_text__vYz6E",
	"footer_header_text_outlook": "footer_footer_header_text_outlook__jUbL5"
};


/***/ }),

/***/ 3466:
/***/ ((module) => {

// Exports
module.exports = {
	"links": "links_links__pQM89",
	"links_item": "links_links_item__E7QK8"
};


/***/ }),

/***/ 3435:
/***/ ((module) => {

// Exports
module.exports = {
	"mobile_header": "header_mobile_header__UpWEW",
	"mobile_header_top": "header_mobile_header_top__G0P5R",
	"mobile_header_top_image": "header_mobile_header_top_image__Wvwyg",
	"mobile_header_top_right": "header_mobile_header_top_right__q9wSQ",
	"mobile_header_logo": "header_mobile_header_logo__Kabx1",
	"mobile_menu_ul": "header_mobile_menu_ul__uNO0n",
	"mobile_menu_ul_item": "header_mobile_menu_ul_item__6RAEW",
	"mobile_menu_ul_item_select": "header_mobile_menu_ul_item_select__B2pEF",
	"mobile_menu_ul_item_li": "header_mobile_menu_ul_item_li__YPZzc",
	"mobile_menu_mask": "header_mobile_menu_mask__ekY_T",
	"mobile_menu_modal": "header_mobile_menu_modal___Qnzm",
	"ant-modal-content": "header_ant-modal-content__cqOuP",
	"mobile_search": "header_mobile_search__X3bTS"
};


/***/ }),

/***/ 5537:
/***/ ((module) => {

// Exports
module.exports = {
	"custom_select": "selects_custom_select__rx9gZ",
	"custom_select_contains": "selects_custom_select_contains__8lHca",
	"border_select": "selects_border_select__arTOy",
	"custom_select_value": "selects_custom_select_value__LpcjI",
	"custom_select_wrap": "selects_custom_select_wrap__wdDf8"
};


/***/ }),

/***/ 2822:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-cn-hongkong.aliyuncs.com/client/_next/static/media/logo.c466b17b.svg","height":149,"width":139});

/***/ }),

/***/ 831:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-cn-hongkong.aliyuncs.com/client/_next/static/media/logo_a.55dc3968.svg","height":101,"width":310});

/***/ }),

/***/ 1826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-cn-hongkong.aliyuncs.com/client/_next/static/media/menudown.25b8c9c3.png","height":32,"width":46,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAQAAABUDBdwAAAAUElEQVR42jXMuw1FYABA4e/eRGMJid7jb8ygsIJBrOLRECtYQWIGs6AQOfX52N0ut7eDoFbJFHJBAjRWvdGsI0JrMxksOviDVFB+y0/sfNEHka4UFfl/TNsAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 931:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-cn-hongkong.aliyuncs.com/client/_next/static/media/menuup.b256d6d3.png","height":32,"width":46,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAQAAABUDBdwAAAAT0lEQVR42iXBuw1FUAAA0PNeorGERO9zGzMorGAQq/g0xApWkJjBLK7COcBP6hZFF/xBLqhlJOgdFpPNAHR2o9lqIGg1CpVSkHGKHtH3egEfExQVb3g9EwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 3824:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7987);
/* harmony import */ var _contants_nav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2263);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3904);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3775);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_1__]);
react_i18next__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 








function NavMenu() {
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)();
    const [overKey, setOver] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("");
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "nav"
            });
        }
        return t(label, {
            ns: "nav"
        });
    };
    const asPath = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)().asPath;
    // const renderMenu = (data: Array<Menu_Info>) => {
    //   return data.map((menuItem: Menu_Info, index) => {
    //     if (menuItem.childrens) {
    //       return (
    //         <div
    //           key={index}
    //           onMouseOver={(e) => { 
    //             e.stopPropagation()
    //             console.log('over')
    //             setOver(menuItem.key)
    //           }}
    //           onMouseLeave={(e) => { 
    //                           e.stopPropagation()
    //             console.log('leave')
    //             setOver('')
    //           }}
    //           className={`${styles.navMenu_wrap}`}>
    //           <span className={`${styles.navMenu_item}` }>
    //             {t(menuItem.key, { ns: "nav" })}
    //             {getSvgIcon('down')}
    //             {/* {menuItem.icon && (
    //               <span className="defaule-icon new_icon">
    //                 { menuItem.icon === 'New' ? getSvgIcon('newIcon'):menuItem.icon}
    //                </span>
    //         )} */}
    //           </span>
    //           <div className={`${styles.navMenu_wrap_cont}`}
    //             style={{visibility:overKey === menuItem.key ? 'visible':'hidden'}}
    //             key={menuItem.key}>
    //             {renderMenu(menuItem.childrens)}
    //           </div>
    //         </div>
    //       );
    //     }
    //     return (
    //       <li
    //         key={menuItem.key}
    //         className={`${styles.navMenu_item}`}>
    //         {menuItem.link ? (
    //           <Link href={menuItem.link} replace prefetch>
    //             <span style={{ color: menuItem.color }} onClick={ 
    //             () => { 
    //               if (asPath === menuItem.link) { 
    //                 window.location.reload()
    //               }
    //             }
    //           }>{t(menuItem.key, { ns: "nav" })}</span> 
    //             {/* {t(menuItem.key, { ns: "nav" })} */}
    //           </Link>
    //         ) : (
    //           <span>{t(menuItem.key, { ns: "nav" })}</span>
    //         )}
    //         {/* {menuItem.icon && (
    //           <span  className="defaule-icon"  >{menuItem.icon}</span>
    //         )} */}
    //       </li>
    //     );
    //   });
    // };
    // const renderMenuItem = (data: Array<Menu_Info>):JSX.Element[] => { 
    //   return data.map((menuItem: any, index) => { 
    //     if (menuItem.childrens) {
    //       return <Menu.SubMenu
    //         popupClassName={'custom_subMenu'}
    //         key={menuItem.key}
    //         popupOffset={ [-30,0]}
    //         className={`${styles.nav_menu_submenu} `}
    //         title={
    //           <span className={`${styles.nav_menu_submenu_title}`}>
    //             {menuItem.preIcon && getSvgIcon(menuItem.preIcon)}
    //           {tr(menuItem.key)}
    //             {getSvgIcon('down')}
    //             {menuItem.sufIcon && getSvgIcon(menuItem.sufIcon)}
    //          </span>
    //       }>
    //         {renderMenuItem(menuItem.childrens)}
    //       </Menu.SubMenu>
    //     }
    //     return <Menu.Item key={menuItem.key}  className={`${styles.nav_menu_item}`} >
    //       {menuItem.link ? <Link href={menuItem.link} className={`${styles.nav_menu_item_title}`} >
    //         {tr(menuItem.key)}
    //          {menuItem.sufIcon && getSvgIcon(menuItem.sufIcon)}
    //       </Link> : tr(menuItem.key)}
    //     </Menu.Item>
    //   })
    // }
    const renderItems = (data)=>{
        return data.map((items)=>{
            if (items.childrens) {
                items.popupOffset = [
                    [
                        -30,
                        0
                    ]
                ];
                items.children = renderItems(items === null || items === void 0 ? void 0 : items.childrens);
                items.label = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().nav_menu_submenu_title)}`,
                    children: [
                        (items === null || items === void 0 ? void 0 : items.preIcon) && (0,_svgUtils__WEBPACK_IMPORTED_MODULE_5__/* .getSvgIcon */ .a)(items.preIcon),
                        tr(items.key),
                        (0,_svgUtils__WEBPACK_IMPORTED_MODULE_5__/* .getSvgIcon */ .a)("down"),
                        (items === null || items === void 0 ? void 0 : items.sufIcon) && (0,_svgUtils__WEBPACK_IMPORTED_MODULE_5__/* .getSvgIcon */ .a)(items.sufIcon)
                    ]
                });
            } else {
                items.label = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().nav_menu_submenu_title)}`,
                    children: [
                        (items === null || items === void 0 ? void 0 : items.preIcon) && (0,_svgUtils__WEBPACK_IMPORTED_MODULE_5__/* .getSvgIcon */ .a)(items.preIcon),
                        items.outLink && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            onClick: ()=>{
                                window.open(items.outLink);
                            },
                            children: tr(items.out_key)
                        }),
                        items.link ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            href: items.link,
                            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().nav_menu_item_title)}`,
                            children: [
                                "  ",
                                tr(items.key),
                                " "
                            ]
                        }) : tr(items.key),
                        (items === null || items === void 0 ? void 0 : items.sufIcon) && (0,_svgUtils__WEBPACK_IMPORTED_MODULE_5__/* .getSvgIcon */ .a)(items.sufIcon)
                    ]
                });
            }
            return {
                ...items
            };
        });
    };
    const items = renderItems(_contants_nav__WEBPACK_IMPORTED_MODULE_2__/* .navMenu */ .$);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Menu, {
        mode: "horizontal",
        theme: "light",
        items: items,
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().nav_menu)
    });
//return <div className={styles.navMenu}>{renderMenu(navMenu)}</div>;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavMenu);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7015:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contants_nav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2263);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3904);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1311);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9189);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3775);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_3__, _store_server__WEBPACK_IMPORTED_MODULE_5__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_3__, _store_server__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const [input, setInput] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [select, setSelect] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const handleSearch = ()=>{
        const showInput = input.trim();
        if (input) {
            (0,_store_server__WEBPACK_IMPORTED_MODULE_5__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_6__/* .apiUrl.searchInfo */ .J.searchInfo, {
                input: showInput,
                input_type: select
            }).then((res)=>{
                var _res_result;
                const type = res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.result_type;
                if (type) {
                    if (type === "owner") {
                        //owner 
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/owner/${showInput}`);
                    } else if (type === "address") {
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/address/${showInput}`);
                    } else if (type === "height") {
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/tipset/chain?height=${showInput}`);
                    } else if (type === "message_details") {
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/message/${showInput}`);
                    } else if (type === "miner") {
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/miner/${showInput}`);
                    } else if (type === "block_details") {
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/tipset/chain?cid=${showInput}`);
                    } else if (type === "opengate-fns") {
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/domain/${showInput}`);
                    } else {
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/address/${showInput}`);
                    }
                } else {
                    //404
                    next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/noResult/${showInput}`);
                }
            });
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().search),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_4__.Input, {
            bordered: false,
            className: `custom_input ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().search_input)}`,
            placeholder: t(_contants_nav__WEBPACK_IMPORTED_MODULE_2__/* .search.holder */ .y.holder, {
                ns: "nav"
            }) || "",
            onPressEnter: handleSearch,
            onChange: (e)=>{
                setInput(e.target.value);
            },
            suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().search_input_svg),
                onClick: handleSearch,
                children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_8__/* .getSvgIcon */ .a)("searchIcon")
            })
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9980:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_images_logo_a_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(831);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3904);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var _NavMenu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3824);
/* harmony import */ var _Search__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7015);
/* harmony import */ var _packages_selects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9956);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3775);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8194);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_3__, _NavMenu__WEBPACK_IMPORTED_MODULE_4__, _Search__WEBPACK_IMPORTED_MODULE_5__, _packages_selects__WEBPACK_IMPORTED_MODULE_6__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_3__, _NavMenu__WEBPACK_IMPORTED_MODULE_4__, _Search__WEBPACK_IMPORTED_MODULE_5__, _packages_selects__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 











function NavHead({ value  }) {
    var _process_env;
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const { filscan , setFilscan  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z);
    const hanleDark = ()=>{
        setFilscan({
            ...filscan,
            theme: filscan.theme === "dark" ? "light" : "dark"
        });
        localStorage.setItem("filscan", JSON.stringify({
            ...filscan,
            theme: filscan.theme === "dark" ? "light" : "dark"
        }));
    };
    const handleChange = (type, item)=>{
        if (type === "lang") {
            setFilscan({
                ...filscan,
                lang: item.value
            });
            i18n.changeLanguage(item.value); // 更改i18n语言
        }
        localStorage.setItem("filscan", JSON.stringify({
            ...filscan,
            lang: item.value
        }));
    // 切换网络
    };
    const apiFlag = (process === null || process === void 0 ? void 0 : (_process_env = process.env) === null || _process_env === void 0 ? void 0 : "https://api-v2.filscan.io:27000/api/v1") === "http://192.168.1.189:27001/api/v1";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().head),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().top),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().top_content),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().top_content_left),
                            onClick: ()=>next_router__WEBPACK_IMPORTED_MODULE_10___default().push("/home"),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                src: _assets_images_logo_a_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                                alt: "Fliscan Logo",
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().logo)
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().top_content_right),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().top_content_right_old),
                                    onClick: ()=>{
                                        window.open("http://v1.filscan.io");
                                    },
                                    children: "Old Version"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    children: [
                                        t("network_title", {
                                            ns: "nav"
                                        }),
                                        ":"
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    defaultValue: apiFlag ? "Calibration" : "Mainnet",
                                    onChange: (item)=>{
                                        const value = item.value;
                                        if (value === "Calibration") {
                                            window.open("https://calibration.filscan.io/");
                                        } else if (value === "Mainnet") {
                                            window.open("https://filscan.io/");
                                        }
                                    },
                                    options: [
                                        {
                                            value: "Mainnet",
                                            label: "Mainnet"
                                        },
                                        {
                                            value: "Calibration",
                                            label: "Calibration"
                                        }
                                    ]
                                }, "network"),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    defaultValue: filscan.lang,
                                    className: `default_select ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().select)}`,
                                    onChange: (value)=>handleChange("lang", value),
                                    options: [
                                        {
                                            value: "zh",
                                            label: "中文"
                                        },
                                        {
                                            value: "en",
                                            label: "English"
                                        }
                                    ]
                                }, "lang"),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().top_content_right_icon),
                                    onClick: hanleDark,
                                    children: filscan.theme === "dark" ? (0,_svgUtils__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("moonSvg") : (0,_svgUtils__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("sunSvg")
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().bottom),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().bottom_content),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavMenu__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Search__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavHead);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8173:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2684);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _assets_images_logo_a_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(831);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3775);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_3__]);
react_i18next__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 





const footerLinks = [
    {
        label: "twitter",
        type: "_blank",
        link: "https://twitter.com/FilscanOfficial"
    },
    {
        label: "telegram",
        type: "_blank",
        link: "https://t.me/+bI9fUEkmPjMzYjg1"
    },
    {
        label: "outlook",
        type: "_self",
        link: "mailto:filscan@ipfsforce.com"
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer_top),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer_header),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer_header_logo),
                            src: _assets_images_logo_a_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer_header_text),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    t("footer_text", {
                                        ns: "home"
                                    }),
                                    "  "
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer_header_text_outlook),
                                children: footerLinks.map((linkItem)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        target: linkItem.type,
                                        style: {
                                            color: "#fff"
                                        },
                                        href: linkItem.link,
                                        children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)(linkItem.label)
                                    }, linkItem.label);
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer_bottom),
                children: [
                    t("footer_detail_a", {
                        ns: "home"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "https://www.mit-license.org/",
                        target: "_blank",
                        children: " MIT"
                    }),
                    "     ",
                    t("footer_detail_b", {
                        ns: "home"
                    }),
                    "  ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "https://www.apache.org/licenses/LICENSE-2.0.html",
                        target: "_blank",
                        children: "Apache 2.0"
                    }),
                    "   ",
                    t("footer_detail_c", {
                        ns: "home"
                    }),
                    " ."
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2875:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3775);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3466);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_2__);



const footerLinks = [
    {
        label: "twitter",
        type: "_blank",
        link: "https://twitter.com/FilscanOfficial"
    },
    {
        label: "telegram",
        type: "_blank",
        link: "https://t.me/+bI9fUEkmPjMzYjg1"
    },
    {
        label: "outlook",
        type: "_self",
        link: "mailto:filscan@ipfsforce.com"
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_2___default().links),
        children: footerLinks.map((linkItem)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_2___default().links_item),
                target: linkItem.type,
                style: {
                    color: "#fff"
                },
                href: linkItem.link,
                children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)(linkItem.label)
            }, linkItem.label);
        })
    });
});


/***/ }),

/***/ 2263:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ navMenu),
/* harmony export */   "y": () => (/* binding */ search)
/* harmony export */ });
const navMenu = [
    {
        key: "home",
        link: "/home"
    },
    {
        key: "contract",
        preIcon: "newIcon",
        color: "#F44C30",
        childrens: [
            {
                key: "contract_verify",
                link: "/contract/verify/"
            },
            {
                key: "token",
                link: "/contract/token/"
            }
        ]
    },
    {
        key: "tipset",
        childrens: [
            {
                key: "tipset_chain",
                link: "/tipset/chain/"
            },
            {
                key: "tipset_message",
                link: "/tipset/message-list/"
            },
            {
                key: "tipset_ranking",
                link: "/tipset/address-list/"
            },
            {
                key: "tipset_dsn",
                link: "/tipset/dsn/"
            },
            {
                key: "tipset_pool-message",
                link: "/tipset/pool-message/"
            }
        ]
    },
    {
        key: "ranking",
        link: "/rank"
    },
    {
        key: "statistics",
        childrens: [
            {
                key: "statistics_gas",
                link: "/statistics/gas"
            },
            {
                key: "statistics_base",
                link: "/statistics/power"
            },
            {
                key: "statistics_fil",
                link: "/statistics/fil"
            },
            {
                key: "statistics_charts",
                link: "/statistics/charts"
            }
        ]
    },
    // {
    //     key: 'resources',
    //     childrens: [
    //         { key: 'resources_tools' ,link:'resources/tools'},
    //     ]
    // }, 
    {
        key: "fvm",
        sufIcon: "hotIcon",
        color: "#F44C30",
        link: "/fvm"
    },
    {
        out_key: "provider",
        key: "",
        outLink: "http://v1.filscan.io/account?key=login"
    }
];
const search = {
    holder: "search_holder",
    opt: [
        {
            label: "all",
            value: "all"
        },
        {
            label: "address",
            value: "address"
        },
        {
            label: "message_id",
            value: "message_id"
        },
        {
            label: "height",
            value: "height"
        },
        {
            label: "cid",
            value: "cid"
        },
        {
            label: "node",
            value: "node"
        }
    ]
};



/***/ }),

/***/ 6599:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const contract = {
    overview: "Overview",
    market: "Market",
    next: "Continue",
    reset: "Reset",
    confirm: "Verify&Publish",
    back: "Return to Main",
    file_name: "SELECT *.SOL FILES",
    verify_title: "Verify & Publish Contract Source Code",
    verify_des: "COMPILER TYPE AND VERSION SELECTION",
    content_des: 'Source code verification provides transparency for users interacting with smart contracts. By uploading the source code, Filscan will match the compiled code with that on the blockchain. Just like contracts, a "smart contract" should provide end users with more information on what they are "digitally signing" for and give users an opportunity to audit the code to independently verify that it actually does what it is supposed to do.',
    address: "Please Enter Contract Address to Verify",
    address_placeholder: "Please enter the Contract Address",
    verify_address: "Please Enter Complier Version to Verify",
    verify_address_placeholder: "Please select",
    license_type: "Please select Open Source License Type",
    content_des1: "1. If the contract compiles correctly at REMIX, it should also compile correctly here.",
    content_des2: "2. We have limited support for verifying contracts created by another contract and there is a timeout of up to 45 seconds for each contract compiled.",
    content_des3: "3. For programatic contract verification, check out the Contract API Endpoint.",
    checkbox_service: "I agree to the terms of service",
    verify_select_placeholder: "Please select",
    //logs
    ver_sucess: "Success",
    ver_err: "Error",
    byte_code: "Compilation log",
    contract_name: " Contract Name ",
    local_byte_code: "Contract Bytecode",
    compiler: "Complier Verison",
    //step1
    address_verify: "Contract Address",
    step1_verify_des: "SELECT ONE OR MORE *.SOL FILES",
    source_code: "Contract Source Code",
    compile_version: "Complier",
    compile_output: "Complier Output",
    Optimizations: "Optimizations",
    run_optimizer: "Runs(Optimizer)",
    arguments: "Constructor Argument",
    optimize: "Optimization Enabled",
    //token list 
    token_list: "All Tokens",
    token_name: "Token",
    vol_24: "Trading Volume(24h)",
    transfer_total: "Total Messages of {{value}}",
    owner_total: "From a total of {{value}} holders",
    dex_total: "Total Message of {{value}} Transactions ",
    // ft /fns dashborad
    "total_supply": "Max Supply",
    "owners": "Hoders",
    "transfers": "Total Transfers",
    latest_price: "Price",
    market_value: "Market Cap",
    token_contract: "Token Contract",
    transfer: "Transfers",
    owner: "Holders",
    domain: "Contract",
    dex: "Dex Trades",
    //list 
    message_cid: "Message ID",
    method: "Method",
    time: "Time",
    from: "From",
    to: "To",
    amount: "Amount",
    //拥有者
    rank: "Rank",
    percentage: "Percentage",
    //dex
    platform: "Platform",
    Txn_Value: "Txn Value",
    "swapped_Rate": "Swapped Rate",
    "Token_Amount_in": "Token Amount(In)",
    "Token_Amount_out": "Token Amount(Out)",
    Action: "Action"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contract);


/***/ }),

/***/ 1329:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// pool-detail 
const detail = {
    "24h": "24H",
    "7d": "7D",
    "30d": "30D",
    "1year": "1Y",
    "message_list_all": "All Methods",
    //owner
    "owner_title": "Pool Detail",
    "owner_title_tip": "The data of mine pool is collected from the data of nodes.",
    account: "Account",
    owner_address: "Owner Address",
    owned_miners: "Nodes",
    account_id: "Account Address",
    //account_type
    miner: "Miner",
    evm: "EVM",
    ethaddress: "ETHAddress",
    ethaccount: "ETHAccount",
    account_name: "Account",
    latest_transfer_time: "Lastest Timestamp",
    multisig: "MultiSign Account",
    from_ath: "From",
    to_ath: "To",
    //概览
    owner_overview_title: "Pool Overview",
    balance: "Total Balance",
    available_balance: "Available",
    init_pledge: "Initial Pledge",
    pre_deposits: "PreCommitDeposits",
    locked_balance: "Locked Rewards",
    sector_count: "Total",
    live_sector_count: "Active",
    fault_sector_count: "Faults",
    recover_sector_count: "Recoveries",
    eth_address: "Eth Address",
    stable_address: "Stable Address",
    account_detail: "Account Detail",
    //统计指标
    indicators: "Statistical Indicators",
    power_increase_indicators: "Power Increase",
    power_ratio: "Power Rate",
    sector_increase: "Sector Increase",
    precommit_deposits: "Storage Provider Precommit Deposits",
    gas_fee: "Gas Fee",
    block_rewards: "Block Rewards",
    block_count: "Block",
    block_count_tip: "Blocks mined = the sum of blocks mined",
    mining_efficiency: "Efficiency",
    mining_efficiency_tip: "The ratio of node's cumulative block reward to the adjusted storage power in the selected period.",
    lucky: "Lucky",
    sector_ratio: "Sector Rate",
    win_count: "Winner Rewards",
    win_count_tip: "In Filecoin mining model, there may be multiple blocks under a tipset, and each block may receive multiple win counts.",
    net_profit_per_tb: "Consume per",
    net_profit_per_tb_tip: "Single T package sector size gas consumption in selected period",
    //账户变化
    owner_account_change: "Account Changes",
    power: "Pool Overview",
    power_increase: "Power Increase",
    quality_adjust_power: "Quality Adjusted Power",
    quality_power_rank: "Ranking",
    raw_power_percentage: "Power Rate",
    raw_power: "RawBytePower",
    total_block_count: "30/D  Blocks",
    total_block_count_tip: "Total Blocks in the past 30 days",
    total_reward: "30/D  Reward",
    total_reward_tip: "Total Reward in the past 30 days",
    total_win_count: "30/D  Wincount",
    total_win_count_tip: "Total Wincount in the past 30 days",
    sector_size: "Sector Size",
    sector_stauts: "Sector Status",
    //账户总览
    account_overview: "Account Overview",
    create_time: "Create Time",
    account_type: "Type",
    peer_id: "Peer ID",
    account_address: "Address",
    owner_address: "Owner",
    area: "Region",
    worker_address: "Worker",
    controllers_address: "Controller",
    beneficiary_address: "Beneficiary",
    code_cid: "CODE CID",
    nonce: "Nonce Count",
    // message
    message_overview_detail: "Transaction Details",
    trade: "Internal Transaction",
    message_detail: "Overview",
    event_log: "Log",
    message_overview: "Message Overview",
    cid: "Message ID",
    height: "Height",
    time: "Time",
    blk_cids: "Block Cid",
    value: "Value",
    from: "From",
    to: "To",
    status: "Status",
    method_name: "Method",
    message_other: "Others",
    version: "Version",
    nonce: "Nonce",
    gas_fee_cap: "Gas Fee Cap",
    gas_premium: "Gas Premium",
    gas_limit: "Gas Limit",
    gas_used: "Gas Used",
    base_fee: "BaseFee",
    all_gas_fee: "Gas Fee",
    params: "Params",
    returns: "Returns",
    message_tranf: "Transactions",
    from_tranf: "From",
    to_tranf: "To",
    consume_type: "Type",
    MinerTip: "Miner Tip",
    BaseFeeBurn: "BaseFee Burn",
    Transfer: "Transfer",
    Burn: "Burn",
    exit_code: "Status",
    //内部交易
    amount: "Value",
    method: "Method",
    topic: "Topics",
    //通证转移
    message_ERC20Trans: "Tokens Transferred",
    // 出块列表
    block_cid: "Block Cid",
    block_height: "Height",
    block_time: "Time",
    block_messages_count: "Messages",
    block_miner_id: "Storage Provider",
    block_mined_reward: "Rewards",
    //miner
    message_list: "Message",
    block_list: "Blocks",
    traces_list: "Transaction",
    message_list_total: "Total of {{value}} Messages",
    block_list_total: "Total of  {{value}} Blocks",
    traces_list_total: "Total of {{value}} Messages",
    //general 
    general_overview_title: "Account",
    base_account_id: "ID",
    //dns detail 
    deal_details: "dsn Detail",
    deal_id: "Dsn ID",
    epoch: "Block",
    service_start_time: "Create Time",
    message_cid: "Message",
    piece_cid: "Piece CID",
    verified_deal: "Verified",
    deal_hosting: "Storage Detail",
    deal_left_title: "Client",
    deal_right_title: "Provider",
    deal_value: "Provider",
    deal_cash: "Storage Cost",
    deal_time: "to"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (detail);


/***/ }),

/***/ 1641:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fvm = {
    fvm_all: "Filecoin Ecosystem",
    Defi: "Defi",
    Dex: "Dex",
    DID: "DID",
    NFT: "NFT",
    MarketPlace: "MarketPlace",
    Launchpad: "Launchpad"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fvm);


/***/ }),

/***/ 7005:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const home = {
    seconds: "s",
    minutes: "m",
    hours: "h",
    day: "D",
    meta_title: "The Filecoin Network Data Index",
    mata_show: "Unfold",
    mata_show_false: "Fold",
    latest_height: "Block Height",
    latest_block_time: "Latest Block",
    total_blocks: "Total Block",
    total_rewards: "Total Block Rewards",
    total_quality_power: "Network Quality Adjusted Power",
    total_quality_power_tip: "Total current effective computing power (effective storage space) of the Filecoin network",
    base_fee: "Base Fee",
    miner_initial_pledge: "Current Sector Initial Pledge",
    power_increase_24h: "Latest 24h Power Growth",
    rewards_increase_24h: "Block Rewards Last 24h",
    fil_per_tera_24h: "Output\xa0Efficiency last 24h",
    fil_per_tera_24h_tip: "The average\xa0reward output\xa0for each terabyte of storage capacity over the last 24 hours",
    gas_in_32g: "Gas Used of a 32GiB Sector",
    gas_in_32g_tip: "Gas used of Sealing a 32GiB Sector in the last 24 hours",
    add_power_in_32g: "EST. Cost of a 32GiB Sector",
    add_power_in_32g_tip: "The cost of sealing a 32GiB sector in the past 24 hours, including the sector’s initial pledge and message fee",
    gas_in_64g: "Gas Used of a 64GiB Sector",
    gas_in_64g_tip: "Gas used of Sealing a 64GiB Sector in the last 24 hours",
    add_power_in_64g: "EST. Cost of a 64GiB Sector",
    add_power_in_64g_tip: "The cost of sealing a 64GiB sector in the past 24 hours, including the sector’s initial pledge and message fee",
    win_count_reward: "Rewards per Wincount",
    win_count_reward_tip: "",
    avg_block_count: "Avg. Blocks per TipSet",
    avg_block_count_tip: "Average blocks produced per tipSet in 24h",
    avg_message_count: "Avg. Messages per TipSet",
    avg_message_count_tip: "Average messages packaged per tipSet in 24h",
    active_miners: "Active Nodes",
    burnt: "Destruction Amount",
    circulating_percent: "Circulation Amount",
    rank: "Ranking List",
    footer_text: "Filscan browser is the filecoin blockchain browser and data service platform，It provides one-stop data services such as mining ranking, blockchain data query and visualization chart based on filecoin.",
    footer_outlook: "Email",
    footer_detail_a: "Copyright \xa9 Filecoin-Project devgrants. Distributed under the ",
    footer_detail_b: " and ",
    footer_detail_c: "license",
    search_notFound: "Search Not Found",
    warn_text: "Oops! The search string you enterd was:",
    warn_details: "Sorry! This is an invalid search string",
    go_home: "Back Home"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (home);


/***/ }),

/***/ 8148:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const en = {
    network_title: "Current Network",
    home: "Home",
    contract: "Smart Contract",
    contract_verify: "Contract Verification",
    token: "Tokens",
    tipset: "Tipset",
    tipset_chain: "Chain",
    tipset_message: "Message",
    tipset_ranking: "Wealth Ranking",
    tipset_transfer: "Large Amount Transfer",
    tipset_dsn: "Dsn",
    "tipset_pool-message": "Pool Message",
    ranking: "Ranking",
    statistics: "Statistics",
    statistics_gas: "Gas Fee",
    statistics_base: "Power",
    statistics_fil: "FIL",
    statistics_charts: "Charts",
    statistics_map: "Charts",
    resources: "Resources",
    resources_tools: "Tools",
    provider: "Storage Provider",
    fvm: "Filecoin Ecosystem",
    //search 
    "search_holder": "Search by Address/Message ID/Height/Block Cid/Peer ID",
    all: "All filters",
    address: "Address",
    message_id: "Message ID",
    height: "Height",
    cid: "Block CID",
    node: "Peer ID"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (en);


/***/ }),

/***/ 3279:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const rankZh = {
    pool: "Storage Pool",
    provider: "Storage Provider",
    growth: "Power Growth",
    rewards: "Rewards",
    "24h": "24H",
    week_days: "7D",
    month: "30D",
    select_rank_all: "All",
    select_rank_32: "32GiB",
    select_rank_64: "64GiB",
    more: "More",
    rank_time: "Latest Update on",
    // table columns title
    //存储池排行
    ranking: "Rank",
    pool_owner: "Owner ID",
    pool_power: "Quality Adjusted Power",
    pool_efficiency_24h: "Latest 24h Output Efficiency",
    pool_increase_24h: "Power Growth",
    pool_block_count: "Blocks Mined",
    miner: "Miner",
    pool_block_count_24h: "24h Total Block Rewards",
    // 节点排行
    provider_miner: "Storage Provider",
    provider_power_ratio: "Quality Adjusted Power / Rate",
    provider_block_ratio: "24H Blocks / Rate ",
    provider_rewards_ratio: "24H Wincount Rate",
    balance: "Balance",
    //算力增速
    power_ratio: "Power Growth",
    power_ratio_tip: "Daily total adj. power of the sealed sectors within selected period.",
    quality_power_increase: "Daily Power Growth",
    quality_power_increase_tip: "Node's adjusted storage power increment in the selected period.",
    quality_adj_power: "Quality Adjusted Power",
    raw_power: "Raw Byte Power",
    sector_size: "Sector Size",
    //节点收益
    "rewards/ratio": "Rewards/Ratio",
    "rewards/ratio_tip": "The ratio of node's cumulative block reward to the adjusted storage power in the selected period.",
    block_count: "Blocks",
    block_count_tip: "In Filecoin CryptoEconomics, there may be multiple blocks under a tipset, and each block may receive multiple win counts.",
    winning_rate: "Wincount Rate"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rankZh);


/***/ }),

/***/ 3759:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const statistic = {
    show_more: "More",
    "24h": "24H",
    "7d": "7D",
    "30d": "30D",
    year: "1Y",
    // power 
    "power": "Storage Power Trend",
    power_tips: "The network baseline is the scale of network growth required by the Filecoin Network, which was 2.5 EiB when the Mainnet launched, with a growth rate of 100% per year",
    trend_24: "24h Base Fee Variations",
    total_raw_byte_power: "Network Raw Byte Power",
    base_line_power: "BaseLine",
    total_quality_adj_power: "Quality Adjusted Power",
    change_quality_adj_power: "Quality Adjusted Power Fluctuations",
    gas: "Base Fee Variations",
    base_fee: "Base Fee",
    gas_in_32g: "Gas Cost of Sealing a 32GiB Sector",
    gas_in_64g: "Gas Cost of Sealing a  64GiB Sector",
    //24_gas
    gas_24: "24h Gas Data",
    method_name: "Message Type",
    avg_gas_premium: "Gas Premium",
    avg_gas_limit: "Avg. Gas Limit",
    avg_gas_used: "Avg. Gas Used",
    avg_gas_fee: "Avg. Gas Fee",
    "sum_gas_fee/ratio": "Total Fees/Percentage",
    "message_count/ratio": "Total Messages/Percentage",
    //fil
    TokenRules: "FIL Allocation",
    FilecoinFoundation: "Filecoin Foundation",
    FundraisingRemainder: "Fundraising-Remainder",
    FundraisingSAFT: "Fundraising-SAFT",
    MiningReserve: "Mining Reserve",
    TokenAllocation: "Storage Mining Allocation",
    ReservedTokens: "Mining Reserve",
    Fundraising: "Fundraising - SAFT 2017",
    Funds: "Fundraising - Remainder",
    protocolLab: "Protocol Labs",
    Contributors: "PL Team &amp; Contributors",
    Allocation: "Allocation",
    value: "Value",
    description: "Description",
    filBase: "FIL BASE",
    filBase_des: "The maximum amount of FIL that will ever be created.",
    ReservedTokens_des: "Tokens reserved for funding mining to support growth of the Filecoin Economy, whose future usage will bedecided by the Filecoin community.",
    TokenAllocation_des: "The amount of FIL allocated tostorage nodes through block rewards, network initialization, etc.",
    Fundraising_des: "2017 TOKEN SALE",
    Funds_des: "allocated for ecosystem development, future fundraising",
    protocolLab_des: "allocated for Protocol Labs",
    Contributors_des: "4.5% for the PL team & contributors",
    //charts 
    pie_title: "chart statistics",
    block_trend: "Block Rewards",
    block_reward_per_TiB: "output efficiency",
    active_nodes: "Active Storage Providers",
    active_miner_count: "Node Counts",
    messages_trend: "Message Trend",
    message_count: "Message Trend of Each Block",
    all_message_count: "Messages Variation per Block",
    all_message_count_tip: "Messages Included per Block",
    acc_block_rewards: "Cumulative block rewards",
    pie_title_a: "Released FIL Usage Statistics",
    pie_title_a_tip: "Total FIL Rewarded + Locked Rewards Released + Reserved FIL Allocated = Currently Released Fil",
    pie_title_b: "Released FIL Usage Statistics",
    mined: "Total FIL Rewarded",
    remaining_mined: "Total FIL to Reward",
    vested: "Locked Rewards Released",
    remaining_vested: "Locked Rewards to Release",
    reserve_disbursed: "Reserved FIL Allocated(Testnet Rewards)",
    remaining_reserved: "Reserved FIL to Allocate",
    locked: "Total Sector Pledge",
    burnt: "Total FIL Burned",
    circulating: "Circulating Supply"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (statistic);


/***/ }),

/***/ 192:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const tipset = {
    rank: "Rank",
    tag: "Tag",
    height: "Height",
    cid: "Message ID",
    block_time: "Time",
    from: "From",
    to: "To",
    value: "Value",
    method_name: "Method",
    //chain
    blocks_cid: "Cid",
    blocks_miner: "Storage Provider",
    blocks_messages: "Message",
    blocks_reward: "Reward",
    win_count: "WinCount",
    //cid_details
    message_list_total: "Latest {{value}} Messages",
    chain_cid_detail: "Block details",
    cid_height: "Height",
    parent_weight: "Parent Weight",
    parents_cid: "Parent CID",
    parent_base_fee: "Parent BaseFee Rate",
    ticket_value: "Ticket",
    state_root: "State Root",
    //message 
    message_list: "Message List",
    total_list: "Latest {{value}} Messages",
    message_list_all: "All Methods",
    message_list_exit_code: "Status",
    // adress
    address_all: "All Types",
    address_total_list: "Total of {{value}} Accounts",
    account: "account",
    owner: "owner",
    miner: "node",
    payment: "payment",
    multisig: "multisig",
    address_list: "Wealth Ranking",
    account_address: "Address",
    balance_percentage: "Balance/Percentage",
    account_type: "Status",
    latest_transfer_time: "Last Seen Time",
    //transfer
    transfer_list: "Large Amount Transfer",
    transfer_total_list: "Total of {{value}} Message",
    //dsn
    dsn_list: "Order List",
    dsn_total_list: "Total of {{value}} Deals",
    dsn_placeholder: "Search Client/Provider/DealID",
    deal_id: "Deal ID",
    piece_cid: "Piece CID",
    piece_size: "PieceSize",
    client_address: "Client",
    provider_id: "Provider",
    service_start_time: "Start Time",
    end_time: "End Time",
    start_height: "Start Height",
    end_height: "End Height",
    storage_price_per_height: "Storage Fee",
    verified_deal: "Verified Deal",
    // pool-message
    pool_list: "Message Pool List",
    gas_fee_cap: "Gas Limit",
    gas_premium: "Gas Premium"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (tipset);


/***/ }),

/***/ 7626:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2021);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7987);
/* harmony import */ var _en_nav_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8148);
/* harmony import */ var _zh_nav_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7932);
/* harmony import */ var _zh_home_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4363);
/* harmony import */ var _en_home_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7005);
/* harmony import */ var _zh_statistic_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(596);
/* harmony import */ var _en_statistic_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3759);
/* harmony import */ var _zh_rank_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5302);
/* harmony import */ var _en_rank_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3279);
/* harmony import */ var _zh_tipset_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5636);
/* harmony import */ var _en_tipset__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(192);
/* harmony import */ var _zh_detail__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(929);
/* harmony import */ var _en_detail__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1329);
/* harmony import */ var _ja_nav__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7349);
/* harmony import */ var _ja_home__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3144);
/* harmony import */ var _ja_statistic__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6496);
/* harmony import */ var _zh_fvm_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8593);
/* harmony import */ var _en_fvm__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1641);
/* harmony import */ var _zh_contract_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1014);
/* harmony import */ var _en_contract_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(6599);
/* harmony import */ var _zh_domain_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(1628);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_1__]);
([i18next__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


//import LanguageDetector from 'i18next-browser-languagedetector'




















i18next__WEBPACK_IMPORTED_MODULE_0__["default"].use(react_i18next__WEBPACK_IMPORTED_MODULE_1__.initReactI18next).init({
    resources: {
        en: {
            nav: _en_nav_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
            home: _en_home_js__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
            static: _en_statistic_js__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
            rank: _en_rank_js__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
            tipset: _en_tipset__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z,
            detail: _en_detail__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z,
            fvm: _en_fvm__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z,
            contract: _en_contract_js__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z
        },
        zh: {
            nav: _zh_nav_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
            home: _zh_home_js__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
            static: _zh_statistic_js__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
            rank: _zh_rank_js__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
            tipset: _zh_tipset_js__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
            detail: _zh_detail__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z,
            fvm: _zh_fvm_js__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z,
            contract: _zh_contract_js__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z,
            domain: _zh_domain_js__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z
        },
        ja: {
            nav: _ja_nav__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z,
            home: _ja_home__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z,
            static: _ja_statistic__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z
        }
    },
    fallbackLng: "en",
    debug: true,
    react: {
        useSuspense: false
    },
    detection: {
        order: [
            "querystring",
            "navigator",
            "localStorage"
        ],
        lookupQuerystring: "lang"
    }
});
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (i18n)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const home = {
    minutes: "分",
    hours: "时",
    day: "天",
    //meta
    meta_title: "全ネットワークのデータ指標",
    mata_show: "展開",
    mata_show_false: "片付け",
    latest_height: "最新のブロックのチップセット",
    latest_block_time: "最新のブロック時間",
    total_blocks: "ネットワーク全体で生成されるブロック数",
    total_rewards: "ネットワーク全体の報酬をブロック",
    total_quality_power: "全ネットーワークの有効計算力 ",
    total_quality_power_tip: "現在全ネットーワークの有効計算力（有効なストレージスペース）の合計",
    base_fee: "現在の基本レート",
    miner_initial_pledge: "現在のセクター誓約額",
    power_increase_24h: "直近24h増加した計算力",
    rewards_increase_24h: "直近24hブロックジェネレーション報酬",
    fil_per_tera_24h: "直近24時間のマイニング効率",
    fil_per_tera_24h_tip: "直近24時間の合計ブロックジェネレーション報酬と有効計算力の割合",
    gas_in_32g: "32GiBディスクセクターGas消耗 ",
    gas_in_32g_tip: "密閉の32Gディスクセクター每にT消耗必要なGas値",
    add_power_in_32g: "32GiBディスクセクターの新たに増加する計算力コスト ",
    add_power_in_32g_tip: "32Gディスクセクターの新たに増加する計算力がかかるコストは，ディスクセクター抵当とパッケージ化の手数料を含む",
    gas_in_64g: "64GiBディスクセクターGas消耗",
    gas_in_64g_tip: "密閉の64GディスクセクターTあたり消耗必要なGas値",
    add_power_in_64g: "64GiBディスクセクターの新たに増加する計算力コスト",
    add_power_in_64g_tip: "64Gディスクセクターの新たに増加する計算力がかかるコストは，ディスクセクター抵当とパッケージ化の手数料を含む",
    win_count_reward: "勝利ごとの報酬",
    win_count_reward_tip: "最新の高さの単位ブロック報酬、各高さには複数のブロックがあり、各ブロックはこの報酬を得ることができます",
    avg_block_count: "平均のチップセットごとのブロック数",
    avg_block_count_tip: "直近24h平均のチップセットごとのブロック数",
    avg_message_count: "高さあたりの平均メッセージ数",
    avg_message_count_tip: "過去 24 時間の各高さでのメッセージの平均数",
    active_miners: "アクティブなマイナー数",
    burnt: "破壊された量",
    circulating_percent: "流通率",
    rank: "ランキング"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (home);


/***/ }),

/***/ 7349:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const zh = {
    network_title: "現在のネットワーク",
    home: "ホームページ",
    tipset: "ブロックチェーン",
    tipset_chain: "ブロック",
    tipset_message: "メッセージ",
    tipset_ranking: "富豪ランキング",
    tipset_transfer: "大量振込",
    tipset_dsn: "オーダー",
    "tipset_pool-message": "メッセージプール",
    ranking: "ランキング",
    statistics: "統計",
    statistics_gas: "Gas費用トレンド",
    statistics_base: "ベースラインと計算力トレンド",
    statistics_fil: "FIL",
    statistics_charts: "チャート統計",
    statistics_map: "节点地图",
    resources: "資源",
    resources_tools: "常用ツール",
    provider: "ストレージプロバイダ",
    //search 
    "search_holder": "アドレスを入力ください/メッセージID/チップセット/ブロックCid/ノートID",
    all: "全てのフィルタータイプ",
    address: "アドレス",
    message_id: "メッセージID",
    height: "チップセット",
    cid: "ブロックCid",
    node: "ノートID"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (zh);


/***/ }),

/***/ 6496:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const statistic = {
    show_more: "更なる",
    "24h": "24時間",
    "7d": "7日間",
    "30d": "30日",
    year: "1年",
    // power 
    "power": "ベースラインとハッシュレートの傾向",
    power_tips: "ベースライン基準は、Filecoinに要求されるネットワーク成長規模であり、メインネットがオンラインになったときに2.5EiBであり、年間成長率は100％となる。",
    trend_24: "24h基础手续费走势",
    total_raw_byte_power: "全ネットーワークの計算力",
    base_line_power: "ベースライントレンド",
    change_quality_adj_power: "リング間の実効計算能力",
    total_quality_adj_power: "計算能力を高める",
    gas: "基本手数料トレンド",
    base_fee: "基本手数料",
    gas_in_32g: "32GiBディスクセクターGas消耗",
    gas_in_64g: "64GiBディスクセクターGas消耗",
    //24_gas
    gas_24: "24h Gas データ",
    method_name: "メッセージタイプ",
    avg_gas_premium: "Gas Premium",
    avg_gas_limit: "平均Gas制限",
    avg_gas_used: "平均Gas消耗",
    avg_gas_fee: "平均手数料",
    "sum_gas_fee/ratio": "手数料合計/割合",
    "message_count/ratio": "メッセージ数合計/割合",
    //fil
    TokenRules: "Filecoinトークンの割り当てルール",
    FilecoinFoundation: "Filecoin基金会",
    FundraisingRemainder: "募资 – 剩余通证",
    FundraisingSAFT: "募资 – 未来通证简单协议",
    MiningReserve: "为存储服务提供者预留通证",
    TokenAllocation: "存储提供者通证分配",
    ReservedTokens: "存储提供者预留通证",
    Fundraising: "募资形式 – 未来通证简单协议 2017",
    Funds: "募资形式 – 剩余资金",
    protocolLab: "协议实验室",
    Contributors: "协议实验室团队和贡献者",
    Allocation: "分配项目",
    value: "数额",
    description: "具体用途",
    filBase: "FIL的基础发放",
    filBase_des: "网络FIL铸造上限",
    ReservedTokens_des: "为未来Filecoin经济增长而预留的通证储备，具体未来使用方案由Filecoin社区决定",
    TokenAllocation_des: "通过区块奖励、网络初始化等方式分给存储提供者的通证奖励",
    Fundraising_des: "2017年出售的通证",
    Funds_des: "用作生态发展和后续融资",
    protocolLab_des: "用作协议实验室的相关工作",
    Contributors_des: "4.5%给协议实验室团队和贡献者",
    //charts 
    pie_title: "图表统计",
    block_trend: "区块奖励",
    block_reward_per_TiB: "产出效率",
    acc_block_rewards: "累计区块奖励",
    active_nodes: "活跃节点数",
    active_miner_count: "节点数量",
    messages_trend: "消息数走势图",
    message_count: "单消息走势",
    all_message_count: "总消息走势"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (statistic);


/***/ }),

/***/ 1014:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const contract = {
    overview: "概览",
    market: "Market",
    next: "下一步",
    reset: "重置",
    confirm: "验证并发布",
    back: "返回",
    file_name: "选择 *.sol 文件",
    verify_title: "验证并发布合约源代码",
    verify_des: "编译器类型和版本选择",
    content_des: "源代码验证为与智能合约交互的用户提供了透明度。通过上传源代码，Filscan 将编译后的代码与区块链上的代码进行匹配。就像合同一样，“智能合同”应该为最终用户提供更多关于他们“数字签名”的目的的信息，并让用户有机会审核代码以独立验证它是否确实做了它应该做的事情。",
    address: "请输入您要验证的合约地址",
    address_placeholder: "请输入您要验证的合约地址",
    verify_address: "请选择编译版本",
    verify_address_placeholder: "请选择",
    license_type: "请输入开源许可证类型",
    content_des1: "1. 如果合同在 REMIX 处编译正确，则此处也应编译正确",
    content_des2: "2. 我们对验证由另一个合约创建的合约的支持有限，编译的每个合约的超时时间最多为45秒",
    content_des3: "3. 对于编程合同验证，请查看合同 API 端点",
    checkbox_service: "我同意服务条款",
    verify_select_placeholder: "请选择",
    //logs
    ver_sucess: "Success: 验证成功",
    ver_err: "Error: 验证失败",
    byte_code: "编译日志",
    contract_name: "合约名",
    local_byte_code: "合约字节码",
    compiler: "编译器版本",
    //step1
    address_verify: "合约地址",
    step1_verify_des: "请选择单个或多个 *.SOL 文件",
    source_code: "合约源码",
    compile_version: "编译器",
    compile_output: "编译输出",
    Optimizations: "优化参数",
    run_optimizer: "运行(优化器)",
    arguments: "构造函数参数",
    optimize: "优化开启",
    optimize_runs: "RUNS",
    //token list 
    token_list: "全部通证",
    token_name: "Token",
    vol_24: "成交量(24h)",
    transfer_total: "共 {{value}} 条消息",
    owner_total: "总共 {{value}} 人持有",
    dex_total: "共 {{value}} 条交易",
    //nft list 
    nfts_list: "全部 NFTs",
    trading_volume: "全部成交量",
    // ft /fns dashborad
    "total_supply": "MAX总供应量",
    "owners": "持有人",
    "transfers": "总共转移",
    latest_price: "价格",
    market_value: "市值",
    token_contract: "通证合约",
    transfer: "转移",
    owner: "拥有者",
    domain: "合约",
    dex: "DEX 交易",
    //list 
    message_cid: "消息ID",
    method: "Method",
    time: "时间",
    from: "发送地址",
    to: "接收地址",
    amount: "数量",
    //拥有者
    rank: "排行",
    percentage: "百分率",
    //dex
    platform: "交易平台",
    Txn_Value: "Txn Value",
    "swapped_Rate": "Swapped Rate",
    "Token_Amount_in": "Token Amount(In)",
    "Token_Amount_out": "Token Amount(Out)",
    Action: "Action"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contract);


/***/ }),

/***/ 929:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// pool-detail 
const detail = {
    "24h": "24时",
    "7d": "7天",
    "30d": "30天",
    "1year": "1年",
    //owner
    "owner_title": "存储池详情",
    "owner_title_tip": "存储池详情：存储池数据由名下节点数据,汇总而成",
    message_list_all: "全部方法",
    account: "账户",
    owner_address: "Owner地址",
    owned_miners: "名下节点",
    owned_active_miners: "名下活跃节点",
    miner: "Miner",
    evm: "EVM",
    ethaddress: "ETHAddress",
    ethaccount: "ETHAccount",
    //account_type
    account_name: "账户",
    latest_transfer_time: "最新交易时间",
    multisig: "多签账户",
    account_detail: "储存池详情",
    from_ath: "发送方",
    to_ath: "接受方",
    account_id: "账户地址",
    //概览
    owner_overview_title: "存储池概览",
    balance: "账户余额",
    available_balance: "可用余额",
    init_pledge: "扇区质押",
    pre_deposits: "预存款",
    locked_balance: "锁仓奖励",
    sector_count: "全部",
    live_sector_count: "有效",
    fault_sector_count: "错误",
    recover_sector_count: "恢复",
    eth_address: "ETH Address",
    stable_address: "稳定地址",
    //统计指标
    indicators: "统计指标",
    power_increase_indicators: "算力增量",
    power_ratio: "算力增速",
    sector_increase: "扇区增量",
    precommit_deposits: "扇区抵押",
    gas_fee: "Gas消耗",
    block_rewards: "出块奖励",
    block_count: "出块数量",
    block_count_tip: "出块数 = 出块数量（block）的总和",
    mining_efficiency: "效率",
    mining_efficiency_tip: "选定周期内，节点累计出块奖励与有效算 力的比值",
    lucky: "幸运值",
    sector_ratio: "扇区增速",
    sector_ratio_tip: "",
    win_count: "赢票数量",
    win_count_tip: "Filecoin经济模型中，一个高度 （tipset）下可能有多个区块（block），每 个区块可能获得多份奖励（win count）。 累计出块份数=每次出块获得奖励份数的总和",
    net_profit_per_tb: "单T消耗",
    net_profit_per_tb_tip: "选定周期内单T封装扇区大小Gas消耗",
    //账户变化
    owner_account_change: "账户变化",
    power: "有效算力",
    power_increase: "有效算力增长",
    quality_adjust_power: "有效算力",
    quality_power_rank: "排名",
    raw_power_percentage: "算力占比",
    raw_power: "原值算力",
    total_block_count: "30天出块数",
    total_block_count_tip: "近30天总出块数",
    total_reward: "30天奖励",
    total_reward_tip: "近30天奖励",
    total_win_count: "30天赢票",
    total_win_count_tip: "近30天总赢票",
    sector_size: "扇区大小",
    sector_stauts: "扇区状态",
    //账户总览
    account_overview: "账户总览",
    create_time: "创建时间",
    account_type: "账户类型",
    peer_id: "节点标识",
    account_address: "地址",
    owner_address: "Owner",
    area: "地区",
    worker_address: "Worker",
    controllers_address: "Controller",
    beneficiary_address: "Beneficiary",
    code_cid: "代码 CID",
    nonce: "Nonce 数",
    //miner 
    //pool_overview_title:'账户',
    // message
    message_overview_detail: "交易明细",
    trade: "内部交易",
    message_detail: "概况",
    event_log: "事件日志",
    message_overview: "消息概览",
    eth_message: "ETH Hash",
    cid: "消息ID",
    height: "高度",
    time: "时间",
    blk_cids: "区块",
    value: "金额",
    from: "发送地址",
    to: "接收地址",
    status: "状态",
    method_name: "方法",
    message_other: "其他信息",
    version: "版本编号",
    nonce: "Nonce",
    gas_fee_cap: "手续费率上限",
    gas_premium: "节点小费费率",
    gas_limit: "Gas用量上限",
    gas_used: "Gas实际用量",
    base_fee: "基础手续费率",
    all_gas_fee: "手续费",
    params: "参数",
    returns: "返回值",
    message_tranf: "转账信息",
    from_tranf: "发送方",
    to_tranf: "接受方",
    consume_type: "类型",
    MinerTip: "节点手续费",
    BaseFeeBurn: "销毁手续费",
    Transfer: "转账",
    Burn: "销毁聚合费用",
    exit_code: "状态",
    //内部交易
    amount: "价值",
    method: "方法",
    topic: "主题",
    //通证转移
    message_ERC20Trans: "通证转移",
    // 出块列表
    block_cid: "区块Cid",
    block_height: "区块高度",
    block_time: "出块时间",
    block_messages_count: "消息数",
    block_miner_id: "节点地址",
    block_mined_reward: "出块奖励",
    //miner
    message_list: "消息列表",
    block_list: "出块列表",
    traces_list: "转账列表",
    message_list_total: "共 {{value}} 条消息",
    block_list_total: "总计 {{value}} 区块",
    traces_list_total: "总计 {{value}} 条消息",
    //general 
    general_overview_title: "账户概览",
    base_account_id: "账户ID",
    //dns detail 
    deal_details: "区块详情",
    deal_id: "交易ID",
    epoch: "所属区块",
    service_start_time: "创建时间",
    message_cid: "所属消息",
    piece_cid: "Piece CID",
    verified_deal: "已验证",
    deal_hosting: "托管详情",
    deal_left_title: "客户",
    deal_right_title: "托管节点",
    deal_value: "质押金额",
    deal_cash: "托管费用",
    deal_time: "至"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (detail);


/***/ }),

/***/ 1628:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const domain = {
    domain_title: "Overview",
    resolved_address: "解析地址",
    expired_at: "过期时间",
    registrant: "注册人",
    controller: "控制人"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (domain);


/***/ }),

/***/ 8593:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fvm = {
    fvm_all: "FVM生态项目总览",
    Defi: "Defi",
    Dex: "Dex",
    DID: "DID",
    NFT: "NFT",
    MarketPlace: "MarketPlace",
    Launchpad: "Launchpad"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fvm);


/***/ }),

/***/ 4363:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const home = {
    seconds: "秒",
    minutes: "分",
    hours: "时",
    day: "天",
    //meta
    meta_title: "全网数据指标",
    mata_show: "展开",
    mata_show_false: "收起",
    latest_height: "最新区块高度",
    latest_block_time: "最新区块时间",
    total_blocks: "全网出块数量",
    total_rewards: "全网出块奖励",
    total_quality_power: "全网有效算力",
    total_quality_power_tip: "当前全网有效算力（有效存储空间）的总和",
    base_fee: "当前基础费率",
    miner_initial_pledge: "当前扇区质押量",
    power_increase_24h: "近24h增长算力",
    rewards_increase_24h: "近24h出块奖励",
    fil_per_tera_24h: "近24h产出效率",
    fil_per_tera_24h_tip: "最近24小时的总出块奖励与有效算力的比值",
    gas_in_32g: "32GiB扇区Gas消耗",
    gas_in_32g_tip: "近24小时密封32G扇区每T所要消耗的Gas值",
    add_power_in_32g: "预估32GiB扇区新增算力成本",
    add_power_in_32g_tip: "近24小时32G扇区新增算力所需要花费的成本，包括扇区质押和封装手续费",
    gas_in_64g: "64GiB扇区Gas消耗",
    gas_in_64g_tip: "近24小时密封64G扇区每T所要消耗的Gas值",
    add_power_in_64g: "预估64GiB扇区新增算力成本",
    add_power_in_64g_tip: "近24小时64G扇区新增算力所需要花费的成本，包括扇区质押和封装手续费",
    win_count_reward: "每赢票奖励",
    win_count_reward_tip: "最新高度的单位出块奖励，每个高度有多个区块，每个区块均可获得该奖励",
    avg_block_count: "平均每高度区块数量",
    avg_block_count_tip: "最近24h平均每个高度下的区块数量",
    avg_message_count: "平均每高度消息数",
    avg_message_count_tip: "最近24h平均每个高度下的消息数量",
    active_miners: "活跃节点数",
    burnt: "销毁量",
    circulating_percent: "流通率",
    rank: "排行榜",
    footer_text: "Filscan浏览器是 Filecoin 区块链浏览器及数据服务平台，提供基于 Filecoin 的各类收节点收益排行榜、区块链数据查询、可视化图表等一站式数据服务。",
    footer_outlook: "邮箱",
    footer_detail_a: "版权所有 \xa9 Filecoin开发补助计划 遵循",
    footer_detail_b: " 和 ",
    footer_detail_c: "版权协议",
    search_notFound: "搜索无结果",
    warn_text: "Oops! 您输入的搜索字符:",
    warn_details: "对不起！这是一个无效的字符串",
    go_home: "返回首页"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (home);


/***/ }),

/***/ 7932:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const zh = {
    network_title: "当前网络",
    home: "首页",
    contract: "合约",
    contract_verify: "合约验证",
    token: "Tokens",
    nft: "NFTS",
    tipset: "区块链",
    tipset_chain: "区块",
    tipset_message: "消息",
    tipset_ranking: "富豪榜",
    tipset_transfer: "大额转账",
    tipset_dsn: "订单",
    "tipset_pool-message": "消息池",
    ranking: "排行榜",
    statistics: "统计",
    statistics_gas: "Gas费趋势",
    statistics_base: "算力走势",
    statistics_fil: "FIL",
    statistics_charts: "图表统计",
    statistics_map: "节点地图",
    resources: "资源",
    resources_tools: "常用工具",
    provider: "存储提供者",
    fvm: "FVM生态总览",
    //search 
    "search_holder": "请输入地址/消息ID/高度/区块Cid/节点ID",
    all: "全部筛选类型",
    address: "地址",
    message_id: "消息ID",
    height: "高度",
    cid: "区块CID",
    node: "节点"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (zh);


/***/ }),

/***/ 5302:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const rankZh = {
    pool: "存储池排行",
    provider: "节点排行",
    growth: "算力增速",
    rewards: "节点收益",
    "24h": "24时",
    week_days: "7天",
    month: "30天",
    select_rank_all: "全部扇区",
    select_rank_32: "32G 扇区",
    select_rank_64: "64G 扇区",
    more: "更多",
    rank_time: "上次更新时间为",
    // table columns title
    //存储池排行
    ranking: "排名",
    pool_owner: "Owner ID",
    pool_power: "有效算力",
    pool_efficiency_24h: "近24h产出效率",
    pool_increase_24h: "近24h算力增量",
    pool_block_count: "出块总数",
    pool_block_count_24h: "近24h出块总数",
    miner: "节点",
    // 节点排行
    provider_miner: "节点",
    provider_power_ratio: "有效算力/占比",
    provider_block_ratio: "近24h 出块/占比",
    provider_rewards_ratio: "近24h 奖励/占比",
    balance: "余额",
    //算力增速
    power_ratio: "算力增速",
    power_ratio_tip: "选定周期内，平均每天完成封装扇区的有效算力总和",
    quality_power_increase: "算力增量",
    quality_power_increase_tip: "选定周期内，节点的有效算力增量",
    quality_adj_power: "有效算力",
    raw_power: "原值算力",
    sector_size: "扇区大小",
    //节点收益
    "rewards/ratio": "出块奖励/占比",
    "rewards/ratio_tip": "在选定周期内，节点获得出块奖励与累计产出区块奖励的比值。",
    block_count: "出块数",
    winning_rate: "赢票率",
    block_count_tip: "Filecoin经济模型中，一个高度（tipset）下可能有多个区块（block），每个区块可能获得多份奖励（win count）。"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rankZh);


/***/ }),

/***/ 596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const statistic = {
    show_more: "更多",
    "24h": "24时",
    "7d": "7天",
    "30d": "30天",
    year: "1年",
    // power 
    "power": "算力走势",
    power_tips: "基线标准即是Filecoin网络要求的网络增长规模，主网上线时2.5EiB，每年100%增长率。",
    trend_24: "24h基础手续费走势",
    total_raw_byte_power: "原值算力",
    base_line_power: "基线走势",
    change_quality_adj_power: "环比有效算力变化",
    total_quality_adj_power: "有效算力",
    gas: "基础手续费走势",
    base_fee: "基础手续费",
    gas_in_32g: "32GiB 扇区Gas消耗",
    gas_in_64g: "64GiB 扇区Gas消耗",
    //24_gas
    gas_24: "24h Gas 数据",
    method_name: "消息类型",
    avg_gas_premium: "Gas Premium",
    avg_gas_limit: "平均Gas限额",
    avg_gas_used: "平均Gas消耗",
    avg_gas_fee: "平均手续费",
    "sum_gas_fee/ratio": "手续费合计/占比",
    "message_count/ratio": "消息数合计/占比",
    //fil
    TokenRules: "Filecoin通证分配细则",
    FilecoinFoundation: "Filecoin基金会",
    FundraisingRemainder: "募资 – 剩余通证",
    FundraisingSAFT: "募资 – 未来通证简单协议",
    MiningReserve: "为存储服务提供者预留通证",
    TokenAllocation: "存储提供者通证分配",
    ReservedTokens: "存储提供者预留通证",
    Fundraising: "募资形式 – 未来通证简单协议 2017",
    Funds: "募资形式 – 剩余资金",
    protocolLab: "协议实验室",
    Contributors: "协议实验室团队和贡献者",
    Allocation: "分配项目",
    value: "数额",
    description: "具体用途",
    filBase: "FIL的基础发放",
    filBase_des: "网络FIL铸造上限",
    ReservedTokens_des: "为未来Filecoin经济增长而预留的通证储备，具体未来使用方案由Filecoin社区决定",
    TokenAllocation_des: "通过区块奖励、网络初始化等方式分给存储提供者的通证奖励",
    Fundraising_des: "2017年出售的通证",
    Funds_des: "用作生态发展和后续融资",
    protocolLab_des: "用作协议实验室的相关工作",
    Contributors_des: "4.5%给协议实验室团队和贡献者",
    //charts 
    pie_title: "图表统计",
    block_trend: "区块奖励",
    block_reward_per_TiB: "产出效率",
    acc_block_rewards: "累计区块奖励",
    active_nodes: "活跃节点数",
    active_miner_count: "节点数量",
    messages_trend: "消息数走势图",
    message_count: "区块平均消息走势",
    all_message_count: "总消息走势",
    pie_title_a: "当前Fil的基础发放用途统计",
    pie_title_a_tip: "已提供存储者奖励的Fil + 已释放锁仓奖励的Fil + 已分配保留部分的Fil = 当前已释放的Fil",
    pie_title_b: "当前已释放的Fil用途统计",
    mined: "已提供存储者奖励的Fil",
    remaining_mined: "剩余存储者奖励的Fil",
    vested: "已释放锁仓奖励的Fil	",
    remaining_vested: "剩余锁仓奖励的Fil",
    reserve_disbursed: "已分配保留部分的Fil(测试网奖励)",
    remaining_reserved: "剩余保留部分的Fil",
    locked: "扇区抵押的Fil",
    burnt: "已销毁的Fil",
    circulating: "可交易流通的Fil"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (statistic);


/***/ }),

/***/ 5636:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const tipset = {
    rank: "排名",
    tag: "标签",
    height: "区块高度",
    cid: "消息ID",
    block_time: "时间",
    from: "发送地址",
    to: "接收地址",
    value: "数额",
    method_name: "方法",
    //chain
    blocks_cid: "Cid",
    blocks_miner: "节点",
    blocks_messages: "消息",
    blocks_reward: "奖励",
    win_count: "赢票",
    //cid_details
    message_list_total: "共 {{value}} 条消息",
    chain_cid_detail: "区块详情",
    cid_height: "高度",
    parent_weight: "父块重量",
    parents_cid: "父块CID",
    parent_base_fee: "父基础费率",
    ticket_value: "票值",
    state_root: "根",
    //message 
    message_list: "消息列表",
    total_list: "共 {{value}} 条消息",
    message_list_all: "全部方法",
    message_list_exit_code: "状态",
    message_list_method_name: "方法名称",
    // adress
    address_total_list: "共有 {{value}} 账户",
    address_list: "富豪榜",
    address_all: "全部类型",
    account: "一般账户",
    owner: "所有者账户",
    miner: "节点账户",
    payment: "支付通道",
    multisig: "多签账户",
    account_address: "地址",
    balance_percentage: "余额/占比",
    account_type: "类型",
    latest_transfer_time: "最新交易时间",
    //transfer
    transfer_list: "大额转账记录",
    transfer_total_list: "共有 {{value}} 条信息",
    //dsn
    dsn_list: "订单列表",
    dsn_total_list: "共 {{value}} 条交易",
    dsn_placeholder: "搜素 客户/托管者/交易ID",
    deal_id: "交易ID",
    piece_cid: "文件ID",
    piece_size: "文件大小",
    client_address: "客户",
    provider_id: "托管者",
    service_start_time: "开始时间",
    end_time: "结束时间",
    start_height: "开始高度",
    end_height: "结束高度",
    storage_price_per_height: "存储费用",
    verified_deal: "已验证",
    // pool-message
    pool_list: "消息池列表",
    gas_fee_cap: "Gas限额",
    gas_premium: "Gas Premium"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (tipset);


/***/ }),

/***/ 3738:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_nav__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2263);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3435);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _assets_images_mobile_menuup_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(931);
/* harmony import */ var _assets_images_mobile_menudown_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1826);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7987);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_6__]);
react_i18next__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










function Menu() {
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "nav"
        });
    };
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const [showMenu, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [select, setSelect] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const handleClick = (link)=>{
        if (link) router.push(link);
        setShow(false);
    };
    const renderMenu = (menuItem)=>{
        return menuItem === null || menuItem === void 0 ? void 0 : menuItem.map((child)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu_ul_item_li),
                onClick: ()=>handleClick(child.link),
                children: tr(child.key)
            });
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                src: showMenu ? _assets_images_mobile_menudown_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z : _assets_images_mobile_menuup_png__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                alt: "menu",
                onClick: ()=>{
                    setShow(!showMenu);
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu_ul),
                style: {
                    display: showMenu ? "block" : "none"
                },
                children: _contants_nav__WEBPACK_IMPORTED_MODULE_1__/* .navMenu.map */ .$.map((menu, index)=>{
                    if (menu.childrens) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu_ul_item),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu_ul_item_select),
                                    onClick: ()=>{
                                        setSelect(select === menu.key ? "" : menu.key);
                                    },
                                    children: [
                                        tr(menu.key),
                                        " ",
                                        select === menu.key ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_7__.UpOutlined, {
                                            rev: undefined
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_7__.DownOutlined, {
                                            rev: undefined
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    style: {
                                        display: select === menu.key ? "block" : "none"
                                    },
                                    children: renderMenu(menu.childrens)
                                })
                            ]
                        }, index);
                    }
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu_ul_item),
                        onClick: ()=>handleClick(menu.link),
                        children: tr(menu.key)
                    }, index);
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu_mask),
                style: {
                    display: showMenu ? "block" : "none"
                },
                onClick: ()=>{
                    setShow(false);
                }
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Menu);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 521:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var _contants_nav__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2263);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3435);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1311);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9189);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_3__, _store_server__WEBPACK_IMPORTED_MODULE_6__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_3__, _store_server__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const [input, setInput] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [select, setSelect] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const handleSearch = ()=>{
        (0,_store_server__WEBPACK_IMPORTED_MODULE_6__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_7__/* .apiUrl.searchInfo */ .J.searchInfo, {
            input,
            input_type: select
        }).then((res)=>{
            var _res_result, _res_result1, _res_result_search_result;
            const result = (res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.search_result.result) || {};
            const type = res === null || res === void 0 ? void 0 : (_res_result1 = res.result) === null || _res_result1 === void 0 ? void 0 : (_res_result_search_result = _res_result1.search_result) === null || _res_result_search_result === void 0 ? void 0 : _res_result_search_result.result_type;
            if (type) {
                if (type === "owner") {
                    //owner 
                    next_router__WEBPACK_IMPORTED_MODULE_8___default().push(`/owner/${input}`);
                } else if (type === "basic") {
                    next_router__WEBPACK_IMPORTED_MODULE_8___default().push(`/address/${input}`);
                }
            }
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_search),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_5__.Input, {
            bordered: false,
            className: "custom_input",
            placeholder: t(_contants_nav__WEBPACK_IMPORTED_MODULE_4__/* .search.holder */ .y.holder, {
                ns: "nav"
            }) || "",
            onPressEnter: handleSearch,
            onChange: (e)=>{
                setInput(e.target.value);
            },
            suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__.SearchOutlined, {
                className: "antd-icon",
                onClick: handleSearch,
                rev: undefined
            })
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4442:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_images_logo_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2822);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3435);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(521);
/* harmony import */ var _Menu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3738);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Search__WEBPACK_IMPORTED_MODULE_3__, _Menu__WEBPACK_IMPORTED_MODULE_4__]);
([_Search__WEBPACK_IMPORTED_MODULE_3__, _Menu__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().mobile_header),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().mobile_header_top),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().mobile_header_top_image),
                        onClick: ()=>{
                            next_router__WEBPACK_IMPORTED_MODULE_5___default().push("/home");
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                src: _assets_images_logo_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                                alt: "Fliscan Logo",
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().mobile_header_logo)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().logo_title),
                                children: "Filscan"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().mobile_header_top_right),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Menu__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().mobile_header_bottom),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Search__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9956:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5537);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8194);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3775);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { options , defaultValue , border , warpClass , onChange , className , valueClass , value , ns  } = props;
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns
        });
    };
    const [label, setLabel] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (value || defaultValue) {
            const defaultItem = options.find((v)=>v.value === defaultValue || v.value === value);
            if (defaultItem) {
                setLabel(ns ? tr(defaultItem === null || defaultItem === void 0 ? void 0 : defaultItem.label) : defaultItem === null || defaultItem === void 0 ? void 0 : defaultItem.label);
            }
        }
    }, [
        value,
        defaultValue,
        filscanStore.filscan
    ]);
    const handleChange = (item)=>{
        setLabel(ns ? tr(item.label) : item.label);
        if (onChange) onChange(item);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().custom_select)} ${className} ${border ? (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().border_select) : ""}`,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().custom_select_value)} ${valueClass} `,
                children: [
                    label,
                    (0,_svgUtils__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)("down")
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().custom_select_contains)} ${warpClass} `,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().custom_select_wrap),
                    children: options.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            value: item.value + index,
                            onClick: ()=>handleChange(item),
                            children: ns ? tr(item.label) : item.label
                        }, item.value);
                    })
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3847:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_dist_reset_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9107);
/* harmony import */ var antd_dist_reset_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_dist_reset_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3716);
/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_common_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7526);
/* harmony import */ var _styles_common_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_common_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_custom_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6333);
/* harmony import */ var _styles_custom_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_custom_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _styles_media_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8644);
/* harmony import */ var _styles_media_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_media_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9980);
/* harmony import */ var _components_footer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8173);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8194);
/* harmony import */ var _mobile_header__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4442);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var antd_locale_en_US__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9656);
/* harmony import */ var antd_locale_en_US__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(antd_locale_en_US__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var antd_locale_zh_CN__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2771);
/* harmony import */ var antd_locale_zh_CN__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(antd_locale_zh_CN__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var dayjs_locale_zh_cn__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5468);
/* harmony import */ var dayjs_locale_zh_cn__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(dayjs_locale_zh_cn__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _components_links__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2875);
/* harmony import */ var _i18n__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7626);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(9927);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_20__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Header__WEBPACK_IMPORTED_MODULE_7__, _components_footer__WEBPACK_IMPORTED_MODULE_8__, _mobile_header__WEBPACK_IMPORTED_MODULE_11__, _i18n__WEBPACK_IMPORTED_MODULE_17__, _utils_utils__WEBPACK_IMPORTED_MODULE_18__]);
([_components_Header__WEBPACK_IMPORTED_MODULE_7__, _components_footer__WEBPACK_IMPORTED_MODULE_8__, _mobile_header__WEBPACK_IMPORTED_MODULE_11__, _i18n__WEBPACK_IMPORTED_MODULE_17__, _utils_utils__WEBPACK_IMPORTED_MODULE_18__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 




















function App({ Component , pageProps  }) {
    const { t , i18n  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_9__.useTranslation)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_19__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (router.asPath.includes("#")) {
            var _window_location;
            const a = router.asPath;
            window === null || window === void 0 ? void 0 : (_window_location = window.location) === null || _window_location === void 0 ? void 0 : _window_location.replace(a.replaceAll("/#", ""));
        }
    }, [
        router.asPath
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        dayjs__WEBPACK_IMPORTED_MODULE_12___default().locale("en");
    }, []);
    const [filscan, setFilscan] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
        theme: "light",
        lang: "en"
    });
    const [locale, setLocal] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)((antd_locale_zh_CN__WEBPACK_IMPORTED_MODULE_14___default()));
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        const filscan_local = localStorage.getItem("filscan");
        let new_filscan = {
            ...filscan
        };
        if (filscan_local) {
            const Obj = JSON.parse(filscan_local);
            if (Obj) {
                setFilscan({
                    ...Obj
                });
                i18n.changeLanguage(Obj.lang);
                handleChange(Obj);
                document.documentElement.setAttribute("theme", Obj.theme);
            }
        } else {
            const lang = navigator.language.startsWith("zh") ? "zh" : "en";
            if (lang !== filscan.lang) {
                setFilscan({
                    ...filscan,
                    lang: navigator.language.startsWith("zh") ? "zh" : "en"
                });
                i18n.changeLanguage(lang); // 更改i18n语言
            }
        }
    }, []);
    const handleChange = (item)=>{
        if (item.lang === "zh") {
            dayjs__WEBPACK_IMPORTED_MODULE_12___default().locale("zh-cn");
            setLocal((antd_locale_zh_CN__WEBPACK_IMPORTED_MODULE_14___default()));
        } else {
            dayjs__WEBPACK_IMPORTED_MODULE_12___default().locale("en");
            setLocal((antd_locale_en_US__WEBPACK_IMPORTED_MODULE_13___default()));
        }
        document.documentElement.setAttribute("theme", item.theme);
        setFilscan(item);
    };
    if ((0,_utils_utils__WEBPACK_IMPORTED_MODULE_18__/* .isMobile */ .tq)()) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_store_content__WEBPACK_IMPORTED_MODULE_10__/* ["default"].Provider */ .Z.Provider, {
            value: {
                filscan,
                setFilscan: handleChange
            },
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_20__.ConfigProvider, {
                    locale: locale,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mobile_header__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "main-container",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                ...pageProps
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footer__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_store_content__WEBPACK_IMPORTED_MODULE_10__/* ["default"].Provider */ .Z.Provider, {
        value: {
            filscan,
            setFilscan: handleChange
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_20__.ConfigProvider, {
            locale: locale,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    value: {
                        filscan,
                        setFilscan
                    }
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "main-container",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_links__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                            ...pageProps
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footer__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_router__WEBPACK_IMPORTED_MODULE_19__.withRouter)(App));
function aScript(aScript) {
    throw new Error("Function not implemented.");
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8194:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/** @format */ 
const FilscanState = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({
    theme: "light",
    lang: "zh-CN"
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FilscanState);


/***/ }),

/***/ 9107:
/***/ (() => {



/***/ }),

/***/ 7526:
/***/ (() => {



/***/ }),

/***/ 6333:
/***/ (() => {



/***/ }),

/***/ 3716:
/***/ (() => {



/***/ }),

/***/ 8644:
/***/ (() => {



/***/ }),

/***/ 7066:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5725:
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ 9656:
/***/ ((module) => {

"use strict";
module.exports = require("antd/locale/en_US");

/***/ }),

/***/ 2771:
/***/ ((module) => {

"use strict";
module.exports = require("antd/locale/zh_CN");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 5468:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs/locale/zh-cn");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 9766:
/***/ ((module) => {

"use strict";
module.exports = import("bignumber.js");;

/***/ }),

/***/ 2021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 7987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9210,3121,5675,676,1664,9189,9927,1311,3775], () => (__webpack_exec__(3847)));
module.exports = __webpack_exports__;

})();
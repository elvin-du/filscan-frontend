(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 3904:
/***/ ((module) => {

// Exports
module.exports = {
	"head": "Header_head__fdYAG",
	"top": "Header_top__G0l11",
	"top_content": "Header_top_content__AtyRO",
	"top_content_left": "Header_top_content_left__GS9Me",
	"logo": "Header_logo__vA21C",
	"logo_title": "Header_logo_title__XWYEz",
	"top_content_right": "Header_top_content_right__ZMED4",
	"top_content_right_old": "Header_top_content_right_old__fWFrA",
	"top_content_right_icon": "Header_top_content_right_icon__E3LQ7",
	"bottom": "Header_bottom__cudrP",
	"bottom_content": "Header_bottom_content__9RSUe",
	"navMenu": "Header_navMenu__1Q4fv",
	"navMenu_item": "Header_navMenu_item__UYMzf",
	"navMenu_wrap": "Header_navMenu_wrap__1TGC1",
	"navMenu_wrap_cont": "Header_navMenu_wrap_cont__9nOL3",
	"navMenu_wrap_cont_child": "Header_navMenu_wrap_cont_child__pZR4m",
	"navMenu_wrap_icon": "Header_navMenu_wrap_icon__JTK8J",
	"icon": "Header_icon__9WNTn",
	"select": "Header_select__qoSAh"
};


/***/ }),

/***/ 2684:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "footer_footer__pOtN3",
	"footer_top": "footer_footer_top__qm86m",
	"footer_bottom": "footer_footer_bottom__RRyDx",
	"footer_header": "footer_footer_header__4aXzc",
	"footer_header_logo": "footer_footer_header_logo__gNh__",
	"footer_header_title": "footer_footer_header_title__Wt_Gg",
	"footer_header_text": "footer_footer_header_text__vYz6E",
	"footer_header_text_outlook": "footer_footer_header_text_outlook__jUbL5"
};


/***/ }),

/***/ 3466:
/***/ ((module) => {

// Exports
module.exports = {
	"links": "links_links__pQM89",
	"links_item": "links_links_item__E7QK8"
};


/***/ }),

/***/ 9936:
/***/ ((module) => {

// Exports
module.exports = {
	"loading_wrap": "loading_loading_wrap__gdHDc"
};


/***/ }),

/***/ 7748:
/***/ ((module) => {

// Exports
module.exports = {
	"search": "search_search__KbbCM",
	"search_options": "search_search_options__ZbsYm",
	"search_input": "search_search_input__E6Odk",
	"search_input_svg": "search_search_input_svg__04IRw",
	"search_options_ul": "search_search_options_ul__LzeB7",
	"search_options_ul_li": "search_search_options_ul_li__wgwX4"
};


/***/ }),

/***/ 3435:
/***/ ((module) => {

// Exports
module.exports = {
	"mobile_header": "header_mobile_header__UpWEW",
	"mobile_header_top": "header_mobile_header_top__G0P5R",
	"mobile_header_top_image": "header_mobile_header_top_image__Wvwyg",
	"mobile_header_top_right": "header_mobile_header_top_right__q9wSQ",
	"mobile_header_logo": "header_mobile_header_logo__Kabx1",
	"mobile_menu_ul": "header_mobile_menu_ul__uNO0n",
	"mobile_menu_ul_item": "header_mobile_menu_ul_item__6RAEW",
	"mobile_menu_ul_item_select": "header_mobile_menu_ul_item_select__B2pEF",
	"mobile_menu_ul_item_li": "header_mobile_menu_ul_item_li__YPZzc",
	"mobile_menu_mask": "header_mobile_menu_mask__ekY_T",
	"mobile_menu_modal": "header_mobile_menu_modal___Qnzm",
	"ant-modal-content": "header_ant-modal-content__cqOuP",
	"mobile_search": "header_mobile_search__X3bTS"
};


/***/ }),

/***/ 5537:
/***/ ((module) => {

// Exports
module.exports = {
	"custom_select": "selects_custom_select__rx9gZ",
	"custom_select_contains": "selects_custom_select_contains__8lHca",
	"border_select": "selects_border_select__arTOy",
	"custom_select_value": "selects_custom_select_value__LpcjI",
	"custom_select_wrap": "selects_custom_select_wrap__wdDf8"
};


/***/ }),

/***/ 2822:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-cn-hongkong.aliyuncs.com/client/_next/static/media/logo.c466b17b.svg","height":149,"width":139});

/***/ }),

/***/ 831:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-cn-hongkong.aliyuncs.com/client/_next/static/media/logo_a.55dc3968.svg","height":101,"width":310});

/***/ }),

/***/ 1826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-cn-hongkong.aliyuncs.com/client/_next/static/media/menudown.25b8c9c3.png","height":32,"width":46,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAQAAABUDBdwAAAAUElEQVR42jXMuw1FYABA4e/eRGMJid7jb8ygsIJBrOLRECtYQWIGs6AQOfX52N0ut7eDoFbJFHJBAjRWvdGsI0JrMxksOviDVFB+y0/sfNEHka4UFfl/TNsAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 931:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-cn-hongkong.aliyuncs.com/client/_next/static/media/menuup.b256d6d3.png","height":32,"width":46,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAQAAABUDBdwAAAAT0lEQVR42iXBuw1FUAAA0PNeorGERO9zGzMorGAQq/g0xApWkJjBLK7COcBP6hZFF/xBLqhlJOgdFpPNAHR2o9lqIGg1CpVSkHGKHtH3egEfExQVb3g9EwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 3712:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

class ErrorBoundary extends react__WEBPACK_IMPORTED_MODULE_0__.Component {
    state = {
        hasError: false
    };
    static getDerivedStateFromError(_) {
        // Update state so the next render will show the fallback UI.
        return {
            hasError: true
        };
    }
    componentDidCatch(error, errorInfo) {
        console.error("Uncaught error:", error, errorInfo);
    }
    render() {
        if (this.state.hasError) {
            return this.props.fallback;
        }
        return this.props.children;
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorBoundary);


/***/ }),

/***/ 3824:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7987);
/* harmony import */ var _contants_nav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2263);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3904);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5063);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3775);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_1__]);
react_i18next__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 





function NavMenu() {
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "nav"
            });
        }
        return t(label, {
            ns: "nav"
        });
    };
    const renderMenu = (data)=>{
        return data.map((menuItem, index)=>{
            if (menuItem.childrens) {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().navMenu_wrap)}`,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().navMenu_item)}`,
                            children: [
                                (menuItem === null || menuItem === void 0 ? void 0 : menuItem.preIcon) && (0,_svgUtils__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)(menuItem.preIcon),
                                tr(menuItem.key),
                                (0,_svgUtils__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)("down"),
                                (menuItem === null || menuItem === void 0 ? void 0 : menuItem.sufIcon) && (0,_svgUtils__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)(menuItem.sufIcon)
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().navMenu_wrap_cont)}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().navMenu_wrap_cont_child)}`,
                                children: renderMenu(menuItem.childrens)
                            }, menuItem.key)
                        })
                    ]
                }, index);
            }
            let showLink = menuItem.link ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                href: menuItem.link,
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().nav_menu_item_title)}`,
                children: [
                    "  ",
                    tr(menuItem.key),
                    " "
                ]
            }) : tr(menuItem.key);
            if (menuItem.outLink) {
                showLink = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    onClick: ()=>{
                        window.open(menuItem.outLink);
                    },
                    children: tr(menuItem.key)
                });
            }
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().navMenu_item)}`,
                children: [
                    (menuItem === null || menuItem === void 0 ? void 0 : menuItem.preIcon) && (0,_svgUtils__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)(menuItem.preIcon),
                    showLink,
                    (menuItem === null || menuItem === void 0 ? void 0 : menuItem.sufIcon) && (0,_svgUtils__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)(menuItem.sufIcon)
                ]
            }, menuItem.key);
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().navMenu),
        children: renderMenu(_contants_nav__WEBPACK_IMPORTED_MODULE_2__/* .navMenu */ .$)
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavMenu);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9980:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_images_logo_a_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(831);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3904);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var _NavMenu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3824);
/* harmony import */ var _components_search__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1517);
/* harmony import */ var _packages_selects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9956);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3775);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8194);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_3__, _NavMenu__WEBPACK_IMPORTED_MODULE_4__, _components_search__WEBPACK_IMPORTED_MODULE_5__, _packages_selects__WEBPACK_IMPORTED_MODULE_6__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_3__, _NavMenu__WEBPACK_IMPORTED_MODULE_4__, _components_search__WEBPACK_IMPORTED_MODULE_5__, _packages_selects__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 











function NavHead({ value  }) {
    var _process_env;
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const { filscan , setFilscan  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const hanleDark = ()=>{
        setFilscan({
            ...filscan,
            theme: filscan.theme === "dark" ? "light" : "dark"
        });
        localStorage.setItem("filscan", JSON.stringify({
            ...filscan,
            theme: filscan.theme === "dark" ? "light" : "dark"
        }));
    };
    const handleChange = (type, item)=>{
        if (type === "lang") {
            setFilscan({
                ...filscan,
                lang: item.value
            });
            router.push(router.asPath, router.asPath, {
                locale: item.value
            });
            i18n.changeLanguage(item.value); // 更改i18n语言
        }
        localStorage.setItem("filscan", JSON.stringify({
            ...filscan,
            lang: item.value
        }));
    // 切换网络
    };
    const apiFlag = (process === null || process === void 0 ? void 0 : (_process_env = process.env) === null || _process_env === void 0 ? void 0 : "https://api-v2.filscan.io/api/v1") === "http://192.168.1.189:27001/api/v1";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().head),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().top),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().top_content),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().top_content_left),
                            onClick: ()=>next_router__WEBPACK_IMPORTED_MODULE_10___default().push("/home"),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                src: _assets_images_logo_a_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                                alt: "Fliscan Logo",
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().logo)
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().top_content_right),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().top_content_right_old),
                                    onClick: ()=>{
                                        window.open("http://v1.filscan.io");
                                    },
                                    children: "Old Version"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    children: [
                                        t("network_title", {
                                            ns: "nav"
                                        }),
                                        ":"
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    defaultValue: apiFlag ? "Calibration" : "Mainnet",
                                    onChange: (item)=>{
                                        const value = item.value;
                                        if (value === "Calibration") {
                                            window.open("https://calibration.filscan.io/");
                                        } else if (value === "Mainnet") {
                                            window.open("https://filscan.io/");
                                        }
                                    },
                                    options: [
                                        {
                                            value: "Mainnet",
                                            label: "Mainnet"
                                        },
                                        {
                                            value: "Calibration",
                                            label: "Calibration"
                                        }
                                    ]
                                }, "network"),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    defaultValue: filscan.lang,
                                    className: `default_select ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().select)}`,
                                    onChange: (value)=>handleChange("lang", value),
                                    options: [
                                        {
                                            value: "zh",
                                            label: "中文"
                                        },
                                        {
                                            value: "en",
                                            label: "English"
                                        },
                                        {
                                            value: "kr",
                                            label: "한국인"
                                        }
                                    ]
                                }, "lang"),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().top_content_right_icon),
                                    onClick: hanleDark,
                                    children: filscan.theme === "dark" ? (0,_svgUtils__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("moonSvg") : (0,_svgUtils__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("sunSvg")
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().bottom),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().bottom_content),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavMenu__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_search__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavHead);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8173:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2684);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _assets_images_logo_a_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(831);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3775);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_3__]);
react_i18next__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 





const footerLinks = [
    {
        label: "twitter",
        type: "_blank",
        link: "https://twitter.com/FilscanOfficial"
    },
    {
        label: "telegram",
        type: "_blank",
        link: "https://t.me/+bI9fUEkmPjMzYjg1"
    },
    {
        label: "outlook",
        type: "_self",
        link: "mailto:filscan@ipfsforce.com"
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer_top),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer_header),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer_header_logo),
                            src: _assets_images_logo_a_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer_header_text),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    t("footer_text", {
                                        ns: "home"
                                    }),
                                    "  "
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer_header_text_outlook),
                                children: footerLinks.map((linkItem)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        target: linkItem.type,
                                        style: {
                                            color: "#fff"
                                        },
                                        href: linkItem.link,
                                        children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)(linkItem.label)
                                    }, linkItem.label);
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().footer_bottom),
                children: [
                    t("footer_detail_a", {
                        ns: "home"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "https://www.mit-license.org/",
                        target: "_blank",
                        children: " MIT"
                    }),
                    "     ",
                    t("footer_detail_b", {
                        ns: "home"
                    }),
                    "  ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "https://www.apache.org/licenses/LICENSE-2.0.html",
                        target: "_blank",
                        children: "Apache 2.0"
                    }),
                    "   ",
                    t("footer_detail_c", {
                        ns: "home"
                    }),
                    " ."
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2875:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3775);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3466);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_2__);



const footerLinks = [
    {
        label: "twitter",
        type: "_blank",
        link: "https://twitter.com/FilscanOfficial"
    },
    {
        label: "telegram",
        type: "_blank",
        link: "https://t.me/+bI9fUEkmPjMzYjg1"
    },
    {
        label: "outlook",
        type: "_self",
        link: "mailto:filscan@ipfsforce.com"
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_2___default().links),
        children: footerLinks.map((linkItem)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_2___default().links_item),
                target: linkItem.type,
                style: {
                    color: "#fff"
                },
                href: linkItem.link,
                children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)(linkItem.label)
            }, linkItem.label);
        })
    });
});


/***/ }),

/***/ 6571:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9936);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_2__);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_2___default().loading_wrap),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_1__.LoadingOutlined, {
            style: {
                fontSize: 36
            },
            rev: undefined
        })
    });
});


/***/ }),

/***/ 1517:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contants_nav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2263);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7748);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1311);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9189);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3775);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_3__, _store_server__WEBPACK_IMPORTED_MODULE_5__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_3__, _store_server__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 










/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const [input, setInput] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [select, setSelect] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const handleSearch = ()=>{
        const showInput = input.trim();
        if (input) {
            (0,_store_server__WEBPACK_IMPORTED_MODULE_5__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_6__/* .apiUrl.searchInfo */ .J.searchInfo, {
                input: showInput,
                input_type: select
            }).then((res)=>{
                var _res_result;
                const type = res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.result_type;
                if (type) {
                    if (type === "owner") {
                        //owner 
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/owner/${showInput}`);
                    } else if (type === "address") {
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/address/${showInput}`);
                    } else if (type === "height") {
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/tipset/chain?height=${showInput}`);
                    } else if (type === "message_details") {
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/message/${showInput}`);
                    } else if (type === "miner") {
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/miner/${showInput}`);
                    } else if (type === "block_details") {
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/tipset/chain?cid=${showInput}`);
                    } else if (type === "fns") {
                        var _res_result1;
                        if ((res === null || res === void 0 ? void 0 : (_res_result1 = res.result) === null || _res_result1 === void 0 ? void 0 : _res_result1.fns_tokens.length) > 0) {
                            var _res_result2;
                            setOptions(res === null || res === void 0 ? void 0 : (_res_result2 = res.result) === null || _res_result2 === void 0 ? void 0 : _res_result2.fns_tokens.map((v)=>({
                                    ...v,
                                    label: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                src: v.icon,
                                                alt: "",
                                                width: 45,
                                                height: 45,
                                                className: "logo_img"
                                            }),
                                            `${v.name}`
                                        ]
                                    }),
                                    value: v.provider
                                })));
                            setActive(type);
                        } else {
                            next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/domain/${showInput}`);
                        }
                    } else {
                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/address/${showInput}`);
                    }
                } else {
                    //404
                    next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/noResult/${showInput}`);
                }
            });
        }
    };
    const handleClick = (item)=>{
        setOptions([]);
        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/domain/${item.name}?provider=${item.value}`);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().search),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_4__.Input, {
                bordered: false,
                className: `custom_input ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().search_input)}`,
                placeholder: t(_contants_nav__WEBPACK_IMPORTED_MODULE_2__/* .search.holder */ .y.holder, {
                    ns: "nav"
                }) || "",
                onPressEnter: handleSearch,
                onChange: (e)=>{
                    setInput(e.target.value);
                    setOptions([]);
                },
                suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().search_input_svg),
                    onClick: handleSearch,
                    children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_8__/* .getSvgIcon */ .a)("searchIcon")
                })
            }),
            options && options.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().search_options),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().search_options_ul),
                    children: options.map((item)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().search_options_ul_li),
                            onClick: ()=>handleClick(item),
                            children: item.label
                        }, item.value);
                    })
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2263:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ navMenu),
/* harmony export */   "y": () => (/* binding */ search)
/* harmony export */ });
const navMenu = [
    {
        key: "home",
        link: "/home"
    },
    {
        key: "tipset",
        childrens: [
            {
                key: "tipset_chain",
                link: "/tipset/chain/"
            },
            {
                key: "tipset_message",
                link: "/tipset/message-list/"
            },
            {
                key: "tipset_ranking",
                link: "/tipset/address-list/"
            },
            {
                key: "tipset_dsn",
                link: "/tipset/dsn/"
            },
            {
                key: "tipset_pool-message",
                link: "/tipset/pool-message/"
            }
        ]
    },
    {
        key: "contract",
        preIcon: "newIcon",
        color: "#F44C30",
        childrens: [
            {
                key: "token",
                link: "/contract/token/"
            },
            {
                key: "nft",
                link: "/contract/nft/"
            },
            {
                key: "contract_list",
                link: "/contract/list/"
            },
            {
                key: "contract_rank",
                link: "/contract/rank/"
            },
            {
                key: "contract_verify",
                link: "/contract/verify/"
            }
        ]
    },
    {
        key: "ranking",
        link: "/rank"
    },
    {
        key: "statistics",
        childrens: [
            {
                key: "statistics_gas",
                link: "/statistics/gas"
            },
            {
                key: "statistics_base",
                link: "/statistics/power"
            },
            {
                key: "statistics_fil",
                link: "/statistics/fil"
            },
            {
                key: "statistics_charts",
                link: "/statistics/charts"
            }
        ]
    },
    // {
    //     key: 'resources',
    //     childrens: [
    //         { key: 'resources_tools' ,link:'resources/tools'},
    //     ]
    // }, 
    {
        key: "fvm",
        sufIcon: "hotIcon",
        color: "#F44C30",
        link: "/fvm"
    },
    {
        out_key: "provider",
        key: "provider",
        outLink: "http://v1.filscan.io/account?key=login"
    }
];
const search = {
    holder: "search_holder",
    opt: [
        {
            label: "all",
            value: "all"
        },
        {
            label: "address",
            value: "address"
        },
        {
            label: "message_id",
            value: "message_id"
        },
        {
            label: "height",
            value: "height"
        },
        {
            label: "cid",
            value: "cid"
        },
        {
            label: "node",
            value: "node"
        }
    ]
};



/***/ }),

/***/ 6599:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const contract = {
    overview: "Overview",
    market: "Market",
    look_adres: "View Account",
    gohome: "Go Home",
    reset_ver: "Revalidate",
    next: "Continue",
    reset: "Reset",
    confirm: "Verify&Publish",
    back: "Return to Main",
    file_name: "SELECT *.SOL FILES",
    config_file_name: "SELECT Metadata FILES",
    verify_title: "Verify & Publish Contract Source Code",
    verify_des: "COMPILER TYPE AND VERSION SELECTION",
    content_des: 'Source code verification provides transparency for users interacting with smart contracts. By uploading the source code, Filscan will match the compiled code with that on the blockchain. Just like contracts, a "smart contract" should provide end users with more information on what they are "digitally signing" for and give users an opportunity to audit the code to independently verify that it actually does what it is supposed to do.',
    address: "Please Enter Contract Address to Verify",
    address_placeholder: "Please enter the Contract Address",
    verify_address: "Please Enter Complier Version to Verify",
    verify_address_placeholder: "Please select",
    license_type: "Please select Open Source License Type",
    content_des1: "1. If the contract compiles correctly at REMIX, it should also compile correctly here.",
    content_des2: "2. We have limited support for verifying contracts created by another contract and there is a timeout of up to 45 seconds for each contract compiled.",
    content_des3: "3. For programatic contract verification, check out the Contract API Endpoint.",
    checkbox_service: "I agree to the terms of service",
    verify_select_placeholder: "Please select",
    //logs
    ver_sucess: "Success",
    ver_err: "Error",
    has_been_verified: "Error:Has Been Verified",
    byte_code: "Compilation log",
    contract_name: " Contract Name ",
    local_byte_code: "Contract Bytecode",
    compiler: "Complier Verison",
    //step1
    address_verify: "Contract Address",
    step1_verify_des: "SELECT ONE OR MORE *.SOL FILES",
    source_code: "Contract Source Code",
    compile_version: "Complier",
    compile_output: "Complier Output",
    Optimizations: "Optimizations",
    run_optimizer: "Runs(Optimizer)",
    arguments: "Constructor Argument",
    optimize: "Optimization Enabled",
    //token list 
    token_list: "All Tokens",
    token_name: "Token",
    vol_24: "Trading Volume(24h)",
    transfer_total: "Total Messages of {{value}}",
    owner_total: "From a total of {{value}} hodlers",
    dex_total: "Total Message of {{value}} Transactions ",
    // ft /fns dashborad
    "total_supply": "Max Supply",
    "owners": "Hodlers",
    "transfers": "Total Transfers",
    latest_price: "Price",
    market_value: "Market Cap",
    token_contract: "Token Contract",
    transfer: "Transfers",
    owner: "Hodlers",
    domain: "Contract",
    dex: "Dex Trades",
    //list 
    message_cid: "Message ID",
    method: "Method",
    time: "Time",
    from: "From",
    to: "To",
    amount: "Amount",
    //拥有者
    rank: "Rank",
    percentage: "Percentage",
    //dex
    platform: "Platform",
    Txn_Value: "Txn Value",
    "swapped_Rate": "Swapped Rate",
    "Token_Amount_in": "Token Amount(In)",
    "Token_Amount_out": "Token Amount(Out)",
    Action: "Action",
    //合约列表
    contract_list: "Verified Contracts",
    contract_address: "Address",
    language: "Language",
    license: "License",
    //合约详情
    contract_list_total: "Total of {{value}} Contracts",
    verify_contract: "Contract Source Code Verified",
    source_code: "Contract Source Code",
    source_code_create: "Contract Creation Code",
    source_abi: "Contract ABI",
    source_abi_default: "Export ABI",
    nfts_list: "NFTs List",
    owner_nft: "Owner",
    item: "Item",
    controller: "Registrant",
    //rank
    contract_rank_des: "Latest Update on:{{value}}",
    contract_rank_total: "Total of {{value}} Contracts",
    contract_rank: "Contract Rank",
    actor_id: "actorID",
    actor_address: "actorAddress",
    transaction_count: "Transaction Count",
    user_count: "Transaction Address",
    actor_balance: "Balance",
    gas_cost: "Gas Cost",
    ver_address: "Pending Verification",
    //log 
    epoch: "Height",
    cid: "CID",
    event_name: "Method",
    topics: "Topics",
    coompoent_data: "Params",
    log_index: "Index",
    removed: "Removed"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contract);


/***/ }),

/***/ 1329:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// pool-detail 
const detail = {
    "24h": "24H",
    "7d": "7D",
    "30d": "30D",
    "1year": "1Y",
    "message_list_all": "All Methods",
    //owner
    "owner_title": "Pool Detail",
    "owner_title_tip": "The data of mine pool is collected from the data of nodes.",
    account: "Account",
    owner_address: "Owner Address",
    owned_miners: "Nodes",
    account_id: "Account Address",
    look_all: "View All Data",
    //account_type
    miner: "Miner",
    evm: "EVM",
    ethaddress: "ETHAddress",
    ethaccount: "ETHAccount",
    account_name: "Account",
    latest_transfer_time: "Lastest Timestamp",
    multisig: "MultiSign Account",
    from_ath: "From",
    to_ath: "To",
    //概览
    owner_overview_title: "Pool Overview",
    balance: "Total Balance",
    available_balance: "Available",
    init_pledge: "Initial Pledge",
    pre_deposits: "PreCommitDeposits",
    locked_balance: "Locked Rewards",
    sector_count: "Total",
    live_sector_count: "Active",
    fault_sector_count: "Faults",
    recover_sector_count: "Recoveries",
    eth_address: "ETH Address",
    eth_message: "ETH Hash",
    stable_address: "Stable Address",
    showContract: "Contract: {{value}}",
    showAddress: "Address: {{value}}",
    account_detail: "Account Detail",
    contract_name: "Contract Name",
    //统计指标
    indicators: "Statistical Indicators",
    power_increase_indicators: "Power Increase",
    power_ratio: "Power Rate",
    sector_increase: "Sector Increase",
    precommit_deposits: "Storage Provider Precommit Deposits",
    gas_fee: "Gas Fee",
    block_rewards: "Block Rewards",
    block_count: "Block",
    block_count_tip: "Blocks mined = the sum of blocks mined",
    mining_efficiency: "Efficiency",
    mining_efficiency_tip: "The ratio of node's cumulative block reward to the adjusted storage power in the selected period.",
    lucky: "Lucky",
    sector_ratio: "Sector Rate",
    win_count: "Winner Rewards",
    win_count_tip: "In Filecoin mining model, there may be multiple blocks under a tipset, and each block may receive multiple win counts.",
    net_profit_per_tb: "Consume per",
    net_profit_per_tb_tip: "Single T package sector size gas consumption in selected period",
    //账户变化
    owner_account_change: "Account Changes",
    power: "Pool Overview",
    power_increase: "Power Increase",
    quality_adjust_power: "Quality Adjusted Power",
    quality_power_rank: "Ranking",
    raw_power_percentage: "Power Rate",
    raw_power: "RawBytePower",
    total_block_count: "30/D  Blocks",
    total_block_count_tip: "Total Blocks in the past 30 days",
    total_reward: "30/D  Reward",
    total_reward_tip: "Total Reward in the past 30 days",
    total_win_count: "30/D  Wincount",
    total_win_count_tip: "Total Wincount in the past 30 days",
    sector_size: "Sector Size",
    sector_stauts: "Sector Status",
    contract_verify: "Contract",
    //账户总览
    account_overview: "Account Overview",
    create_time: "Create Time",
    account_type: "Type",
    peer_id: "Peer ID",
    account_address: "Address",
    // eslint-disable-next-line no-dupe-keys
    owner_address: "Owner",
    area: "Region",
    worker_address: "Worker",
    controllers_address: "Controller",
    beneficiary_address: "Beneficiary",
    code_cid: "CODE CID",
    nonce: "Nonce Count",
    // message
    message_overview_detail: "Transaction Details",
    trade: "Internal Transaction",
    message_detail: "Overview",
    event_log: "Log",
    message_overview: "Message Overview",
    cid: "Message ID",
    height: "Height",
    time: "Time",
    blk_cids: "Block Cid",
    value: "Value",
    from: "From",
    to: "To",
    status: "Status",
    method_name: "Method",
    message_other: "Others",
    version: "Version",
    // eslint-disable-next-line no-dupe-keys
    nonce: "Nonce",
    gas_fee_cap: "Gas Fee Cap",
    gas_premium: "Gas Premium",
    gas_limit: "Gas Limit",
    gas_used: "Gas Used",
    base_fee: "BaseFee",
    all_gas_fee: "Gas Fee",
    params: "Params",
    returns: "Returns",
    message_tranf: "Transactions",
    from_tranf: "From",
    to_tranf: "To",
    consume_type: "Type",
    MinerTip: "Miner Tip",
    BaseFeeBurn: "BaseFee Burn",
    Transfer: "Transfer",
    Burn: "Burn",
    exit_code: "Status",
    //内部交易
    amount: "Value",
    method: "Method",
    topic: "Topics",
    //通证转移
    message_ERC20Trans: "Tokens Transferred",
    message_NftTrans: "NFTS Transferred",
    // 出块列表
    block_cid: "Block Cid",
    block_height: "Height",
    block_time: "Time",
    block_messages_count: "Messages",
    block_miner_id: "Storage Provider",
    block_mined_reward: "Rewards",
    //miner
    message_list: "Message",
    block_list: "Blocks",
    traces_list: "Transaction",
    message_list_total: "Total of {{value}} Messages",
    block_list_total: "Total of  {{value}} Blocks",
    traces_list_total: "Total of {{value}} Messages",
    //general 
    general_overview_title: "Account",
    base_account_id: "ID",
    tokenList: "Token Holdings",
    //dns detail 
    deal_details: "dsn Detail",
    deal_id: "Dsn ID",
    epoch: "Block",
    service_start_time: "Create Time",
    message_cid: "Message",
    piece_cid: "Piece CID",
    verified_deal: "Verified",
    deal_hosting: "Storage Detail",
    deal_left_title: "Client",
    deal_right_title: "Provider",
    deal_value: "Provider",
    deal_cash: "Storage Cost",
    deal_time: "to",
    user_count: "User Count",
    transfer_count: "Transfer Count",
    go_verify: "To Verify",
    //代币
    contract_token_list: "Field",
    token_name: "Token Name",
    contract_id: "Contract Id",
    amount: "Amount"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (detail);


/***/ }),

/***/ 7085:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const domain = {
    domain_title: "Overview",
    resolved_address: "Resolved Address",
    expired_at: "Expiration Date",
    registrant: "Registrant",
    controller: "Controller",
    Result_for: "Result for",
    allDomains: "All Domains"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (domain);


/***/ }),

/***/ 1641:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fvm = {
    all: "Filecoin Ecosystem",
    Defi: "Defi",
    Dex: "Dex",
    DID: "DID",
    NFT: "NFT",
    MarketPlace: "MarketPlace",
    Launchpad: "Launchpad"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fvm);


/***/ }),

/***/ 7005:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const home = {
    seconds: "s",
    minutes: "m",
    hours: "h",
    day: "D",
    meta_title: "The Filecoin Network Data Index",
    mata_show: "Unfold",
    mata_show_false: "Fold",
    latest_height: "Block Height",
    latest_block_time: "Latest Block",
    total_blocks: "Total Block",
    total_rewards: "Total Block Rewards",
    total_quality_power: "Network Quality Adjusted Power",
    total_quality_power_tip: "Total current effective computing power (effective storage space) of the Filecoin network",
    base_fee: "Base Fee",
    miner_initial_pledge: "Current Sector Initial Pledge",
    power_increase_24h: "Latest 24h Power Growth",
    rewards_increase_24h: "Block Rewards Last 24h",
    fil_per_tera_24h: "Output\xa0Efficiency last 24h",
    fil_per_tera_24h_tip: "The average\xa0reward output\xa0for each terabyte of storage capacity over the last 24 hours",
    gas_in_32g: "Gas Used of a 32GiB Sector",
    gas_in_32g_tip: "Gas used of Sealing a 32GiB Sector in the last 24 hours",
    add_power_in_32g: "EST. Cost of a 32GiB Sector",
    add_power_in_32g_tip: "The cost of sealing a 32GiB sector in the past 24 hours, including the sector’s initial pledge and message fee",
    gas_in_64g: "Gas Used of a 64GiB Sector",
    gas_in_64g_tip: "Gas used of Sealing a 64GiB Sector in the last 24 hours",
    add_power_in_64g: "EST. Cost of a 64GiB Sector",
    add_power_in_64g_tip: "The cost of sealing a 64GiB sector in the past 24 hours, including the sector’s initial pledge and message fee",
    win_count_reward: "Rewards per Wincount",
    win_count_reward_tip: "",
    avg_block_count: "Avg. Blocks per TipSet",
    avg_block_count_tip: "Average blocks produced per tipSet in 24h",
    avg_message_count: "Avg. Messages per TipSet",
    avg_message_count_tip: "Average messages packaged per tipSet in 24h",
    active_miners: "Active Nodes",
    burnt: "Destruction Amount",
    circulating_percent: "Circulation Amount",
    rank: "Ranking List",
    footer_text: "Filscan browser is the filecoin blockchain browser and data service platform,It provides one-stop data services such as mining ranking, blockchain data query and visualization chart based on filecoin.",
    footer_outlook: "Email",
    footer_detail_a: "Copyright \xa9 Filecoin-Project devgrants. Distributed under the ",
    footer_detail_b: " and ",
    footer_detail_c: "license",
    search_notFound: "Search Not Found",
    warn_text: "Oops! The search string you enterd was:",
    warn_details: "Sorry! This is an invalid search string",
    go_home: "Back Home"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (home);


/***/ }),

/***/ 8148:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const en = {
    network_title: "Current Network",
    home: "Home",
    contract: "Smart Contract",
    contract_verify: "Contract Verification",
    token: "Tokens",
    nft: "NFTs",
    contract_list: "Verified Contracts",
    contract_rank: "Contract Rank",
    tipset: "Tipset",
    tipset_chain: "Chain",
    tipset_message: "Message",
    tipset_ranking: "Wealth Ranking",
    tipset_transfer: "Large Amount Transfer",
    tipset_dsn: "Dsn",
    "tipset_pool-message": "Pool Message",
    ranking: "Ranking",
    statistics: "Statistics",
    statistics_gas: "Gas Fee",
    statistics_base: "Power",
    statistics_fil: "FIL",
    statistics_charts: "Charts",
    statistics_map: "Charts",
    resources: "Resources",
    resources_tools: "Tools",
    provider: "Storage Provider",
    fvm: "Filecoin Ecosystem",
    //search 
    "search_holder": "Search by Address/Message ID/Height/Block Cid/Peer ID/FNS",
    all: "All filters",
    address: "Address",
    message_id: "Message ID",
    height: "Height",
    cid: "Block CID",
    node: "Peer ID"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (en);


/***/ }),

/***/ 3279:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const rankZh = {
    pool: "Storage Pool",
    provider: "Storage Provider",
    growth: "Power Growth",
    rewards: "Rewards",
    "24h": "24H",
    week_days: "7D",
    month: "30D",
    select_rank_all: "All",
    select_rank_32: "32GiB",
    select_rank_64: "64GiB",
    more: "More",
    rank_time: "Latest Update on",
    // table columns title
    //存储池排行
    ranking: "Rank",
    pool_owner: "Owner ID",
    pool_power: "Quality Adjusted Power",
    pool_efficiency_24h: "Latest 24h Output Efficiency",
    pool_increase_24h: "Power Growth",
    pool_block_count: "Blocks Mined",
    miner: "Miner",
    pool_block_count_24h: "24h Total Block Rewards",
    // 节点排行
    provider_miner: "Storage Provider",
    provider_power_ratio: "Quality Adjusted Power / Rate",
    provider_block_ratio: "24H Blocks / Rate ",
    provider_rewards_ratio: "24H Wincount Rate",
    balance: "Balance",
    //算力增速
    power_ratio: "Power Growth",
    power_ratio_tip: "Daily total adj. power of the sealed sectors within selected period.",
    quality_power_increase: "Daily Power Growth",
    quality_power_increase_tip: "Node's adjusted storage power increment in the selected period.",
    quality_adj_power: "Quality Adjusted Power",
    raw_power: "Raw Byte Power",
    sector_size: "Sector Size",
    //节点收益
    "rewards/ratio": "Rewards/Ratio",
    "rewards/ratio_tip": "The ratio of node's cumulative block reward to the adjusted storage power in the selected period.",
    block_count: "Blocks",
    block_count_tip: "In Filecoin CryptoEconomics, there may be multiple blocks under a tipset, and each block may receive multiple win counts.",
    winning_rate: "Wincount Rate"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rankZh);


/***/ }),

/***/ 3759:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const statistic = {
    show_more: "More",
    "24h": "24H",
    "7d": "7D",
    "30d": "30D",
    year: "1Y",
    // power 
    "power": "Storage Power Trend",
    power_tips: "The network baseline is the scale of network growth required by the Filecoin Network, which was 2.5 EiB when the Mainnet launched, with a growth rate of 100% per year",
    trend_24: "24h Base Fee Variations",
    total_raw_byte_power: "Network Raw Byte Power",
    base_line_power: "BaseLine",
    total_quality_adj_power: "Quality Adjusted Power",
    change_quality_adj_power: "Quality Adjusted Power Fluctuations",
    gas: "Base Fee Variations",
    base_fee: "Base Fee",
    gas_in_32g: "Gas Cost of Sealing a 32GiB Sector",
    gas_in_64g: "Gas Cost of Sealing a  64GiB Sector",
    //24_gas
    gas_24: "24h Gas Data",
    method_name: "Message Type",
    avg_gas_premium: "Gas Premium",
    avg_gas_limit: "Avg. Gas Limit",
    avg_gas_used: "Avg. Gas Used",
    avg_gas_fee: "Avg. Gas Fee",
    "sum_gas_fee/ratio": "Total Fees/Percentage",
    "message_count/ratio": "Total Messages/Percentage",
    //fil
    TokenRules: "FIL Allocation",
    FilecoinFoundation: "Filecoin Foundation",
    FundraisingRemainder: "Fundraising-Remainder",
    FundraisingSAFT: "Fundraising-SAFT",
    MiningReserve: "Mining Reserve",
    TokenAllocation: "Storage Mining Allocation",
    ReservedTokens: "Mining Reserve",
    Fundraising: "Fundraising - SAFT 2017",
    Funds: "Fundraising - Remainder",
    protocolLab: "Protocol Labs",
    Contributors: "PL Team &amp; Contributors",
    Allocation: "Allocation",
    value: "Value",
    description: "Description",
    filBase: "FIL BASE",
    filBase_des: "The maximum amount of FIL that will ever be created.",
    ReservedTokens_des: "Tokens reserved for funding mining to support growth of the Filecoin Economy, whose future usage will bedecided by the Filecoin community.",
    TokenAllocation_des: "The amount of FIL allocated tostorage nodes through block rewards, network initialization, etc.",
    Fundraising_des: "2017 TOKEN SALE",
    Funds_des: "allocated for ecosystem development, future fundraising",
    protocolLab_des: "allocated for Protocol Labs",
    Contributors_des: "4.5% for the PL team & contributors",
    //charts 
    pie_title: "chart statistics",
    block_trend: "Block Rewards",
    block_reward_per_TiB: "output efficiency",
    active_nodes: "Active Storage Providers",
    active_miner_count: "Node Counts",
    messages_trend: "Message Trend",
    message_count: "Message Trend of Each Block",
    all_message_count: "Messages Variation per Block",
    all_message_count_tip: "Messages Included per Block",
    acc_block_rewards: "Cumulative block rewards",
    pie_title_a: "Released FIL Usage Statistics",
    pie_title_a_tip: "Total FIL Rewarded + Locked Rewards Released + Reserved FIL Allocated = Currently Released Fil",
    pie_title_b: "Released FIL Usage Statistics",
    mined: "Total FIL Rewarded",
    remaining_mined: "Total FIL to Reward",
    vested: "Locked Rewards Released",
    remaining_vested: "Locked Rewards to Release",
    reserve_disbursed: "Reserved FIL Allocated(Testnet Rewards)",
    remaining_reserved: "Reserved FIL to Allocate",
    locked: "Total Sector Pledge",
    burnt: "Total FIL Burned",
    circulating: "Circulating Supply"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (statistic);


/***/ }),

/***/ 192:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const tipset = {
    rank: "Rank",
    tag: "Tag",
    height: "Height",
    cid: "Message ID",
    block_time: "Time",
    from: "From",
    to: "To",
    value: "Value",
    method_name: "Method",
    //chain
    blocks_cid: "Cid",
    blocks_miner: "Storage Provider",
    blocks_messages: "Message",
    blocks_reward: "Reward",
    win_count: "WinCount",
    //cid_details
    message_list_total: "Latest {{value}} Messages",
    chain_cid_detail: "Block details",
    cid_height: "Height",
    parent_weight: "Parent Weight",
    parents_cid: "Parent CID",
    parent_base_fee: "Parent BaseFee Rate",
    ticket_value: "Ticket",
    state_root: "State Root",
    //message 
    message_list: "Message List",
    total_list: "Latest {{value}} Messages",
    message_list_all: "All Methods",
    message_list_exit_code: "Status",
    // adress
    address_all: "All Types",
    address_total_list: "Total of {{value}} Accounts",
    account: "account",
    owner: "owner",
    miner: "node",
    payment: "payment",
    multisig: "multisig",
    address_list: "Wealth Ranking",
    account_address: "Address",
    balance_percentage: "Balance/Percentage",
    account_type: "Status",
    latest_transfer_time: "Last Seen Time",
    //transfer
    transfer_list: "Large Amount Transfer",
    transfer_total_list: "Total of {{value}} Message",
    //dsn
    dsn_list: "Order List",
    dsn_total_list: "Total of {{value}} Deals",
    dsn_placeholder: "Search Client/Provider/DealID",
    deal_id: "Deal ID",
    piece_cid: "Piece CID",
    piece_size: "PieceSize",
    client_address: "Client",
    provider_id: "Provider",
    service_start_time: "Start Time",
    end_time: "End Time",
    start_height: "Start Height",
    end_height: "End Height",
    storage_price_per_height: "Storage Fee",
    verified_deal: "Verified Deal",
    // pool-message
    pool_list: "Message Pool List",
    gas_fee_cap: "Gas Limit",
    gas_premium: "Gas Premium"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (tipset);


/***/ }),

/***/ 7626:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2021);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7987);
/* harmony import */ var _en_nav_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8148);
/* harmony import */ var _zh_nav_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7932);
/* harmony import */ var _kr_nav_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9171);
/* harmony import */ var _zh_home_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4363);
/* harmony import */ var _en_home_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7005);
/* harmony import */ var _kr_home_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4271);
/* harmony import */ var _zh_statistic_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(596);
/* harmony import */ var _en_statistic_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3759);
/* harmony import */ var _kr_statistic_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6248);
/* harmony import */ var _zh_rank_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5302);
/* harmony import */ var _en_rank_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3279);
/* harmony import */ var _kr_rank_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4513);
/* harmony import */ var _zh_tipset_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5636);
/* harmony import */ var _en_tipset__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(192);
/* harmony import */ var _kr_tipset_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3551);
/* harmony import */ var _zh_detail__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(5584);
/* harmony import */ var _en_detail__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1329);
/* harmony import */ var _kr_detail__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1661);
/* harmony import */ var _ja_nav__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(7349);
/* harmony import */ var _ja_home__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(3144);
/* harmony import */ var _ja_statistic__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(6496);
/* harmony import */ var _zh_fvm_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(8593);
/* harmony import */ var _en_fvm__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(1641);
/* harmony import */ var _kr_fvm__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(8718);
/* harmony import */ var _zh_contract_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(1014);
/* harmony import */ var _en_contract_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(6599);
/* harmony import */ var _kr_contract_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(5217);
/* harmony import */ var _zh_domain_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(1628);
/* harmony import */ var _en_domain_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(7085);
/* harmony import */ var _kr_domain_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(4174);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_1__]);
([i18next__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
































i18next__WEBPACK_IMPORTED_MODULE_0__["default"].use(react_i18next__WEBPACK_IMPORTED_MODULE_1__.initReactI18next).init({
    resources: {
        en: {
            nav: _en_nav_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
            home: _en_home_js__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
            static: _en_statistic_js__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
            rank: _en_rank_js__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z,
            tipset: _en_tipset__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z,
            detail: _en_detail__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z,
            fvm: _en_fvm__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z,
            contract: _en_contract_js__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z,
            domain: _en_domain_js__WEBPACK_IMPORTED_MODULE_30__/* ["default"] */ .Z
        },
        kr: {
            nav: _kr_nav_js__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
            home: _kr_home_js__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
            static: _kr_statistic_js__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
            rank: _kr_rank_js__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z,
            tipset: _kr_tipset_js__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z,
            detail: _kr_detail__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z,
            fvm: _kr_fvm__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z,
            contract: _kr_contract_js__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z,
            domain: _kr_domain_js__WEBPACK_IMPORTED_MODULE_31__/* ["default"] */ .Z
        },
        zh: {
            nav: _zh_nav_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
            home: _zh_home_js__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
            static: _zh_statistic_js__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
            rank: _zh_rank_js__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z,
            tipset: _zh_tipset_js__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z,
            detail: _zh_detail__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z,
            fvm: _zh_fvm_js__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z,
            contract: _zh_contract_js__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z,
            domain: _zh_domain_js__WEBPACK_IMPORTED_MODULE_29__/* ["default"] */ .Z
        },
        ja: {
            nav: _ja_nav__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z,
            home: _ja_home__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z,
            static: _ja_statistic__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z
        }
    },
    fallbackLng: "zh",
    debug: true,
    react: {
        useSuspense: false
    },
    detection: {
        order: [
            "querystring",
            "navigator",
            "localStorage"
        ],
        lookupQuerystring: "lang"
    }
});
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (i18n)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const home = {
    minutes: "分",
    hours: "时",
    day: "天",
    //meta
    meta_title: "全ネットワークのデータ指標",
    mata_show: "展開",
    mata_show_false: "片付け",
    latest_height: "最新のブロックのチップセット",
    latest_block_time: "最新のブロック時間",
    total_blocks: "ネットワーク全体で生成されるブロック数",
    total_rewards: "ネットワーク全体の報酬をブロック",
    total_quality_power: "全ネットーワークの有効計算力 ",
    total_quality_power_tip: "現在全ネットーワークの有効計算力（有効なストレージスペース）の合計",
    base_fee: "現在の基本レート",
    miner_initial_pledge: "現在のセクター誓約額",
    power_increase_24h: "直近24h増加した計算力",
    rewards_increase_24h: "直近24hブロックジェネレーション報酬",
    fil_per_tera_24h: "直近24時間のマイニング効率",
    fil_per_tera_24h_tip: "直近24時間の合計ブロックジェネレーション報酬と有効計算力の割合",
    gas_in_32g: "32GiBディスクセクターGas消耗 ",
    gas_in_32g_tip: "密閉の32Gディスクセクター每にT消耗必要なGas値",
    add_power_in_32g: "32GiBディスクセクターの新たに増加する計算力コスト ",
    add_power_in_32g_tip: "32Gディスクセクターの新たに増加する計算力がかかるコストは，ディスクセクター抵当とパッケージ化の手数料を含む",
    gas_in_64g: "64GiBディスクセクターGas消耗",
    gas_in_64g_tip: "密閉の64GディスクセクターTあたり消耗必要なGas値",
    add_power_in_64g: "64GiBディスクセクターの新たに増加する計算力コスト",
    add_power_in_64g_tip: "64Gディスクセクターの新たに増加する計算力がかかるコストは，ディスクセクター抵当とパッケージ化の手数料を含む",
    win_count_reward: "勝利ごとの報酬",
    win_count_reward_tip: "最新の高さの単位ブロック報酬、各高さには複数のブロックがあり、各ブロックはこの報酬を得ることができます",
    avg_block_count: "平均のチップセットごとのブロック数",
    avg_block_count_tip: "直近24h平均のチップセットごとのブロック数",
    avg_message_count: "高さあたりの平均メッセージ数",
    avg_message_count_tip: "過去 24 時間の各高さでのメッセージの平均数",
    active_miners: "アクティブなマイナー数",
    burnt: "破壊された量",
    circulating_percent: "流通率",
    rank: "ランキング"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (home);


/***/ }),

/***/ 7349:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const zh = {
    network_title: "現在のネットワーク",
    home: "ホームページ",
    tipset: "ブロックチェーン",
    tipset_chain: "ブロック",
    tipset_message: "メッセージ",
    tipset_ranking: "富豪ランキング",
    tipset_transfer: "大量振込",
    tipset_dsn: "オーダー",
    "tipset_pool-message": "メッセージプール",
    ranking: "ランキング",
    statistics: "統計",
    statistics_gas: "Gas費用トレンド",
    statistics_base: "ベースラインと計算力トレンド",
    statistics_fil: "FIL",
    statistics_charts: "チャート統計",
    statistics_map: "节点地图",
    resources: "資源",
    resources_tools: "常用ツール",
    provider: "ストレージプロバイダ",
    //search 
    "search_holder": "アドレスを入力ください/メッセージID/チップセット/ブロックCid/ノートID",
    all: "全てのフィルタータイプ",
    address: "アドレス",
    message_id: "メッセージID",
    height: "チップセット",
    cid: "ブロックCid",
    node: "ノートID"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (zh);


/***/ }),

/***/ 6496:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const statistic = {
    show_more: "更なる",
    "24h": "24時間",
    "7d": "7日間",
    "30d": "30日",
    year: "1年",
    // power 
    "power": "ベースラインとハッシュレートの傾向",
    power_tips: "ベースライン基準は、Filecoinに要求されるネットワーク成長規模であり、メインネットがオンラインになったときに2.5EiBであり、年間成長率は100％となる。",
    trend_24: "24h基础手续费走势",
    total_raw_byte_power: "全ネットーワークの計算力",
    base_line_power: "ベースライントレンド",
    change_quality_adj_power: "リング間の実効計算能力",
    total_quality_adj_power: "計算能力を高める",
    gas: "基本手数料トレンド",
    base_fee: "基本手数料",
    gas_in_32g: "32GiBディスクセクターGas消耗",
    gas_in_64g: "64GiBディスクセクターGas消耗",
    //24_gas
    gas_24: "24h Gas データ",
    method_name: "メッセージタイプ",
    avg_gas_premium: "Gas Premium",
    avg_gas_limit: "平均Gas制限",
    avg_gas_used: "平均Gas消耗",
    avg_gas_fee: "平均手数料",
    "sum_gas_fee/ratio": "手数料合計/割合",
    "message_count/ratio": "メッセージ数合計/割合",
    //fil
    TokenRules: "Filecoinトークンの割り当てルール",
    FilecoinFoundation: "Filecoin基金会",
    FundraisingRemainder: "募资 – 剩余通证",
    FundraisingSAFT: "募资 – 未来通证简单协议",
    MiningReserve: "为存储服务提供者预留通证",
    TokenAllocation: "存储提供者通证分配",
    ReservedTokens: "存储提供者预留通证",
    Fundraising: "募资形式 – 未来通证简单协议 2017",
    Funds: "募资形式 – 剩余资金",
    protocolLab: "协议实验室",
    Contributors: "协议实验室团队和贡献者",
    Allocation: "分配项目",
    value: "数额",
    description: "具体用途",
    filBase: "FIL的基础发放",
    filBase_des: "网络FIL铸造上限",
    ReservedTokens_des: "为未来Filecoin经济增长而预留的通证储备，具体未来使用方案由Filecoin社区决定",
    TokenAllocation_des: "通过区块奖励、网络初始化等方式分给存储提供者的通证奖励",
    Fundraising_des: "2017年出售的通证",
    Funds_des: "用作生态发展和后续融资",
    protocolLab_des: "用作协议实验室的相关工作",
    Contributors_des: "4.5%给协议实验室团队和贡献者",
    //charts 
    pie_title: "图表统计",
    block_trend: "区块奖励",
    block_reward_per_TiB: "产出效率",
    acc_block_rewards: "累计区块奖励",
    active_nodes: "活跃节点数",
    active_miner_count: "节点数量",
    messages_trend: "消息数走势图",
    message_count: "单消息走势",
    all_message_count: "总消息走势"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (statistic);


/***/ }),

/***/ 5217:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const contract = {
    overview: "개요",
    market: "마켓",
    look_adres: "주소 확인",
    gohome: "홈으로",
    reset_ver: "재검증",
    next: "다음",
    reset: "초기화",
    confirm: "검증 및 배포",
    back: "뒤로",
    file_name: "*.sol 파일 선택",
    config_file_name: "Metadata 파일 선택",
    verify_title: "스마트 컨트랙트 소스 코드 검증 및 배포",
    verify_des: "컴파일러 유형 및 버전 선택",
    content_des: '스마트 컨트랙트와 상호작용하는 사용자에게 소스 코드 검증은 투명성을 제공합니다. 소스 코드를 업로드하여 Filscan이 컴파일된 코드를 블록체인 상의 코드와 일치시킵니다. 계약이 제공하는 것처럼 "스마트 컨트랙트"는 최종 사용자에게 "디지털 서명"의 목적에 대한 더 많은 정보를 제공하고 사용자가 코드를 검토하여 그것이 정말로 해야 할 일을 수행했는지 독립적으로 확인할 수 있도록 해야 합니다.',
    address: "검증할 컨트랙트 주소를 입력하세요",
    address_placeholder: "검증할 컨트랙트 주소를 입력하세요",
    verify_address: "컴파일러 버전을 선택하세요",
    verify_address_placeholder: "선택하세요",
    license_type: "오픈 소스 라이선스 유형을 입력하세요",
    content_des1: "1. 만약 컨트랙트가 REMIX에서 올바르게 컴파일 된 경우, 여기에도 올바르게 컴파일되어야 합니다.",
    content_des2: "2. 다른 컨트랙트에서 생성된 컨트랙트를 검증하는 것은 제한됩니다. 각 컨트랙트의 컴파일 제한 시간은 최대 45초입니다.",
    content_des3: "3. 프로그래밍 컨트랙트 검증은 컨트랙트 API 엔드포인트를 확인하세요.",
    checkbox_service: "서비스 약관에 동의합니다",
    verify_select_placeholder: "선택하세요",
    //logs
    ver_sucess: "성공: 검증 완료",
    ver_err: "오류: 검증 실패",
    has_been_verified: "오류: 계약이 이미 검증되었습니다",
    byte_code: "컴파일 로그",
    contract_name: "계약 이름",
    local_byte_code: "로컬 바이트 코드",
    compiler: "컴파일러 버전",
    //step1
    address_verify: "계약 주소",
    step1_verify_des: "*.sol 파일을 선택하세요",
    source_code: "계약 소스 코드",
    compile_version: "컴파일러",
    compile_output: "컴파일러 출력",
    Optimizations: "최적화 매개변수",
    run_optimizer: "최적화 실행",
    arguments: "생성자 인수",
    optimize: "최적화 활성화",
    optimize_runs: "RUNS",
    //token list 
    token_list: "전체 토큰",
    token_name: "토큰",
    vol_24: "24시간 거래량",
    transfer_total: "총 {{value}} 건 메시지",
    owner_total: "총 {{value}}명 보유",
    dex_total: "총 {{value}} 건 거래",
    //nft list 
    nfts_list: "전체 NFTs",
    trading_volume: "전체 거래량",
    // ft /fns dashborad
    "total_supply": "총 공급량",
    "owners": "보유자",
    "transfers": "총 전송 수",
    latest_price: "최신 가격",
    market_value: "시가 총액",
    token_contract: "토큰 계약",
    transfer: "이전",
    owner: "소유자",
    owner_nft: "소유자",
    domain: "계약",
    dex: "DEX 거래",
    //list 
    message_cid: "메시지ID",
    method: "메소드",
    time: "시간",
    from: "보내는 주소",
    to: "받는 주소",
    amount: "양",
    //拥有者
    //소유자
    rank: "순위",
    percentage: "비율",
    //DEX
    platform: "거래소",
    Txn_Value: "Txn 값",
    "swapped_Rate": "교환 비율",
    "Token_Amount_in": "Token 양(들어옴)",
    "Token_Amount_out": "Token 양(나감)",
    Action: "액션",
    //계약 목록
    contract_list: "검증된 계약",
    contract_address: "주소",
    language: "언어",
    license: "라이선스",
    //合约详情
    contract_list_total: "총 {{value}}개의 계약",
    byte_code_no_verify: "계약이 검증되지 않았습니다. 이동하여",
    go_to_verify: "계약 검증",
    verify_contract: "계약 소스 코드가 검증되었습니다",
    source_code: "계약 소스 코드",
    source_code_create: "계약 생성 코드",
    source_abi: "계약 ABI",
    source_abi_default: "ABI 내보내기",
    nfts_list: "NFT 목록",
    item: "아이템",
    Items: "수량",
    //rcontract_rank_des:'上次更新时间为:{{value}}',
    contract_rank_des: "마지막 업데이트 시간: {{value}}",
    contract_rank_total: "총 {{value}}개의 계약 ",
    contract_rank: "계약 랭킹",
    rank: "랭킹",
    actor_id: "actorID",
    ver_address: "검증 대기중",
    actor_address: "actorAddress",
    transaction_count: "거래 수",
    user_count: "거래 주소 수",
    actor_balance: "잔액",
    gas_cost: "Gas 소비량",
    //log 
    epoch: "시대",
    cid: "메시지 ID",
    event_name: "방법",
    topics: "주제",
    coompoent_data: "매개변수",
    log_index: "일련 번호",
    removed: "제거됨"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contract);


/***/ }),

/***/ 1661:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// pool-detail 
const detail = {
    "24h": "24시간",
    "7d": "7일",
    "30d": "30일",
    "1year": "1년",
    look_all: "전체 데이터 보기",
    //owner
    "owner_title": "스토리지 풀 정보",
    "owner_title_tip": "스토리지 풀 정보: 노드 데이터를 모아 총합한 데이터입니다",
    message_list_all: "모든 메소드",
    account: "계정",
    owner_address: "Owner 주소",
    owned_miners: "소유한 노드",
    owned_active_miners: "활성화된 노드",
    miner: "노드",
    evm: "EVM",
    ethaddress: "ETH 주소",
    ethaccount: "ETH 계정",
    //account_type
    account_name: "계정",
    latest_transfer_time: "최신 거래 시간",
    multisig: "다중 서명 계정",
    account_detail: "스토리지 풀 정보",
    from_ath: "보낸이",
    to_ath: "받는이",
    account_id: "계정 주소",
    //Overview
    owner_overview_title: "스토리지 풀 개요",
    balance: "계정 잔액",
    available_balance: "사용 가능한 잔액",
    init_pledge: "파티션 담보",
    pre_deposits: "선입금",
    locked_balance: "잠긴 보상",
    sector_count: "전체",
    live_sector_count: "활성화된",
    fault_sector_count: "오류",
    recover_sector_count: "복구",
    eth_address: "ETH 주소",
    stable_address: "안정적인 주소",
    tokenList: "보유한 토큰",
    showContract: "계약: {{value}}",
    showAddress: "주소: {{value}}",
    //统计指标
    indicators: "통계 지표",
    power_increase_indicators: "유효한 해시 능력 증가",
    power_ratio: "유효한 해시 능력 증가 속도",
    sector_increase: "파티션 증가",
    precommit_deposits: "파티션 담보",
    gas_fee: "Gas 소비량",
    block_rewards: "블록 보상",
    block_count: "블록 수",
    block_count_tip: "블록 수 = 블록 (block) 수 총합",
    mining_efficiency: "효율성",
    mining_efficiency_tip: "선택한 기간 동안, 노드가 채굴한 총 블록 보상과 유효한 해시 능력 비율",
    lucky: "러키 인덱스",
    sector_ratio: "파티션 증가 속도",
    sector_ratio_tip: "",
    win_count: "승리한 표 수",
    win_count_tip: "Filecoin 경제 모델에서 높은 높이 (tipset)에서는 여러 블록 (블록)이 있을 수 있으며, 각 블록 (블록)은 다수의 보상 (win count)을 받을 수 있습니다. 채굴한 블록 수 = 보상 수의 총합",
    net_profit_per_tb: "1T당 Gas 소비량",
    net_profit_per_tb_tip: "선택한 기간 동안 1T 파티션 크기의 Gas 소비량",
    //账户变化
    owner_account_change: "계정 변화",
    power: "유효한 해시 능력",
    power_increase: "유효한 해시 능력 증가",
    quality_adjust_power: "유효한 해시 능력",
    quality_power_rank: "순위",
    raw_power_percentage: "해시 능력 비율",
    raw_power: "원시 해시 능력",
    total_block_count: "30일 블록 수",
    total_block_count_tip: "최근 30일간 해당 노드에서 채굴한 블록 수의 총합",
    total_reward: "30일 보상",
    total_reward_tip: "최근 30일간 해당 노드에서 채굴한 블록의 총 보상",
    total_win_count: "30일 승리 횟수",
    total_win_count_tip: "최근 30일간 해당 노드에서 채굴한 블록의 총 승리 횟수",
    sector_size: "파티션 크기",
    sector_stauts: "파티션 상태",
    //账户总览
    account_overview: "계정 개요",
    create_time: "계정 생성 시간",
    account_type: "계정 유형",
    peer_id: "노드 식별자",
    account_address: "주소",
    owner_address: "소유자",
    area: "지역",
    worker_address: "워커",
    controllers_address: "컨트롤러",
    beneficiary_address: "수혜자",
    code_cid: "코드 CID",
    nonce: "Nonce 값",
    contract_verify: "계약 검증",
    contract_name: "계약 이름",
    //miner 
    //pool_overview_title:'账户',
    // message
    message_overview_detail: "거래 세부 정보",
    trade: "내부 거래",
    message_detail: "개요",
    event_log: "이벤트 로그",
    message_overview: "메시지 개요",
    eth_message: "ETH 해시",
    cid: "메시지 ID",
    height: "블록 높이",
    time: "시간",
    blk_cids: "블록",
    value: "금액",
    from: "발신 주소",
    to: "수신 주소",
    status: "상태",
    method_name: "메소드",
    message_other: "기타 정보",
    version: "버전 번호",
    // eslint-disable-next-line no-dupe-keys
    nonce: "Nonce",
    gas_fee_cap: "수수료 상한",
    gas_premium: "노드 팁 비율",
    gas_limit: "Gas 한도",
    gas_used: "Gas 사용량",
    base_fee: "기본 수수료 비율",
    all_gas_fee: "수수료",
    params: "매개 변수",
    returns: "반환 값",
    message_tranf: "송금 정보",
    from_tranf: "보내는 사람",
    to_tranf: "받는 사람",
    consume_type: "유형",
    MinerTip: "노드 수수료",
    BaseFeeBurn: "기본 수수료 소모",
    Transfer: "송금",
    Burn: "수수료 소모",
    exit_code: "상태",
    //内部交易
    amount: "액수",
    method: "메소드",
    topic: "주제",
    //通证转移
    message_ERC20Trans: "토큰 전송",
    message_NftTrans: "NFT 전송",
    // 出块列表
    block_cid: "블록 CID",
    block_height: "블록 높이",
    block_time: "블록 생성 시간",
    block_messages_count: "메시지 수",
    block_miner_id: "노드 주소",
    block_mined_reward: "블록 보상",
    //miner
    message_list: "메시지 목록",
    block_list: "블록 목록",
    traces_list: "전송 목록",
    message_list_total: "총 {{value}}개 메시지",
    block_list_total: "총 {{value}}개 블록",
    traces_list_total: "총 {{value}}개 전송",
    contract_token_list_total: "총 {{value}}개 토큰",
    //general
    general_overview_title: "계정 개요",
    base_account_id: "계정 ID",
    //dns detail 
    //dns detail 
    deal_details: "거래 상세 정보",
    deal_id: "거래 ID",
    epoch: "블록",
    service_start_time: "생성 시간",
    message_cid: "메시지",
    piece_cid: "Piece CID",
    verified_deal: "검증됨",
    deal_hosting: "호스팅 정보",
    deal_left_title: "클라이언트",
    deal_right_title: "호스팅 노드",
    deal_value: "예치 금액",
    deal_cash: "호스팅 비용",
    deal_time: " ~ ",
    user_count: "거래 주소",
    transfer_count: "거래 수",
    go_verify: "검증하러 가기",
    contract_token_list: "토큰",
    token_name: "토큰 이름",
    contract_id: "계약 ID",
    amount: "금액"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (detail);


/***/ }),

/***/ 4174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const domain = {
    domain_title: "개요",
    resolved_address: "해석된 주소",
    expired_at: "만료일",
    registrant: "등록자",
    controller: "컨트롤러",
    allDomains: "이 주소가 소유한 도메인 총 {{value}}개",
    Result_for: "검색 결과"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (domain);


/***/ }),

/***/ 8718:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fvm = {
    all: "FVM 생태 프로젝트 개요",
    Defi: "Defi",
    Dex: "Dex",
    DID: "DID",
    NFT: "NFT",
    MarketPlace: "MarketPlace",
    Launchpad: "Launchpad"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fvm);


/***/ }),

/***/ 4271:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const home = {
    seconds: "초",
    minutes: "분",
    hours: "시간",
    day: "일",
    //meta
    meta_title: "전체 네트워크 데이터 지표",
    mata_show: "펼치기",
    mata_show_false: "접기",
    latest_height: "최신 블록 높이",
    latest_block_time: "최신 블록 시간",
    total_blocks: "전체 블록 생성 수",
    total_rewards: "전체 블록 보상",
    total_quality_power: "전체 유효한 해시파워",
    total_quality_power_tip: "현재 전체 유효한 해시파워(유효한 저장 공간)의 총합",
    base_fee: "현재 기본 수수료",
    miner_initial_pledge: "현재 섹터 토큰 담보금",
    power_increase_24h: "최근 24시간 동안 증가한 해시파워",
    rewards_increase_24h: "최근 24시간 동안 생성된 블록 보상",
    fil_per_tera_24h: "최근 24시간 동안 생성된 테라당 FIL",
    fil_per_tera_24h_tip: "최근 24시간 동안 전체 보상과 유효한 해시파워의 비율",
    gas_in_32g: "32GiB 섹터의 가스 소비량",
    gas_in_32g_tip: "최근 24시간 동안 밀봉된 32G 섹터당 소비된 가스량(TB당)",
    add_power_in_32g: "예상 32GiB 섹터 추가 해시파워 비용",
    add_power_in_32g_tip: "최근 24시간 동안 32G 섹터 추가 해시파워를 위해 필요한 비용 (토큰 담보금 및 밀봉 수수료 포함)",
    gas_in_64g: "64GiB 섹터의 가스 소비량",
    gas_in_64g_tip: "최근 24시간 동안 밀봉된 64G 섹터당 소비된 가스량(TB당)",
    add_power_in_64g: "예상 64GiB 섹터 추가 해시파워 비용",
    add_power_in_64g_tip: "최근 24시간 동안 64G 섹터 추가 해시파워를 위해 필요한 비용 (토큰 담보금 및 밀봉 수수료 포함)",
    win_count_reward: "각 티켓당 블록 보상",
    win_count_reward_tip: "현재 높이에서 각 블록의 보상 (한 높이에서 여러 블록이 생성될 수 있음)",
    avg_block_count: "한 높이당 평균 블록 수",
    avg_block_count_tip: "최근 24시간 동안 한 높이당 평균 블록 수",
    avg_message_count: "한 높이당 평균 메시지 수",
    avg_message_count_tip: "최근 24시간 동안 한 높이당 평균 메시지 수",
    active_miners: "활성 노드 수",
    burnt: "소각된 토큰 수",
    circulating_percent: "유통 비율",
    rank: "순위",
    footer_text: "Filscan 브라우저는 Filecoin 블록체인 브라우저 및 데이터 서비스 플랫폼으로, Filecoin 기반의 수익 랭킹, 블록체인 데이터 쿼리, 시각화 차트 등의 데이터 서비스를 제공합니다.",
    footer_outlook: "이메일",
    footer_detail_a: "판권 소유 \xa9 Filecoin 개발 보조 계획을 따르며 ",
    footer_detail_b: " 및 ",
    footer_detail_c: "저작권 계약",
    search_notFound: "검색 결과 없음",
    warn_text: "Oops! 입력한 검색어:",
    warn_details: "죄송합니다. 유효하지 않은 문자열입니다.",
    go_home: "홈으로 돌아가기"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (home);


/***/ }),

/***/ 9171:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const zh = {
    network_title: "현재 네트워크",
    home: "홈",
    contract: "스마트 컨트랙트",
    contract_verify: "스마트 컨트랙트 검증",
    contract_list: "검증된 스마트 컨트랙트",
    contract_rank: "스마트 컨트랙트 랭킹",
    token: "토큰",
    nft: "NFT",
    tipset: "블록체인",
    tipset_chain: "블록",
    tipset_message: "메시지",
    tipset_ranking: "리치 리스트",
    tipset_transfer: "대규모 송금",
    tipset_dsn: "주문",
    "tipset_pool-message": "메시지 풀",
    ranking: "랭킹",
    statistics: "통계",
    statistics_gas: "가스 비용 추세",
    statistics_base: "해시파워 추세",
    statistics_fil: "FIL",
    statistics_charts: "그래프 통계",
    statistics_map: "노드 맵",
    resources: "리소스",
    resources_tools: "유용한 도구",
    provider: "스토리지 제공자",
    fvm: "FVM 생태 개요",
    //search
    "search_holder": "주소/메시지 ID/높이/블록 CID/노드 ID/FNS를 입력하세요",
    all: "모든 필터 유형",
    address: "주소",
    message_id: "메시지 ID",
    height: "높이",
    cid: "블록 CID",
    node: "노드"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (zh);


/***/ }),

/***/ 4513:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const rankZh = {
    pool: "스토리지 풀 랭킹",
    provider: "노드 랭킹",
    growth: "해시파워 증가율",
    rewards: "노드 수익",
    "24h": "24시간",
    week_days: "7일",
    month: "30일",
    select_rank_all: "모든 섹터",
    select_rank_32: "32G 섹터",
    select_rank_64: "64G 섹터",
    more: "더보기",
    rank_time: "마지막 업데이트 시간:",
    // table columns title
    //存储池排行
    ranking: "순위",
    pool_owner: "Owner ID",
    pool_power: "유효 해시파워",
    pool_efficiency_24h: "최근 24시간 생산 효율",
    pool_increase_24h: "최근 24시간 해시파워 증가량",
    pool_block_count: "총 블록 수",
    pool_block_count_24h: "최근 24시간 블록 수",
    miner: "노드",
    // 节点排行
    provider_miner: "노드",
    provider_power_ratio: "유효 해시파워 / 비율",
    provider_block_ratio: "최근 24시간 블록 / 비율",
    provider_rewards_ratio: "최근 24시간 보상 / 비율",
    balance: "잔액",
    //算力增速
    power_ratio: "해시파워 증가율",
    power_ratio_tip: "선택한 주기 내에서, 매일 평균 패키징된 섹터의 유효 해시파워 총합",
    quality_power_increase: "해시파워 증가량",
    quality_power_increase_tip: "선택한 주기 내에서, 노드의 유효 해시파워 증가량",
    quality_adj_power: "유효 해시파워",
    raw_power: "원래 해시파워",
    sector_size: "섹터 크기",
    //节点收益
    "rewards/ratio": "블록 보상 / 비율",
    "rewards/ratio_tip": "선택한 주기 내에서, 노드가 블록 보상을 받은 비율",
    block_count: "블록 수",
    winning_rate: "낙첨 확률",
    block_count_tip: "Filecoin 경제 모델에서, 높이 (tipset) 당 여러 블록 (block)이 있을 수 있으며 각 블록은 여러 보상 (win count)을 받을 수 있습니다."
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rankZh);


/***/ }),

/***/ 6248:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const statistic = {
    show_more: "더 보기",
    "24h": "24시간",
    "7d": "7일",
    "30d": "30일",
    year: "1년",
    // power
    "power": "해시파워 추이",
    power_tips: "기준선은 Filecoin 네트워크가 요구하는 네트워크 성장 규모이며, 메인넷 온라인 시 2.5EiB이며, 연간 100% 증가율입니다.",
    trend_24: "24시간 기본 수수료 추이",
    total_raw_byte_power: "원래 해시파워",
    base_line_power: "기준선 추이",
    change_quality_adj_power: "환비 유효 해시파워 변화",
    total_quality_adj_power: "유효 해시파워",
    gas: "기본 수수료 추이",
    base_fee: "기본 수수료",
    gas_in_32g: "32GiB 섹터 Gas 소비",
    gas_in_64g: "64GiB 섹터 Gas 소비",
    //24_gas
    gas_24: "24시간 Gas 데이터",
    method_name: "메시지 유형",
    avg_gas_premium: "Gas 프리미엄",
    avg_gas_limit: "평균 Gas 한도",
    avg_gas_used: "평균 Gas 사용",
    avg_gas_fee: "평균 수수료",
    "sum_gas_fee/ratio": "수수료 합계/비율",
    "message_count/ratio": "메시지 수 합계/비율",
    //fil
    TokenRules: "Filecoin 토큰 할당 규칙",
    FilecoinFoundation: "Filecoin 재단",
    FundraisingRemainder: "모금 - 잔여 토큰",
    FundraisingSAFT: "모금 - 미래 토큰 간단 계약",
    MiningReserve: "저장 서비스 제공자를 위한 예비 토큰",
    TokenAllocation: "저장 공급자 토큰 할당",
    ReservedTokens: "저장 공급자 예비 토큰",
    Fundraising: "모금 방식 - 미래 토큰 간단 계약 2017",
    Funds: "모금 방식 - 잔여 자금",
    protocolLab: "프로토콜 실험실",
    Contributors: "프로토콜 실험실 팀 및 기여자",
    Allocation: "할당 항목",
    value: "금액",
    description: "구체적 용도",
    filBase: "FIL 기본 할당",
    filBase_des: "네트워크에서 FIL 주조 상한",
    ReservedTokens_des: "미래 Filecoin 경제 성장을 위해 예비 된 토큰 저장소, 구체적인 사용 방안은 Filecoin 커뮤니티에서 결정됩니다.",
    TokenAllocation_des: "블록 보상, 네트워크 초기화 등을 통해 저장 공급자에게 할당되는 토큰 보상",
    Fundraising_des: "2017년 판매된 토큰",
    Funds_des: "생태계 발전 및 후속 자금 조달 용도",
    protocolLab_des: "프로토콜 실험실 관련 작업용",
    Contributors_des: "4.5%는 프로토콜 실험실 팀 및 기여자에게 지급됩니다.",
    //charts
    pie_title: "그래프 통계",
    block_trend: "블록 보상",
    block_reward_per_TiB: "생산 효율",
    acc_block_rewards: "누적 블록 보상",
    active_nodes: "활성 노드 수",
    active_miner_count: "노드 수",
    messages_trend: "메시지 수 추이 그래프",
    message_count: "블록 평균 메시지 추이",
    all_message_count: "총 메시지 추이",
    pie_title_a: "현재 FIL 기본 할당 용도 통계",
    pie_title_a_tip: "저장 공급자 보상으로 제공된 FIL + 잠금 해제 보상으로 이미 해제된 FIL + 예약된 일부 할당된 FIL = 현재 이미 해제된 FIL",
    pie_title_b: "현재 이미 해제된 FIL 용도 통계",
    mined: "저장 공급자에게 제공된 FIL",
    remaining_mined: "남아있는 저장 공급자 보상 FIL",
    vested: "잠금 해제 된 FIL",
    remaining_vested: "남은 잠금 해제 보상 FIL",
    reserve_disbursed: "할당된 예비 FIL(테스트넷 보상)",
    remaining_reserved: "남아있는 예비 FIL",
    locked: "섹터 예치된 FIL",
    burnt: "소각된 FIL",
    circulating: "거래 가능한 유통 FIL"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (statistic);


/***/ }),

/***/ 3551:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const tipset = {
    rank: "순위",
    tag: "태그",
    height: "블록 높이",
    cid: "메시지 CID",
    block_time: "시간",
    from: "보내는 주소",
    to: "받는 주소",
    value: "금액",
    method_name: "메시지 유형",
    //chain
    blocks_cid: "CID",
    blocks_miner: "노드",
    blocks_messages: "메시지",
    blocks_reward: "보상",
    win_count: "당첨 수",
    //cid_details
    message_list_total: "총 {{value}}개 메시지",
    chain_cid_detail: "블록 정보",
    cid_height: "높이",
    parent_weight: "부모 블록 가중치",
    parents_cid: "부모 블록 CID",
    parent_base_fee: "부모 블록 기본 수수료",
    ticket_value: "티켓 가치",
    state_root: "상태 루트",
    //message
    message_list: "메시지 목록",
    total_list: "총 {{value}}개 메시지",
    message_list_all: "전체 유형",
    message_list_exit_code: "상태 코드",
    message_list_method_name: "메시지 유형",
    // adress
    address_total_list: "총 {{value}}개 계정",
    address_list: "부자 순위",
    address_all: "전체 유형",
    account: "일반 계정",
    owner: "소유자 계정",
    miner: "노드 계정",
    payment: "지불 채널",
    multisig: "다중 서명 계정",
    account_address: "주소",
    balance_percentage: "잔액/비율",
    account_type: "유형",
    latest_transfer_time: "최근 전송 시간",
    //transfer
    transfer_list: "대액 전송 목록",
    transfer_total_list: "총 {{value}}개 기록",
    //dsn
    dsn_list: "거래 목록",
    dsn_total_list: "총 {{value}}개 거래",
    dsn_placeholder: "검색 고객/호스팅자/거래ID",
    deal_id: "거래 ID",
    piece_cid: "파일 ID",
    piece_size: "파일 크기",
    client_address: "고객",
    provider_id: "호스팅자",
    service_start_time: "시작 시간",
    end_time: "종료 시간",
    start_height: "시작 높이",
    end_height: "종료 높이",
    storage_price_per_height: "저장 요금",
    verified_deal: "확인된 거래",
    // pool-message
    pool_list: "메시지 풀 목록",
    gas_fee_cap: "Gas 한도",
    gas_premium: "Gas 프리미엄"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (tipset);


/***/ }),

/***/ 1014:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const contract = {
    overview: "概览",
    market: "Market",
    look_adres: "查看地址",
    gohome: "返回首页",
    reset_ver: "重新验证",
    next: "下一步",
    reset: "重置",
    confirm: "验证并发布",
    back: "返回",
    file_name: "选择 *.sol 文件",
    config_file_name: "选择 Metadata 文件",
    verify_title: "验证并发布合约源代码",
    verify_des: "编译器类型和版本选择",
    content_des: "源代码验证为与智能合约交互的用户提供了透明度。通过上传源代码，Filscan 将编译后的代码与区块链上的代码进行匹配。就像合同一样，“智能合同”应该为最终用户提供更多关于他们“数字签名”的目的的信息，并让用户有机会审核代码以独立验证它是否确实做了它应该做的事情。",
    address: "请输入您要验证的合约地址",
    address_placeholder: "请输入您要验证的合约地址",
    verify_address: "请选择编译版本",
    verify_address_placeholder: "请选择",
    license_type: "请输入开源许可证类型",
    content_des1: "1. 如果合同在 REMIX 处编译正确，则此处也应编译正确",
    content_des2: "2. 我们对验证由另一个合约创建的合约的支持有限，编译的每个合约的超时时间最多为45秒",
    content_des3: "3. 对于编程合同验证，请查看合同 API 端点",
    checkbox_service: "我同意服务条款",
    verify_select_placeholder: "请选择",
    //logs
    ver_sucess: "Success: 验证成功",
    ver_err: "Error: 验证失败",
    has_been_verified: "Error:合约已验证",
    byte_code: "编译日志",
    contract_name: "合约名",
    local_byte_code: "合约字节码",
    compiler: "编译器版本",
    //step1
    address_verify: "合约地址",
    step1_verify_des: "请选择单个或多个 *.SOL 文件",
    source_code: "合约源码",
    compile_version: "编译器",
    compile_output: "编译输出",
    Optimizations: "优化参数",
    run_optimizer: "运行(优化器)",
    arguments: "构造函数参数",
    optimize: "优化开启",
    optimize_runs: "RUNS",
    //token list 
    token_list: "全部通证",
    token_name: "Token",
    vol_24: "成交量(24h)",
    transfer_total: "共 {{value}} 条消息",
    owner_total: "总共 {{value}} 人持有",
    dex_total: "共 {{value}} 条交易",
    //nft list 
    nfts_list: "全部 NFTs",
    trading_volume: "全部成交量",
    // ft /fns dashborad
    "total_supply": "MAX总供应量",
    "owners": "持有人",
    "transfers": "总共转移",
    latest_price: "价格",
    market_value: "市值",
    token_contract: "通证合约",
    transfer: "转移",
    owner: "拥有者",
    owner_nft: "拥有者",
    domain: "合约",
    dex: "DEX 交易",
    //list 
    message_cid: "消息ID",
    method: "Method",
    time: "时间",
    from: "发送地址",
    to: "接收地址",
    amount: "数量",
    //拥有者
    rank: "排行",
    percentage: "占比",
    //dex
    platform: "交易平台",
    Txn_Value: "Txn Value",
    "swapped_Rate": "Swapped Rate",
    "Token_Amount_in": "Token Amount(In)",
    "Token_Amount_out": "Token Amount(Out)",
    Action: "Action",
    //合约列表
    contract_list: "已验证合约",
    contract_address: "地址",
    language: "语言",
    license: "许可证",
    //合约详情
    contract_list_total: "共 {{value}} 个合约",
    byte_code_no_verify: "合约未验证，去",
    go_to_verify: "验证合约",
    verify_contract: "合约源代码已通过验证",
    source_code: "合约源代码",
    source_code_create: "合约创建代码",
    source_abi: "合约ABI",
    source_abi_default: "导出ABI",
    nfts_list: "NFTs List",
    item: "Item",
    Items: "数量",
    controller: "域名注册人",
    //rank
    contract_rank_des: "上次更新时间为:{{value}}",
    contract_rank_total: "共 {{value}} 个合约 ",
    contract_rank: "合约排行",
    rank: "排名",
    actor_id: "actorID",
    ver_address: "待验证",
    actor_address: "actorAddress",
    transaction_count: "交易数量",
    user_count: "交易地址",
    actor_balance: "Balance",
    gas_cost: "Gas消耗",
    //log 
    epoch: "高度",
    cid: "消息ID",
    event_name: "方法",
    topics: "主题",
    coompoent_data: "参数",
    log_index: "序号",
    removed: "移除"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contract);


/***/ }),

/***/ 5584:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// pool-detail 
const detail = {
    "24h": "24时",
    "7d": "7天",
    "30d": "30天",
    "1year": "1年",
    look_all: "查看全部数据",
    //owner
    "owner_title": "存储池详情",
    "owner_title_tip": "存储池详情：存储池数据由名下节点数据,汇总而成",
    message_list_all: "全部方法",
    account: "账户",
    owner_address: "Owner地址",
    owned_miners: "名下节点",
    owned_active_miners: "名下活跃节点",
    miner: "Miner",
    evm: "EVM",
    ethaddress: "ETHAddress",
    ethaccount: "ETHAccount",
    //account_type
    account_name: "账户",
    latest_transfer_time: "最新交易时间",
    multisig: "多签账户",
    account_detail: "储存池详情",
    from_ath: "发送方",
    to_ath: "接受方",
    account_id: "账户地址",
    //概览
    owner_overview_title: "存储池概览",
    balance: "账户余额",
    available_balance: "可用余额",
    init_pledge: "扇区质押",
    pre_deposits: "预存款",
    locked_balance: "锁仓奖励",
    sector_count: "全部",
    live_sector_count: "有效",
    fault_sector_count: "错误",
    recover_sector_count: "恢复",
    eth_address: "ETH Address",
    stable_address: "稳定地址",
    tokenList: "持有Tokens",
    showContract: "合约: {{value}}",
    showAddress: "地址: {{value}}",
    //统计指标
    indicators: "统计指标",
    power_increase_indicators: "算力增量",
    power_ratio: "算力增速",
    sector_increase: "扇区增量",
    precommit_deposits: "扇区抵押",
    gas_fee: "Gas消耗",
    block_rewards: "出块奖励",
    block_count: "出块数量",
    block_count_tip: "出块数 = 出块数量（block）的总和",
    mining_efficiency: "效率",
    mining_efficiency_tip: "选定周期内，节点累计出块奖励与有效算 力的比值",
    lucky: "幸运值",
    sector_ratio: "扇区增速",
    sector_ratio_tip: "",
    win_count: "赢票数量",
    win_count_tip: "Filecoin经济模型中，一个高度 （tipset）下可能有多个区块（block），每 个区块可能获得多份奖励（win count）。 累计出块份数=每次出块获得奖励份数的总和",
    net_profit_per_tb: "单T消耗",
    net_profit_per_tb_tip: "选定周期内单T封装扇区大小Gas消耗",
    //账户变化
    owner_account_change: "账户变化",
    power: "有效算力",
    power_increase: "有效算力增长",
    quality_adjust_power: "有效算力",
    quality_power_rank: "排名",
    raw_power_percentage: "算力占比",
    raw_power: "原值算力",
    total_block_count: "30天出块数",
    total_block_count_tip: "近30天总出块数",
    total_reward: "30天奖励",
    total_reward_tip: "近30天奖励",
    total_win_count: "30天赢票",
    total_win_count_tip: "近30天总赢票",
    sector_size: "扇区大小",
    sector_stauts: "扇区状态",
    //账户总览
    account_overview: "账户总览",
    create_time: "创建时间",
    account_type: "账户类型",
    peer_id: "节点标识",
    account_address: "地址",
    // eslint-disable-next-line no-dupe-keys
    owner_address: "Owner",
    area: "地区",
    worker_address: "Worker",
    controllers_address: "Controller",
    beneficiary_address: "Beneficiary",
    code_cid: "代码 CID",
    nonce: "Nonce 数",
    contract_verify: "合约",
    contract_name: "合约名称",
    //miner 
    //pool_overview_title:'账户',
    // message
    message_overview_detail: "交易明细",
    trade: "内部交易",
    message_detail: "概况",
    event_log: "事件日志",
    message_overview: "消息概览",
    eth_message: "ETH Hash",
    cid: "消息ID",
    height: "高度",
    time: "时间",
    blk_cids: "区块",
    value: "金额",
    from: "发送地址",
    to: "接收地址",
    status: "状态",
    method_name: "方法",
    message_other: "其他信息",
    version: "版本编号",
    // eslint-disable-next-line no-dupe-keys
    nonce: "Nonce",
    gas_fee_cap: "手续费率上限",
    gas_premium: "节点小费费率",
    gas_limit: "Gas用量上限",
    gas_used: "Gas实际用量",
    base_fee: "基础手续费率",
    all_gas_fee: "手续费",
    params: "参数",
    returns: "返回值",
    message_tranf: "转账信息",
    from_tranf: "发送方",
    to_tranf: "接受方",
    consume_type: "类型",
    MinerTip: "节点手续费",
    BaseFeeBurn: "销毁手续费",
    Transfer: "转账",
    Burn: "销毁聚合费用",
    exit_code: "状态",
    //内部交易
    amount: "价值",
    method: "方法",
    topic: "主题",
    //通证转移
    message_ERC20Trans: "通证转移",
    message_NftTrans: "NFTs 转移",
    // 出块列表
    block_cid: "区块Cid",
    block_height: "区块高度",
    block_time: "出块时间",
    block_messages_count: "消息数",
    block_miner_id: "节点地址",
    block_mined_reward: "出块奖励",
    //miner
    message_list: "消息列表",
    block_list: "出块列表",
    traces_list: "转账列表",
    event_log: "事件日志",
    message_list_total: "共 {{value}} 条消息",
    block_list_total: "总计 {{value}} 区块",
    traces_list_total: "总计 {{value}} 条消息",
    contract_token_list_total: "总计 {{value}} 条代币",
    //general 
    general_overview_title: "账户概览",
    base_account_id: "账户ID",
    //dns detail 
    deal_details: "订单详情",
    deal_id: "交易ID",
    epoch: "所属区块",
    service_start_time: "创建时间",
    message_cid: "所属消息",
    piece_cid: "Piece CID",
    verified_deal: "已验证",
    deal_hosting: "托管详情",
    deal_left_title: "客户",
    deal_right_title: "托管节点",
    deal_value: "质押金额",
    deal_cash: "托管费用",
    deal_time: "至",
    user_count: "交易地址",
    transfer_count: "交易次数",
    go_verify: "去验证",
    contract_token_list: "代币",
    token_name: "Token Name",
    contract_id: "Contract Id",
    amount: "Amount"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (detail);


/***/ }),

/***/ 1628:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const domain = {
    domain_title: "概览",
    resolved_address: "解析地址",
    expired_at: "过期时间",
    registrant: "注册人",
    controller: "控制人",
    allDomains: "此地址拥有的域名 共{{value}} 个",
    Result_for: "查询结果"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (domain);


/***/ }),

/***/ 8593:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fvm = {
    all: "FVM生态项目总览",
    Defi: "Defi",
    Dex: "Dex",
    DID: "DID",
    NFT: "NFT",
    MarketPlace: "MarketPlace",
    Launchpad: "Launchpad"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fvm);


/***/ }),

/***/ 4363:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const home = {
    seconds: "秒",
    minutes: "分",
    hours: "时",
    day: "天",
    //meta
    meta_title: "全网数据指标",
    mata_show: "展开",
    mata_show_false: "收起",
    latest_height: "最新区块高度",
    latest_block_time: "最新区块时间",
    total_blocks: "全网出块数量",
    total_rewards: "全网出块奖励",
    total_quality_power: "全网有效算力",
    total_quality_power_tip: "当前全网有效算力（有效存储空间）的总和",
    base_fee: "当前基础费率",
    miner_initial_pledge: "当前扇区质押量",
    power_increase_24h: "近24h增长算力",
    rewards_increase_24h: "近24h出块奖励",
    fil_per_tera_24h: "近24h产出效率",
    fil_per_tera_24h_tip: "最近24小时的总出块奖励与有效算力的比值",
    gas_in_32g: "32GiB扇区Gas消耗",
    gas_in_32g_tip: "近24小时密封32G扇区每T所要消耗的Gas值",
    add_power_in_32g: "预估32GiB扇区新增算力成本",
    add_power_in_32g_tip: "近24小时32G扇区新增算力所需要花费的成本，包括扇区质押和封装手续费",
    gas_in_64g: "64GiB扇区Gas消耗",
    gas_in_64g_tip: "近24小时密封64G扇区每T所要消耗的Gas值",
    add_power_in_64g: "预估64GiB扇区新增算力成本",
    add_power_in_64g_tip: "近24小时64G扇区新增算力所需要花费的成本，包括扇区质押和封装手续费",
    win_count_reward: "每赢票奖励",
    win_count_reward_tip: "最新高度的单位出块奖励，每个高度有多个区块，每个区块均可获得该奖励",
    avg_block_count: "平均每高度区块数量",
    avg_block_count_tip: "最近24h平均每个高度下的区块数量",
    avg_message_count: "平均每高度消息数",
    avg_message_count_tip: "最近24h平均每个高度下的消息数量",
    active_miners: "活跃节点数",
    burnt: "销毁量",
    circulating_percent: "流通率",
    rank: "排行榜",
    footer_text: "Filscan浏览器是 Filecoin 区块链浏览器及数据服务平台,提供基于 Filecoin 的各类节点收益排行榜、区块链数据查询、可视化图表等一站式数据服务.",
    footer_outlook: "邮箱",
    footer_detail_a: "版权所有 \xa9 Filecoin开发补助计划 遵循",
    footer_detail_b: " 和 ",
    footer_detail_c: "版权协议",
    search_notFound: "搜索无结果",
    warn_text: "Oops! 您输入的搜索字符:",
    warn_details: "对不起！这是一个无效的字符串",
    go_home: "返回首页"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (home);


/***/ }),

/***/ 7932:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const zh = {
    network_title: "当前网络",
    home: "首页",
    contract: "合约",
    contract_verify: "合约验证",
    contract_list: "已验证合约",
    contract_rank: "合约排行",
    token: "Tokens",
    nft: "NFTs",
    tipset: "区块链",
    tipset_chain: "区块",
    tipset_message: "消息",
    tipset_ranking: "富豪榜",
    tipset_transfer: "大额转账",
    tipset_dsn: "订单",
    "tipset_pool-message": "消息池",
    ranking: "排行榜",
    statistics: "统计",
    statistics_gas: "Gas费趋势",
    statistics_base: "算力走势",
    statistics_fil: "FIL",
    statistics_charts: "图表统计",
    statistics_map: "节点地图",
    resources: "资源",
    resources_tools: "常用工具",
    provider: "存储提供者",
    fvm: "FVM生态总览",
    //search 
    "search_holder": "请输入地址/消息ID/高度/区块Cid/节点ID/FNS",
    all: "全部筛选类型",
    address: "地址",
    message_id: "消息ID",
    height: "高度",
    cid: "区块CID",
    node: "节点"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (zh);


/***/ }),

/***/ 5302:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const rankZh = {
    pool: "存储池排行",
    provider: "节点排行",
    growth: "算力增速",
    rewards: "节点收益",
    "24h": "24时",
    week_days: "7天",
    month: "30天",
    select_rank_all: "全部扇区",
    select_rank_32: "32G 扇区",
    select_rank_64: "64G 扇区",
    more: "更多",
    rank_time: "上次更新时间为",
    // table columns title
    //存储池排行
    ranking: "排名",
    pool_owner: "Owner ID",
    pool_power: "有效算力",
    pool_efficiency_24h: "近24h产出效率",
    pool_increase_24h: "近24h算力增量",
    pool_block_count: "出块总数",
    pool_block_count_24h: "近24h出块总数",
    miner: "节点",
    // 节点排行
    provider_miner: "节点",
    provider_power_ratio: "有效算力/占比",
    provider_block_ratio: "近24h 出块/占比",
    provider_rewards_ratio: "近24h 奖励/占比",
    balance: "余额",
    //算力增速
    power_ratio: "算力增速",
    power_ratio_tip: "选定周期内，平均每天完成封装扇区的有效算力总和",
    quality_power_increase: "算力增量",
    quality_power_increase_tip: "选定周期内，节点的有效算力增量",
    quality_adj_power: "有效算力",
    raw_power: "原值算力",
    sector_size: "扇区大小",
    //节点收益
    "rewards/ratio": "出块奖励/占比",
    "rewards/ratio_tip": "在选定周期内，节点获得出块奖励与累计产出区块奖励的比值。",
    block_count: "出块数",
    winning_rate: "赢票率",
    block_count_tip: "Filecoin经济模型中，一个高度（tipset）下可能有多个区块（block），每个区块可能获得多份奖励（win count）。"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rankZh);


/***/ }),

/***/ 596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const statistic = {
    show_more: "更多",
    "24h": "24时",
    "7d": "7天",
    "30d": "30天",
    year: "1年",
    // power 
    "power": "算力走势",
    power_tips: "基线标准即是Filecoin网络要求的网络增长规模，主网上线时2.5EiB，每年100%增长率。",
    trend_24: "24h基础手续费走势",
    total_raw_byte_power: "原值算力",
    base_line_power: "基线走势",
    change_quality_adj_power: "环比有效算力变化",
    total_quality_adj_power: "有效算力",
    gas: "基础手续费走势",
    base_fee: "基础手续费",
    gas_in_32g: "32GiB 扇区Gas消耗",
    gas_in_64g: "64GiB 扇区Gas消耗",
    //24_gas
    gas_24: "24h Gas 数据",
    method_name: "消息类型",
    avg_gas_premium: "Gas Premium",
    avg_gas_limit: "平均Gas限额",
    avg_gas_used: "平均Gas消耗",
    avg_gas_fee: "平均手续费",
    "sum_gas_fee/ratio": "手续费合计/占比",
    "message_count/ratio": "消息数合计/占比",
    //fil
    TokenRules: "Filecoin通证分配细则",
    FilecoinFoundation: "Filecoin基金会",
    FundraisingRemainder: "募资 – 剩余通证",
    FundraisingSAFT: "募资 – 未来通证简单协议",
    MiningReserve: "为存储服务提供者预留通证",
    TokenAllocation: "存储提供者通证分配",
    ReservedTokens: "存储提供者预留通证",
    Fundraising: "募资形式 – 未来通证简单协议 2017",
    Funds: "募资形式 – 剩余资金",
    protocolLab: "协议实验室",
    Contributors: "协议实验室团队和贡献者",
    Allocation: "分配项目",
    value: "数额",
    description: "具体用途",
    filBase: "FIL的基础发放",
    filBase_des: "网络FIL铸造上限",
    ReservedTokens_des: "为未来Filecoin经济增长而预留的通证储备，具体未来使用方案由Filecoin社区决定",
    TokenAllocation_des: "通过区块奖励、网络初始化等方式分给存储提供者的通证奖励",
    Fundraising_des: "2017年出售的通证",
    Funds_des: "用作生态发展和后续融资",
    protocolLab_des: "用作协议实验室的相关工作",
    Contributors_des: "4.5%给协议实验室团队和贡献者",
    //charts 
    pie_title: "图表统计",
    block_trend: "区块奖励",
    block_reward_per_TiB: "产出效率",
    acc_block_rewards: "累计区块奖励",
    active_nodes: "活跃节点数",
    active_miner_count: "节点数量",
    messages_trend: "消息数走势图",
    message_count: "区块平均消息走势",
    all_message_count: "总消息走势",
    pie_title_a: "当前Fil的基础发放用途统计",
    pie_title_a_tip: "已提供存储者奖励的Fil + 已释放锁仓奖励的Fil + 已分配保留部分的Fil = 当前已释放的Fil",
    pie_title_b: "当前已释放的Fil用途统计",
    mined: "已提供存储者奖励的Fil",
    remaining_mined: "剩余存储者奖励的Fil",
    vested: "已释放锁仓奖励的Fil	",
    remaining_vested: "剩余锁仓奖励的Fil",
    reserve_disbursed: "已分配保留部分的Fil(测试网奖励)",
    remaining_reserved: "剩余保留部分的Fil",
    locked: "扇区抵押的Fil",
    burnt: "已销毁的Fil",
    circulating: "可交易流通的Fil"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (statistic);


/***/ }),

/***/ 5636:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const tipset = {
    rank: "排名",
    tag: "标签",
    height: "区块高度",
    cid: "消息ID",
    block_time: "时间",
    from: "发送地址",
    to: "接收地址",
    value: "数额",
    method_name: "方法",
    //chain
    blocks_cid: "Cid",
    blocks_miner: "节点",
    blocks_messages: "消息",
    blocks_reward: "奖励",
    win_count: "赢票",
    //cid_details
    message_list_total: "共 {{value}} 条消息",
    chain_cid_detail: "区块详情",
    cid_height: "高度",
    parent_weight: "父块重量",
    parents_cid: "父块CID",
    parent_base_fee: "父基础费率",
    ticket_value: "票值",
    state_root: "根",
    //message 
    message_list: "消息列表",
    total_list: "共 {{value}} 条消息",
    message_list_all: "全部方法",
    message_list_exit_code: "状态",
    message_list_method_name: "方法名称",
    // adress
    address_total_list: "共有 {{value}} 账户",
    address_list: "富豪榜",
    address_all: "全部类型",
    account: "一般账户",
    owner: "所有者账户",
    miner: "节点账户",
    payment: "支付通道",
    multisig: "多签账户",
    account_address: "地址",
    balance_percentage: "余额/占比",
    account_type: "类型",
    latest_transfer_time: "最新交易时间",
    //transfer
    transfer_list: "大额转账记录",
    transfer_total_list: "共有 {{value}} 条信息",
    //dsn
    dsn_list: "订单列表",
    dsn_total_list: "共 {{value}} 条交易",
    dsn_placeholder: "搜素 客户/托管者/交易ID",
    deal_id: "交易ID",
    piece_cid: "文件ID",
    piece_size: "文件大小",
    client_address: "客户",
    provider_id: "托管者",
    service_start_time: "开始时间",
    end_time: "结束时间",
    start_height: "开始高度",
    end_height: "结束高度",
    storage_price_per_height: "存储费用",
    verified_deal: "已验证",
    // pool-message
    pool_list: "消息池列表",
    gas_fee_cap: "Gas限额",
    gas_premium: "Gas Premium"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (tipset);


/***/ }),

/***/ 3738:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_nav__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2263);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3435);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _assets_images_mobile_menuup_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(931);
/* harmony import */ var _assets_images_mobile_menudown_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1826);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7987);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_6__]);
react_i18next__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










function Menu() {
    const { t , i18n  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "nav"
        });
    };
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const [showMenu, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [select, setSelect] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const handleClick = (link)=>{
        if (link) router.push(link);
        setShow(false);
    };
    const renderMenu = (menuItem)=>{
        return menuItem === null || menuItem === void 0 ? void 0 : menuItem.map((child, index)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu_ul_item_li),
                onClick: ()=>handleClick(child.link),
                children: tr(child.key)
            }, index);
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                src: showMenu ? _assets_images_mobile_menudown_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z : _assets_images_mobile_menuup_png__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                width: 32,
                alt: "menu",
                onClick: ()=>{
                    setShow(!showMenu);
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu_ul),
                style: {
                    display: showMenu ? "block" : "none"
                },
                children: _contants_nav__WEBPACK_IMPORTED_MODULE_1__/* .navMenu.map */ .$.map((menu, index)=>{
                    if (menu.childrens) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu_ul_item),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu_ul_item_select),
                                    onClick: ()=>{
                                        setSelect(select === menu.key ? "" : menu.key);
                                    },
                                    children: [
                                        tr(menu.key),
                                        " ",
                                        select === menu.key ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_7__.UpOutlined, {
                                            rev: undefined
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_7__.DownOutlined, {
                                            rev: undefined
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    style: {
                                        display: select === menu.key ? "block" : "none"
                                    },
                                    children: renderMenu(menu.childrens)
                                })
                            ]
                        }, index);
                    }
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu_ul_item),
                        onClick: ()=>handleClick(menu.link),
                        children: tr(menu.key)
                    }, index);
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mobile_menu_mask),
                style: {
                    display: showMenu ? "block" : "none"
                },
                onClick: ()=>{
                    setShow(false);
                }
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Menu);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4442:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_images_logo_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2822);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3435);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1517);
/* harmony import */ var _Menu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3738);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_search__WEBPACK_IMPORTED_MODULE_3__, _Menu__WEBPACK_IMPORTED_MODULE_4__]);
([_components_search__WEBPACK_IMPORTED_MODULE_3__, _Menu__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().mobile_header),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().mobile_header_top),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().mobile_header_top_image),
                        onClick: ()=>{
                            next_router__WEBPACK_IMPORTED_MODULE_5___default().push("/home");
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                src: _assets_images_logo_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                                alt: "Fliscan Logo",
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().mobile_header_logo)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().logo_title),
                                children: "Filscan"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().mobile_header_top_right),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Menu__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().mobile_header_bottom),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_search__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9956:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5537);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8194);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3775);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { options , defaultValue , border , warpClass , onChange , className , valueClass , value , ns  } = props;
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns
        });
    };
    const [label, setLabel] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (value || defaultValue) {
            const defaultItem = options.find((v)=>v.value === defaultValue || v.value === value);
            if (defaultItem) {
                setLabel(ns ? tr(defaultItem === null || defaultItem === void 0 ? void 0 : defaultItem.label) : defaultItem === null || defaultItem === void 0 ? void 0 : defaultItem.label);
            }
        }
    }, [
        value,
        defaultValue,
        filscanStore.filscan
    ]);
    const handleChange = (item)=>{
        setLabel(ns ? tr(item.label) : item.label);
        if (onChange) onChange(item);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().custom_select)} ${className} ${border ? (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().border_select) : ""}`,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().custom_select_value)} ${valueClass} `,
                children: [
                    label,
                    (0,_svgUtils__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)("down")
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().custom_select_contains)} ${warpClass} `,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().custom_select_wrap),
                    children: options.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            value: item.value + index,
                            onClick: ()=>handleChange(item),
                            children: ns ? tr(item.label) : item.label
                        }, item.value);
                    })
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3847:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_dist_reset_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9107);
/* harmony import */ var antd_dist_reset_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_dist_reset_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3716);
/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_common_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7526);
/* harmony import */ var _styles_common_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_common_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_custom_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6333);
/* harmony import */ var _styles_custom_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_custom_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _styles_media_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8644);
/* harmony import */ var _styles_media_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_media_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9980);
/* harmony import */ var _components_footer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8173);
/* harmony import */ var _components_Bounday__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3712);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8194);
/* harmony import */ var _mobile_header__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4442);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var antd_locale_en_US__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9656);
/* harmony import */ var antd_locale_en_US__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(antd_locale_en_US__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var antd_locale_zh_CN__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2771);
/* harmony import */ var antd_locale_zh_CN__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(antd_locale_zh_CN__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var dayjs_locale_zh_cn__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5468);
/* harmony import */ var dayjs_locale_zh_cn__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(dayjs_locale_zh_cn__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _components_links__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2875);
/* harmony import */ var _components_loading__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6571);
/* harmony import */ var _i18n__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(7626);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(9927);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(6641);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_24__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Header__WEBPACK_IMPORTED_MODULE_7__, _components_footer__WEBPACK_IMPORTED_MODULE_8__, _mobile_header__WEBPACK_IMPORTED_MODULE_12__, _i18n__WEBPACK_IMPORTED_MODULE_19__, _utils_utils__WEBPACK_IMPORTED_MODULE_20__]);
([_components_Header__WEBPACK_IMPORTED_MODULE_7__, _components_footer__WEBPACK_IMPORTED_MODULE_8__, _mobile_header__WEBPACK_IMPORTED_MODULE_12__, _i18n__WEBPACK_IMPORTED_MODULE_19__, _utils_utils__WEBPACK_IMPORTED_MODULE_20__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 
























function App({ Component , pageProps  }) {
    const { t , i18n  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_10__.useTranslation)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_21__.useRouter)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(true);
    const [filscan, setFilscan] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
        theme: "light",
        lang: "zh"
    });
    const [locale, setLocal] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)((antd_locale_zh_CN__WEBPACK_IMPORTED_MODULE_15___default()));
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        setLoading(false);
        const filscan_local = localStorage.getItem("filscan");
        const Obj = JSON.parse(filscan_local || "{}");
        if (filscan_local && Obj.lanthemeg !== filscan.theme) {
            document.documentElement.setAttribute("theme", Obj.theme);
        }
        if (router.locale && router.locale !== filscan.lang) {
            const obj = {
                ...filscan,
                lang: router.locale
            };
            setFilscan({
                ...obj
            });
            i18n.changeLanguage(obj.lang);
        } else {
            const lang = navigator.language.startsWith("zh") ? "zh" : "en";
            if (lang !== filscan.lang) {
                setFilscan({
                    ...filscan,
                    lang: navigator.language.startsWith("zh") ? "zh" : "en"
                });
                i18n.changeLanguage(lang); // 更改i18n语言
            }
        }
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (router.asPath.includes("#")) {
            var _window_location;
            const a = router.asPath;
            window === null || window === void 0 ? void 0 : (_window_location = window.location) === null || _window_location === void 0 ? void 0 : _window_location.replace(a.replaceAll("/#", ""));
        }
    }, [
        router.asPath
    ]);
    const handleChange = (item)=>{
        if (item.lang === "zh") {
            dayjs__WEBPACK_IMPORTED_MODULE_13___default().locale("zh-cn");
            setLocal((antd_locale_zh_CN__WEBPACK_IMPORTED_MODULE_15___default()));
        } else {
            dayjs__WEBPACK_IMPORTED_MODULE_13___default().locale("en");
            setLocal((antd_locale_en_US__WEBPACK_IMPORTED_MODULE_14___default()));
        }
        document.documentElement.setAttribute("theme", item.theme);
        setFilscan(item);
    };
    if (loading) {
        return null;
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_24__.NextSeo, {
                title: filscan.lang === "zh" ? "Filscan--Filecoin 浏览器" : "Filscan--Filecoin Explorer",
                description: filscan.lang === "zh" ? `Filecoin官方区块浏览器,Filecoin官方浏览器, Filscan,Filecoin,最新区块,Filecoin Explorer,FIL,IPFS，FIL,Filecoin区块链查询浏览器,FIL浏览器,Filecoin浏览器,Filecoin区块查询,区块链搜索引擎,区块高度,区块链交易'` : `Filscan is a blockchain explorer that serves as a fundamental tool for the Filecoin ecosystem, providing real-time on-chain data. It enables users to query information about Filecoin's blockchain, transactions, FIL tokens, wallets, etc., and synchronizes real-time information from all nodes.`
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Bounday__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                fallback: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loading__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {}),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_23___default()), {
                        src: "https://www.googletagmanager.com/gtag/js?id=G-VZ0MMF5MLC"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_23___default()), {
                        id: "google-analytics",
                        children: `
         window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'G-VZ0MMF5MLC');
        `
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_store_content__WEBPACK_IMPORTED_MODULE_11__/* ["default"].Provider */ .Z.Provider, {
                        value: {
                            filscan,
                            setFilscan: handleChange
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_22__.ConfigProvider, {
                            locale: locale,
                            children: [
                                (0,_utils_utils__WEBPACK_IMPORTED_MODULE_20__/* .isMobile */ .tq)() ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mobile_header__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    value: {
                                        filscan,
                                        setFilscan
                                    }
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "main-container",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_links__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                            ...pageProps
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footer__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_router__WEBPACK_IMPORTED_MODULE_21__.withRouter)(App));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8194:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/** @format */ 
const FilscanState = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({
    theme: "light",
    lang: "zh-CN"
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FilscanState);


/***/ }),

/***/ 9107:
/***/ (() => {



/***/ }),

/***/ 7526:
/***/ (() => {



/***/ }),

/***/ 6333:
/***/ (() => {



/***/ }),

/***/ 3716:
/***/ (() => {



/***/ }),

/***/ 8644:
/***/ (() => {



/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(3573)


/***/ }),

/***/ 7066:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5725:
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ 9656:
/***/ ((module) => {

"use strict";
module.exports = require("antd/locale/en_US");

/***/ }),

/***/ 2771:
/***/ ((module) => {

"use strict";
module.exports = require("antd/locale/zh_CN");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 5468:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs/locale/zh-cn");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 6641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 9766:
/***/ ((module) => {

"use strict";
module.exports = import("bignumber.js");;

/***/ }),

/***/ 2021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 7987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9210,9505,3121,1664,5675,9189,1311,3775,9927], () => (__webpack_exec__(3847)));
module.exports = __webpack_exports__;

})();
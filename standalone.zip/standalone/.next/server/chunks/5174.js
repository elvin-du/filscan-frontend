exports.id = 5174;
exports.ids = [5174];
exports.modules = {

/***/ 43224:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "copy_wrap__ZheNH"
};


/***/ }),

/***/ 25174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ components_copy)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(85893);
// EXTERNAL MODULE: external "antd/lib/message"
var message_ = __webpack_require__(17369);
var message_default = /*#__PURE__*/__webpack_require__.n(message_);
// EXTERNAL MODULE: external "copy-to-clipboard"
var external_copy_to_clipboard_ = __webpack_require__(68887);
var external_copy_to_clipboard_default = /*#__PURE__*/__webpack_require__.n(external_copy_to_clipboard_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
;// CONCATENATED MODULE: ./assets/images/copy.svg
var _filter, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgCopy = function SvgCopy(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 13 14"
  }, props), _filter || (_filter = /*#__PURE__*/external_react_.createElement("filter", {
    id: "copy_svg__a"
  }, /*#__PURE__*/external_react_.createElement("feColorMatrix", {
    in: "SourceGraphic",
    values: "0 0 0 0 0.141176 0 0 0 0 0.450980 0 0 0 0 0.980392 0 0 0 1.000000 0"
  }))), _g || (_g = /*#__PURE__*/external_react_.createElement("g", {
    fill: "none",
    fillRule: "evenodd",
    filter: "url(#copy_svg__a)",
    transform: "translate(-213 -138)"
  }, /*#__PURE__*/external_react_.createElement("g", {
    fill: "#336afa",
    fillRule: "nonzero"
  }, /*#__PURE__*/external_react_.createElement("path", {
    d: "M222.389 139.944h-8.185c-.665.001-1.203.545-1.204 1.216v9.236c0 .67.54 1.215 1.204 1.215h8.185a1.21 1.21 0 0 0 1.204-1.215v-9.236c0-.67-.54-1.216-1.204-1.216zm.24 10.452a.243.243 0 0 1-.24.243h-8.185a.242.242 0 0 1-.241-.243v-9.236c0-.135.108-.243.24-.243h8.186c.133 0 .24.108.24.243z"
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M224.315 138h-8.185a.484.484 0 0 0-.482.486c0 .269.216.486.482.486h8.185c.133 0 .24.109.24.243v9.236c0 .269.216.486.482.486a.484.484 0 0 0 .482-.486v-9.236c0-.67-.54-1.215-1.204-1.215z"
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M220.704 143.585h-4.815a.484.484 0 0 0-.482.487c0 .268.216.486.482.486h4.815a.484.484 0 0 0 .481-.486.484.484 0 0 0-.481-.487zm-1.926 2.974h-2.89a.484.484 0 0 0-.48.487c0 .268.215.486.48.486h2.89a.484.484 0 0 0 .481-.486.484.484 0 0 0-.481-.487z"
  })))));
};
/* harmony default export */ const copy = (SvgCopy);
// EXTERNAL MODULE: ./components/copy/index.module.scss
var index_module = __webpack_require__(43224);
var index_module_default = /*#__PURE__*/__webpack_require__.n(index_module);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(59003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./svgsIcon.tsx
var svgsIcon = __webpack_require__(7947);
// EXTERNAL MODULE: ./components/device-detect/index.tsx
var device_detect = __webpack_require__(29676);
;// CONCATENATED MODULE: ./components/copy/index.tsx
/** @format */ 







/* harmony default export */ const components_copy = (({ text, icon, className })=>{
    const handleClick = ()=>{
        //copynavigator
        external_copy_to_clipboard_default()(text);
        return message_default().success("Clipboard Successfully");
    // navigator?.clipboard?.writeText(text).then(function() {
    //     /* clipboard successfully set */
    //     message.success('clipboard successfully')
    //     }, function() {
    //     /* clipboard write failed */
    //     message.warning('clipboard failed')
    //     });
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
        style: {
            cursor: "pointer",
            width: "13px"
        },
        className: external_classnames_default()(`flex-center text-bgCopy ${className}`, (index_module_default()).wrap),
        onClick: handleClick,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(device_detect/* BrowserView */.I, {
                children: [
                    (0,svgsIcon/* getSvgIcon */.a)("copyIcon"),
                    " "
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx(device_detect/* MobileView */.$, {
                children: icon ?? /*#__PURE__*/ jsx_runtime.jsx(copy, {
                    width: 13,
                    height: 14
                })
            })
        ]
    });
});


/***/ })

};
;
exports.id = 9035;
exports.ids = [9035];
exports.modules = {

/***/ 31037:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgTrendIcon = function SvgTrendIcon(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 14 14"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M0 0h14v14H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#1C6AFD",
    fillRule: "nonzero",
    d: "M2.676 2.088v8.99c0 .11.09.2.2.2h8.597a.611.611 0 1 1 0 1.222H2.5a1 1 0 0 1-1-1V2.088a.588.588 0 0 1 1.176 0Zm9.408 1.856a.623.623 0 0 1 0 .865l-2.22 2.306a1 1 0 0 1-1.44 0L7.38 6.032 5.272 8.222a.577.577 0 0 1-.832 0 .623.623 0 0 1 0-.864l2.22-2.307a1 1 0 0 1 1.44 0l1.044 1.084 2.109-2.19a.577.577 0 0 1 .831 0Z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgTrendIcon);

/***/ }),

/***/ 15713:
/***/ ((module) => {

// Exports
module.exports = {
	"modalAccount_icon": "trendModal_modalAccount_icon__dFUqN",
	"modalAccount_content": "trendModal_modalAccount_content__VjeaZ",
	"modalAccount_content_times": "trendModal_modalAccount_content_times___R9qn"
};


/***/ }),

/***/ 9035:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _assets_images_TrendIcon_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(31037);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25622);
/* harmony import */ var _src_detail_accountChange__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16735);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(76418);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd_lib_modal__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(15713);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(29745);
/* harmony import */ var _hooks_Translation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(62881);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_packages_segmented__WEBPACK_IMPORTED_MODULE_2__, _src_detail_accountChange__WEBPACK_IMPORTED_MODULE_3__, _contents_detail__WEBPACK_IMPORTED_MODULE_6__, _hooks_Translation__WEBPACK_IMPORTED_MODULE_7__]);
([_packages_segmented__WEBPACK_IMPORTED_MODULE_2__, _src_detail_accountChange__WEBPACK_IMPORTED_MODULE_3__, _contents_detail__WEBPACK_IMPORTED_MODULE_6__, _hooks_Translation__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { account } = props;
    const [isModalOpen, setModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("1m");
    const { tr } = (0,_hooks_Translation__WEBPACK_IMPORTED_MODULE_7__/* .Translation */ .W)({
        ns: "detail"
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().modalAccount),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().modalAccount_icon),
                onClick: ()=>{
                    setModalOpen(true);
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_TrendIcon_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_modal__WEBPACK_IMPORTED_MODULE_4___default()), {
                title: "",
                width: 1000,
                open: isModalOpen,
                footer: null,
                onCancel: ()=>setModalOpen(false),
                wrapClassName: "custom_modal " //noTopModal
                ,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().modalAccount_content),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_detail_accountChange__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        header: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mx-2.5 mb-2.5 mt-5 flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "HarmonyOS_Medium text-lg  font-medium",
                                    children: tr("account_change")
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    data: [
                                        {
                                            title: "7d",
                                            dataIndex: "7d"
                                        },
                                        {
                                            title: "30d",
                                            dataIndex: "1m"
                                        }
                                    ],
                                    ns: "detail",
                                    defaultValue: active,
                                    isHash: false,
                                    onChange: (value)=>{
                                        setActive(value);
                                    }
                                })
                            ]
                        }, "detail_account_change"),
                        accountId: account,
                        interval: active,
                        list: _contents_detail__WEBPACK_IMPORTED_MODULE_6__/* .address_detail */ .Tt.account_change.list
                    })
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
"use strict";
exports.id = 6801;
exports.ids = [6801];
exports.modules = {

/***/ 6801:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DF": () => (/* binding */ chain_cid),
/* harmony export */   "Hr": () => (/* binding */ pool_list),
/* harmony export */   "II": () => (/* binding */ dsn_columns),
/* harmony export */   "Js": () => (/* binding */ transfer_list),
/* harmony export */   "N5": () => (/* binding */ transfer_columns),
/* harmony export */   "Sk": () => (/* binding */ dsn_list),
/* harmony export */   "WO": () => (/* binding */ pool_columns),
/* harmony export */   "X": () => (/* binding */ address_list),
/* harmony export */   "Xd": () => (/* binding */ message_list),
/* harmony export */   "a": () => (/* binding */ address_list_columns),
/* harmony export */   "bE": () => (/* binding */ basic_height),
/* harmony export */   "mG": () => (/* binding */ message_list_columns),
/* harmony export */   "vG": () => (/* binding */ chain_columns)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5063);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9927);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var dayjs_plugin_relativeTime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4195);
/* harmony import */ var dayjs_plugin_relativeTime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(dayjs_plugin_relativeTime__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _assets_images_champion_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2577);
/* harmony import */ var _assets_images_runnerup_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6131);
/* harmony import */ var _assets_images_thirdrunner_png__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5694);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _varible__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(697);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_utils__WEBPACK_IMPORTED_MODULE_2__, _varible__WEBPACK_IMPORTED_MODULE_10__]);
([_utils_utils__WEBPACK_IMPORTED_MODULE_2__, _varible__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 










dayjs__WEBPACK_IMPORTED_MODULE_3___default().extend((dayjs_plugin_relativeTime__WEBPACK_IMPORTED_MODULE_4___default()));
const basic_height = [
    {
        dataIndex: "miner_id",
        title: "miner_id"
    },
    {
        dataIndex: "height",
        title: "height"
    },
    {
        dataIndex: "block_time",
        title: "block_time",
        render: (text)=>{
            const time = dayjs__WEBPACK_IMPORTED_MODULE_3___default()(text * 1000).format("YYYY-MM-DD HH:mm:ss");
            return `${time} (UTC + 08:00)`;
        }
    },
    {
        dataIndex: "cid",
        title: "cid"
    }
];
const chain_columns = [
    {
        dataIndex: "height",
        title: "height",
        render: (text, record)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                className: "link",
                href: `/tipset/chain?height=${text}`,
                children: text
            });
        }
    },
    {
        dataIndex: "cid",
        title: "blocks_cid",
        type: [
            "block_basic"
        ],
        render: (text, rowData)=>{
            const record = rowData === null || rowData === void 0 ? void 0 : rowData.block_basic;
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "array_item_column",
                children: record.map((data, index)=>{
                    if (data === null || data === void 0 ? void 0 : data.cid) {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            className: "link",
                            href: `/tipset/chain?cid=${data.cid}`,
                            children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(data.cid, 6)
                        }, index);
                    }
                    return "--";
                })
            });
        }
    },
    {
        dataIndex: "miner_id",
        title: "blocks_miner",
        render: (text, rowData)=>{
            const record = rowData === null || rowData === void 0 ? void 0 : rowData.block_basic;
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "array_item_column",
                children: record.map((data, index)=>{
                    if (data === null || data === void 0 ? void 0 : data.miner_id) {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            className: "link",
                            href: `/miner/${data.miner_id}`,
                            children: data.miner_id
                        }, index);
                    }
                    return "--";
                })
            });
        }
    },
    {
        dataIndex: "tag",
        title: "tag",
        render: (text, rowData)=>{
            const record = rowData.block_basic;
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "array_item_column",
                children: record === null || record === void 0 ? void 0 : record.map((data, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: (data === null || data === void 0 ? void 0 : data.tag) || "--"
                    }, index);
                })
            });
        }
    },
    {
        dataIndex: "messages_count",
        title: "blocks_messages",
        render: (text, rowData)=>{
            const record = rowData.block_basic;
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "array_item_column",
                children: record.map((data, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: (data === null || data === void 0 ? void 0 : data.messages_count) || 0
                    }, index);
                })
            });
        }
    },
    {
        dataIndex: "reward",
        title: "blocks_reward",
        render: (text, rowData)=>{
            const record = rowData.block_basic;
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "array_item_column",
                children: record.map((data, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: (data === null || data === void 0 ? void 0 : data.reward) ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(data.reward, false, false) : ""
                    }, index);
                })
            });
        }
    },
    {
        dataIndex: "block_time",
        title: "block_time",
        type: [
            "blocks",
            "block_basic"
        ],
        render: (text, rowData)=>{
            var _record_;
            const record = rowData.block_basic;
            const time = record.length > 0 && ((_record_ = record[0]) === null || _record_ === void 0 ? void 0 : _record_.block_time);
            if (time) {
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(time)
                });
            }
            return "--";
        }
    }
];
const chain_cid = {
    title: "chain_cid_detail",
    list: [
        {
            label: "blocks_cid",
            dataIndex: "cid",
            type: [
                "block_basic"
            ],
            render: (text, data)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    style: {
                        fontWeight: "bolder"
                    },
                    children: text
                });
            }
        },
        {
            label: "cid_height",
            dataIndex: "height",
            type: [
                "block_basic"
            ],
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: `/tipset/chain?height=${text}`,
                    className: "link",
                    children: text
                });
            }
        },
        {
            label: "block_time",
            dataIndex: "block_time",
            type: [
                "block_basic"
            ],
            render: (text, data)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format()
                });
            }
        },
        {
            label: "blocks_messages",
            dataIndex: "messages_count",
            type: [
                "block_basic"
            ]
        },
        {
            label: "blocks_miner",
            dataIndex: "miner_id",
            type: [
                "block_basic"
            ],
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: `/miner/${text}`,
                    className: "link",
                    children: text
                });
            }
        },
        {
            label: "win_count",
            dataIndex: "win_count"
        },
        {
            label: "blocks_reward",
            dataIndex: "mined_reward",
            type: [
                "block_basic"
            ],
            render: (text, data)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    children: [
                        (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 6),
                        " FIL"
                    ]
                });
            }
        },
        {
            label: "parents_cid",
            dataIndex: "parents",
            type: [
                "block_basic"
            ],
            render: (text, data)=>{
                var _data_parents;
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "array_item_column",
                    children: data === null || data === void 0 ? void 0 : (_data_parents = data.parents) === null || _data_parents === void 0 ? void 0 : _data_parents.map((item)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: `/tipset/chain?cid=${item}`,
                            className: "link",
                            children: item
                        }, item);
                    })
                });
            }
        },
        {
            label: "parent_weight",
            dataIndex: "parent_weight"
        },
        {
            label: "parent_base_fee",
            dataIndex: "parent_base_fee"
        },
        {
            label: "ticket_value",
            dataIndex: "ticket_value"
        },
        {
            label: "state_root",
            dataIndex: "state_root"
        }
    ],
    total: "message_list_total",
    columns: [
        {
            dataIndex: "cid",
            title: "cid",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: `/message/${text}`,
                    className: "link",
                    children: text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6) : ""
                })
        },
        {
            dataIndex: "height",
            title: "height",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: `/tipset/chain?height=${text}`,
                    className: "link",
                    children: text
                })
        },
        {
            dataIndex: "block_time",
            title: "block_time",
            render: (text)=>dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm")
        },
        {
            dataIndex: "from",
            title: "from",
            render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_10__/* .get_account_type */ .$B)(record.from_type, text)
        },
        {
            dataIndex: "to",
            title: "to",
            render: (text, record)=>{
                return (0,_varible__WEBPACK_IMPORTED_MODULE_10__/* .get_account_type */ .$B)(record.to_type, text);
            }
        },
        {
            dataIndex: "value",
            title: "value",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL"
        },
        {
            dataIndex: "exit_code",
            title: "message_list_exit_code"
        },
        {
            dataIndex: "method_name",
            title: "method_name"
        }
    ]
};
const message_list = {
    title: "message_list",
    total_list: "total_list"
};
const message_list_columns = [
    {
        dataIndex: "cid",
        title: "cid",
        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: `/message/${text}`,
                className: "link",
                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6)
            })
    },
    {
        dataIndex: "height",
        title: "height",
        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: `/tipset/chain?height=${text}`,
                className: "link",
                children: text
            })
    },
    {
        dataIndex: "block_time",
        title: "block_time",
        render: (text)=>dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm")
    },
    {
        dataIndex: "from",
        title: "from",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_10__/* .get_account_type */ .$B)(record.from_type, text)
    },
    {
        dataIndex: "to",
        title: "to",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_10__/* .get_account_type */ .$B)(record.to_type, text)
    },
    {
        dataIndex: "value",
        title: "value",
        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 4) + "FIL"
            })
    },
    {
        dataIndex: "exit_code",
        title: "message_list_exit_code"
    },
    {
        dataIndex: "method_name",
        title: "method_name"
    }
];
const address_list = {
    title: "address_list",
    total_list: "address_total_list",
    options: [
        {
            value: "all",
            label: "address_all"
        },
        {
            value: "account",
            label: "account"
        },
        // { value: "2", label: "owner" },
        {
            value: "storageminer",
            label: "miner"
        },
        // { value: "9", label: "payment" },
        {
            value: "multisig",
            label: "multisig"
        }
    ]
};
const address_list_columns = (tr)=>{
    return [
        {
            dataIndex: "rank",
            title: "rank",
            width: "15%",
            render: (_text, record, index)=>{
                const url = _text === 1 ? _assets_images_champion_png__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z : _text === 2 ? _assets_images_runnerup_png__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z : _text === 3 ? _assets_images_thirdrunner_png__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z : "";
                return _text < 4 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_9___default()), {
                    src: url,
                    width: 24,
                    className: "rank-icon",
                    alt: ""
                }) : _text;
            }
        },
        {
            width: "15%",
            dataIndex: "account_address",
            title: "account_address",
            render: (text, record)=>{
                return (0,_varible__WEBPACK_IMPORTED_MODULE_10__/* .get_account_type */ .$B)(record === null || record === void 0 ? void 0 : record.account_type, text);
            }
        },
        {
            dataIndex: "balance",
            width: "20%",
            title: "balance_percentage",
            rowKey: "balance_percentage",
            render: (text, record)=>{
                return `${(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 2)} FIL / ${(record.balance_percentage * 100).toFixed(2)}%`;
            }
        },
        {
            dataIndex: "account_type",
            title: "account_type",
            width: "20%",
            render: (text)=>{
                return `${tr(text)}`;
            }
        },
        {
            dataIndex: "latest_transfer_time",
            width: "20%",
            title: "latest_transfer_time",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
        }
    ];
};
const transfer_list = {
    title: "transfer_list",
    total_list: "transfer_total_list"
};
const transfer_columns = [
    {
        dataIndex: "height",
        title: "height",
        render: (text)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: `/tipset/chain?height=${text}`,
                className: "link",
                children: text
            });
        }
    },
    {
        dataIndex: "cid",
        title: "cid",
        render: (text)=>{
            if (!text) return "--";
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: `/message/${text}`,
                className: "table_link",
                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
            });
        }
    },
    {
        dataIndex: "block_time",
        title: "block_time",
        render: (text)=>dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm:ss")
    },
    {
        dataIndex: "from",
        title: "from",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_10__/* .get_account_type */ .$B)(record.from_type, text)
    },
    {
        dataIndex: "to",
        title: "to",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_10__/* .get_account_type */ .$B)(record.to_type, text)
    },
    {
        dataIndex: "value",
        title: "value",
        render: (text)=>{
            let str = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false);
            let ArrStr = str.split(" ");
            return Number(ArrStr[0]).toFixed(3) + " " + ArrStr[1];
        }
    },
    {
        dataIndex: "method_name",
        title: "method_name"
    }
];
const dsn_list = {
    title: "dsn_list",
    total_list: "dsn_total_list",
    placeholder: "dsn_placeholder"
};
const dsn_columns = [
    {
        dataIndex: "deal_id",
        title: "deal_id",
        render: (text, record)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: `/deal/${text}`,
                className: "link",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_5__.Tooltip, {
                    children: text
                })
            });
        }
    },
    {
        dataIndex: "piece_cid",
        title: "piece_cid",
        render: (text)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6)
            });
        }
    },
    {
        dataIndex: "piece_size",
        title: "piece_size",
        with: 120,
        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text)
    },
    {
        dataIndex: "client_address",
        title: "client_address",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_10__/* .get_account_type */ .$B)(record.client_type, text)
    },
    {
        dataIndex: "provider_id",
        title: "provider_id",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_10__/* .get_account_type */ .$B)(record.provider_type, text)
    },
    {
        dataIndex: "service_start_time",
        title: "service_start_time",
        render: (text)=>dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm:ss")
    },
    {
        dataIndex: "end_time",
        title: "end_time",
        render: (text)=>dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm:ss")
    },
    // {
    //   dataIndex: "start_height",
    //   title: "start_height",
    // },
    // {
    //   dataIndex: "end_height",
    //   title: "end_height",
    // },
    {
        dataIndex: "storage_price_per_height",
        title: "storage_price_per_height",
        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text)
    },
    {
        dataIndex: "verified_deal",
        title: "verified_deal",
        render: (text)=>String(text)
    }
];
const pool_list = {
    title: "pool_list",
    total_list: "total_list"
};
const pool_columns = [
    {
        dataIndex: "cid",
        title: "cid",
        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: `/message/${text}`,
                className: "table_link",
                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
            })
    },
    {
        dataIndex: "block_time",
        title: "block_time",
        render: (text)=>dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm")
    },
    {
        dataIndex: "from",
        title: "from",
        render: (text, record)=>{
            return (0,_varible__WEBPACK_IMPORTED_MODULE_10__/* .get_account_type */ .$B)(record === null || record === void 0 ? void 0 : record.from_type, text);
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: `/address/${text}`,
                className: "table_link",
                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
            });
        }
    },
    {
        dataIndex: "to",
        title: "to",
        render: (text, record)=>{
            return (0,_varible__WEBPACK_IMPORTED_MODULE_10__/* .get_account_type */ .$B)(record === null || record === void 0 ? void 0 : record.to_type, text);
        //   return (
        //   <Link href={`/miner/${text}`} className='table_link'>
        //     {isIndent(text)}
        //   </Link>
        // )
        }
    },
    {
        dataIndex: "value",
        title: "value",
        render: (text)=>{
            return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false);
        }
    },
    {
        dataIndex: "gas_fee_cap",
        title: "gas_fee_cap"
    },
    {
        dataIndex: "gas_premium",
        title: "gas_premium",
        render: (text)=>text ? text + " attoFIL" : "--"
    },
    {
        dataIndex: "method_name",
        title: "method_name"
    }
];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
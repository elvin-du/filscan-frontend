exports.id = 1016;
exports.ids = [1016];
exports.modules = {

/***/ 1016:
/***/ ((module) => {

// Exports
module.exports = {
	"fil": "index_fil__fvjFU",
	"fil_chart": "index_fil_chart__pKeGI",
	"fil_ul": "index_fil_ul__fwb_l",
	"fil_ul_li": "index_fil_ul_li__bZwBw",
	"fil_ul_li_label": "index_fil_ul_li_label__HiYNi",
	"fil_ul_li_value": "index_fil_ul_li_value__AuTDh",
	"fil_ul_li_des": "index_fil_ul_li_des__8PnEH",
	"static_charts": "index_static_charts__yMFQV",
	"static_charts_first": "index_static_charts_first__0CXUC",
	"owner": "index_owner___vBgo",
	"general": "index_general__kzkWb",
	"general_title": "index_general_title__wilFE",
	"general_erc20List": "index_general_erc20List__zUWu3",
	"general_erc20List_logo": "index_general_erc20List_logo__7MFEa",
	"general_erc20List_content": "index_general_erc20List_content__eH8PD",
	"general_erc20List_name": "index_general_erc20List_name__GAqbg",
	"general_accountChange": "index_general_accountChange__1Ujzs",
	"miner": "index_miner__fs9Z7",
	"miner_account_overview": "index_miner_account_overview__wGwar",
	"miner_account_overview_item": "index_miner_account_overview_item__FKEZi",
	"message_title": "index_message_title__w9AuL",
	"message_content": "index_message_content__Biq1i",
	"message_tab": "index_message_tab__QB3Ub",
	"message_card": "index_message_card__IC5U_",
	"message_label": "index_message_label__RJnmu",
	"message_ERC20Trans": "index_message_ERC20Trans__Oyf5H",
	"message_event_log": "index_message_event_log__blGEv",
	"message_event_log_wrap": "index_message_event_log_wrap__dW3gS",
	"message_content_loading": "index_message_content_loading__neMiC"
};


/***/ })

};
;
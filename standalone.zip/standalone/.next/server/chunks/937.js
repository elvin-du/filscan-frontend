exports.id = 937;
exports.ids = [937];
exports.modules = {

/***/ 95607:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "table_wrap__yRzbf"
};


/***/ }),

/***/ 78817:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var antd_lib_table__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(74285);
/* harmony import */ var antd_lib_table__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_table__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(95607);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(23495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_4__]);
_utils__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const Table = (props)=>{
    const { columns, loading, current, total = 0, limit } = props;
    const showLimit = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return limit || _utils__WEBPACK_IMPORTED_MODULE_4__/* .pageLimit */ .P5;
    }, [
        limit
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().wrap)),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_table__WEBPACK_IMPORTED_MODULE_1___default()), {
            ...props,
            onChange: props.onChange,
            pagination: total > showLimit ? {
                position: [
                    "bottomRight"
                ],
                current: current,
                pageSize: _utils__WEBPACK_IMPORTED_MODULE_4__/* .pageLimit */ .P5,
                showSizeChanger: false,
                showLessItems: true,
                total
            } : false
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Table);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
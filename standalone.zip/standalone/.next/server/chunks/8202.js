exports.id = 8202;
exports.ids = [8202];
exports.modules = {

/***/ 807:
/***/ ((module) => {

// Exports
module.exports = {
	"content": "content_content__feA3f",
	"content_bolder_itemitem": "content_content_bolder_itemitem__gKv9C",
	"content_item": "content_content_item__FUzXe",
	"content_item_label": "content_content_item_label__badLT",
	"content_item_value": "content_content_item_value__Kt5Xh",
	"content_item_value-br": "content_content_item_value-br__p10Bj"
};


/***/ }),

/***/ 8202:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(807);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9927);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _tips__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4950);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_utils__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
([_utils_utils__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ content , data , ns , bolder , warpClassName , ItemClassName  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().content)} ${warpClassName}`,
        children: content?.map((item, index)=>{
            let showData = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .getShowData */ .IC)(item, data);
            let value = showData && showData[item.dataIndex];
            let isHtml = false;
            if (item.render) {
                if (item.elasticity && Array.isArray(value) && value?.length === 0) {
                    value = "--";
                } else {
                    isHtml = false;
                    value = item.render(value, data, tr);
                }
            } else {
                if (Array.isArray(value) && value.length > 0) {
                    value = value.join("<br />");
                    isHtml = true;
                } else {
                    value = !!value ? String(value) : "--";
                }
            }
            if (item.isNs) {
                value = tr(value);
            }
            if (!value && !item.render || value?.length === 0 && !item.render) {
                value = "--";
            }
            const ItemStyle = item?.style;
            if (item?.elasticity && value === "--") {
                return null;
            }
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                style: {
                    ...ItemStyle || {}
                },
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().content_item)}  ${bolder ? (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().content_bolder_item) : ""} ${ItemClassName}`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        style: {
                            minWidth: !!ItemStyle?.width ? "0px" : "180px"
                        },
                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().content_item_label)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().message_label)}`,
                        children: typeof item.title === "function" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex-center",
                            children: [
                                item.title(tr),
                                ":"
                            ]
                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex-center",
                            children: [
                                tr(item.title || item.label),
                                "  ",
                                item.label_tip && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tips__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    context: tr(item.label_tip)
                                }),
                                ":"
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().content_item_value)}`,
                        children: isHtml ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "html_br",
                            dangerouslySetInnerHTML: {
                                __html: value
                            }
                        }) : value
                    })
                ]
            }, index);
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
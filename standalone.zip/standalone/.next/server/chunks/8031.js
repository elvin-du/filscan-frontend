"use strict";
exports.id = 8031;
exports.ids = [8031];
exports.modules = {

/***/ 8031:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FG": () => (/* binding */ gas_24),
/* harmony export */   "O3": () => (/* binding */ charts),
/* harmony export */   "gc": () => (/* binding */ fil),
/* harmony export */   "hd": () => (/* binding */ statistics)
/* harmony export */ });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9927);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_utils__WEBPACK_IMPORTED_MODULE_0__]);
_utils_utils__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 
const power = {
    title: {
        label: "power",
        // tip: "power_tips",
        right: {
            opt: []
        }
    },
    list: [
        {
            label: "total_raw_byte_power",
            yIndex: 0,
            type: "line"
        },
        // { label: "base_line_power", yIndex: 1, type: "line" },
        {
            label: "total_quality_adj_power",
            yIndex: 0,
            type: "line"
        },
        {
            label: "change_quality_adj_power",
            yIndex: 1,
            type: "bar"
        }
    ]
};
const gas = {
    title: {
        label: "gas",
        right: {
            opt: [
                {
                    label: "24h",
                    value: "24h"
                },
                {
                    label: "7d",
                    value: "7d"
                },
                {
                    label: "30d",
                    value: "1m"
                }
            ]
        }
    },
    list: [
        {
            label: "base_fee",
            yIndex: 0,
            type: "line",
            unit: "nanoFiL"
        },
        {
            label: "gas_in_32g",
            yIndex: 1,
            type: "line"
        },
        {
            label: "gas_in_64g",
            yIndex: 1,
            type: "line"
        }
    ]
};
const gas_24 = {
    title: {
        label: "gas_24"
    },
    columns: [
        {
            dataIndex: "method_name",
            title: "method_name",
            align: "left"
        },
        {
            dataIndex: "avg_gas_premium",
            title: "avg_gas_premium",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFilNum */ .Nm)(text, false, false)
        },
        {
            dataIndex: "avg_gas_limit",
            title: "avg_gas_limit",
            render: (v)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatNumber */ .uf)(v)
        },
        {
            dataIndex: "avg_gas_used",
            title: "avg_gas_used",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL"
        },
        {
            dataIndex: "avg_gas_fee",
            title: "avg_gas_fee",
            render: (v)=>{
                if (Number(v) === 0) {
                    return 0;
                }
                return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFilNum */ .Nm)(v, false, false);
            }
        },
        {
            dataIndex: "sum_gas_fee",
            title: "sum_gas_fee/ratio",
            render: (text, record)=>{
                if (Number(text) === 0) {
                    return 0;
                }
                return `${(0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFilNum */ .Nm)(text, false, false)}/${Number(record.gas_fee_ratio * 100).toFixed(2)}%`;
            }
        },
        {
            dataIndex: "message_count",
            title: "message_count/ratio",
            render: (text, record)=>{
                return `${text}/${(record.message_count_ratio * 100).toFixed(2)}%`;
            }
        }
    ]
};
const fil = {
    title: {
        label: "TokenRules"
    },
    chart: [
        {
            key: "FilecoinFoundation",
            name: "Filecoin基金会",
            value: "5",
            color: "#477DE5"
        },
        {
            key: "Contributors",
            name: "协议实验室团队及贡献者",
            value: "4.5",
            color: "#4FD0A1"
        },
        {
            key: "protocolLab",
            name: "协议实验室",
            value: "10.5",
            color: "#5D77A3"
        },
        {
            key: "FundraisingRemainder",
            name: "募资 – 剩余通证",
            value: "2.5",
            color: "#E8B61B"
        },
        {
            key: "FundraisingSAFT",
            name: "募资 – 未来通证简单协议",
            value: "7.5",
            color: "#D75B42"
        },
        {
            key: "MiningReserve",
            name: "为存储服务提供者预留通证",
            value: "15",
            color: "#59BAE3"
        },
        {
            key: "TokenAllocation",
            name: "存储提供者通证分配",
            value: "55",
            color: "#876AC3"
        }
    ],
    content: [
        {
            label: "Allocation",
            value: "value",
            Released: "Released",
            description: "description"
        },
        {
            label: "filBase",
            value: "2,000,000,000",
            Released: "2,000,000",
            description: "filBase_des"
        },
        {
            label: "ReservedTokens",
            value: "300,000,000 ",
            Released: "300,000 ",
            description: "ReservedTokens_des"
        },
        {
            label: "TokenAllocation",
            value: "1,100,000,000",
            Released: "1,100",
            description: "TokenAllocation_des"
        },
        {
            label: "Fundraising",
            value: "150,000,000 ",
            Released: "50,000 ",
            description: "Fundraising_des"
        },
        {
            label: "Funds",
            value: "50,000,000",
            Released: "50,000 ",
            description: "Funds_des"
        },
        {
            label: "protocolLab",
            value: "210,000,000",
            Released: "20,000",
            description: "protocolLab_des"
        },
        {
            label: "Contributors",
            value: "90,000,000",
            Released: "9,000 ",
            description: "Contributors_des"
        }
    ]
};
const charts = {
    header: [
        {
            label: "24h",
            value: "24h"
        },
        {
            label: "7d",
            value: "7d"
        },
        {
            label: "30d",
            value: "1m"
        }
    ],
    pie: {
        title: {
            label: "pie_title"
        },
        list: [
            {
                title: "pie_title_a",
                list: [
                    {
                        key: "mined",
                        color: "#477DE5"
                    },
                    {
                        key: "remaining_mined",
                        color: "#4FD0A1"
                    },
                    {
                        key: "vested",
                        color: "#5D77A3"
                    },
                    {
                        key: "remaining_vested",
                        color: "#E8B61B"
                    },
                    {
                        key: "reserve_disbursed",
                        color: "#D75B42"
                    },
                    {
                        key: "remaining_reserved",
                        color: "#59BAE3"
                    }
                ]
            },
            {
                title: "pie_title_b",
                title_tip: "pie_title_a_tip",
                list: [
                    {
                        key: "locked",
                        color: "#477DE5"
                    },
                    {
                        key: "burnt",
                        color: "#4FD0A1"
                    },
                    {
                        key: "circulating",
                        color: "#5D77A3"
                    }
                ]
            }
        ]
    },
    block_trend: {
        title: {
            label: "block_trend"
        },
        list: [
            {
                label: "acc_block_rewards",
                yIndex: 0,
                type: "line",
                unit: "FIL",
                color: "#477DE5",
                yUnit: "FIL"
            },
            {
                label: "block_reward_per_TiB",
                yIndex: 1,
                type: "line",
                unit: "FIL/TiB",
                color: "#E8B61B",
                yUnit: "FIL/TiB"
            }
        ]
    },
    active_nodes: {
        title: {
            label: "active_nodes"
        },
        list: [
            {
                label: "active_miner_count",
                yIndex: 0,
                type: "line",
                unit: "",
                color: "#477DE5"
            }
        ]
    },
    messages_trend: {
        title: {
            label: "messages_trend"
        },
        list: [
            //  { label: "all_message_count", yIndex: 0, type: "line", unit: '', color: '#477DE5', },
            {
                label: "message_count",
                yIndex: 0,
                type: "line",
                unit: "",
                color: "#E8B61B",
                tip: "all_message_count_tip"
            }
        ]
    }
};
const statistics = {
    power,
    gas
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
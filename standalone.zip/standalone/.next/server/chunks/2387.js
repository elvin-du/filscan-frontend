exports.id = 2387;
exports.ids = [2387];
exports.modules = {

/***/ 92976:
/***/ ((module) => {

// Exports
module.exports = {
	"static-menu": "charts_static-menu__ufKrv",
	"tab-content": "charts_tab-content__Iukl8",
	"statistics-target": "charts_statistics-target__QRUtE",
	"statistics-charts": "charts_statistics-charts__OgleB",
	"content": "charts_content__HybXV",
	"nav-wrap": "charts_nav-wrap__BDVsE",
	"active": "charts_active__4Lv5E"
};


/***/ }),

/***/ 27804:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "ActiveNodeTrend_wrap__Z6TYG",
	"title-wrap": "ActiveNodeTrend_title-wrap__hAQ__",
	"content": "ActiveNodeTrend_content__BTfXp"
};


/***/ }),

/***/ 19896:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "BlockRewardPer_wrap__xpu7i",
	"title-wrap": "BlockRewardPer_title-wrap__SCimK",
	"content": "BlockRewardPer_content__b7o6_"
};


/***/ }),

/***/ 73728:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "BlockRewardTrend_wrap__ORqAq",
	"title-wrap": "BlockRewardTrend_title-wrap__x_7Dg",
	"content": "BlockRewardTrend_content__wrdxK"
};


/***/ }),

/***/ 18694:
/***/ ((module) => {

// Exports
module.exports = {
	"title": "Charts_title__lJgS2",
	"content": "Charts_content__y5aEC",
	"chart-wrap": "Charts_chart-wrap__uAaCb",
	"chart": "Charts_chart__fZ2Fi",
	"legend-label-wrap": "Charts_legend-label-wrap__odnlJ",
	"value": "Charts_value__Z_Owu",
	"dot": "Charts_dot__Dilb2",
	"describe-item": "Charts_describe-item__kxxtm",
	"label": "Charts_label__USQzZ"
};


/***/ }),

/***/ 3565:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "DCCTrend_wrap__KKvYl",
	"title-wrap": "DCCTrend_title-wrap__oHNrI",
	"content": "DCCTrend_content__rad_Y"
};


/***/ }),

/***/ 68690:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "FilChart_wrap__2RDQX",
	"title": "FilChart_title__jPPCY",
	"card-reset": "FilChart_card-reset__9tmJi",
	"card": "FilChart_card__b9KZA",
	"echart": "FilChart_echart__Ky_O8",
	"legend-wrap": "FilChart_legend-wrap__I18qn",
	"legend-item": "FilChart_legend-item__9kuYe",
	"legend-item-left": "FilChart_legend-item-left__AjHpN",
	"legend-value": "FilChart_legend-value__QvpSJ"
};


/***/ }),

/***/ 69986:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap-reset": "Meta_wrap-reset__UI0i3",
	"wrap": "Meta_wrap__V0dCJ",
	"item-reset": "Meta_item-reset__3IGtK",
	"item": "Meta_item__1xyNL"
};


/***/ }),

/***/ 72305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7947);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(69348);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { context, icon = true } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default()), {
        overlayClassName: "custom-tooltip-wrap",
        title: context,
        children: [
            icon ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "cursor-pointer",
                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("tip")
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: props.children
            })
        ]
    });
});


/***/ }),

/***/ 60883:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(24852);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ActiveNodeTrend_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(27804);
/* harmony import */ var _ActiveNodeTrend_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_ActiveNodeTrend_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(68108);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(25622);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(31061);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(25572);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__, _packages_segmented__WEBPACK_IMPORTED_MODULE_10__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__, _packages_segmented__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 














/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_13__.observer)((props)=>{
    const { className } = props;
    const { theme } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_12__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("24h");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value}",
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0]?.data?.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + item.seriesName + ": " + item.data.amount + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .active_miner_count */ .bZ.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.static_active_miner, {
            interval: inter
        });
        result?.items?.forEach((value)=>{
            const { block_time, active_miner_count } = value;
            const showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "MM-DD HH:mm");
            dateList.push(showTime);
            //amount
            seriesObj.active_miner_count.push({
                value: active_miner_count,
                amount: active_miner_count,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm"),
                unit: ""
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .active_miner_count */ .bZ.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                ..._utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .seriesChangeArea */ .v$,
                data: seriesObj[item.dataIndex],
                name: tr(item.title),
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            newSeries.push(seriesItem);
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        options,
        defaultOptions
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        //id='active_nodes'
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_ActiveNodeTrend_module_scss__WEBPACK_IMPORTED_MODULE_14___default().wrap), `h-[full] w-full  ${className}`),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("mx-2.5 mb-4 flex flex-1  flex-row flex-wrap items-center justify-between", (_ActiveNodeTrend_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-fit min-w-[120px] font-HarmonyOS text-lg font-semibold ",
                        children: tr("active_nodes")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        defaultValue: interval,
                        data: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                        ns: "static",
                        isHash: false,
                        onChange: (value)=>{
                            setInterval(value);
                            load(value);
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(`card_shadow border_color h-[350px] w-full rounded-xl border pb-2`, (_ActiveNodeTrend_module_scss__WEBPACK_IMPORTED_MODULE_14___default().content)),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 68297:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(24852);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _BlockRewardPer_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(19896);
/* harmony import */ var _BlockRewardPer_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_BlockRewardPer_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(68108);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(25622);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(31061);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(25572);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__, _packages_segmented__WEBPACK_IMPORTED_MODULE_10__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__, _packages_segmented__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 














/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_13__.observer)((props)=>{
    const { className } = props;
    const { theme, lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_12__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("24h");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value} FIL",
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.amount + item.data.unit + "/T";
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        lang,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .block_rewards_per */ .eh.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.static_block_trend, {
            interval: inter
        }, {
            flag: "new"
        });
        result?.items?.forEach((value)=>{
            const { block_time, block_reward_per_tib } = value;
            const showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "MM-DD HH:mm");
            dateList.push(showTime);
            //amount
            seriesObj.block_reward_per_tib.push({
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFil */ .Uk)(block_reward_per_tib, "FIL", 2),
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm"),
                amount: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFilNum */ .Nm)(block_reward_per_tib, false, false, 4, false).split(" ")[0],
                unit: "FIL"
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .block_rewards_per */ .eh.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                ..._utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .seriesChangeArea */ .v$,
                data: seriesObj[item.dataIndex],
                name: item.title,
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            newSeries.push(seriesItem);
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        // id='block_reward_per'
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_BlockRewardPer_module_scss__WEBPACK_IMPORTED_MODULE_14___default().wrap), `h-[full] w-full  ${className}`),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("mx-2.5 mb-4 flex flex-1  flex-row flex-wrap items-center justify-between", (_BlockRewardPer_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-fit min-w-[120px] font-HarmonyOS text-lg font-semibold ",
                        children: tr("block_reward_per_TiB")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        defaultValue: interval,
                        data: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                        ns: "static",
                        isHash: false,
                        onChange: (value)=>{
                            setInterval(value);
                            load(value);
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(`card_shadow border_color h-[350px] w-full rounded-xl border pb-2`, (_BlockRewardPer_module_scss__WEBPACK_IMPORTED_MODULE_14___default().content)),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 658:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(24852);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _BlockRewardTrend_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(73728);
/* harmony import */ var _BlockRewardTrend_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_BlockRewardTrend_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(68108);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(25622);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(31061);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(25572);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__, _packages_segmented__WEBPACK_IMPORTED_MODULE_10__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__, _packages_segmented__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 














/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_13__.observer)((props)=>{
    const { className } = props;
    const { theme, lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_12__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("24h");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value} FIL",
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.amount + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        lang,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .block_rewards */ .jD.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.static_block_trend, {
            interval: inter
        });
        result?.items?.forEach((value)=>{
            const { block_time, acc_block_rewards } = value;
            const showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "MM-DD HH:mm");
            dateList.push(showTime);
            //amount
            seriesObj.acc_block_rewards.push({
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFil */ .Uk)(acc_block_rewards, "FIL", 2),
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm"),
                amount: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFilNum */ .Nm)(acc_block_rewards, false, false, 4, false).split(" ")[0],
                unit: "FIL"
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .block_rewards */ .jD.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                ..._utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .seriesChangeArea */ .v$,
                data: seriesObj[item.dataIndex],
                name: item.title,
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            newSeries.push(seriesItem);
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        // id='block_trend'
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_BlockRewardTrend_module_scss__WEBPACK_IMPORTED_MODULE_14___default().wrap), `h-[full] w-full  ${className}`),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("mx-2.5 mb-4 flex flex-1  flex-row flex-wrap items-center justify-between", (_BlockRewardTrend_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-fit min-w-[120px] font-HarmonyOS text-lg font-semibold ",
                        children: tr("block_trend")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        defaultValue: interval,
                        data: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                        ns: "static",
                        isHash: false,
                        onChange: (value)=>{
                            setInterval(value);
                            load(value);
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(`card_shadow border_color h-[350px] w-full rounded-xl border pb-2`, (_BlockRewardTrend_module_scss__WEBPACK_IMPORTED_MODULE_14___default().content)),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 67320:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(24852);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7355);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Charts_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(18694);
/* harmony import */ var _Charts_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_Charts_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(31061);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(29676);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(25572);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_statistic__WEBPACK_IMPORTED_MODULE_3__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_statistic__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 











function Overview() {
    const { theme, lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_9__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "static"
    });
    const [legendData, setLegendData] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({});
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({});
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_6__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_4__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const defaultOtions = (0,react__WEBPACK_IMPORTED_MODULE_6__.useMemo)(()=>{
        return {
            tooltip: {
                show: false
            },
            series: [
                {
                    type: "pie",
                    radius: "50%",
                    label: {
                        show: true,
                        color: color.labelColor,
                        formatter: (param)=>{
                            return param.name + "(" + param.value + "%)";
                        //return param.name + '<br />' +`<span style="color:${color.textStyle}">(${param.value}%)</span>`
                        }
                    },
                    data: []
                }
            ]
        };
    }, [
        theme
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        const seriesData = [];
        const legendData = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_3__/* .fil_charts */ .qd.chart.forEach((item)=>{
            const value = item.value || "--";
            const name = `${tr(item.key)}`;
            legendData[item.key] = {
                name,
                value,
                color: item.color,
                key: item.key,
                isShow: true
            };
            seriesData.push({
                value,
                name,
                key: item.key,
                itemStyle: {
                    color: item.color
                }
            });
        });
        const newOpt = {
            ...defaultOtions
        };
        newOpt.series[0].data = seriesData;
        setData(newOpt);
        setLegendData(legendData);
    }, [
        lang,
        theme
    ]);
    const options = (0,react__WEBPACK_IMPORTED_MODULE_6__.useMemo)(()=>{
        const newData = {
            ...data
        };
        const series = [];
        if (newData.series && newData.series.length > 0) {
            data.series[0].data?.forEach((v)=>{
                if (legendData[v.key]?.isShow) {
                    series.push(v);
                }
            });
            newData.series[0].data = series;
            if (isMobile) {
                newData.series[0].radius = "80%";
                newData.series[0].label.show = false;
                newData.tooltip.position = [
                    "40%",
                    "50%"
                ];
                newData.tooltip.show = true;
                newData.tooltip.formatter = (v)=>{
                    const { name, value, data } = v;
                    return `${v.marker} ${data.value}% <div>${data.name}</div>`;
                };
                newData.series[0].center = [
                    "50%",
                    "45%"
                ];
            }
        }
        return newData;
    }, [
        data,
        legendData,
        isMobile
    ]);
    const handleLegend = (legendKey)=>{
        const newLegend = {
            ...legendData
        };
        newLegend[legendKey].isShow = !newLegend[legendKey].isShow;
        setLegendData(newLegend);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("mb-4 flex h-9 w-fit items-center pl-2.5 font-HarmonyOS text-lg font-semibold", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_11___default().title)),
                children: tr("charts_title")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("card_shadow border_color w-full rounded-[12px] border", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_11___default().content)),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("border_color flex flex-row border-b", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_11___default()["chart-wrap"]), (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_11___default()["chart-wrap-reset"])),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("h-[350px] w-2/3 py-5", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_11___default().chart)),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    options: options
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: "1/3 flex flex-col  justify-center gap-y-2.5",
                                children: Object.keys(legendData).map((legendKey)=>{
                                    const legend = legendData[legendKey];
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "text_des flex cursor-pointer items-center gap-x-2 text-xs",
                                        onClick: ()=>{
                                            handleLegend(legendKey);
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("block h-2 w-2 rounded-full", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_11___default().dot)),
                                                style: {
                                                    background: legend.isShow ? legend?.color || "" : "#d1d5db"
                                                }
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("flex", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_11___default()["legend-label-wrap"])),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_8__/* .BrowserView */ .I, {
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                            className: "flex-shrink-0",
                                                            children: [
                                                                legend?.name || "",
                                                                " "
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_8__/* .MobileView */ .$, {
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                className: "flex-shrink-0",
                                                                children: [
                                                                    legend?.name || "",
                                                                    ":",
                                                                    " "
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_11___default().value),
                                                                children: " " + `${legend?.value}%`
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }, legendKey);
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_8__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text_des p-10 font-HarmonyOS_Medium text-xs",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: "border_color rounded-[5px] border",
                                children: _contents_statistic__WEBPACK_IMPORTED_MODULE_3__/* .fil_charts */ .qd.content.map((v, index)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "border_color flex min-h-[36px] w-full items-center break-words border-b last:border-none",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    width: "20%"
                                                },
                                                className: "border_color flex h-full min-h-[36px] items-center  border-r px-2.5",
                                                children: tr(v.label)
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    width: "25%"
                                                },
                                                className: "border_color flex h-full min-h-[36px]  items-center border-r px-2.5",
                                                children: index === 0 ? tr(v.value) : v.value
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    width: "40%"
                                                },
                                                className: "px-2.5",
                                                children: tr(v.description)
                                            })
                                        ]
                                    }, index);
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_8__/* .MobileView */ .$, {
                        children: _contents_statistic__WEBPACK_IMPORTED_MODULE_3__/* .fil_charts */ .qd.content.filter((value)=>{
                            return value.label !== "Allocation";
                        }).map((v, index)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("text_des border_color flex flex-col gap-y-[15px] border-b px-[12px] py-[14px] last:border-none", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_11___default()["describe-item"])),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("min-w-[100px] pt-[2px]", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_11___default().label)),
                                                children: [
                                                    tr("Allocation"),
                                                    ":"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-HarmonyOS_Medium  text-black",
                                                children: tr(v.label)
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("min-w-[100px]", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_11___default().label)),
                                                children: [
                                                    tr("value"),
                                                    ":"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-HarmonyOS_Medium  text-black",
                                                children: index === 0 ? tr(v.value) : v.value
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("min-w-[100px]", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_11___default().label)),
                                                children: [
                                                    tr("description"),
                                                    ":"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-HarmonyOS_Medium  text-black",
                                                children: tr(v.description)
                                            })
                                        ]
                                    })
                                ]
                            }, index);
                        })
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_10__.observer)(Overview));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 53950:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(24852);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(96051);
/* harmony import */ var _ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(29676);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(68108);
/* harmony import */ var _packages_select__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(76423);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(31061);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(25572);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_select__WEBPACK_IMPORTED_MODULE_11__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_select__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_14__.observer)((props)=>{
    const { origin, className } = props;
    const { theme, lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_13__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("1m");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value} FIL",
                    margin: 8,
                    hideOverlap: true,
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFilNum */ .Nm)(item.data.amount, false, false, 4) + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        tr,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .contract_balance */ .OC.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .ContractBalanceTrend */ ._7, {
            interval: inter
        });
        result?.items?.forEach((value)=>{
            const { block_time, contract_total_balance } = value;
            let showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "MM-DD HH:mm");
            if (isMobile) {
                showTime = (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "MM-DD");
            }
            dateList.push(showTime);
            //amount
            seriesObj.contract_total_balance.push({
                amount: contract_total_balance,
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFil */ .Uk)(contract_total_balance, "FIL"),
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm"),
                unit: ""
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .contract_balance */ .OC.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                data: seriesObj[item.dataIndex],
                name: item.title,
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            if (!noShow[seriesItem?.name]) {
                newSeries.push(seriesItem);
            }
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions,
        noShow
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default().trend), `h-[full] w-full  ${className}`),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(`mb-2.5 flex min-h-[36px] flex-wrap items-center justify-between ${lang === "en" ? "h-[60px]" : ""}`, (_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-1 flex-row flex-wrap items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("w-fit min-w-[120px] pl-2.5 font-HarmonyOS text-lg font-semibold", (_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default().title)),
                            children: tr("contract_balance")
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_9__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mx-2.5 flex items-center gap-x-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_select__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                ns: "static",
                                options: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                                value: interval,
                                onChange: (interval)=>{
                                    setInterval(interval);
                                    load(interval);
                                }
                            }, `static_${origin}_contract`)
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `card_shadow border_color h-[350px] w-full rounded-xl border pb-2`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 27927:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(24852);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3565);
/* harmony import */ var _DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(68108);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(25622);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(31061);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(25572);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__, _packages_segmented__WEBPACK_IMPORTED_MODULE_10__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__, _packages_segmented__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 














/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_13__.observer)((props)=>{
    const { className } = props;
    const { theme, lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_12__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("24h");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value} PiB",
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0]?.data?.showTime || "";
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + item.seriesName + ": " + item.data.amount + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .cc_dc_trend */ .l2.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .DCTrend */ .b, {
            interval: inter
        });
        result?.items?.forEach((value)=>{
            const { block_time, cc, dc } = value;
            const showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "MM-DD HH:mm");
            dateList.push(showTime);
            const [cc_amount, cc_unit] = cc && (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .unitConversion */ .dN)(cc, 2)?.split(" ");
            const [dc_amount, dc_unit] = dc && (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .unitConversion */ .dN)(dc, 2)?.split(" ");
            //amount
            seriesObj.cc.push({
                amount: cc_amount,
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .unitConversion */ .dN)(cc, 2, 5).split(" ")[0],
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm"),
                unit: cc_unit
            });
            seriesObj.dc.push({
                amount: dc_amount,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm"),
                value: Number((0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .unitConversion */ .dN)(dc, 2, 5).split(" ")[0]),
                unit: dc_unit
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .cc_dc_trend */ .l2.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                // ...seriesChangeArea,
                data: seriesObj[item.dataIndex],
                name: tr(item.title),
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            newSeries.push(seriesItem);
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        // id='block_reward_per'
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_14___default().wrap), `h-[full] w-full  ${className}`),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("mx-2.5 mb-4 flex flex-1  flex-row flex-wrap items-center justify-between", (_DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("w-fit min-w-[120px] font-HarmonyOS text-lg font-semibold ", (_DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_14___default().title)),
                        children: tr("cc_dc_power")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        defaultValue: interval,
                        data: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                        ns: "static",
                        isHash: false,
                        onChange: (value)=>{
                            setInterval(value);
                            load(value);
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(`card_shadow border_color h-[350px] w-full rounded-xl border pb-2`, (_DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_14___default().content)),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 41340:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13778);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7355);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(68108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8054);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(24852);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23495);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(59591);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(29676);
/* harmony import */ var _FilChart_module_scss__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(68690);
/* harmony import */ var _FilChart_module_scss__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(31061);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(25572);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__, _contents_statistic__WEBPACK_IMPORTED_MODULE_7__, _utils__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__, _contents_statistic__WEBPACK_IMPORTED_MODULE_7__, _utils__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 















function Overview({ className }) {
    const { theme, lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_13__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { data: filData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_6__/* .apiUrl */ .JW.static_fil_chart, {});
    const [optionsA, setOptionA] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    const [legendA, setLegendA] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    const [optionsB, setOptionB] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    const [legendB, setLegendB] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_4__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const defaultOtions = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return {
            tooltip: {
                trigger: "item",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    const { name, value, data } = v;
                    return `${v.marker} ${data.showName}`;
                },
                position: "right"
            },
            series: [
                {
                    type: "pie",
                    radius: "50%",
                    label: {
                        show: true,
                        color: color.labelColor
                    },
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: color.textStyle
                    }
                }
            ]
        };
    }, [
        theme
    ]);
    const newData = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        const newList = {};
        const data = filData?.fil_compose || {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_7__/* .fil_overviewList */ .a$.forEach((itemList)=>{
            newList[itemList.title] = itemList.list.map((itemValue)=>{
                const show_value = data && (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .formatFil */ .Uk)(data[itemValue.key], "FIL");
                if (itemList.title === "pie_title_a") {
                    const percentage_a = Number(20 * Math.pow(10, 8));
                    return {
                        ...itemValue,
                        percentage: Number(Number(show_value) / percentage_a * 100).toFixed(2) + "%",
                        value: show_value,
                        unit: "FIL"
                    };
                } else {
                    const percentage_b = Number(Number(data[itemValue.key]) / data.total_released * 100).toFixed(2) + "%";
                    return {
                        ...itemValue,
                        percentage: percentage_b,
                        value: show_value,
                        unit: "FIL"
                    };
                }
            });
        });
        return newList;
    }, [
        filData
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        loadOptions();
    }, [
        newData,
        lang,
        theme
    ]);
    const loadOptions = ()=>{
        let options_a = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9___default()({
            ...defaultOtions
        });
        let options_b = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9___default()({
            ...defaultOtions
        });
        let legend_a = [];
        let legend_b = [];
        _contents_statistic__WEBPACK_IMPORTED_MODULE_7__/* .fil_overviewList */ .a$.forEach((item, index)=>{
            const showData = newData && newData[item.title] || {};
            const seriesData = [];
            const legend = {};
            item.list.forEach((seriesItem, index)=>{
                const baseData = showData[index];
                const showValue = (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .formatNumberUnit */ .sQ)(baseData?.value);
                const name = `${tr(seriesItem.key)}`;
                const value = `${showValue} FIL`;
                legend[seriesItem.key] = {
                    name,
                    value,
                    color: seriesItem.color,
                    isShow: true,
                    key: seriesItem.key
                };
                seriesData.push({
                    ...baseData,
                    name,
                    showName: `${tr(seriesItem.key)}: ${baseData?.value} FIL`,
                    key: seriesItem.key,
                    itemStyle: {
                        color: seriesItem.color
                    }
                });
            });
            if (item.title === "pie_title_a") {
                options_a.series[0].data = seriesData;
                legend_a = {
                    ...legend
                };
            } else {
                options_b.series[0].data = seriesData;
                legend_b = {
                    ...legend
                };
            }
        });
        setOptionA(options_a);
        setLegendA(legend_a);
        setOptionB(options_b);
        setLegendB(legend_b);
    };
    const newOptionsA = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        const newData = [];
        const newOption = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9___default()(optionsA);
        if (newOption?.series && newOption.series.length > 0) {
            optionsA?.series && optionsA?.series[0]?.data.map((v)=>{
                if (legendA[v.key].isShow) {
                    newData.push(v);
                }
            });
            if (isMobile) {
                newOption.series[0].label.show = false;
                newOption.series[0].radius = "80%";
                newOption.tooltip.position = [
                    "15%",
                    "50%"
                ];
                newOption.tooltip.formatter = (v)=>{
                    const { name, value, data } = v;
                    return `${v.marker} ${data.value} <div>${data.name}</div>`;
                };
                newOption.series[0].center = [
                    "50%",
                    "50%"
                ];
            }
            newOption.series[0].data = newData;
        }
        return newOption;
    }, [
        legendA,
        optionsA,
        isMobile
    ]);
    const newOptionsB = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        const newData = [];
        const newOption = lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_9___default()(optionsB);
        if (newOption?.series && newOption.series.length > 0) {
            optionsB?.series && optionsB?.series[0]?.data.map((v)=>{
                if (legendB[v.key].isShow) {
                    newData.push(v);
                }
            });
            if (isMobile) {
                newOption.series[0].label.show = false;
                newOption.series[0].radius = "80%";
                newOption.tooltip.position = [
                    "15%",
                    "50%"
                ];
                newOption.tooltip.formatter = (v)=>{
                    const { name, value, data } = v;
                    return `${v.marker} ${data.value} <div>${data.name}</div>`;
                };
                newOption.series[0].center = [
                    "50%",
                    "50%"
                ];
            }
            newOption.series[0].data = newData;
        }
        return newOption;
    }, [
        legendB,
        optionsB,
        isMobile
    ]);
    const handleLegend = (type, key)=>{
        if (type === "pie_title_a") {
            const newLegend = {
                ...legendA
            };
            newLegend[key].isShow = !newLegend[key].isShow;
            setLegendA(newLegend);
        } else {
            const newLegend = {
                ...legendB
            };
            newLegend[key].isShow = !newLegend[key].isShow;
            setLegendB(newLegend);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("flex  h-fit flex-col gap-y-5", (_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_15___default().wrap)),
        children: _contents_statistic__WEBPACK_IMPORTED_MODULE_7__/* .fil_overviewList */ .a$.map((dataItem, index)=>{
            const legendData = index === 1 ? legendB : legendA;
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `h-full w-full ${className} `,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("mb-4 flex h-9 w-fit items-center pl-2.5 font-HarmonyOS text-lg font-semibold", (_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_15___default().title)),
                        children: tr(dataItem.title)
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("card_shadow border_color rounded-[12px] border", (_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_15___default().card), (_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_15___default()["card-reset"])),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("h-[400px] w-full", (_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_15___default().echart)),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    options: index === 1 ? {
                                        ...newOptionsB
                                    } : {
                                        ...newOptionsA
                                    }
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_10__/* .BrowserView */ .I, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: "flex w-full flex-wrap gap-y-2.5 px-10 pb-10 ",
                                    children: Object.keys(legendData).map((legendKey)=>{
                                        const legend = legendData[legendKey];
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "text_des flex w-1/3 cursor-pointer items-center gap-x-2 text-xs",
                                            onClick: ()=>{
                                                handleLegend(dataItem.title, legendKey);
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "block h-2 w-2 rounded-full",
                                                    style: {
                                                        background: legend.isShow ? legend?.color || "" : "#d1d5db"
                                                    }
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    children: [
                                                        `${legend?.name || ""}`,
                                                        " "
                                                    ]
                                                })
                                            ]
                                        }, legendKey);
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_10__/* .MobileView */ .$, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_15___default()["legend-wrap"])),
                                    children: Object.keys(legendData).map((legendKey)=>{
                                        const legend = legendData[legendKey];
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_15___default()["legend-item"])),
                                            onClick: ()=>{
                                                handleLegend(dataItem.title, legendKey);
                                            },
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_15___default()["legend-item-left"])),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "block h-2 w-2 rounded-full",
                                                        style: {
                                                            background: legend.isShow ? legend?.color || "" : "#d1d5db"
                                                        }
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        children: [
                                                            `${legend?.name || ""}:`,
                                                            " "
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: (_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_15___default()["legend-value"]),
                                                        children: legend?.value || ""
                                                    })
                                                ]
                                            })
                                        }, legendKey);
                                    })
                                })
                            })
                        ]
                    })
                ]
            }, dataItem.title);
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_14__.observer)(Overview));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1004:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _components_hooks_useInterval__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(39447);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8054);
/* harmony import */ var _contents_home__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(69729);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(72305);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(68108);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7947);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _Meta_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(69986);
/* harmony import */ var _Meta_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_Meta_module_scss__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_home__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_home__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "home"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({});
    const [otherData, setOtherData] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({});
    const [contractData, setContractData] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)();
    (0,_components_hooks_useInterval__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(()=>{
        load();
        loadOther();
    }, 5 * 60 * 1000);
    const load = async ()=>{
        const data = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl */ .JW.home_meta);
        setData(data?.total_indicators || {});
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .EvmContractSummary */ .Uh);
        setContractData(result || {});
    };
    const loadOther = async ()=>{
        const otherData = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .metaOther */ ._y);
        setOtherData(otherData || {});
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("card_shadow border_color mt-[46px] flex flex-wrap gap-5 rounded-[12px] border px-6 py-5", (_Meta_module_scss__WEBPACK_IMPORTED_MODULE_10___default().wrap), (_Meta_module_scss__WEBPACK_IMPORTED_MODULE_10___default()["wrap-reset"])),
        children: _contents_home__WEBPACK_IMPORTED_MODULE_4__/* .meta_list */ .QU.map((item, index)=>{
            const { title, tip, render, dataIndex } = item;
            const newData = {
                ...contractData,
                ...data,
                ...otherData
            };
            const value = newData[dataIndex];
            let renderDom = render ? render(value, newData, tr) : value;
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("border_color flex w-[210px] flex-col items-center gap-y-1 rounded-[5px] border py-4", (_Meta_module_scss__WEBPACK_IMPORTED_MODULE_10___default().item), (_Meta_module_scss__WEBPACK_IMPORTED_MODULE_10___default()["item-reset"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "font-HarmonyOS_Bold text-base font-medium",
                        children: renderDom
                    }),
                    tip ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            context: tr(tip),
                            icon: false,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "text_des flex items-center gap-x-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr(item.title)
                                    }),
                                    (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("tip")
                                ]
                            })
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text_des text-center ",
                        children: tr(item.title)
                    })
                ]
            }, index);
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 10860:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(24852);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(96051);
/* harmony import */ var _ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(29676);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(68108);
/* harmony import */ var _packages_select__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(76423);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(31061);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(25572);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_select__WEBPACK_IMPORTED_MODULE_11__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_select__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_14__.observer)((props)=>{
    const { origin, className } = props;
    const { theme, lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_13__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("1m");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value}",
                    margin: 8,
                    hideOverlap: true,
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.amount + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        tr,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .contract_addr */ .dZ.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .ContractUsersTrend */ .tl, {
            interval: inter
        });
        result?.items?.forEach((value)=>{
            const { block_time, contract_users } = value;
            let showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "MM-DD HH:mm");
            if (isMobile) {
                showTime = (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "MM-DD");
            }
            dateList.push(showTime);
            //amount
            seriesObj.contract_users.push({
                amount: contract_users,
                value: contract_users,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm"),
                unit: ""
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .contract_addr */ .dZ.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                data: seriesObj[item.dataIndex],
                name: item.title,
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            if (!noShow[seriesItem?.name]) {
                newSeries.push(seriesItem);
            }
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions,
        noShow
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default().trend), `h-[full] w-full  ${className}`),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(`mb-2.5 flex min-h-[36px] flex-wrap items-center justify-between ${lang === "en" ? "h-[60px]" : ""}`, (_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-1 flex-row flex-wrap items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("w-fit min-w-[120px] pl-2.5 font-HarmonyOS text-lg font-semibold", (_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default().title)),
                            children: tr("contract_addr")
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_9__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mx-2.5 flex items-center gap-x-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_select__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                ns: "static",
                                options: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                                value: interval,
                                onChange: (interval)=>{
                                    setInterval(interval);
                                    load(interval);
                                }
                            }, `static_${origin}_contract`)
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `card_shadow border_color h-[350px] w-full rounded-xl border pb-2`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 77995:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(24852);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(96051);
/* harmony import */ var _ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(29676);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(68108);
/* harmony import */ var _packages_select__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(76423);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(31061);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(25572);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_select__WEBPACK_IMPORTED_MODULE_11__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_select__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_14__.observer)((props)=>{
    const { origin, className } = props;
    const { theme, lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_13__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("1m");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value}",
                    margin: 8,
                    hideOverlap: true,
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.amount + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        tr,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .contract_con */ .h0.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .ContractCntTrend */ .JI, {
            interval: inter
        });
        result?.items?.forEach((value)=>{
            const { block_time, contract_counts } = value;
            let showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "MM-DD HH:mm");
            if (isMobile) {
                showTime = (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "MM-DD");
            }
            dateList.push(showTime);
            //amount
            seriesObj.contract_counts.push({
                amount: contract_counts,
                value: contract_counts,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm"),
                unit: ""
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .contract_con */ .h0.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                data: seriesObj[item.dataIndex],
                name: item.title,
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            if (!noShow[seriesItem?.name]) {
                newSeries.push(seriesItem);
            }
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions,
        noShow
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default().trend), `h-[full] w-full  ${className}`),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(`mb-2.5 flex min-h-[36px] flex-wrap items-center justify-between ${lang === "en" ? "h-[60px]" : ""}`, (_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-1 flex-row flex-wrap items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("w-fit min-w-[120px] pl-2.5 font-HarmonyOS text-lg font-semibold", (_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default().title)),
                            children: tr("contract_con")
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_9__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mx-2.5 flex items-center gap-x-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_select__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                ns: "static",
                                options: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                                value: interval,
                                onChange: (interval)=>{
                                    setInterval(interval);
                                    load(interval);
                                }
                            }, `static_${origin}_contract`)
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `card_shadow border_color h-[350px] w-full rounded-xl border pb-2`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 52832:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(24852);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(96051);
/* harmony import */ var _ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(29676);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(68108);
/* harmony import */ var _packages_select__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(76423);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(31061);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(25572);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_select__WEBPACK_IMPORTED_MODULE_11__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_select__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_14__.observer)((props)=>{
    const { origin, className } = props;
    const { theme, lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_13__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("1m");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_6__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value} FIL",
                    margin: 8,
                    hideOverlap: true,
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFilNum */ .Nm)(item.data.amount, false, false, 4) + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        tr,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .contract_gas */ .Um.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .EvmGasTrend */ .K3, {
            interval: inter
        });
        result?.points?.forEach((value)=>{
            const { timestamp, txs_gas } = value;
            let showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(timestamp, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(timestamp, "MM-DD HH:mm");
            if (isMobile) {
                showTime = (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(timestamp, "MM-DD");
            }
            dateList.push(showTime);
            //amount
            seriesObj.txs_gas.push({
                amount: txs_gas,
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFil */ .Uk)(txs_gas, "FIL"),
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(timestamp, "YYYY-MM-DD HH:mm"),
                unit: ""
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .contract_gas */ .Um.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                data: seriesObj[item.dataIndex],
                name: item.title,
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            if (!noShow[seriesItem?.name]) {
                newSeries.push(seriesItem);
            }
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions,
        noShow
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default().trend), `h-[full] w-full  ${className}`),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(`mb-2.5 flex min-h-[36px] flex-wrap items-center justify-between ${lang === "en" ? "h-[60px]" : ""}`, (_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-1 flex-row flex-wrap items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("w-fit min-w-[120px] pl-2.5 font-HarmonyOS text-lg font-semibold", (_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_15___default().title)),
                            children: tr("contract_gas")
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_9__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mx-2.5 flex items-center gap-x-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_select__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                ns: "static",
                                options: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                                value: interval,
                                onChange: (interval)=>{
                                    setInterval(interval);
                                    load(interval);
                                }
                            }, `static_${origin}_contract`)
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `card_shadow border_color h-[350px] w-full rounded-xl border pb-2`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
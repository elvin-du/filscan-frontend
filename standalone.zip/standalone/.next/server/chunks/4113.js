exports.id = 4113;
exports.ids = [4113];
exports.modules = {

/***/ 67608:
/***/ ((module) => {

// Exports
module.exports = {
	"contain": "user_contain__X3HVz",
	"contain_text": "user_contain_text__GefkT",
	"contain_text_pro": "user_contain_text_pro__VgXn5",
	"contain_left": "user_contain_left__z04x8",
	"contain_left_text": "user_contain_left_text__61RIl",
	"contain_right": "user_contain_right__7fbPC"
};


/***/ }),

/***/ 99258:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/loginIcon.793569fc.png","height":838,"width":1080,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAA0UlEQVR4nAHGADn/AavJ26Lr9fcivsUgljxO8nL6A//158UNoiUn5WgVDQamAc/c6trh4t4J9QUWp639AHX/Av/5aRMDnAT382br/AnDAQCY+1HiUPvT9Qb527TK4PsGAwYFOCwR/fPU6xtEIiVCAQDR/VXtAPvF/yIA3fT+8wjs7fIA6uX78JhFpyIQ8V9DAaTG2ef99fwCSDUeUQD0A1HT1eL5DRcJ1eH576D5BvzFAcjKzI37Bwg50Bnjo/cU6dgBAQD+N/sxOg/fDV/Lx9GfX/lr6LT2cLcAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 36854:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ useCountdown)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

// 自定义hook
function useCountdown(initialCount) {
    const [count, setCount] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialCount);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (count > 0) {
            const timer = setInterval(()=>{
                setCount((prevCount)=>prevCount - 1);
            }, 1000);
            return ()=>clearInterval(timer);
        }
    }, [
        count
    ]);
    const resetCountdown = (newCount)=>{
        setCount(newCount);
    };
    return {
        count,
        resetCountdown
    };
}


/***/ }),

/***/ 12912:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ai: () => (/* binding */ login_list),
/* harmony export */   PO: () => (/* binding */ logTabs)
/* harmony export */ });
/* unused harmony exports personal_list, personal_setting */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _assets_images_member_vip_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62539);


const logTabs = [
    {
        title: "password_login",
        dataIndex: "password"
    },
    {
        title: "verification_code",
        dataIndex: "code"
    }
];
const login_list = {
    password: [
        {
            label: "email",
            name: "email",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-mail-line custom_remix-icon"
            }),
            placeholder: "email_placeholder",
            rules: [
                {
                    required: true,
                    message: "Email is required"
                }
            ]
        },
        {
            label: "password",
            name: "password",
            placeholder: "password_placeholder",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-lock-2-line custom_remix-icon"
            }),
            rules: [
                {
                    required: true,
                    message: "Password is required"
                }
            ]
        }
    ],
    code: [
        {
            label: "email",
            name: "email",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-mail-line custom_remix-icon"
            }),
            placeholder: "email_placeholder",
            rules: [
                {
                    required: true,
                    message: "Email is required"
                }
            ]
        },
        {
            label: "code",
            name: "code",
            placeholder: "code_placeholder",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-shield-check-line custom_remix-icon"
            }),
            rules: [
                {
                    required: true,
                    message: "Code is required"
                }
            ]
        },
        {
            label: "invite",
            name: "invite",
            placeholder: "invite_placeholder",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-p2p-line custom_remix-icon"
            }),
            rules: [
                {
                    required: true,
                    message: "Password is required"
                }
            ]
        }
    ],
    forget: [
        {
            label: "email",
            name: "email",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-mail-line custom_remix-icon"
            }),
            placeholder: "email_placeholder",
            rules: [
                {
                    required: true,
                    message: "Email is required"
                }
            ]
        },
        {
            label: "code",
            name: "code",
            placeholder: "code_placeholder",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-shield-check-line custom_remix-icon"
            }),
            rules: [
                {
                    required: true,
                    message: "Code is required"
                }
            ]
        },
        {
            label: "password",
            name: "new_password",
            placeholder: "new_password",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-lock-2-line custom_remix-icon"
            }),
            rules: [
                {
                    required: true,
                    message: "Password is required"
                }
            ]
        },
        {
            label: "password",
            name: "confirm_password",
            placeholder: "confirm_password",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-lock-2-line custom_remix-icon"
            }),
            rules: [
                {
                    required: true,
                    message: "Confirm assword is required"
                }
            ]
        }
    ],
    register: [
        {
            label: "email",
            name: "email",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-mail-line custom_remix-icon"
            }),
            placeholder: "email_placeholder",
            rules: [
                {
                    required: true,
                    message: "Email is required"
                }
            ]
        },
        {
            label: "code",
            name: "code",
            placeholder: "code_placeholder",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-shield-check-line custom_remix-icon"
            }),
            rules: [
                {
                    required: true,
                    message: "Code is required"
                }
            ]
        },
        {
            label: "password",
            name: "new_password",
            placeholder: "new_password",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-lock-2-line custom_remix-icon"
            }),
            rules: [
                {
                    required: true,
                    message: "Password is required"
                }
            ]
        },
        {
            label: "password",
            name: "confirm_password",
            placeholder: "confirm_password",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-lock-2-line custom_remix-icon"
            }),
            rules: [
                {
                    required: true,
                    message: "Confirm password is required"
                }
            ]
        },
        {
            label: "invite",
            name: "invite",
            placeholder: "invite_placeholder",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "ri-p2p-line custom_remix-icon"
            }),
            rules: [
                {
                    required: true,
                    message: "Password is required"
                }
            ]
        }
    ]
};
const personal_list = [
    {
        title: "personal_1",
        key: "member",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_vip_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
    },
    {
        title: "personal_2",
        key: "mail"
    },
    {
        title: "personal_3",
        key: "password"
    }
];
const personal_setting = [
    // {
    //   title: 'personal_name',
    //   dataIndex: 'name',
    //   placeholder: 'personal_name_holder',
    // },
    {
        title: "old_password",
        placeholder: "old_placeholder",
        dataIndex: "old_password",
        rules: [
            {
                required: true,
                message: "old_placeholder is required"
            }
        ]
    },
    {
        title: "new_password",
        placeholder: "new_placeholder",
        dataIndex: "new_password",
        rules: [
            {
                required: true,
                message: "${new_password} is required"
            }
        ]
    },
    {
        title: "confirm_password",
        dataIndex: "confirm_password",
        placeholder: "confirm_password",
        rules: [
            {
                required: true,
                message: "${confirm_password} is required"
            }
        ]
    }
];


/***/ }),

/***/ 82104:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _components_hooks_useCount__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36854);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(23495);
/* harmony import */ var _store_modules_user__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(63414);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_3__, _store_modules_user__WEBPACK_IMPORTED_MODULE_4__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_3__, _store_modules_user__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 




// 在组件中使用自定义hook
function VerifyCodeButton({ mail, onChange }) {
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "common"
    });
    const { count, resetCountdown } = (0,_components_hooks_useCount__WEBPACK_IMPORTED_MODULE_2__/* .useCountdown */ .a)(0);
    // 模拟发送验证码的函数
    const sendCode = async (e)=>{
        // 假设验证码发送后，倒计时60秒
        if (mail && (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .isEmail */ .Jh)(mail)) {
            resetCountdown(60) // 证码有效期为60秒
            ;
            _store_modules_user__WEBPACK_IMPORTED_MODULE_4__["default"].getVerifyCode(mail);
        // if (result?.token) {
        //   localStorage.setItem('send_code', result.token)
        //   if (onChange) onChange(result?.token)
        // }
        }
        e.preventDefault();
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        className: "text_primary border_color cursor-pointer border-s pl-2 text-sm",
        disabled: count > 0,
        onClick: sendCode,
        children: count > 0 ? `${tr("retry_code")}(${count})` : tr("get_code")
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VerifyCodeButton);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 98690:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(67608);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_images_loginIcon_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(99258);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62881);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__]);
_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { children } = props;
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "common"
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().contain)}`,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().contain_left),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().contain_left_text),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().contain_text),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: tr("active_top_1")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().contain_text_pro),
                                        children: tr("active_top_2")
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().contain_text),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: tr("active_bottom_1")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().contain_text_pro),
                                        children: tr("active_bottom_2")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                        src: _assets_images_loginIcon_png__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
                        alt: "",
                        height: 288
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().contain_right),
                children: children
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
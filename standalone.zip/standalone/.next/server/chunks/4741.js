exports.id = 4741;
exports.ids = [4741];
exports.modules = {

/***/ 9936:
/***/ ((module) => {

// Exports
module.exports = {
	"loading_wrap": "loading_loading_wrap__gdHDc"
};


/***/ }),

/***/ 6703:
/***/ ((module) => {

// Exports
module.exports = {
	"contract_wrap": "detail_contract_wrap__OUcKK",
	"contract_wrap_tabs": "detail_contract_wrap_tabs__bOOiA",
	"contract_wrap_textMain_toVerify": "detail_contract_wrap_textMain_toVerify__O9_NL",
	"contract_wrap_textMain_title": "detail_contract_wrap_textMain_title__THvB8",
	"contract_wrap_textMain_title_nameText": "detail_contract_wrap_textMain_title_nameText__uO_2z",
	"contract_wrap_textMain_title_name": "detail_contract_wrap_textMain_title_name__kFf8w",
	"contract_wrap_textMain_title_right": "detail_contract_wrap_textMain_title_right__gR_v4",
	"contract_wrap_textMain_codeContent": "detail_contract_wrap_textMain_codeContent__8JipI",
	"contract_wrap_textMain_content": "detail_contract_wrap_textMain_content__1qDWu",
	"contract_wrap_card": "detail_contract_wrap_card__n_F_T",
	"contract_wrap_overview": "detail_contract_wrap_overview__14Vws",
	"contract_wrap_overview_content": "detail_contract_wrap_overview_content__D0pgD",
	"abi_content": "detail_abi_content__ZpWCn",
	"abi_content_wallet": "detail_abi_content_wallet__k1L5s",
	"abi_content_reset": "detail_abi_content_reset__Whq9z",
	"abi_content_item_btn": "detail_abi_content_item_btn__Hrfty",
	"abi_content_item_response": "detail_abi_content_item_response__V8fxm",
	"abi_content_item_response_title": "detail_abi_content_item_response_title__qGQm0",
	"abi_content_item_response_value": "detail_abi_content_item_response_value__5_ZnA",
	"abi_content_item_content": "detail_abi_content_item_content__4tBct",
	"abi_content_item_content_icon": "detail_abi_content_item_content_icon__P8z5m",
	"abi_content_item_content_name": "detail_abi_content_item_content_name__HHCZO",
	"abi_content_item_content_name_des": "detail_abi_content_item_content_name_des__eZOn4",
	"abi_content_item_content_input": "detail_abi_content_item_content_input__zib4d",
	"show_content": "detail_show_content__8uB6r",
	"show_content_name": "detail_show_content_name__rqJc8",
	"show_content_main": "detail_show_content_main__6SFF_"
};


/***/ }),

/***/ 3294:
/***/ ((module) => {

// Exports
module.exports = {
	"contract_event_log": "log_contract_event_log__5gBbK",
	"contract_event_log_wrap": "log_contract_event_log_wrap__KKDQd",
	"contract_event_log_pg": "log_contract_event_log_pg__X3PZM"
};


/***/ }),

/***/ 6150:
/***/ ((module) => {

// Exports
module.exports = {
	"message_list": "style_message_list__6Xacb",
	"message_list_tabs": "style_message_list_tabs__SClAb",
	"message_list_header": "style_message_list_header__sv_JJ",
	"message_list_mainTotal": "style_message_list_mainTotal__Ms_9O",
	"message_list_main": "style_message_list_main__wAzLX",
	"message_list_main_looksAll": "style_message_list_main_looksAll__R1YqQ"
};


/***/ }),

/***/ 6571:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9936);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_2__);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_2___default().loading_wrap),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_1__.LoadingOutlined, {
            style: {
                fontSize: 36
            },
            rev: undefined
        })
    });
});


/***/ }),

/***/ 6602:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_contract__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2196);
/* harmony import */ var _packages_tabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5943);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6703);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _verify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4563);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_contract__WEBPACK_IMPORTED_MODULE_1__, _packages_tabs__WEBPACK_IMPORTED_MODULE_2__, _verify__WEBPACK_IMPORTED_MODULE_4__]);
([_contants_contract__WEBPACK_IMPORTED_MODULE_1__, _packages_tabs__WEBPACK_IMPORTED_MODULE_2__, _verify__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const Read = next_dynamic__WEBPACK_IMPORTED_MODULE_5___default()(null, {
    loadableGenerated: {
        modules: [
            "../src/contract/detail/index.tsx -> " + "./Read"
        ]
    },
    ssr: false
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ id , verifyData  })=>{
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("Verify_code");
    const handleChange = (type, item)=>{
        setActive(item.value);
    };
    if (!verifyData?.contract_address) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().contract_wrap),
            children: [
                " ",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_verify__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    verifyData: verifyData,
                    id: id
                })
            ]
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().contract_wrap),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tabs__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                border: true,
                data: _contants_contract__WEBPACK_IMPORTED_MODULE_1__/* .verify_tabs */ .s3,
                ns: "contract",
                defaultValue: active,
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().contract_wrap_tabs),
                onChange: (value)=>handleChange("active", value)
            }),
            active === "Verify_code" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_verify__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                verifyData: verifyData,
                id: id
            }),
            active === "Verify_read" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Read, {
                verifyData: verifyData,
                type: "view",
                id: id
            }),
            active === "Verify_write" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Read, {
                verifyData: verifyData,
                type: "write",
                id: id
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4563:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _packages_custom_card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3625);
/* harmony import */ var _packages_main__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8266);
/* harmony import */ var _contants_contract__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2196);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6703);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7987);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3775);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9997);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__, _packages_main__WEBPACK_IMPORTED_MODULE_3__, _contants_contract__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_5__]);
([_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__, _packages_main__WEBPACK_IMPORTED_MODULE_3__, _contants_contract__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const Editor = next_dynamic__WEBPACK_IMPORTED_MODULE_9___default()(null, {
    loadableGenerated: {
        modules: [
            "../src/contract/detail/verify.tsx -> " + "@/components/ace"
        ]
    },
    ssr: false
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ id , verifyData  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "contract"
            });
        }
        return t(label, {
            ns: "contract"
        });
    };
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setData(verifyData);
    }, [
        verifyData
    ]);
    const handleClick = (value)=>{
        if (id) {
            window.open(`${window.location.origin}/contract/abi/${id}?format=${value}`);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            data?.source_file && Object.keys(data?.source_file).length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        title: _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.overview.title */ .JZ.overview.title,
                        ns: "contract",
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_card),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_main__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            content: _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.overview.list */ .JZ.overview.list,
                            data: data,
                            ns: "contract",
                            splitFlex: true,
                            splitClassName: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_overview),
                            warpClassName: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_overview_content)
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        title: `${tr(_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.code.title */ .JZ.code.title)} (${data?.language})`,
                        ns: "contract",
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_card),
                        children: data?.source_file?.map((itemData, index)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_title),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_title_name),
                                                children: [
                                                    (0,_svgUtils__WEBPACK_IMPORTED_MODULE_6__/* .getSvgIcon */ .a)("fileIcon"),
                                                    tr(itemData.file_name)
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_title_right),
                                                children: [
                                                    _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.code.copy */ .JZ.code.copy && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        text: itemData[_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.code.content */ .JZ.code.content]
                                                    }),
                                                    _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.code.link */ .JZ.code.link && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        text: window?.location?.href,
                                                        icon: "linkIcon"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_codeContent),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Editor, {
                                            value: itemData[_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.code.content */ .JZ.code.content],
                                            otherProps: {
                                                readOnly: true
                                            }
                                        })
                                    })
                                ]
                            }, index);
                        })
                    })
                ]
            }),
            data[_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.abi.text */ .JZ.abi.text] && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                ns: "contract",
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_card),
                header: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_title),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_title_nameText),
                            children: tr(_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.abi.title */ .JZ.abi.title)
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_title_right),
                            children: [
                                _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.abi.options */ .JZ.abi.options && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_8__.Select, {
                                    className: "custom_select",
                                    options: _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.abi.options.list */ .JZ.abi.options.list,
                                    onChange: handleClick,
                                    placeholder: tr(_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.abi.options.placeholder */ .JZ.abi.options.placeholder)
                                }),
                                _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.abi.copy */ .JZ.abi.copy && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    text: data[_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.abi.text */ .JZ.abi.text]
                                })
                            ]
                        })
                    ]
                }),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_content),
                        children: data[_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.abi.text */ .JZ.abi.text]
                    })
                })
            }),
            _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.byte_code */ .JZ.byte_code && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                ns: "contract",
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_card),
                header: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        !data?.source_file || Object.keys(data?.source_file).length === 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_toVerify),
                            children: [
                                tr("byte_code_no_verify"),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    href: "//contract/verify",
                                    className: "link",
                                    children: tr("go_to_verify")
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_title),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_title_nameText),
                                    children: tr(_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.byte_code.title */ .JZ.byte_code.title)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_title_right),
                                    children: _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.abi.copy */ .JZ.abi.copy && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        text: data[_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.byte_code.text */ .JZ.byte_code.text]
                                    })
                                })
                            ]
                        })
                    ]
                }),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_content),
                        children: data[_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.byte_code.text */ .JZ.byte_code.text]
                    })
                })
            }),
            data?.arguments && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                ns: "contract",
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_card),
                header: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_title),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_title_nameText),
                        children: tr("arguments")
                    })
                }),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().contract_wrap_textMain_content),
                        children: data.arguments
                    })
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 137:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9189);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1311);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _packages_main__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8266);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3294);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _contants_contract__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2196);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_loading__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6571);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_server__WEBPACK_IMPORTED_MODULE_2__, _packages_main__WEBPACK_IMPORTED_MODULE_4__, _contants_contract__WEBPACK_IMPORTED_MODULE_5__]);
([_store_server__WEBPACK_IMPORTED_MODULE_2__, _packages_main__WEBPACK_IMPORTED_MODULE_4__, _contants_contract__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ actor_id  })=>{
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(1);
    const [total, setTotal] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (actor_id) {
            load();
        }
    }, [
        actor_id
    ]);
    const load = (index)=>{
        setLoading(true);
        (0,_store_server__WEBPACK_IMPORTED_MODULE_2__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl.contract_verify_logs */ .J.contract_verify_logs, {
            actor_id: actor_id,
            page: index || current,
            limit: 5
        }).then((res)=>{
            setLoading(false);
            setData(res.result.event_list);
            setTotal(res.result.total_count);
        });
    };
    const handleChange = (cur)=>{
        setCurrent(cur);
        load(cur);
    };
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().contract_event_log),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loading__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().contract_event_log),
        children: [
            data?.map((ItemData, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_main__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    warpClassName: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().contract_event_log_wrap),
                    content: _contants_contract__WEBPACK_IMPORTED_MODULE_5__/* .contract_log */ .OR,
                    data: ItemData,
                    ns: "contract"
                }, index);
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Pagination, {
                showQuickJumper: true,
                className: `custom_Pagination ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().contract_event_log_pg)}`,
                current: current,
                total: total,
                onChange: handleChange
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4741:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6150);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _packages_tabs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5943);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _packages_newTable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7692);
/* harmony import */ var _contants_detail__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2448);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7987);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8194);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1311);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9189);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(697);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _src_contract_detail__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6602);
/* harmony import */ var _src_contract_log__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(137);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_packages_tabs__WEBPACK_IMPORTED_MODULE_1__, _packages_newTable__WEBPACK_IMPORTED_MODULE_3__, _contants_detail__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_5__, _store_server__WEBPACK_IMPORTED_MODULE_7__, _contants_varible__WEBPACK_IMPORTED_MODULE_9__, _src_contract_detail__WEBPACK_IMPORTED_MODULE_12__, _src_contract_log__WEBPACK_IMPORTED_MODULE_13__]);
([_packages_tabs__WEBPACK_IMPORTED_MODULE_1__, _packages_newTable__WEBPACK_IMPORTED_MODULE_3__, _contants_detail__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_5__, _store_server__WEBPACK_IMPORTED_MODULE_7__, _contants_varible__WEBPACK_IMPORTED_MODULE_9__, _src_contract_detail__WEBPACK_IMPORTED_MODULE_12__, _src_contract_log__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 














/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ account_id , actor_id , erc20 , ootions , verifyData  })=>{
    var _filscanStore_filscan, _filscanStore_filscan1;
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_10__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { activeTab  } = router.query;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "detail"
            });
        }
        return t(label, {
            ns: "detail"
        });
    };
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)([]);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(false);
    const [methodValue, setMethod] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("all");
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)([]);
    const [fromList, setFrom] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)({});
    const [toList, setTo] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)({});
    const [total, setTotal] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(0);
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)({
        label: "message_list",
        value: "MessagesByAccountID",
        headerList: true,
        options: []
    });
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(1);
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        if (options) {
            const newOptios = options.map((v)=>{
                return {
                    ...v,
                    label: tr(v.key)
                };
            });
            setOptions(newOptios);
        }
    }, [
        filscanStore === null || filscanStore === void 0 ? void 0 : (_filscanStore_filscan = filscanStore.filscan) === null || _filscanStore_filscan === void 0 ? void 0 : _filscanStore_filscan.lang
    ]);
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(()=>{
        return _contants_detail__WEBPACK_IMPORTED_MODULE_4__/* .miner_list.columns */ .aV.columns(active.value, fromList, toList).map((v)=>{
            const newObj = {
                ...v,
                title: tr(v.title)
            };
            return newObj;
        });
    }, [
        filscanStore === null || filscanStore === void 0 ? void 0 : (_filscanStore_filscan1 = filscanStore.filscan) === null || _filscanStore_filscan1 === void 0 ? void 0 : _filscanStore_filscan1.lang,
        active,
        fromList,
        toList
    ]);
    const handleChange = (type, item)=>{
        if (type === "active") {
            setActive(item);
            setTotal(0);
            setMethod("all");
            setFrom({});
            setTo({});
            setData([]);
            setCurrent(1);
            if (item.value === "event_log") {
                return;
            }
            if (!item.value.startsWith("verify")) {
                load(1, item.value, "all", undefined, item);
            }
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        if (account_id) {
            let defaultItem = active;
            if (defaultItem.value !== "MessagesByAccountID") {
                defaultItem = {
                    label: "message_list",
                    value: "MessagesByAccountID",
                    headerList: true
                };
                setActive(defaultItem);
            }
            load_options();
            load(1, defaultItem.value);
        }
    }, [
        account_id,
        actor_id,
        activeTab
    ]);
    const getActiveItem = ()=>{
        return (ootions || _contants_detail__WEBPACK_IMPORTED_MODULE_4__/* .miner_list.title */ .aV.title).find((item)=>{
            return item.value === (active === null || active === void 0 ? void 0 : active.value);
        });
    };
    const load_options = ()=>{
        (0,_store_server__WEBPACK_IMPORTED_MODULE_7__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_8__/* .apiUrl.detail_list_method */ .J.detail_list_method, {
            account_id
        }).then((res)=>{
            var _res_result;
            const opt = [];
            const newObj = (res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.method_name_list) || {};
            opt.push({
                label: `${tr("all")}`,
                value: "all",
                key: "all"
            });
            Object.keys(newObj).forEach((key)=>{
                opt.push({
                    label: `${tr(key)}`,
                    value: key,
                    key: key
                });
            });
            setOptions(opt);
        });
    };
    const load = (cur, value, method, payload, activeItem)=>{
        setLoading(true);
        const index = cur || current;
        const showValue = value || active.value;
        const linkUrl = _contants_apiUrl__WEBPACK_IMPORTED_MODULE_8__/* .apiUrl.detail_miner_list */ .J.detail_miner_list + "/" + showValue;
        const active_item = activeItem || getActiveItem() || {};
        const showMethod = method || methodValue;
        const obj = active.headerList ? {
            method_name: showMethod === "all" ? "" : showMethod
        } : {};
        (0,_store_server__WEBPACK_IMPORTED_MODULE_7__/* .postAxios */ .xW)(linkUrl, {
            account_id: account_id,
            address: erc20,
            filters: {
                index: index - 1,
                page: index - 1,
                limit: _contants_varible__WEBPACK_IMPORTED_MODULE_9__/* .pageLimit */ .P5,
                ...obj
            },
            ...payload
        }).then((res)=>{
            const result = (res === null || res === void 0 ? void 0 : res.result) || {};
            setLoading(false);
            const result_key = _contants_detail__WEBPACK_IMPORTED_MODULE_4__/* .miner_list.resultObj */ .aV.resultObj(showValue);
            const data = result[result_key] || [];
            setTotal((result === null || result === void 0 ? void 0 : result.total_count) || (result === null || result === void 0 ? void 0 : result.total));
            setData(data);
            if (data.length > 0) {
                const formItems = data.map((v)=>v.from);
                const toItems = data.map((v)=>v.to);
                loadFnsUrl(formItems, "form");
                loadFnsUrl(toItems, "to");
            }
        });
        if (active_item.headerList) {
            if ((active_item === null || active_item === void 0 ? void 0 : active_item.options) && active_item.options.length > 0) {
                const new_ops = active_item.options.map((v)=>{
                    return {
                        ...v,
                        label: v.label === "all" ? `${tr(v.label)}` : v.label,
                        value: v.value
                    };
                });
                setOptions(new_ops);
            } else {
                load_options();
            }
        }
    };
    const loadFnsUrl = (items, type)=>{
        (0,_store_server__WEBPACK_IMPORTED_MODULE_7__/* .postAxios */ .xW)(`${_contants_apiUrl__WEBPACK_IMPORTED_MODULE_8__/* .apiUrl.contract_fnsUrl */ .J.contract_fnsUrl}`, {
            addresses: items
        }).then((res)=>{
            if (type === "form") {
                setFrom(res === null || res === void 0 ? void 0 : res.result);
            } else {
                setTo(res === null || res === void 0 ? void 0 : res.result);
            }
        });
    };
    const renderChildren = ()=>{
        if (active.value === "event_log") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_contract_log__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                actor_id: actor_id
            });
        }
        if (active.value.startsWith("verify")) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_contract_detail__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                verifyData: verifyData,
                id: active.value.split("_")[1]
            });
        }
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default().message_list_header),
                    children: tr(`${active.label}_total`, {
                        value: total
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_newTable__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    dataSource: [
                        ...data
                    ],
                    total: total,
                    columns: columns,
                    current: current,
                    loading: loading,
                    // rowKey={(record: any) => `${active.value}_${new Date().getTime()}`}
                    onPage: (cur)=>{
                        setCurrent(cur);
                        load(cur);
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default().message_list_main_looksAll),
                    onClick: ()=>{
                        window.open(`http://v1.filscan.io/tipset/address-detail?address=${account_id}`);
                    },
                    children: tr("look_all")
                })
            ]
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default().message_list),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default().message_list_tabs),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tabs__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        border: true,
                        data: ootions || _contants_detail__WEBPACK_IMPORTED_MODULE_4__/* .miner_list.title */ .aV.title,
                        ns: "detail",
                        defaultValue: active.value,
                        onChange: (value)=>handleChange("active", value)
                    }),
                    active.headerList && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_11__.Select, {
                        // options={options}
                        showSearch: true,
                        value: methodValue,
                        className: "custom_select",
                        onChange: (value)=>{
                            setCurrent(1);
                            const showValue = value === "all" ? "" : value;
                            setMethod(value);
                            load(1, undefined, showValue);
                        },
                        children: options.map((opt, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_11__.Select.Option, {
                                value: opt.value || opt.label || opt.title,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (opt === null || opt === void 0 ? void 0 : opt.isIndent) ? "margin-30 " : "",
                                    children: opt.label || opt.title
                                })
                            }, index);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${(_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default().message_list_main)} ${total > _contants_varible__WEBPACK_IMPORTED_MODULE_9__/* .pageLimit */ .P5 ? "" : (_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default().message_list_mainTotal)}`,
                children: renderChildren()
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
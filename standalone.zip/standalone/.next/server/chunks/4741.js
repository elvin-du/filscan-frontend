exports.id = 4741;
exports.ids = [4741];
exports.modules = {

/***/ 6150:
/***/ ((module) => {

// Exports
module.exports = {
	"message_list": "style_message_list__6Xacb",
	"message_list_tabs": "style_message_list_tabs__SClAb",
	"message_list_header": "style_message_list_header__sv_JJ",
	"message_list_main": "style_message_list_main__wAzLX"
};


/***/ }),

/***/ 4741:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6150);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _packages_tabs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5943);
/* harmony import */ var _packages_newTable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7692);
/* harmony import */ var _contants_detail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2448);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8194);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1311);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9189);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(697);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_packages_tabs__WEBPACK_IMPORTED_MODULE_1__, _packages_newTable__WEBPACK_IMPORTED_MODULE_2__, _contants_detail__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _store_server__WEBPACK_IMPORTED_MODULE_6__, _contants_varible__WEBPACK_IMPORTED_MODULE_8__]);
([_packages_tabs__WEBPACK_IMPORTED_MODULE_1__, _packages_newTable__WEBPACK_IMPORTED_MODULE_2__, _contants_detail__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _store_server__WEBPACK_IMPORTED_MODULE_6__, _contants_varible__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 











/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ account_id , ootions  })=>{
    var _filscanStore_filscan, _filscanStore_filscan1;
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_9__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "detail"
            });
        }
        return t(label, {
            ns: "detail"
        });
    };
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)([]);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [methodValue, setMethod] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)([]);
    const [total, setTotal] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(0);
    // const [data, setData] = useState({
    //   total: 0,
    //   dataSource: [],
    // });
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({
        label: "message_list",
        value: "MessagesByAccountID",
        headerList: true
    });
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(1);
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        if (options) {
            const newOptios = options.map((v)=>{
                return {
                    ...v,
                    label: tr(v.key)
                };
            });
            setOptions(newOptios);
        }
    }, [
        filscanStore === null || filscanStore === void 0 ? void 0 : (_filscanStore_filscan = filscanStore.filscan) === null || _filscanStore_filscan === void 0 ? void 0 : _filscanStore_filscan.lang
    ]);
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        return _contants_detail__WEBPACK_IMPORTED_MODULE_3__/* .miner_list.columns */ .aV.columns(active.value).map((v)=>{
            const newObj = {
                ...v,
                title: tr(v.title)
            };
            return newObj;
        });
    }, [
        filscanStore === null || filscanStore === void 0 ? void 0 : (_filscanStore_filscan1 = filscanStore.filscan) === null || _filscanStore_filscan1 === void 0 ? void 0 : _filscanStore_filscan1.lang,
        active
    ]);
    const handleChange = (type, item)=>{
        if (type === "active") {
            setActive(item);
            setTotal(0);
            setMethod("");
            setData([]);
            setCurrent(1);
            load(1, item.value);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        if (account_id) {
            (0,_store_server__WEBPACK_IMPORTED_MODULE_6__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_7__/* .apiUrl.detail_list_method */ .J.detail_list_method, {
                account_id
            }).then((res)=>{
                var _res_result;
                const opt = [];
                const newObj = (res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.method_name_list) || {};
                opt.push({
                    label: `${tr("message_list_all")}`,
                    value: "all",
                    key: "all"
                });
                Object.keys(newObj).forEach((key)=>{
                    opt.push({
                        label: `${tr(key)}`,
                        value: key,
                        key: key
                    });
                });
                setOptions(opt);
            });
            load();
        }
    }, [
        account_id
    ]);
    const load = (cur, value, method)=>{
        setLoading(true);
        const index = cur || current;
        const showValue = value || active.value;
        const linkUrl = _contants_apiUrl__WEBPACK_IMPORTED_MODULE_7__/* .apiUrl.detail_miner_list */ .J.detail_miner_list + "/" + showValue;
        const obj = active.headerList ? {
            method_name: method || methodValue
        } : {};
        (0,_store_server__WEBPACK_IMPORTED_MODULE_6__/* .postAxios */ .xW)(linkUrl, {
            account_id: account_id,
            filters: {
                index: index - 1,
                limit: _contants_varible__WEBPACK_IMPORTED_MODULE_8__/* .pageLimit */ .P5,
                ...obj
            }
        }).then((res)=>{
            const result = (res === null || res === void 0 ? void 0 : res.result) || {};
            setLoading(false);
            const result_key = _contants_detail__WEBPACK_IMPORTED_MODULE_3__/* .miner_list.resultObj */ .aV.resultObj(showValue);
            const data = result[result_key] || [];
            setTotal(result.total_count);
            setData(data);
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default().message_list),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default().message_list_tabs),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tabs__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        border: true,
                        data: ootions || _contants_detail__WEBPACK_IMPORTED_MODULE_3__/* .miner_list.title */ .aV.title,
                        ns: "detail",
                        defaultValue: active.value,
                        onChange: (value)=>handleChange("active", value)
                    }),
                    active.headerList && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_10__.Select, {
                        options: options,
                        defaultValue: "all",
                        className: "custom_select",
                        onChange: (value)=>{
                            setCurrent(1);
                            const showValue = value === "all" ? "" : value;
                            setMethod(showValue);
                            load(1, undefined, showValue);
                        }
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default().message_list_main),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default().message_list_header),
                        children: tr(`${active.label}_total`, {
                            value: total
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_newTable__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        dataSource: [
                            ...data
                        ],
                        total: total,
                        columns: columns,
                        current: current,
                        loading: loading,
                        // rowKey={(record: any) => `${active.value}_${new Date().getTime()}`}
                        onPage: (cur)=>{
                            setCurrent(cur);
                            load(cur);
                        }
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
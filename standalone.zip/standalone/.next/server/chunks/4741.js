exports.id = 4741;
exports.ids = [4741];
exports.modules = {

/***/ 6703:
/***/ ((module) => {

// Exports
module.exports = {
	"contract_wrap": "detail_contract_wrap__OUcKK",
	"contract_wrap_textMain_title": "detail_contract_wrap_textMain_title__THvB8",
	"contract_wrap_textMain_title_nameText": "detail_contract_wrap_textMain_title_nameText__uO_2z",
	"contract_wrap_textMain_title_name": "detail_contract_wrap_textMain_title_name__kFf8w",
	"contract_wrap_textMain_title_right": "detail_contract_wrap_textMain_title_right__gR_v4",
	"contract_wrap_textMain_codeContent": "detail_contract_wrap_textMain_codeContent__8JipI",
	"contract_wrap_textMain_content": "detail_contract_wrap_textMain_content__1qDWu",
	"contract_wrap_card": "detail_contract_wrap_card__n_F_T",
	"contract_wrap_overview": "detail_contract_wrap_overview__14Vws",
	"contract_wrap_overview_content": "detail_contract_wrap_overview_content__D0pgD"
};


/***/ }),

/***/ 6150:
/***/ ((module) => {

// Exports
module.exports = {
	"message_list": "style_message_list__6Xacb",
	"message_list_tabs": "style_message_list_tabs__SClAb",
	"message_list_header": "style_message_list_header__sv_JJ",
	"message_list_mainTotal": "style_message_list_mainTotal__Ms_9O",
	"message_list_main": "style_message_list_main__wAzLX",
	"message_list_main_looksAll": "style_message_list_main_looksAll__R1YqQ"
};


/***/ }),

/***/ 929:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _packages_custom_card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3625);
/* harmony import */ var _packages_main__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8266);
/* harmony import */ var _contants_contract__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2196);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6703);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7987);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3775);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9997);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__, _packages_main__WEBPACK_IMPORTED_MODULE_3__, _contants_contract__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_5__]);
([_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__, _packages_main__WEBPACK_IMPORTED_MODULE_3__, _contants_contract__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const Editor = next_dynamic__WEBPACK_IMPORTED_MODULE_9___default()(null, {
    loadableGenerated: {
        modules: [
            "../src/contract/detail/index.tsx -> " + "@/components/ace"
        ]
    },
    ssr: false
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ id , verifyData  })=>{
    var _data_source_file;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "contract"
            });
        }
        return t(label, {
            ns: "contract"
        });
    };
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setData(verifyData);
    // if (id && !verifyData) { 
    //     postAxios(apiUrl.contract_verify_des, {
    //     input_address:id
    //     }).then(
    //         (res: any) => {
    //             setData({ ...res?.result?.compiled_file || {},source_file:res?.result?.source_file || []});
    //     }
    // );
    // }
    }, [
        verifyData
    ]);
    const handleClick = (value)=>{
        if (id) {
            window.open(`${window.location.origin}/contract/abi/${id}?format=${value}`);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                title: _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.overview.title */ .JZ.overview.title,
                ns: "contract",
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_card),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_main__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    content: _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.overview.list */ .JZ.overview.list,
                    data: data,
                    ns: "contract",
                    splitFlex: true,
                    splitClassName: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_overview),
                    warpClassName: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_overview_content)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                title: `${tr(_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.code.title */ .JZ.code.title)} (${data === null || data === void 0 ? void 0 : data.language})`,
                ns: "contract",
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_card),
                children: data === null || data === void 0 ? void 0 : (_data_source_file = data.source_file) === null || _data_source_file === void 0 ? void 0 : _data_source_file.map((itemData, index)=>{
                    var _window_location;
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_textMain),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_textMain_title),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_textMain_title_name),
                                        children: [
                                            (0,_svgUtils__WEBPACK_IMPORTED_MODULE_6__/* .getSvgIcon */ .a)("fileIcon"),
                                            tr(itemData.file_name)
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_textMain_title_right),
                                        children: [
                                            _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.code.copy */ .JZ.code.copy && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                text: itemData[_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.code.content */ .JZ.code.content]
                                            }),
                                            _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.code.link */ .JZ.code.link && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                text: window === null || window === void 0 ? void 0 : (_window_location = window.location) === null || _window_location === void 0 ? void 0 : _window_location.href,
                                                icon: "linkIcon"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_textMain_codeContent),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Editor, {
                                    value: itemData[_contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.code.content */ .JZ.code.content],
                                    otherProps: {
                                        readOnly: true
                                    }
                                })
                            })
                        ]
                    }, index);
                })
            }),
            _contants_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail.other.map */ .JZ.other.map((contentItem)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    ns: "contract",
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_card),
                    header: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_textMain_title),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_textMain_title_nameText),
                                children: tr(contentItem.title)
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_textMain_title_right),
                                children: [
                                    contentItem.options && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_8__.Select, {
                                        className: "custom_select",
                                        options: contentItem.options.list,
                                        onChange: handleClick,
                                        placeholder: tr(contentItem.options.placeholder)
                                    }),
                                    contentItem.copy && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        text: data[contentItem.text]
                                    })
                                ]
                            })
                        ]
                    }),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_textMain),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().contract_wrap_textMain_content),
                            children: data[contentItem.text]
                        })
                    })
                });
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4741:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6150);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _packages_tabs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5943);
/* harmony import */ var _packages_newTable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7692);
/* harmony import */ var _contants_detail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8194);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1311);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9189);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(697);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _src_contract_detail__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(929);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_packages_tabs__WEBPACK_IMPORTED_MODULE_1__, _packages_newTable__WEBPACK_IMPORTED_MODULE_2__, _contants_detail__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _store_server__WEBPACK_IMPORTED_MODULE_6__, _contants_varible__WEBPACK_IMPORTED_MODULE_8__, _src_contract_detail__WEBPACK_IMPORTED_MODULE_11__]);
([_packages_tabs__WEBPACK_IMPORTED_MODULE_1__, _packages_newTable__WEBPACK_IMPORTED_MODULE_2__, _contants_detail__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _store_server__WEBPACK_IMPORTED_MODULE_6__, _contants_varible__WEBPACK_IMPORTED_MODULE_8__, _src_contract_detail__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 












/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ account_id , ootions , verifyData  })=>{
    var _filscanStore_filscan, _filscanStore_filscan1;
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_9__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "detail"
            });
        }
        return t(label, {
            ns: "detail"
        });
    };
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)([]);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [methodValue, setMethod] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)([]);
    const [total, setTotal] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(0);
    // const [data, setData] = useState({
    //   total: 0,
    //   dataSource: [],
    // });
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({
        label: "message_list",
        value: "MessagesByAccountID",
        headerList: true
    });
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(1);
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        if (options) {
            const newOptios = options.map((v)=>{
                return {
                    ...v,
                    label: tr(v.key)
                };
            });
            setOptions(newOptios);
        }
    }, [
        filscanStore === null || filscanStore === void 0 ? void 0 : (_filscanStore_filscan = filscanStore.filscan) === null || _filscanStore_filscan === void 0 ? void 0 : _filscanStore_filscan.lang
    ]);
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        return _contants_detail__WEBPACK_IMPORTED_MODULE_3__/* .miner_list.columns */ .aV.columns(active.value).map((v)=>{
            const newObj = {
                ...v,
                title: tr(v.title)
            };
            return newObj;
        });
    }, [
        filscanStore === null || filscanStore === void 0 ? void 0 : (_filscanStore_filscan1 = filscanStore.filscan) === null || _filscanStore_filscan1 === void 0 ? void 0 : _filscanStore_filscan1.lang,
        active
    ]);
    const handleChange = (type, item)=>{
        if (type === "active") {
            setActive(item);
            setTotal(0);
            setMethod("");
            setData([]);
            setCurrent(1);
            if (!item.value.startsWith("verify")) {
                // if (item.value.startsWith('token')) {
                //   const [flag, url, address] = item.value.split('_');
                //   load(1, url,undefined,{address})
                // } else { 
                // }
                load(1, item.value);
            }
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        if (account_id) {
            setActive({
                label: "message_list",
                value: "MessagesByAccountID",
                headerList: true
            });
            (0,_store_server__WEBPACK_IMPORTED_MODULE_6__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_7__/* .apiUrl.detail_list_method */ .J.detail_list_method, {
                account_id
            }).then((res)=>{
                var _res_result;
                const opt = [];
                const newObj = (res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.method_name_list) || {};
                opt.push({
                    label: `${tr("message_list_all")}`,
                    value: "all",
                    key: "all"
                });
                Object.keys(newObj).forEach((key)=>{
                    opt.push({
                        label: `${tr(key)}`,
                        value: key,
                        key: key
                    });
                });
                setOptions(opt);
            });
            load(1, "MessagesByAccountID");
        }
    }, [
        account_id
    ]);
    const load = (cur, value, method, payload)=>{
        setLoading(true);
        const index = cur || current;
        const showValue = value || active.value;
        const linkUrl = _contants_apiUrl__WEBPACK_IMPORTED_MODULE_7__/* .apiUrl.detail_miner_list */ .J.detail_miner_list + "/" + showValue;
        const obj = active.headerList ? {
            method_name: method || methodValue
        } : {};
        (0,_store_server__WEBPACK_IMPORTED_MODULE_6__/* .postAxios */ .xW)(linkUrl, {
            account_id: account_id,
            filters: {
                index: index - 1,
                limit: _contants_varible__WEBPACK_IMPORTED_MODULE_8__/* .pageLimit */ .P5,
                ...obj
            },
            ...payload
        }).then((res)=>{
            const result = (res === null || res === void 0 ? void 0 : res.result) || {};
            setLoading(false);
            const result_key = _contants_detail__WEBPACK_IMPORTED_MODULE_3__/* .miner_list.resultObj */ .aV.resultObj(showValue);
            const data = result[result_key] || [];
            setTotal((result === null || result === void 0 ? void 0 : result.total_count) || (result === null || result === void 0 ? void 0 : result.total));
            setData(data);
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_list),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_list_tabs),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tabs__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        border: true,
                        data: ootions || _contants_detail__WEBPACK_IMPORTED_MODULE_3__/* .miner_list.title */ .aV.title,
                        ns: "detail",
                        defaultValue: active.value,
                        onChange: (value)=>handleChange("active", value)
                    }),
                    active.headerList && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_10__.Select, {
                        options: options,
                        defaultValue: "all",
                        className: "custom_select",
                        onChange: (value)=>{
                            setCurrent(1);
                            const showValue = value === "all" ? "" : value;
                            setMethod(showValue);
                            load(1, undefined, showValue);
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${(_style_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_list_main)} ${total > _contants_varible__WEBPACK_IMPORTED_MODULE_8__/* .pageLimit */ .P5 ? "" : (_style_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_list_mainTotal)}`,
                children: active.value.startsWith("verify") ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_contract_detail__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    verifyData: verifyData,
                    id: active.value.split("_")[1]
                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_list_header),
                            children: tr(`${active.label}_total`, {
                                value: total
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_newTable__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            dataSource: [
                                ...data
                            ],
                            total: total,
                            columns: columns,
                            current: current,
                            loading: loading,
                            // rowKey={(record: any) => `${active.value}_${new Date().getTime()}`}
                            onPage: (cur)=>{
                                setCurrent(cur);
                                load(cur);
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_list_main_looksAll),
                            onClick: ()=>{
                                window.open(`http://v1.filscan.io/tipset/address-detail?address=${account_id}`);
                            },
                            children: tr("look_all")
                        })
                    ]
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
exports.id = 9140;
exports.ids = [9140];
exports.modules = {

/***/ 6306:
/***/ ((module) => {

// Exports
module.exports = {
	"content": "tooltip_content__ouhoP",
	"content_text": "tooltip_content_text__HnUXp"
};


/***/ }),

/***/ 9140:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6306);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ text , id , className , title , children  })=>{
    const [isShow, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const contentRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const textRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (textRef) {
            const textWidth = textRef?.current?.offsetWidth || 0;
            const contentWidth = contentRef?.current?.offsetWidth || 0;
            if (textWidth > contentWidth) {
                setShow(true);
            }
        }
    }, [
        textRef.current,
        contentRef?.current
    ]);
    if (children) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
            overlayClassName: "custom-tooltip-wrap",
            title: title,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    " ",
                    children
                ]
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().content),
        ref: contentRef,
        children: isShow ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
            overlayClassName: "custom-tooltip-wrap",
            title: text,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().content_text)} ${className}`,
                id: id,
                ref: textRef,
                children: text
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().content_text)} ${className}`,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                ref: textRef,
                id: id,
                children: text
            })
        })
    });
});


/***/ })

};
;
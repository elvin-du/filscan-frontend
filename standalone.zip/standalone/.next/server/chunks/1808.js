exports.id = 1808;
exports.ids = [1808];
exports.modules = {

/***/ 2601:
/***/ ((module) => {

// Exports
module.exports = {
	"chain_card": "chain-card_chain_card__wdi0D",
	"chain_card_header": "chain-card_chain_card_header__3mY7e",
	"chain_card_header_item": "chain-card_chain_card_header_item__cPJut",
	"chain_card_content": "chain-card_chain_card_content__X5PqZ",
	"chain_card_content_item": "chain-card_chain_card_content_item___079Q"
};


/***/ }),

/***/ 6872:
/***/ ((module) => {

// Exports
module.exports = {
	"chain_chart": "chain_chain_chart__AX6S3",
	"chain_chart_leftIcon": "chain_chain_chart_leftIcon__HSkuZ",
	"chain_chart_rightIcon": "chain_chain_chart_rightIcon__QU6Oe",
	"chain_content": "chain_chain_content__gqCdL",
	"chain_content_loading": "chain_chain_content_loading__vZqih",
	"chain_content_pg": "chain_chain_content_pg__U4zRX"
};


/***/ }),

/***/ 1905:
/***/ ((module) => {

// Exports
module.exports = {
	"message_list": "style_message_list__E_P_2",
	"message_list_header": "style_message_list_header__6lzGf",
	"cid_detail_list": "style_cid_detail_list__IGQGR"
};


/***/ }),

/***/ 4993:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_tipset__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6801);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9927);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2601);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _packages_main__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8266);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_tipset__WEBPACK_IMPORTED_MODULE_1__, _utils_utils__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_3__, _packages_main__WEBPACK_IMPORTED_MODULE_4__]);
([_contants_tipset__WEBPACK_IMPORTED_MODULE_1__, _utils_utils__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_3__, _packages_main__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ data  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "tipset"
            });
        }
        return t(label, {
            ns: "tipset"
        });
    };
    if ((0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isMobile */ .tq)()) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_main__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            ns: "tipset",
            content: _contants_tipset__WEBPACK_IMPORTED_MODULE_1__/* .chain_columns */ .vG,
            data: data,
            warpClassName: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().mobile_chain_card_content)
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().chain_card),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().chain_card_header),
                children: _contants_tipset__WEBPACK_IMPORTED_MODULE_1__/* .chain_columns.map */ .vG.map((v, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().chain_card_header_item),
                        children: tr(v.title)
                    }, `header-${index}`);
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().chain_card_content),
                children: _contants_tipset__WEBPACK_IMPORTED_MODULE_1__/* .chain_columns.map */ .vG.map((v, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().chain_card_content_item)}`,
                        children: v.render ? v.render(data[v.dataIndex], data) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: data[v.dataIndex]
                        })
                    }, `${index}_${v.dataIndex}`);
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4950:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3775);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { context  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
        overlayClassName: "custom-tooltip-wrap",
        title: context,
        children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("tip")
    });
});


/***/ }),

/***/ 2306:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9189);
/* harmony import */ var _contants_tipset__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6801);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1905);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _packages_custom_card__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3625);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _packages_main__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8266);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1311);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _packages_newTable__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7692);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7987);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8194);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(697);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_tipset__WEBPACK_IMPORTED_MODULE_2__, _packages_custom_card__WEBPACK_IMPORTED_MODULE_3__, _packages_main__WEBPACK_IMPORTED_MODULE_5__, _store_server__WEBPACK_IMPORTED_MODULE_6__, _packages_newTable__WEBPACK_IMPORTED_MODULE_8__, react_i18next__WEBPACK_IMPORTED_MODULE_9__, _contants_varible__WEBPACK_IMPORTED_MODULE_11__]);
([_contants_tipset__WEBPACK_IMPORTED_MODULE_2__, _packages_custom_card__WEBPACK_IMPORTED_MODULE_3__, _packages_main__WEBPACK_IMPORTED_MODULE_5__, _store_server__WEBPACK_IMPORTED_MODULE_6__, _packages_newTable__WEBPACK_IMPORTED_MODULE_8__, react_i18next__WEBPACK_IMPORTED_MODULE_9__, _contants_varible__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ cid , onChange  })=>{
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_9__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "tipset"
            });
        }
        return t(label, {
            ns: "tipset"
        });
    };
    const [total, setTotal] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(0);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)([]);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(1);
    const [selectValue, setSelect] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("");
    const [detail, setDetail] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)([]);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false);
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        if (cid) {
            (0,_store_server__WEBPACK_IMPORTED_MODULE_6__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl.tipset_BlockDetails */ .J.tipset_BlockDetails, {
                block_cid: cid
            }).then((res)=>{
                if (onChange) onChange(res?.result?.block_details);
                setDetail(res?.result?.block_details);
            });
            (0,_store_server__WEBPACK_IMPORTED_MODULE_6__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl.tipset_block_message_opt */ .J.tipset_block_message_opt, {
                cid
            }).then((res)=>{
                const opt = [];
                const newObj = res?.result?.method_name_list || {};
                opt.push({
                    label: `${tr("message_list_all")}`,
                    value: "all",
                    key: "all"
                });
                Object.keys(newObj).forEach((key)=>{
                    opt.push({
                        label: `${tr(key)} (${newObj[key]})`,
                        value: key,
                        key: key
                    });
                });
                setOptions(opt);
            });
            loadMessage();
        }
    }, [
        cid
    ]);
    const loadMessage = (cur, method)=>{
        const showIndex = cur || current;
        const showMethod = method === "all" ? undefined : method || selectValue;
        setLoading(true);
        (0,_store_server__WEBPACK_IMPORTED_MODULE_6__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl.tipset_Block_meaages */ .J.tipset_Block_meaages, {
            filters: {
                index: showIndex - 1,
                limit: _contants_varible__WEBPACK_IMPORTED_MODULE_11__/* .pageLimit */ .P5,
                method_name: showMethod
            },
            block_cid: cid
        }).then((res)=>{
            setLoading(false);
            setData(res?.result?.message_list || []);
            setTotal(res?.result?.total_count);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        if (options) {
            const newOptios = options.map((v)=>{
                return {
                    ...v,
                    label: tr(v.key)
                };
            });
            setOptions(newOptios);
        }
    }, [
        filscanStore?.filscan?.lang
    ]);
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return _contants_tipset__WEBPACK_IMPORTED_MODULE_2__/* .chain_cid.columns.map */ .DF.columns.map((v)=>{
            const newObj = {
                ...v,
                title: tr(v.title)
            };
            return newObj;
        });
    }, [
        filscanStore?.filscan?.lang
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                title: _contants_tipset__WEBPACK_IMPORTED_MODULE_2__/* .chain_cid.title */ .DF.title,
                bgColor: true,
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_12___default().cid_detail),
                ns: "tipset",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_main__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    content: _contants_tipset__WEBPACK_IMPORTED_MODULE_2__/* .chain_cid.list */ .DF.list,
                    warpClassName: (_style_module_scss__WEBPACK_IMPORTED_MODULE_12___default().cid_detail_content),
                    data: detail,
                    ns: "tipset"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_12___default().cid_detail_list),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_list_header),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: tr(_contants_tipset__WEBPACK_IMPORTED_MODULE_2__/* .chain_cid.total */ .DF.total, {
                                    value: total
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_4__.Select, {
                                options: options,
                                defaultValue: "all",
                                className: "custom_select",
                                onChange: (value)=>{
                                    setCurrent(1);
                                    setSelect(value);
                                    loadMessage(1, value);
                                }
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_newTable__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        dataSource: data,
                        total: total,
                        rowKey: (record)=>`${record.cid}_${record.block_time}`,
                        columns: columns,
                        current: current,
                        loading: loading,
                        onPage: (cur)=>{
                            setCurrent(cur);
                            loadMessage(cur);
                        }
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
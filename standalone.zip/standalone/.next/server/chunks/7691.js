"use strict";
exports.id = 7691;
exports.ids = [7691];
exports.modules = {

/***/ 7691:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(697);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_varible__WEBPACK_IMPORTED_MODULE_2__]);
_contants_varible__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ dataSource , columns , current , onPage , className , onChange , loading , total =0 , rowKey  })=>{
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (loading) {
            setData([]);
        } else {
            setData(dataSource);
        }
    }, [
        dataSource,
        loading
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Table, {
        className: `custom-table custom-border-table ${className}`,
        dataSource: [
            ...data
        ],
        columns: columns,
        rowKey: rowKey,
        loading: loading,
        onChange: (pagination, filters, sorter)=>{
            if (onChange) onChange(pagination, filters, sorter);
        },
        pagination: total > _contants_varible__WEBPACK_IMPORTED_MODULE_2__/* .pageLimit */ .P5 ? {
            position: [
                "bottomCenter"
            ],
            current: current,
            showQuickJumper: true,
            pageSize: _contants_varible__WEBPACK_IMPORTED_MODULE_2__/* .pageLimit */ .P5,
            showSizeChanger: false,
            total,
            onChange: (cur)=>{
                if (onPage) {
                    onPage(cur);
                }
            }
        } : false
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
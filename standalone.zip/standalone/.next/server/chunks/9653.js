"use strict";
exports.id = 9653;
exports.ids = [9653];
exports.modules = {

/***/ 9653:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1311);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9189);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(697);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9927);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7987);
/* harmony import */ var _contants_statistic__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8031);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8194);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2533);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7003);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6113);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_server__WEBPACK_IMPORTED_MODULE_2__, _contants_varible__WEBPACK_IMPORTED_MODULE_4__, _utils_utils__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_6__, _contants_statistic__WEBPACK_IMPORTED_MODULE_7__, _components_echarts__WEBPACK_IMPORTED_MODULE_9__, _Header__WEBPACK_IMPORTED_MODULE_10__]);
([_store_server__WEBPACK_IMPORTED_MODULE_2__, _contants_varible__WEBPACK_IMPORTED_MODULE_4__, _utils_utils__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_6__, _contants_statistic__WEBPACK_IMPORTED_MODULE_7__, _components_echarts__WEBPACK_IMPORTED_MODULE_9__, _Header__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 











function Trend(props) {
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z);
    const { headerData , type  } = props;
    const showData = _contants_statistic__WEBPACK_IMPORTED_MODULE_7__/* .statistics */ .hd[type];
    const { title  } = headerData || showData;
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("1m");
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "static"
        });
    };
    const color = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return (0,_contants_varible__WEBPACK_IMPORTED_MODULE_4__/* .getColor */ .Lq)(filscanStore.filscan.theme);
    }, [
        filscanStore.filscan.theme
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return {
            ...(0,_contants_varible__WEBPACK_IMPORTED_MODULE_4__/* .defaultOpt */ .Re)("line", filscanStore.filscan.theme),
            yAxis: [
                {
                    type: "value",
                    position: "left",
                    scale: true,
                    nameTextStyle: {
                        color: color.textStyle
                    },
                    axisLabel: {
                        formatter: "{value} EiB",
                        textStyle: {
                            color: color.textStyle
                        }
                    },
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        show: false,
                        lineStyle: {
                            type: "dashed",
                            color: color.splitLine
                        }
                    }
                },
                {
                    type: "value",
                    position: "right",
                    scale: true,
                    nameTextStyle: {
                        color: color.textStyle
                    },
                    axisLabel: {
                        formatter: "{value} PiB",
                        textStyle: {
                            //  fontSize: this.fontSize,
                            color: color.textStyle
                        }
                    },
                    axisTick: {
                        show: false
                    },
                    axisLine: {
                        show: false
                    },
                    splitLine: {
                        lineStyle: {
                            type: "dashed",
                            color: color.splitLine
                        }
                    }
                }
            ],
            tooltip: {
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].name;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + item.seriesName + ": " + item.data.amount + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    }, [
        filscanStore.filscan.theme
    ]);
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const load = (interval)=>{
        const dateList = [];
        const legendList = [];
        const seriesObj = {
            total_quality_adj_power: [],
            base_line_power: [],
            total_raw_byte_power: [],
            change_quality_adj_power: []
        };
        const newOpt = {
            ...defaultOptions
        };
        (0,_store_server__WEBPACK_IMPORTED_MODULE_2__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl.line_trend */ .J.line_trend, {
            interval: interval
        }).then((res)=>{
            var _res_result, _res_result_list;
            res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : (_res_result_list = _res_result.list) === null || _res_result_list === void 0 ? void 0 : _res_result_list.reverse().forEach((value)=>{
                var _unitConversion, _unitConversion1, _unitConversion2, _unitConversion3;
                const { timestamp , base_line_power , total_raw_byte_power , total_quality_adj_power , change_quality_adj_power  } = value;
                const showTime = timestamp.split("-")[1] + "." + timestamp.split("-")[2].split(" ")[0];
                dateList.push(showTime);
                //amount
                const [total_raw_byte_power_amount, total_raw_byte_power_unit] = total_raw_byte_power && ((_unitConversion = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .unitConversion */ .dN)(total_raw_byte_power, 2)) === null || _unitConversion === void 0 ? void 0 : _unitConversion.split(" "));
                const [base_line_power_amount, base_line_power_unit] = base_line_power && ((_unitConversion1 = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .unitConversion */ .dN)(base_line_power, 2)) === null || _unitConversion1 === void 0 ? void 0 : _unitConversion1.split(" "));
                const [total_quality_adj_power_amount, total_quality_adj_power_unit] = total_quality_adj_power && ((_unitConversion2 = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .unitConversion */ .dN)(total_quality_adj_power, 2)) === null || _unitConversion2 === void 0 ? void 0 : _unitConversion2.split(" "));
                const [change_quality_adj_power_amount, change_quality_adj_power_unit] = change_quality_adj_power && ((_unitConversion3 = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .unitConversion */ .dN)(change_quality_adj_power, 2)) === null || _unitConversion3 === void 0 ? void 0 : _unitConversion3.split(" "));
                seriesObj.total_raw_byte_power.push({
                    amount: total_raw_byte_power_amount,
                    value: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .unitConversion */ .dN)(total_raw_byte_power, 2, 6).split(" ")[0],
                    unit: total_raw_byte_power_unit
                });
                seriesObj.base_line_power.push({
                    amount: base_line_power_amount,
                    value: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .unitConversion */ .dN)(base_line_power, 2, 6).split(" ")[0],
                    unit: base_line_power_unit
                });
                seriesObj.total_quality_adj_power.push({
                    amount: total_quality_adj_power_amount,
                    value: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .unitConversion */ .dN)(total_quality_adj_power, 2, 6).split(" ")[0],
                    unit: total_quality_adj_power_unit
                });
                seriesObj.change_quality_adj_power.push({
                    amount: change_quality_adj_power_amount,
                    value: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .unitConversion */ .dN)(change_quality_adj_power, 2, 5).split(" ")[0],
                    unit: change_quality_adj_power_unit
                });
            });
            newOpt.xAxis.data = dateList;
            newOpt.series = [];
            showData.list.forEach((item)=>{
                legendList.push(tr(item.label));
                newOpt.series.push({
                    type: item.type,
                    data: seriesObj[item.label],
                    name: tr(item.label),
                    yAxisIndex: item.yIndex,
                    symbol: "circle",
                    smooth: true,
                    barMaxWidth: "30"
                });
            });
            newOpt.legend.data = legendList;
            setOptions({
                ...newOpt
            });
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (headerData) {
            load("1m");
        } else {
            load(interval);
        }
    }, [
        filscanStore.filscan,
        headerData
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().statis)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().statis_trend)} default-card`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                title: title,
                defaultValue: interval,
                onChange: (item)=>{
                    setInterval(item.value);
                    load(item.value);
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                propsOption: {
                    ...options
                },
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().statis_chart)
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Trend);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
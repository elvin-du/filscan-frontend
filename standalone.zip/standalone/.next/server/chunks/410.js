exports.id = 410;
exports.ids = [410];
exports.modules = {

/***/ 6850:
/***/ ((module) => {

// Exports
module.exports = {
	"rank": "rank_rank__W3mwH",
	"rank_contain": "rank_rank_contain__Xq_I9",
	"rank_header": "rank_rank_header__4EjBP",
	"rank_header_Item": "rank_rank_header_Item__1HSPG",
	"rank_header_Item_tabs": "rank_rank_header_Item_tabs__aMuWO",
	"rank_header_right": "rank_rank_header_right__P24df",
	"rank_header_time": "rank_rank_header_time__9cD1H",
	"rank_footer": "rank_rank_footer__ZiUM8",
	"rank_html": "rank_rank_html__V5Ysz"
};


/***/ }),

/***/ 5108:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ku": () => (/* binding */ select_rank),
/* harmony export */   "Pu": () => (/* binding */ getColumns),
/* harmony export */   "Uc": () => (/* binding */ header_right),
/* harmony export */   "r0": () => (/* binding */ rank_header)
/* harmony export */ });
/* unused harmony exports resultObj, TimeList */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9927);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5063);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_images_champion_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2577);
/* harmony import */ var _assets_images_runnerup_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6131);
/* harmony import */ var _assets_images_thirdrunner_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5694);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_utils__WEBPACK_IMPORTED_MODULE_1__]);
_utils_utils__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 







const rank_header = [
    {
        label: "provider",
        value: "provider"
    },
    {
        label: "pool",
        value: "pool"
    },
    {
        label: "growth",
        value: "growth"
    },
    {
        label: "rewards",
        value: "rewards"
    }
];
const getColumns = (type, progress)=>{
    const fristObj = {
        title: "ranking",
        dataIndex: "rank",
        width: "120px",
        align: "center",
        render: (text)=>{
            if (text === 1) {
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                    src: _assets_images_champion_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                    alt: "",
                    width: 22
                });
            } else if (text === 2) {
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                    src: _assets_images_runnerup_png__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                    alt: "",
                    width: 22
                });
            } else if (text === 3) {
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                    src: _assets_images_thirdrunner_png__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                    alt: "",
                    width: 22
                });
            }
            return text;
        }
    };
    let list = [];
    switch(type){
        case "pool":
            list = [
                {
                    title: "pool_owner",
                    dataIndex: "owner_id",
                    align: "center",
                    render: (text)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: `/owner/${text}`,
                            className: "table_link",
                            children: text
                        });
                    }
                },
                {
                    title: "pool_power",
                    dataIndex: "quality_adj_power",
                    align: "center",
                    sorter: true,
                    render: (text)=>{
                        const left = Number(text) / Number(progress) * 100 + "%";
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "other_progress",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "progress",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "mask",
                                        style: {
                                            left
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2)
                                })
                            ]
                        });
                    }
                },
                {
                    title: "pool_efficiency_24h",
                    dataIndex: "rewards_ratio_24h",
                    sorter: true,
                    align: "center",
                    render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL/TiB"
                },
                {
                    title: "pool_increase_24h",
                    dataIndex: "power_change_24h",
                    sorter: true,
                    align: "center",
                    render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 4)
                },
                {
                    title: "pool_block_count_24h",
                    dataIndex: "blocks",
                    align: "center",
                    render: (text)=>Number(text)
                }
            ];
            break;
        case "provider":
            list = [
                {
                    title: "provider_miner",
                    dataIndex: "miner_id",
                    align: "center",
                    render: (text)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: `/miner/${text}`,
                            prefetch: true,
                            className: "table_link",
                            children: text
                        });
                    }
                },
                // {
                //   title: "miner", //节点号
                //   dataIndex: "miner",
                // },
                {
                    title: "provider_power_ratio",
                    dataIndex: "quality_power_ratio",
                    rowKey: "quality_adj_power",
                    render: (text, record)=>{
                        const text1 = record.quality_adj_power;
                        const left = Number(text1) / Number(progress) * 100 + "%";
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "other_progress",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "progress",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "mask",
                                        style: {
                                            left
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: `${(0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text1, 2)} / ${(Number(text) * 100).toFixed(2)}%`
                                })
                            ]
                        });
                    }
                },
                {
                    title: "pool_increase_24h",
                    dataIndex: "power_increase_24h",
                    render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 4)
                },
                {
                    title: "provider_block_ratio",
                    dataIndex: "block_ratio",
                    rowKey: "block_count",
                    render: (text, record)=>{
                        const text1 = record.block_count;
                        return `${text1} / ${(Number(text) * 100).toFixed(2)}%`;
                    }
                },
                {
                    title: "provider_rewards_ratio",
                    dataIndex: "rewards_ratio",
                    rowKey: "rewards",
                    render: (text, record)=>{
                        const text1 = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(record.rewards, "FIL", 2) + "FIL";
                        return `${text1} / ${(Number(text) * 100).toFixed(2)}%`;
                    }
                },
                {
                    title: "balance",
                    dataIndex: "balance",
                    render: (text)=>{
                        const showText = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(text, "FIL", 2);
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: showText < 200 ? "warning text-center" : "text-center",
                            children: showText < 200 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_4__.Popover, {
                                trigger: "hover",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    slot: "reference",
                                    className: "pointer",
                                    children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(showText) + " FIL" || 0
                                })
                            }) : (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(showText) + " FIL" || 0
                        });
                    }
                }
            ];
            break;
        case "growth":
            list = [
                {
                    title: "miner",
                    dataIndex: "miner_id",
                    render: (text)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: `/miner/${text}`,
                            className: "table_link",
                            children: text
                        });
                    }
                },
                {
                    title: "power_ratio",
                    title_tip: "power_ratio_tip",
                    dataIndex: "power_ratio",
                    render: (text, record)=>{
                        const text1 = record.power_ratio;
                        const left = Number(text1) / Number(progress) * 100 + "%";
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "other_progress",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "progress",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "mask",
                                        style: {
                                            left
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: `${(0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2)} / D`
                                })
                            ]
                        });
                    }
                },
                {
                    title: "quality_power_increase",
                    title_tip: "quality_power_increase_tip",
                    align: "center",
                    dataIndex: "quality_power_increase",
                    render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2)
                },
                {
                    title: "quality_adj_power",
                    dataIndex: "quality_adj_power",
                    render: (text)=>{
                        const num = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2);
                        return num;
                    }
                },
                {
                    title: "raw_power",
                    dataIndex: "raw_power",
                    render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2)
                },
                {
                    title: "sector_size",
                    dataIndex: "sector_size"
                }
            ];
            break;
        case "rewards":
            list = [
                {
                    title: "miner",
                    dataIndex: "miner_id",
                    render: (text)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: `/miner/${text}`,
                            className: "table_link",
                            children: text
                        });
                    }
                },
                {
                    title: "rewards/ratio",
                    dataIndex: "rewards",
                    title_tip: "rewards/ratio_tip",
                    sorter: true,
                    align: "center",
                    render: (text, record)=>{
                        const showNum = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(text, "FIL");
                        const ratio = Number(record.rewards_ratio * 100).toFixed(2) + "%";
                        return `${showNum}/${ratio}`;
                    }
                },
                {
                    title: "block_count",
                    dataIndex: "block_count",
                    align: "center",
                    title_tip: "block_count_tip",
                    sorter: true
                },
                {
                    title: "winning_rate",
                    dataIndex: "winning_rate",
                    render: (text)=>Number(text * 100).toFixed(2) + "%" //
                },
                {
                    title: "quality_adj_power",
                    dataIndex: "quality_adj_power",
                    render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2)
                },
                {
                    title: "sector_size",
                    dataIndex: "sector_size"
                }
            ];
            break;
    }
    list.unshift(fristObj);
    return list;
};
const resultObj = (type)=>{
    switch(type){
        case "pool":
            return "ore_pool_rank_list";
        case "provider":
            return "miner_rank_list";
        default:
            return "miner_profit_rank_list";
    }
};
const TimeList = [
    {
        label: "24h",
        value: "24h"
    },
    {
        label: "week_days",
        value: "7d"
    }
];
const select_rank = [
    {
        label: "select_rank_all",
        value: "all"
    },
    {
        label: "select_rank_32",
        value: "32 GiB"
    },
    {
        label: "select_rank_64",
        value: "64 GiB"
    }
];
const header_right = {
    growth: {
        TimeList,
        select_rank
    },
    rewards: {
        TimeList,
        select_rank
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8933:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_rank__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5108);
/* harmony import */ var _packages_tabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5943);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6850);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9927);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_rank__WEBPACK_IMPORTED_MODULE_1__, _packages_tabs__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_3__, _utils_utils__WEBPACK_IMPORTED_MODULE_5__]);
([_contants_rank__WEBPACK_IMPORTED_MODULE_1__, _packages_tabs__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_3__, _utils_utils__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "rank"
        });
    };
    const { onChange , active , other , time  } = props;
    const handleChange = (type, item)=>{
        onChange(type, item);
    };
    const { TimeList  } = _contants_rank__WEBPACK_IMPORTED_MODULE_1__/* .header_right */ .Uc[active] || {};
    const options = _contants_rank__WEBPACK_IMPORTED_MODULE_1__/* .select_rank.map */ .Ku.map((v)=>{
        return {
            ...v,
            label: tr(v.label)
        };
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().rank_header)}`,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().rank_header_Item)}`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tabs__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().rank_header_Item_tabs)}`,
                        data: _contants_rank__WEBPACK_IMPORTED_MODULE_1__/* .rank_header */ .r0,
                        ns: "rank",
                        defaultValue: active,
                        onChange: (value)=>handleChange("active", value)
                    }),
                    time && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().rank_header_time),
                        children: [
                            tr("rank_time"),
                            ": ",
                            (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(time, "YYYY-MM-DD HH:mm")
                        ]
                    })
                ]
            }),
            TimeList && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().rank_header_right),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tabs__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        data: TimeList,
                        ns: "rank",
                        defaultValue: other.interval,
                        border: true,
                        onChange: (value)=>handleChange("interval", value.value)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_4__.Select, {
                        className: "custom_select w-120",
                        options: options,
                        value: other.sector_size,
                        onChange: (value)=>{
                            handleChange("sector_size", value);
                        }
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 410:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8933);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6850);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9189);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1311);
/* harmony import */ var _contants_rank__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5108);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(697);
/* harmony import */ var _packages_newTable__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7692);
/* harmony import */ var _packages_tips__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4950);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8194);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5063);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Header__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_2__, _store_server__WEBPACK_IMPORTED_MODULE_5__, _contants_rank__WEBPACK_IMPORTED_MODULE_6__, _contants_varible__WEBPACK_IMPORTED_MODULE_7__, _packages_newTable__WEBPACK_IMPORTED_MODULE_8__]);
([_Header__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_2__, _store_server__WEBPACK_IMPORTED_MODULE_5__, _contants_rank__WEBPACK_IMPORTED_MODULE_6__, _contants_varible__WEBPACK_IMPORTED_MODULE_7__, _packages_newTable__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 














function Rank(params) {
    var _useRouter, _filscanStore_filscan;
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z);
    const { type  } = params;
    const asPath = (_useRouter = (0,next_router__WEBPACK_IMPORTED_MODULE_13__.useRouter)()) === null || _useRouter === void 0 ? void 0 : _useRouter.asPath;
    const pathActive = asPath.split("=")[1];
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "rank"
        });
    };
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(pathActive || "provider");
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const [time, setTime] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(1);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [total, setTotal] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const [order, setOrder] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [progress, setProgress] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [other, setOther] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        interval: "24h",
        sector_size: "all"
    });
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return (0,_contants_rank__WEBPACK_IMPORTED_MODULE_6__/* .getColumns */ .Pu)(active, progress).map((item)=>{
            if (item.title_tip) {
                return {
                    ...item,
                    align: "left",
                    title: ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                tr(item.title),
                                " ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tips__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    context: tr(item.title_tip)
                                })
                            ]
                        })
                };
            }
            return {
                ...item,
                align: "left",
                title: tr(item.title)
            };
        });
    }, [
        active,
        progress,
        filscanStore === null || filscanStore === void 0 ? void 0 : (_filscanStore_filscan = filscanStore.filscan) === null || _filscanStore_filscan === void 0 ? void 0 : _filscanStore_filscan.lang
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        load();
    }, []);
    const handleChange = (type, item)=>{
        if (type === "active") {
            const others = {
                interval: "24h",
                sector_size: "all"
            };
            setData([]);
            setActive(item.value);
            setCurrent(1);
            setTotal(0);
            setOther(others);
            setOrder(undefined);
            load(item.value, 1, others, {});
        } else {
            setOther({
                ...other,
                [type]: item
            });
            load(undefined, undefined, {
                ...other,
                [type]: item
            });
        }
    };
    const load = (value, cur, others, orderF)=>{
        setLoading(true);
        const showValue = value || active;
        const linkUrl = `rank_${showValue}`;
        const page = cur || current;
        const newOth = others || other;
        const orders = orderF || order;
        let config = {
            index: page - 1,
            limit: _contants_varible__WEBPACK_IMPORTED_MODULE_7__/* .pageLimit */ .P5,
            order: orders && Object.keys(orders).length > 0 ? {
                ...orders
            } : undefined
        };
        if (_contants_rank__WEBPACK_IMPORTED_MODULE_6__/* .header_right */ .Uc[showValue]) {
            config = {
                ...config,
                ...newOth,
                sector_size: newOth.sector_size === "all" ? null : newOth.sector_size
            };
        }
        (0,_store_server__WEBPACK_IMPORTED_MODULE_5__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_4__/* .apiUrl */ .J[linkUrl], config).then((res)=>{
            setLoading(false);
            const result = (res === null || res === void 0 ? void 0 : res.result) || {};
            setTotal(result.total);
            setTime(result.updated_at);
            const data = result.items || [];
            const show = !order || order && Object.keys(order).length === 0;
            if (page === 1 && show) {
                var _data_, _data_1;
                setProgress(showValue === "growth" ? (_data_ = data[0]) === null || _data_ === void 0 ? void 0 : _data_.power_ratio : ((_data_1 = data[0]) === null || _data_1 === void 0 ? void 0 : _data_1.quality_adj_power) || 0);
            }
            setData(data);
        });
    };
    const handleTableChange = (pagination, filters, sorter)=>{
        if (sorter && sorter.order) {
            //排序
            setOrder({
                field: sorter.field,
                sort: sorter.order === "ascend" ? "asc" : "desc"
            });
            setCurrent(1);
            load(undefined, 1, undefined, {
                field: sorter.field,
                sort: sorter.order === "ascend" ? "asc" : "desc"
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().rank)} ${type ? "" : (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().rank_html)}`,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().rank_contain),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        active: active,
                        time: time,
                        onChange: handleChange,
                        other: other
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_newTable__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        className: "rank_table",
                        columns: columns,
                        total: type ? 0 : total,
                        loading: loading,
                        dataSource: [
                            ...data
                        ],
                        current: current,
                        rowKey: (record)=>`${record.rank}_${active}`,
                        onChange: handleTableChange,
                        onPage: (cur)=>{
                            setCurrent(cur);
                            load(active, cur);
                        }
                    })
                ]
            }),
            type && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().rank_footer),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_12___default()), {
                        href: `/rank?active=${active}`,
                        children: tr("more")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_10__.RightOutlined, {
                        rev: undefined
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Rank);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
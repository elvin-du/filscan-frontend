"use strict";
exports.id = 5634;
exports.ids = [5634];
exports.modules = {

/***/ 45634:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AX: () => (/* binding */ time_options),
/* harmony export */   DO: () => (/* binding */ liquidity_chart),
/* harmony export */   En: () => (/* binding */ related_options),
/* harmony export */   F1: () => (/* binding */ fil_list),
/* harmony export */   FG: () => (/* binding */ token_list),
/* harmony export */   Sc: () => (/* binding */ related_list),
/* harmony export */   Vj: () => (/* binding */ releaseList),
/* harmony export */   ZI: () => (/* binding */ fund_card),
/* harmony export */   _Q: () => (/* binding */ tabList_chart),
/* harmony export */   bW: () => (/* binding */ kline_options),
/* harmony export */   q2: () => (/* binding */ overviewList),
/* harmony export */   sO: () => (/* binding */ liquidity),
/* harmony export */   uE: () => (/* binding */ fund_list),
/* harmony export */   xL: () => (/* binding */ fil_trend),
/* harmony export */   yN: () => (/* binding */ activeList)
/* harmony export */ });
/* unused harmony exports balance_options, rank_options, level_options */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23495);
/* harmony import */ var _assets_images_member_vip_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62539);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(25174);
/* harmony import */ var antd_lib_progress__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(76429);
/* harmony import */ var antd_lib_progress__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd_lib_progress__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_1__]);
_utils__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const tabList_chart = [
    {
        title: "trend_chart",
        dataIndex: "trend_chart"
    },
    {
        title: "k_chart",
        dataIndex: "k_chart"
    }
];
const time_options = [
    {
        title: "30d",
        dataIndex: "30d"
    }
];
const overviewList = [
    [
        {
            title: "market_value",
            dataIndex: "circulating",
            tip: "market_value_tip",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get$Number */ .Uy)(text)
        },
        {
            title: "circulation",
            dataIndex: "circulating_amount",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text)
        },
        {
            title: "proportion",
            dataIndex: "circulating_rate",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 2) + "%"
        },
        {
            title: "supply",
            dataIndex: "max_supply",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text)
        },
        {
            title: "market_total",
            dataIndex: "vol",
            tip: "market_total_tip",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get$Number */ .Uy)(text)
        }
    ],
    [
        {
            title: "locked",
            dataIndex: "locked",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text)
        },
        {
            title: "locked_ratio",
            dataIndex: "locked_rate",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 2) + "%"
        },
        {
            title: "burn",
            dataIndex: "burn",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text)
        },
        {
            title: "burn_ratio",
            dataIndex: "burn_rate",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 2) + "%"
        },
        {
            title: "24_quantity",
            dataIndex: "changed_vol",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get$Number */ .Uy)(text)
        }
    ],
    [
        {
            title: "24_amount",
            dataIndex: "changed_amount",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get$Number */ .Uy)(text)
        },
        {
            title: "turnover_rate",
            dataIndex: "change_rate",
            tip: "turnover_rate_tip",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text * 100, 2) + "%"
        }
    ]
];
const kline_options = [
    {
        title: "period_1",
        value: "1"
    },
    {
        title: "period_5",
        value: "5"
    },
    {
        title: "period_30",
        value: "30"
    },
    {
        title: "period_60",
        value: "60"
    },
    {
        title: "period_240",
        value: "240"
    },
    {
        title: "period_1440",
        value: "1440"
    },
    {
        title: "period_10080",
        value: "10080",
        select: true
    },
    {
        title: "period_43200",
        value: "43200",
        select: true
    }
];
const fil_list = [
    {
        title: "change_day",
        dataIndex: "change_day",
        value: "d"
    },
    {
        title: "change_week",
        dataIndex: "change_week",
        value: "w"
    },
    {
        title: "change_month",
        dataIndex: "change_month",
        value: "m"
    },
    {
        title: "change_threemonth",
        dataIndex: "change_threemonth",
        value: "3m"
    },
    {
        title: "change_sixmonth",
        dataIndex: "change_sixmonth",
        value: "6m"
    },
    {
        title: "change_year",
        dataIndex: "change_year",
        value: "y"
    },
    {
        title: "change_thisyear",
        dataIndex: "change_thisyear",
        value: "ytd"
    },
    {
        title: "change_ico",
        dataIndex: "change_ico",
        value: "all"
    }
];
const fil_trend = [
    {
        title: "usd_price",
        dataIndex: "usd",
        color: "rgba(36, 166, 66, 1)",
        type: "line",
        name: "usd_price"
    },
    {
        title: "btc_price",
        dataIndex: "btc",
        color: "rgba(239, 127, 26, 1)",
        type: "line",
        name: "btc_price",
        yIndex: 1
    },
    {
        title: "market_price",
        dataIndex: "market",
        name: "market_price",
        type: "line",
        color: "rgba(28, 106, 253, 1)"
    },
    {
        title: "volume",
        name: "volume",
        dataIndex: "volume",
        color: "#B0CBFE",
        type: "bar",
        gridIndex: 1,
        xIndex: 1,
        yIndex: 2
    }
];
const liquidity = {
    left: [
        {
            title: "provider_rewards_24",
            dataIndex: "mined"
        },
        {
            title: "lockup_freed_24",
            dataIndex: "vested",
            tip: "lockup_freed_tip"
        },
        {
            title: "reserved_freed_24",
            dataIndex: "reserved"
        }
    ],
    right_main: {
        title: "liquidity_pledge_24",
        dataIndex: "pledge"
    },
    right: [
        {
            title: "sector_pledge_24",
            dataIndex: "pledge"
        },
        {
            title: "defi_staking_24",
            dataIndex: "defi_tvl"
        }
    ]
};
const liquidity_chart = [
    {
        type: "line",
        dataIndex: "circulating",
        title: "liquidity_total",
        color: "rgba(255, 197, 61, 1)"
    },
    {
        type: "line",
        dataIndex: "produced",
        title: "liquidity_freed",
        color: "rgba(74, 202, 180, 1)"
    },
    {
        type: "line",
        dataIndex: "locked",
        title: "liquidity_pledge",
        color: "rgba(28, 106, 253, 1)"
    },
    {
        type: "line",
        dataIndex: "burn",
        title: "liquidity_destruction",
        color: "rgba(176, 203, 254, 1)"
    }
];
const releaseList = (tr)=>[
        {
            title: "account",
            dataIndex: "account_id",
            render: (text, record)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                            href: `/address/${text}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text)
                            })
                        }),
                        record?.account_tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "account_tag",
                            children: record?.account_tag
                        })
                    ]
                });
            }
        },
        {
            title: "total_lockup",
            dataIndex: "initial_balance",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(Number(text), 0)
        },
        {
            title: "released",
            dataIndex: "released",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(Number(text), 0)
        },
        {
            title: "daily_release",
            dataIndex: "daily_release",
            render: (text, record)=>{
                if (!record.initial_balance) return "--";
                const number = record.initial_balance / ((record.unlock_end_time - record.unlock_start_time) / 86400);
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(number, 0)
                });
            }
        },
        {
            title: "release_cycle",
            dataIndex: "release_cycle",
            render: (text, record)=>{
                if (!record.initial_balance) return "--";
                const number = record.released / record.initial_balance * 100;
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_progress__WEBPACK_IMPORTED_MODULE_4___default()), {
                            percent: number,
                            size: "small",
                            showInfo: false
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-xs",
                            children: tr("release_cycle_detail", {
                                value: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(number, 2),
                                date: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(record.unlock_end_time, "YYYY-MM-DD")
                            })
                        })
                    ]
                });
            }
        },
        {
            title: "account_balance",
            dataIndex: "balance",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(Number(text), 0)
        },
        {
            title: "balance_change_7",
            dataIndex: "balance_changed"
        },
        {
            title: "fund_penetration",
            dataIndex: "",
            render: (text, record)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                    href: `/analysis/fund/${record.account_id}`,
                    className: "link",
                    children: tr("go_fund")
                });
            }
        }
    ];
const activeList = [
    {
        title: "rank",
        dataIndex: "rank",
        width: "10%",
        render: (text, record, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "rank_icon",
                children: index + 1
            })
    },
    {
        title: "account",
        dataIndex: "address",
        width: "20%"
    },
    {
        title: "quantity",
        dataIndex: "quantity",
        width: "30%",
        render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text)
    },
    {
        title: "percentage",
        dataIndex: "percentage",
        width: "20%",
        render: (text)=>text + "%"
    },
    {
        title: "change_7d",
        dataIndex: "change",
        width: "30%",
        render: (text)=>{
            if (Number(text) === 0) return text;
            if (!text) return "--";
            const className = Number(text) > 0 ? "text_green" : "text_red";
            const flag = Number(text) > 0 ? "+" : "";
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: className,
                children: [
                    flag,
                    (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text)
                ]
            });
        }
    }
];
//token
const token_list = [
    {
        title: "token_top_10",
        dataIndex: "top10rate",
        color: "#FFC53D"
    },
    {
        title: "token_top_20",
        dataIndex: "top20rate",
        color: "#4ACAB4"
    },
    {
        title: "token_top_50",
        dataIndex: "top50rate",
        color: "#1C6AFD"
    },
    {
        title: "token_top_100",
        dataIndex: "top100rate",
        color: "#B0CBFE"
    }
];
//资金穿透
const balance_options = [
    {
        title: "7d",
        dataIndex: "7d"
    },
    {
        title: "30d",
        dataIndex: "30d",
        disabled: true,
        sufIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_vip_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            width: 16
        })
    },
    {
        title: "1year",
        dataIndex: "1year",
        disabled: true,
        sufIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_vip_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            width: 16
        })
    }
];
const fund_list = [
    {
        title: "check_account",
        dataIndex: "address",
        render: (text, record)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        text: text
                    }),
                    record?.tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "account_tag",
                        children: record?.tag
                    })
                ]
            });
        }
    },
    {
        title: "network_rank",
        dataIndex: "rank",
        render: (text)=>{
            if (Number(text) === -1) {
                return "1000+";
            }
            return text;
        }
    },
    {
        title: "account_balance",
        dataIndex: "balance",
        render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(text) + " FIL"
    },
    {
        title: "position_ratio",
        dataIndex: "proportion",
        render: (text)=>{
            if (Number(text) < 0.0001) {
                return "<0.01%";
            }
            return Number((0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .truncateDecimalAfterZeros */ .$h)(Number(text))) * 100 + "%";
        }
    },
    {
        title: "balance_change",
        dataIndex: "balance_increase",
        options: balance_options,
        defaultValue: "7d"
    }
];
const related_options = [
    {
        title: "fund_volume",
        dataIndex: "transaction_volume"
    },
    {
        title: "fund_number",
        dataIndex: "transaction_count"
    }
];
const rank_options = [
    {
        title: "rank_3",
        dataIndex: "rank_3"
    },
    {
        title: "rank_5",
        dataIndex: "rank_5",
        disabled: true,
        sufIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_vip_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            width: 16
        })
    },
    {
        title: "rank_10",
        dataIndex: "rank_10",
        disabled: true,
        sufIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_vip_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            width: 16
        })
    }
];
const level_options = [
    {
        title: "level_3",
        dataIndex: "level_3"
    },
    {
        title: "level_5",
        dataIndex: "level_5",
        disabled: true,
        sufIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_vip_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            width: 16
        })
    },
    {
        title: "level_all",
        dataIndex: "level_all",
        disabled: true,
        sufIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_vip_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            width: 16
        })
    }
];
const related_list = [
    {
        title: "rank",
        dataIndex: "rank",
        options: rank_options,
        defaultValue: "rank_3"
    },
    {
        title: "level",
        dataIndex: "level",
        options: level_options,
        defaultValue: "level_3"
    }
];
const fund_card = (type)=>{
    const list = [
        {
            title: "select_account",
            dataIndex: "address",
            render: (text, record)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text)
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            text: text
                        }),
                        record.tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "account_tag ml-2",
                            children: record.tag || ""
                        })
                    ]
                });
            }
        },
        {
            title: "account_balance",
            dataIndex: "balance",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)((0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(text)) + " FIL"
        },
        {
            title: "position_ratio",
            dataIndex: "proportion",
            render: (text)=>{
                if (Number(text) < 0.0001) {
                    return "<0.01%";
                }
                return Number((0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .truncateDecimalAfterZeros */ .$h)(Number(text))) * 100 + "%";
            }
        }
    ];
    if (type === "volume") {
        list.push({
            title: "total_volume",
            dataIndex: "total_transaction_value",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)((0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(text)) + " FIL"
        });
    } else {
        list.push({
            title: "total_number",
            dataIndex: "total_transaction_Count"
        });
    }
    return list;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
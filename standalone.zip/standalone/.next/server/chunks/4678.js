"use strict";
exports.id = 4678;
exports.ids = [4678];
exports.modules = {

/***/ 4678:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1311);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9189);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(697);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9927);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7987);
/* harmony import */ var _contants_statistic__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8031);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8194);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2533);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7003);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6113);
/* harmony import */ var _Gas_24__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6427);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9766);
/* harmony import */ var _packages_custom_card__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3625);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_server__WEBPACK_IMPORTED_MODULE_2__, _contants_varible__WEBPACK_IMPORTED_MODULE_4__, _utils_utils__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_6__, _contants_statistic__WEBPACK_IMPORTED_MODULE_7__, _components_echarts__WEBPACK_IMPORTED_MODULE_9__, _Header__WEBPACK_IMPORTED_MODULE_10__, _Gas_24__WEBPACK_IMPORTED_MODULE_11__, bignumber_js__WEBPACK_IMPORTED_MODULE_12__, _packages_custom_card__WEBPACK_IMPORTED_MODULE_13__]);
([_store_server__WEBPACK_IMPORTED_MODULE_2__, _contants_varible__WEBPACK_IMPORTED_MODULE_4__, _utils_utils__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_6__, _contants_statistic__WEBPACK_IMPORTED_MODULE_7__, _components_echarts__WEBPACK_IMPORTED_MODULE_9__, _Header__WEBPACK_IMPORTED_MODULE_10__, _Gas_24__WEBPACK_IMPORTED_MODULE_11__, bignumber_js__WEBPACK_IMPORTED_MODULE_12__, _packages_custom_card__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 














function Gas(props) {
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z);
    const { headerData , type  } = props;
    const showData = _contants_statistic__WEBPACK_IMPORTED_MODULE_7__/* .statistics */ .hd[type];
    const { title  } = headerData || showData;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "static"
        });
    };
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("24h");
    const color = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return (0,_contants_varible__WEBPACK_IMPORTED_MODULE_4__/* .getColor */ .Lq)(filscanStore.filscan.theme);
    }, [
        filscanStore.filscan.theme
    ]);
    const defaultOtions = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return {
            yAxis: [
                {
                    type: "value",
                    scale: true,
                    axisLabel: {
                        formatter (v) {
                            return new bignumber_js__WEBPACK_IMPORTED_MODULE_12__["default"](Number(v)).dividedBy(Math.pow(10, 9)).toFixed() + " nanoFIL";
                        },
                        textStyle: {
                            color: color.textStyle
                        }
                    },
                    axisTick: {
                        show: false
                    },
                    axisLine: {
                        show: false,
                        lineStyle: {
                            color: color.lineStyle
                        }
                    },
                    splitLine: {
                        show: true,
                        lineStyle: {
                            type: "dashed",
                            color: color.splitLine
                        }
                    }
                },
                {
                    type: "value",
                    scale: true,
                    axisTick: {
                        show: false
                    },
                    axisLabel: {
                        formatter (v) {
                            return new bignumber_js__WEBPACK_IMPORTED_MODULE_12__["default"](Number(v)).dividedBy(Math.pow(10, 9)).toFixed() + " FIL/TiB";
                        },
                        textStyle: {
                            //  fontSize: this.fontSize,
                            color: color.textStyle
                        }
                    },
                    nameTextStyle: {
                        color: "#ffffff"
                    },
                    axisLine: {
                        show: false,
                        lineStyle: {
                            color: color.lineStyle
                        }
                    },
                    splitLine: {
                        show: false,
                        lineStyle: {
                            type: "dashed",
                            color: color.splitLine
                        }
                    }
                }
            ],
            series: {
                type: "line",
                smooth: true,
                itemStyle: {
                    color: "#00E5FF"
                },
                yAxisIndex: 0,
                markArea: {
                    itemStyle: {
                        color: "#153550"
                    }
                }
            },
            tooltip: {
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.timestamp || v[0].name;
                    v.forEach((item, index)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + item.seriesName + ": " + item.data.showValue + " " + item.data.showUnit;
                        }
                    });
                    return result;
                }
            },
            ...(0,_contants_varible__WEBPACK_IMPORTED_MODULE_4__/* .defaultOpt */ .Re)("line", filscanStore.filscan.theme)
        };
    }, [
        filscanStore.filscan
    ]);
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const load = (value = "24h")=>{
        const dateList = [];
        const legendList = [];
        const seriesObj = {
            gas_in_32g: [],
            base_fee: [],
            gas_in_64g: []
        };
        const newOpt = {
            ...defaultOtions
        };
        (0,_store_server__WEBPACK_IMPORTED_MODULE_2__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl.static_gas */ .J.static_gas, {
            interval: value
        }).then((res)=>{
            res?.result?.list?.reverse().forEach((dataItem)=>{
                const { timestamp , base_fee , gas_in_32g , gas_in_64g  } = dataItem;
                let showTime = "";
                if (value === "24h") {
                    const newTime = timestamp.split(" ")[1];
                    showTime = newTime.split(":")[0] + ":" + newTime.split(":")[1];
                } else {
                    showTime = timestamp.split("+")[0];
                }
                dateList.push(showTime);
                seriesObj.gas_in_32g.push({
                    value: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFil */ .Uk)(gas_in_32g, "nanoFiL"),
                    showValue: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFilNum */ .Nm)(gas_in_32g, false, false, 4, false).split(" ")[0],
                    showUnit: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFilNum */ .Nm)(gas_in_32g, false, false, 4, false).split(" ")[1],
                    unit: "nanoFiL",
                    timestamp: timestamp.split("+")[0]
                });
                seriesObj.base_fee.push({
                    value: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFil */ .Uk)(base_fee, "attoFIL"),
                    showValue: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFilNum */ .Nm)(base_fee, false, false, 4, false).split(" ")[0],
                    showUnit: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFilNum */ .Nm)(base_fee, false, false, 4, false).split(" ")[1],
                    unit: "attoFIL",
                    timestamp: timestamp.split("+")[0]
                });
                seriesObj.gas_in_64g.push({
                    value: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFil */ .Uk)(gas_in_64g, "nanoFiL"),
                    showValue: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFilNum */ .Nm)(gas_in_64g, false, false, 4, false).split(" ")[0],
                    showUnit: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFilNum */ .Nm)(gas_in_64g, false, false, 4, false).split(" ")[1],
                    unit: "nanoFiL",
                    timestamp: timestamp.split("+")[0]
                });
            });
            newOpt.xAxis.data = dateList;
            newOpt.series = [];
            showData.list.forEach((item)=>{
                legendList.push(tr(item.label));
                newOpt.series.push({
                    type: item.type,
                    data: seriesObj[item.label],
                    name: tr(item.label),
                    smooth: true,
                    yAxisIndex: item.yIndex,
                    symbol: "circle",
                    unit: item.unit
                });
            });
            newOpt.legend.data = legendList;
            setOptions({
                ...newOpt
            });
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        load(interval);
    }, [
        filscanStore.filscan
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                ns: "static",
                bgColor: true,
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().statis)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().statis_trend)}`,
                header: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                    title: title,
                    defaultValue: "24h",
                    onChange: (item)=>{
                        setInterval(item.value);
                        load(item.value);
                    }
                }),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    propsOption: {
                        ...options
                    },
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().statis_chart)
                })
            }),
            !headerData && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Gas_24__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
        ]
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().statis)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().statis_trend)} default-card`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        title: title,
                        defaultValue: "24h",
                        onChange: (item)=>{
                            setInterval(item.value);
                            load(item.value);
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        propsOption: {
                            ...options
                        },
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().statis_chart)
                    })
                ]
            }),
            !headerData && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Gas_24__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Gas);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6427:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _packages_custom_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3625);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9189);
/* harmony import */ var _contants_statistic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8031);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1311);
/* harmony import */ var _packages_newTable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7692);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8194);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_packages_custom_card__WEBPACK_IMPORTED_MODULE_1__, _contants_statistic__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _store_server__WEBPACK_IMPORTED_MODULE_6__, _packages_newTable__WEBPACK_IMPORTED_MODULE_7__]);
([_packages_custom_card__WEBPACK_IMPORTED_MODULE_1__, _contants_statistic__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _store_server__WEBPACK_IMPORTED_MODULE_6__, _packages_newTable__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 








/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "static"
        });
    };
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)([]);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(1);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        (0,_store_server__WEBPACK_IMPORTED_MODULE_6__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .apiUrl.static_gas_24 */ .J.static_gas_24).then((res)=>{
            setData(res?.result.items);
        });
    }, []);
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_5__.useMemo)(()=>{
        return _contants_statistic__WEBPACK_IMPORTED_MODULE_3__/* .gas_24.columns.map */ .FG.columns.map((item)=>{
            return {
                ...item,
                align: "center",
                title: tr(item.title)
            };
        });
    }, [
        filscanStore.filscan
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        title: _contants_statistic__WEBPACK_IMPORTED_MODULE_3__/* .gas_24.title.label */ .FG.title.label,
        bgColor: true,
        ns: "static",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_newTable__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
            className: "custom-table",
            dataSource: data,
            columns: columns,
            rowKey: (record)=>`${record.sum_gas_fee}_${record.method_name}`
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
exports.id = 9711;
exports.ids = [9711];
exports.modules = {

/***/ 2639:
/***/ ((module) => {

// Exports
module.exports = {
	"value": "TimerHtml_value__RFlLh"
};


/***/ }),

/***/ 6306:
/***/ ((module) => {

// Exports
module.exports = {
	"content": "tooltip_content__ouhoP",
	"content_text": "tooltip_content_text__HnUXp"
};


/***/ }),

/***/ 9750:
/***/ ((module) => {

// Exports
module.exports = {
	"home_meta": "home_home_meta__ju4E7",
	"ul_list": "home_ul_list__VupB9",
	"list_item": "home_list_item__MQN3s",
	"list_item_title": "home_list_item_title__JlbzR",
	"list_item_value": "home_list_item_value__yhjJ7",
	"list_item_value-meta": "home_list_item_value-meta__GjZOX",
	"home_trend": "home_home_trend__rV17S",
	"home_trend_content": "home_home_trend_content__9flt_",
	"home_rank": "home_home_rank__AP4xG",
	"mata_card_min": "home_mata_card_min__h2lLy",
	"mata_card_max": "home_mata_card_max__5uLGm"
};


/***/ }),

/***/ 4176:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9927);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2639);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_utils__WEBPACK_IMPORTED_MODULE_1__]);
_utils_utils__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { text , tr  } = props;
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const showTime = (number)=>{
        let showText = "";
        const { days , hours , minutes , seconds  } = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatTime */ .mr)(Number(number * 1000));
        if (days !== 0) {
            showText = `${days}${tr("day")} ${hours}${tr("hours")} ${minutes}${tr("minutes")} `;
        } else if (hours !== 0) {
            showText = `${hours}${tr("hours")} ${minutes}${tr("minutes")} `;
        } else if (minutes !== 0) {
            showText = `${minutes}${tr("minutes")} ${seconds}${tr("seconds")} `;
        } else {
            showText = `${seconds}${tr("seconds")} `;
        }
        setShow(showText);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (text) {
            showTime(text);
        }
        const interval = setInterval(()=>{
            showTime(text);
        }, 1000);
        return ()=>{
            clearInterval(interval);
        };
    }, [
        text
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().value),
        children: show
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9140:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6306);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ text , id , className  })=>{
    const [isShow, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const contentRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const textRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (textRef) {
            var _textRef_current, _contentRef_current;
            const textWidth = (textRef === null || textRef === void 0 ? void 0 : (_textRef_current = textRef.current) === null || _textRef_current === void 0 ? void 0 : _textRef_current.offsetWidth) || 0;
            const contentWidth = (contentRef === null || contentRef === void 0 ? void 0 : (_contentRef_current = contentRef.current) === null || _contentRef_current === void 0 ? void 0 : _contentRef_current.offsetWidth) || 0;
            if (textWidth > contentWidth) {
                setShow(true);
            }
        }
    }, [
        textRef.current,
        contentRef === null || contentRef === void 0 ? void 0 : contentRef.current
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().content),
        ref: contentRef,
        children: isShow ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
            overlayClassName: "custom-tooltip-wrap",
            title: text,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().content_text)} ${className}`,
                id: id,
                ref: textRef,
                children: text
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().content_text)} ${className}`,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                ref: textRef,
                id: id,
                children: text
            })
        })
    });
});


/***/ }),

/***/ 790:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_rank__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(410);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_rank__WEBPACK_IMPORTED_MODULE_1__]);
_src_rank__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_rank__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        type: props === null || props === void 0 ? void 0 : props.type
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9711:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_home__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6404);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9750);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _meta__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2135);
/* harmony import */ var _src_statistics_Trend__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9653);
/* harmony import */ var _src_statistics_Gas__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4678);
/* harmony import */ var _pages_rank__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(790);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3775);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_home__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_2__, _meta__WEBPACK_IMPORTED_MODULE_3__, _src_statistics_Trend__WEBPACK_IMPORTED_MODULE_4__, _src_statistics_Gas__WEBPACK_IMPORTED_MODULE_5__, _pages_rank__WEBPACK_IMPORTED_MODULE_6__]);
([_contants_home__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_2__, _meta__WEBPACK_IMPORTED_MODULE_3__, _src_statistics_Trend__WEBPACK_IMPORTED_MODULE_4__, _src_statistics_Gas__WEBPACK_IMPORTED_MODULE_5__, _pages_rank__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 








function Home() {
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().home),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_meta__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().home_trend),
                children: _contants_home__WEBPACK_IMPORTED_MODULE_1__/* .home_tend.map */ .QW.map((item, index)=>{
                    let content = null;
                    if (item.label === "power") {
                        content = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_Trend__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            type: "power",
                            default: "home",
                            headerData: {
                                title: item
                            }
                        });
                    } else {
                        content = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_Gas__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            type: "gas",
                            headerData: {
                                title: item
                            }
                        });
                    }
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().home_trend_content)}`,
                        children: content
                    }, index);
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `default-card ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().home_rank)}`,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "default-card-title font_18",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "image-icon-svg",
                                children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("rank")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: t("rank", {
                                    ns: "home"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_rank__WEBPACK_IMPORTED_MODULE_6__["default"], {
                        type: "home"
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2135:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_home__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6404);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9189);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1311);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9750);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var ahooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7398);
/* harmony import */ var ahooks__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(ahooks__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3775);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9140);
/* harmony import */ var _components_TimerHtml__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4176);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_home__WEBPACK_IMPORTED_MODULE_1__, _store_server__WEBPACK_IMPORTED_MODULE_3__, _components_TimerHtml__WEBPACK_IMPORTED_MODULE_10__]);
([_contants_home__WEBPACK_IMPORTED_MODULE_1__, _store_server__WEBPACK_IMPORTED_MODULE_3__, _components_TimerHtml__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 











function Meta() {
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const { title , list  } = _contants_home__WEBPACK_IMPORTED_MODULE_1__/* .home_meta */ .nW;
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const [last, setLast] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)();
    const [TotalIndicators, setTotalIndicators] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)();
    const tr = (label)=>{
        return t(label, {
            ns: "home"
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        loadInterval();
        (0,_store_server__WEBPACK_IMPORTED_MODULE_3__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .apiUrl.home_meta */ .J.home_meta).then((res)=>{
            var _res_result;
            setTotalIndicators((res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.total_indicators) || {});
        });
    }, []);
    (0,ahooks__WEBPACK_IMPORTED_MODULE_7__.useInterval)(()=>{
        loadInterval();
    }, 15000);
    const loadInterval = ()=>{
        (0,_store_server__WEBPACK_IMPORTED_MODULE_3__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .apiUrl.tipset_chain_FinalHeight */ .J.tipset_chain_FinalHeight).then((res)=>{
            const data = (res === null || res === void 0 ? void 0 : res.result) || {};
            setLast({
                latest_height: data.height,
                latest_block_time: data.block_time
            });
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().home_meta)} default-card ${show ? (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().mata_card_max) : (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().mata_card_min)}`,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "default-card-title font_18",
                children: [
                    (title === null || title === void 0 ? void 0 : title.icon) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "image-icon-svg",
                        children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_8__/* .getSvgIcon */ .a)("mate")
                    }),
                    tr(title.label),
                    title.rightIcon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "right-item",
                        onClick: ()=>{
                            setShow(!show);
                        },
                        children: tr(show ? title.rightIcon + "_false" : title.rightIcon)
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: `default-card-content ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().ul_list)}`,
                children: list.map((item)=>{
                    const { render , label , tip  } = item;
                    let showText = "";
                    if (TotalIndicators) {
                        if (label === "latest_block_time") {
                            const TEXT = last && last[label] || TotalIndicators[label];
                            // 时间显示
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().list_item),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().list_item_title),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: tr(label)
                                            }),
                                            tip && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_5__.Tooltip, {
                                                overlayClassName: "custom-tooltip-wrap",
                                                title: tr(tip),
                                                children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_8__/* .getSvgIcon */ .a)("tip")
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_TimerHtml__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        text: TEXT,
                                        tr: tr,
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().list_item_value_meta)
                                    })
                                ]
                            }, label);
                        }
                        showText = render ? render(last && last[label] || TotalIndicators[label], tr) : last && last[label] || TotalIndicators[label];
                    }
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().list_item),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().list_item_title),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr(label)
                                    }),
                                    tip && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_5__.Tooltip, {
                                        overlayClassName: "custom-tooltip-wrap",
                                        title: tr(tip),
                                        children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_8__/* .getSvgIcon */ .a)("tip")
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().list_item_value),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    text: showText,
                                    id: label,
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().list_item_value_meta)
                                })
                            })
                        ]
                    }, label);
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Meta);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
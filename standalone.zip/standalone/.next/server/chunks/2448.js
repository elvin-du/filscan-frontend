"use strict";
exports.id = 2448;
exports.ids = [2448];
exports.modules = {

/***/ 2448:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$F": () => (/* binding */ minder_details),
/* harmony export */   "Hd": () => (/* binding */ indicators_overview),
/* harmony export */   "L6": () => (/* binding */ message_event_log),
/* harmony export */   "Oy": () => (/* binding */ deal),
/* harmony export */   "UW": () => (/* binding */ account_change),
/* harmony export */   "XW": () => (/* binding */ message_overview_trade),
/* harmony export */   "Xd": () => (/* binding */ message_list),
/* harmony export */   "YI": () => (/* binding */ deal_hosting),
/* harmony export */   "ZF": () => (/* binding */ message_overview_detail),
/* harmony export */   "aV": () => (/* binding */ miner_list),
/* harmony export */   "fs": () => (/* binding */ pool_overview),
/* harmony export */   "hQ": () => (/* binding */ detail_owner),
/* harmony export */   "l$": () => (/* binding */ account_overview),
/* harmony export */   "pS": () => (/* binding */ general_overview),
/* harmony export */   "wO": () => (/* binding */ power_trend),
/* harmony export */   "zf": () => (/* binding */ general_overview_type)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9927);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _varible__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(697);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3775);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_utils__WEBPACK_IMPORTED_MODULE_2__, _varible__WEBPACK_IMPORTED_MODULE_4__]);
([_utils_utils__WEBPACK_IMPORTED_MODULE_2__, _varible__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 








const detail_owner = {
    title: {
        label: "owner_title",
        tip: "owner_title_tip"
    },
    content: [
        {
            label: "account_name",
            dataIndex: "account_id"
        },
        {
            label: "owner_address",
            dataIndex: "account_address",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    className: "link",
                    href: `/address/${text}`,
                    children: text
                });
            }
        },
        {
            label: "owned_miners",
            dataIndex: "owned_miners",
            render: (text, record)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "array_item",
                    children: text && Array.isArray(text) && (text === null || text === void 0 ? void 0 : text.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            className: "link",
                            href: `/miner/${item}`,
                            children: item
                        }, index);
                    }))
                });
            }
        }
    ]
};
//储存池概览 账户余额 & 有效算力
const pool_overview = {
    title: {
        label: "owner_overview_title"
    },
    list: {
        title: "balance",
        content: [
            {
                label: "available_balance",
                dataIndex: "available_balance",
                type: [
                    "account_indicator"
                ],
                color: "#E8B61B"
            },
            {
                label: "init_pledge",
                dataIndex: "init_pledge",
                type: [
                    "account_indicator"
                ],
                color: "#4FD0A1"
            },
            {
                label: "pre_deposits",
                dataIndex: "pre_deposits",
                color: "#5D77A3",
                type: [
                    "account_indicator"
                ]
            },
            {
                label: "locked_balance",
                dataIndex: "locked_balance",
                type: [
                    "account_indicator"
                ],
                color: "#D75B42"
            }
        ]
    },
    power_list: {
        header: [
            {
                label: "quality_adjust_power",
                dataIndex: "quality_adjust_power",
                render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2) : "--"
            },
            {
                label: "quality_power_rank",
                dataIndex: "quality_power_rank",
                render: (text)=>text
            }
        ],
        content: [
            {
                label: "raw_power_percentage",
                dataIndex: "quality_power_percentage",
                render: (text)=>text ? Number(text * 100).toFixed(4) + "%" : "--"
            },
            {
                label: "raw_power",
                dataIndex: "raw_power",
                align: "right",
                render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2) : "--"
            },
            // {
            //   label: "total_block_count",
            //   dataIndex: "total_block_count",
            // },
            // {
            //   label: "total_reward",
            //   dataIndex: "total_reward",
            //   render:(text:number)=>text ? formatFil(text,'FIL',4) +' FIL':'--'
            // },
            // {
            //   label: 'total_win_count',
            //   dataIndex: 'total_win_count',
            // },
            {
                label: "sector_size",
                dataIndex: "sector_size",
                render: (text)=>{
                    return text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text) : "--";
                }
            },
            {
                label: "sector_stauts",
                dataIndex: "sector_stauts",
                width: "100%",
                renderList: [
                    {
                        label: "sector_count",
                        value: "live_sector_count"
                    },
                    {
                        label: "live_sector_count",
                        value: "active_sector_count",
                        color: "#5ad8a6"
                    },
                    {
                        label: "fault_sector_count",
                        value: "fault_sector_count",
                        color: "#ff000f"
                    },
                    {
                        label: "recover_sector_count",
                        value: "recover_sector_count",
                        color: "#ffc631"
                    }
                ]
            }
        ]
    }
};
// 统计指标
const indicators_overview = {
    title: {
        label: "indicators",
        list: [
            {
                label: "24h",
                value: "24h"
            },
            {
                label: "7d",
                value: "7d"
            }
        ]
    },
    content: [
        {
            label: "power_increase_indicators",
            style: {
                width: "22%",
                textAlign: "left"
            },
            dataIndex: "power_increase",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2)
        },
        {
            label: "precommit_deposits",
            dataIndex: "sector_deposits",
            style: {
                width: "33%",
                textAlign: "center"
            },
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false)
        },
        {
            label: "block_count",
            dataIndex: "block_count_increase",
            style: {
                width: "25%",
                textAlign: "center"
            },
            label_tip: "block_count_tip",
            render: (text)=>text
        },
        {
            label: "mining_efficiency",
            dataIndex: "rewards_per_tb",
            style: {
                width: "20%",
                justifyContent: "end"
            },
            label_tip: "mining_efficiency_tip",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL/TiB"
        },
        {
            label: "power_ratio",
            dataIndex: "power_ratio",
            style: {
                width: "22%",
                textAlign: "left"
            },
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2) + "/D"
        },
        {
            label: "gas_fee",
            dataIndex: "gas_fee",
            style: {
                width: "33%",
                textAlign: "center"
            },
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false)
        },
        {
            label: "block_rewards",
            dataIndex: "block_reward_increase",
            style: {
                width: "25%",
                textAlign: "center"
            },
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL"
        },
        {
            label: "lucky",
            dataIndex: "lucky",
            style: {
                width: "20%",
                justifyContent: "end"
            },
            render: (text)=>text !== "-1" ? Number(100 * Number(text)).toFixed(4) + " %" : "--"
        },
        {
            label: "sector_increase",
            style: {
                width: "22%",
                textAlign: "left"
            },
            dataIndex: "sector_increase",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2)
        },
        {
            label: "sector_ratio",
            style: {
                width: "33%",
                textAlign: "center"
            },
            dataIndex: "sector_ratio",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2) + "/D"
        },
        {
            label: "win_count",
            style: {
                width: "25%",
                textAlign: "center"
            },
            dataIndex: "win_count",
            label_tip: "win_count_tip",
            render: (text)=>text
        },
        {
            label: "net_profit_per_tb",
            style: {
                width: "20%",
                justifyContent: "end"
            },
            dataIndex: "gas_fee_per_tb",
            label_tip: "net_profit_per_tb_tip",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 3)
        }
    ]
};
// 账户变化
const account_change = {
    title: {
        label: "owner_account_change"
    },
    list: [
        {
            label: "available_balance",
            type: "line"
        },
        {
            label: "init_pledge",
            type: "line"
        },
        {
            label: "locked_balance",
            type: "line"
        },
        {
            label: "pre_deposits",
            type: "line"
        }
    ]
};
// miner 账户总览
const account_overview = {
    title: {
        label: "account_overview"
    },
    list: [
        {
            label: "create_time",
            dataIndex: "create_time",
            type: [
                "account_basic"
            ],
            render: (text)=>{
                return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text);
            }
        },
        {
            label: "account_type",
            dataIndex: "account_type",
            type: [
                "account_basic"
            ],
            render: (text, record, tr)=>tr(text)
        },
        {
            label: "peer_id",
            dataIndex: "peer_id",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
        },
        {
            label: "account_address",
            dataIndex: "account_address",
            type: [
                "account_basic"
            ],
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
        },
        {
            label: "owner_address",
            dataIndex: "owner_address",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: `/address/${text}`,
                    className: "link",
                    children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
                });
            }
        },
        {
            label: "area",
            dataIndex: "ip_address"
        },
        {
            label: "worker_address",
            dataIndex: "worker_address",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: `/address/${text}`,
                    className: "link",
                    children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
                });
            }
        },
        {
            label: "controllers_address",
            dataIndex: "controllers_address",
            render: (text, record)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "array_item_column",
                    children: text && Array.isArray(text) ? text === null || text === void 0 ? void 0 : text.map((linkItem, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: `/address/${linkItem}`,
                            className: "link",
                            children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(linkItem)
                        }, linkItem);
                    }) : "--"
                });
            }
        },
        {
            label: "beneficiary_address",
            dataIndex: "beneficiary_address",
            render: (text, record)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "array_item",
                    children: text && Array.isArray(text) ? text === null || text === void 0 ? void 0 : text.map((linkItem, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: `/address/${linkItem}`,
                            className: "link",
                            children: linkItem
                        }, linkItem);
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: `/address/${text}`,
                        className: "link",
                        children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
                    }, text)
                });
            }
        }
    ]
};
// 有效算力
const power_trend = {
    title: {
        label: "quality_adjust_power",
        list: [
            {
                label: "7d",
                value: "7d"
            },
            {
                label: "30d",
                value: "1m"
            }
        ]
    },
    list: [
        {
            label: "power",
            type: "line"
        },
        {
            label: "power_increase",
            type: "bar",
            backgroundColor: "#5B8FF9"
        }
    ]
};
//消息
const message_list = {
    tabs: [
        {
            label: "message_detail",
            value: "detail"
        },
        {
            label: "trade",
            value: "trade"
        },
        {
            label: "event_log",
            value: "event_log"
        }
    ]
};
// //详情概况
const message_overview_trade = [
    {
        dataIndex: "from",
        title: "from_ath",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(record.from_type, text)
    },
    {
        dataIndex: "to",
        title: "to_ath",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(record.from_type, text)
    },
    {
        dataIndex: "value",
        title: "amount",
        render: (text)=>{
            return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 4);
        }
    },
    {
        dataIndex: "method",
        title: "method"
    }
];
const message_event_log = [
    {
        title: "account_address",
        dataIndex: "address"
    },
    {
        title: "Name",
        dataIndex: "name"
    },
    {
        title: "topic",
        dataIndex: "topics",
        render: (text, record)=>{
            if (Array.isArray(text)) {
                return text.map((item, index)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: "array_item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "array_item_icon",
                                children: index
                            }),
                            item
                        ]
                    }, item);
                });
            }
            return text || "--";
        }
    },
    {
        title: "params",
        dataIndex: "data",
        render: (text)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-render",
                children: text
            });
        }
    },
    {
        title: "Log Index",
        dataIndex: "log_index"
    },
    {
        title: "Removed",
        dataIndex: "removed"
    }
];
const message_overview_detail = {
    title: {
        label: "message_overview_detail"
    },
    content: [
        [
            {
                dataIndex: "cid",
                title: "cid",
                type: [
                    "message_basic"
                ]
            },
            {
                dataIndex: "eth_message",
                title: "eth_message",
                elasticity: true
            },
            {
                dataIndex: "exit_code",
                title: "exit_code",
                type: [
                    "message_basic"
                ],
                render: (text)=>{
                    if (text === null || text === void 0 ? void 0 : text.startsWith("Ok")) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "table_li",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "antd-icon",
                                    children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_8__/* .getSvgIcon */ .a)("successIcon")
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    style: {
                                        color: "#059b02"
                                    },
                                    children: "Success"
                                })
                            ]
                        });
                    }
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "table_li",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "antd-icon",
                                children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_8__/* .getSvgIcon */ .a)("errorIcon")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                style: {
                                    color: "#e11919"
                                },
                                children: "Error"
                            })
                        ]
                    });
                }
            },
            {
                dataIndex: "value",
                title: "value",
                type: [
                    "message_basic"
                ],
                render: (text)=>{
                    return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 4);
                }
            },
            {
                dataIndex: "height",
                title: "height",
                type: [
                    "message_basic"
                ],
                render: (text)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        className: "link",
                        href: `/tipset/chain?height=${text}`,
                        children: text
                    });
                }
            },
            {
                dataIndex: "block_time",
                title: "time",
                type: [
                    "message_basic"
                ],
                render: (text)=>{
                    return text ? dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm:ss") : "--";
                }
            },
            {
                dataIndex: "method_name",
                title: "method_name",
                type: [
                    "message_basic"
                ]
            },
            {
                dataIndex: "swap_info",
                elasticity: true,
                style: {
                    borderTop: "1px solid var(--border-color)"
                },
                title: (tr)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex-center",
                        children: [
                            (0,_svgUtils__WEBPACK_IMPORTED_MODULE_8__/* .getSvgIcon */ .a)("transaction"),
                            tr("Transaction")
                        ]
                    }),
                render: (text)=>{
                    if (text) {
                        var _text_amount_in;
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "font-Weight_500",
                                    children: "Swap"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: text === null || text === void 0 ? void 0 : (_text_amount_in = text.amount_in) === null || _text_amount_in === void 0 ? void 0 : _text_amount_in.toLocaleString()
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: text === null || text === void 0 ? void 0 : text.amount_in_token_name.toLocaleUpperCase()
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "font-des",
                                    children: "For"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: text === null || text === void 0 ? void 0 : text.amount_out
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: text === null || text === void 0 ? void 0 : text.amount_out_token_name
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "margin-6",
                                    children: "On"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    className: "margin-6 fvm_img_url",
                                    src: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .getImgUrl */ .wD)(text === null || text === void 0 ? void 0 : text.dex),
                                    alt: "",
                                    width: 22,
                                    height: 22
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: text === null || text === void 0 ? void 0 : text.dex
                                })
                            ]
                        });
                    }
                    return null;
                }
            },
            {
                dataIndex: "from",
                title: "from",
                style: {
                    borderTop: "1px solid var(--border-color)"
                },
                type: [
                    "message_basic"
                ],
                render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(record.to_type, text, 0)
            },
            {
                dataIndex: "to",
                title: "to",
                type: [
                    "message_basic"
                ],
                render: (text, record)=>{
                    return (0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(record.to_type, text, 0);
                }
            }
        ],
        [
            {
                label: "message_ERC20Trans",
                elasticity: true,
                dataIndex: "message_ERC20Trans",
                style: {
                    borderBottom: "1px solid var(--border-color)"
                },
                render: (text, record, tr)=>{
                    if (Array.isArray(text)) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "array_item_column",
                            children: [
                                " ",
                                text.map((item, index)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "array_item_column_li",
                                        children: [
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font_weight",
                                                children: tr("from_ath")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: (0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(item.from_type, item.from)
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font_weight",
                                                children: tr("to_ath")
                                            }),
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: (0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(item.to_type, item.to)
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font_weight",
                                                children: "For"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: Number(item === null || item === void 0 ? void 0 : item.amount).toFixed(4) || "--"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: item === null || item === void 0 ? void 0 : item.token_name
                                            })
                                        ]
                                    }, index);
                                })
                            ]
                        });
                    }
                    return "--";
                }
            },
            {
                label: "message_tranf",
                dataIndex: "consume_list",
                elasticity: true,
                render: (text, record, tr)=>{
                    if (Array.isArray(text)) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "array_item_column",
                            children: [
                                " ",
                                text.map((item, index)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "array_item_column_li",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font_weight",
                                                children: tr("from_ath")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: (0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(item.from_type, item.from)
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font_weight",
                                                children: tr("to_ath")
                                            }),
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: (0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(item.to_type, item.to)
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font_weight",
                                                children: "For"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(item.value, false, false, 4) || "--"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                children: [
                                                    "(",
                                                    tr(item.consume_type),
                                                    ")"
                                                ]
                                            })
                                        ]
                                    }, index);
                                })
                            ]
                        });
                    }
                    return "--";
                }
            }
        ],
        [
            {
                dataIndex: "blk_cids",
                title: "blk_cids",
                render: (text)=>{
                    if (!Array.isArray(text) || !text) return "--";
                    return text.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            className: "link link-html",
                            href: `/tipset/chain?cid=${item}`,
                            children: item
                        }, index);
                    });
                }
            },
            {
                dataIndex: "base_fee",
                title: "base_fee",
                style: {
                    borderTop: "1px solid var(--border-color)"
                },
                render: (text)=>{
                    return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 4);
                }
            },
            {
                dataIndex: "version",
                title: "version"
            },
            {
                dataIndex: "nonce",
                title: "nonce"
            },
            {
                dataIndex: "gas_fee_cap",
                title: "gas_fee_cap",
                render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 4)
            },
            {
                dataIndex: "gas_premium",
                title: "gas_premium",
                render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 4)
            },
            {
                dataIndex: "gas_limit",
                title: "gas_limit",
                render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text)
            },
            {
                dataIndex: "gas_used",
                title: "gas_used",
                render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text)
            },
            {
                dataIndex: "all_gas_fee",
                title: "all_gas_fee",
                render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 4)
            },
            {
                dataIndex: "params",
                title: "params",
                isRecord: true,
                render: (text, record)=>{
                    // "returns", "returns_detail"
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "box-html",
                        children: [
                            "Args { ",
                            [
                                "params",
                                "params_detail"
                            ].map((key, index)=>{
                                const showValue = record && record[key] ? record[key] : "";
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text",
                                    children: showValue && JSON.stringify(showValue, undefined, 3)
                                }, index);
                            }),
                            " }"
                        ]
                    });
                }
            },
            {
                dataIndex: "returns",
                title: "returns",
                isRecord: true,
                render: (text, record)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "box-html",
                        children: [
                            "Return { ",
                            [
                                "returns",
                                "returns_detail"
                            ].map((key, index)=>{
                                const showValue = record && record[key] ? record[key] : "";
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text",
                                    children: showValue && JSON.stringify(showValue, undefined, 3)
                                }, index);
                            }),
                            " }"
                        ]
                    });
                }
            }
        ]
    ]
};
const minder_details = {
    pool_overview_title: {
        label: "account"
    }
};
//列表
const miner_list = {
    message_list_total: "message_list_total",
    title: [
        {
            value: "MessagesByAccountID",
            label: "message_list",
            headerList: true
        },
        {
            value: "BlocksByAccountID",
            label: "block_list"
        },
        {
            value: "TracesByAccountID",
            label: "traces_list"
        }
    ],
    columns: (type)=>{
        let arr = [];
        switch(type){
            case "MessagesByAccountID":
                arr = [
                    {
                        dataIndex: "cid",
                        title: "cid",
                        render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/message/${text}`,
                                className: "link",
                                children: text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6) : ""
                            }) : "--"
                    },
                    {
                        dataIndex: "height",
                        title: "height",
                        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/tipset/chain?height=${text}`,
                                className: "link",
                                children: text
                            })
                    },
                    {
                        dataIndex: "block_time",
                        title: "time",
                        render: (text)=>dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm")
                    },
                    {
                        dataIndex: "from",
                        title: "from",
                        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(record.from_type, text)
                    },
                    {
                        dataIndex: "to",
                        title: "to",
                        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(record.to_type, text)
                    },
                    {
                        dataIndex: "value",
                        title: "value",
                        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL"
                    },
                    {
                        dataIndex: "exit_code",
                        title: "status"
                    },
                    {
                        dataIndex: "method_name",
                        title: "method_name"
                    }
                ];
                break;
            case "BlocksByAccountID":
                arr = [
                    {
                        dataIndex: "cid",
                        title: "block_cid",
                        render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/tipset/chain?cid=${text}`,
                                className: "link",
                                children: text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6) : ""
                            }) : "--"
                    },
                    {
                        dataIndex: "height",
                        title: "block_height",
                        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/tipset/chain?height=${text}`,
                                className: "link",
                                children: text
                            })
                    },
                    {
                        dataIndex: "block_time",
                        title: "block_time",
                        render: (text)=>dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm")
                    },
                    {
                        dataIndex: "messages_count",
                        title: "block_messages_count"
                    },
                    {
                        dataIndex: "miner_id",
                        title: "block_miner_id",
                        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/miner/${text}`,
                                className: "link",
                                children: text
                            })
                    },
                    {
                        dataIndex: "reward",
                        title: "block_mined_reward",
                        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 2) + " FIL"
                    }
                ];
                break;
            case "TracesByAccountID":
                arr = [
                    {
                        dataIndex: "block_time",
                        title: "time",
                        render: (text)=>dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm")
                    },
                    {
                        dataIndex: "cid",
                        title: "cid",
                        render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/message/${text}`,
                                className: "link",
                                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6)
                            }) : "--"
                    },
                    {
                        dataIndex: "from",
                        title: "from",
                        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(record.from_type, text)
                    },
                    {
                        dataIndex: "to",
                        title: "to",
                        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(record.to_type, text)
                    },
                    {
                        dataIndex: "value",
                        title: "value",
                        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL"
                    },
                    {
                        dataIndex: "method_name",
                        title: "method_name"
                    }
                ];
            default:
                break;
        }
        return arr;
    },
    resultObj: (type)=>{
        switch(type){
            case "MessagesByAccountID":
                return "messages_by_account_id_list";
            case "BlocksByAccountID":
                return "blocks_by_account_id_list";
            case "TracesByAccountID":
                return "traces_by_account_id_list";
        }
        return "";
    }
};
//general 
const general_overview = {
    title: {
        label: "general_overview_title"
    },
    list: [
        {
            label: "balance",
            type: "line",
            dataIndex: "balance"
        }
    ],
    options: [
        {
            label: "24h",
            value: "24h"
        },
        {
            label: "7d",
            value: "7d"
        }
    ],
    message_list: [
        {
            value: "MessagesByAccountID",
            label: "message_list",
            headerList: true
        },
        {
            value: "TracesByAccountID",
            label: "traces_list"
        }
    ]
};
const default_content = [
    {
        label: "account_address",
        dataIndex: "account_address",
        type: [
            "account_basic"
        ],
        render: (text, record, tr)=>{
            var _record_account_basic;
            const owned_miners = (record === null || record === void 0 ? void 0 : (_record_account_basic = record.account_basic) === null || _record_account_basic === void 0 ? void 0 : _record_account_basic.owned_miners) || [];
            if (owned_miners.length > 0) {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    style: {
                        display: "flex",
                        alignItems: "center"
                    },
                    children: [
                        text,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Button, {
                            className: "btn-link",
                            onClick: ()=>{
                                var _record_account_basic;
                                next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/owner/${record === null || record === void 0 ? void 0 : (_record_account_basic = record.account_basic) === null || _record_account_basic === void 0 ? void 0 : _record_account_basic.account_id}`);
                            },
                            children: tr("account_detail")
                        })
                    ]
                });
            }
            return text;
        }
    },
    {
        label: "account_id",
        elasticity: true,
        dataIndex: "account_id",
        type: [
            "account_basic"
        ]
    },
    {
        label: "base_account_id",
        dataIndex: "account_id",
        type: [
            "account_basic"
        ],
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(record.from_type, text)
    },
    {
        label: "account_type",
        dataIndex: "account_type",
        type: [
            "account_basic"
        ],
        isNs: true
    },
    {
        label: "balance",
        dataIndex: "account_balance",
        type: [
            "account_basic"
        ],
        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text)
            })
    },
    {
        label: "nonce",
        dataIndex: "nonce",
        type: [
            "account_basic"
        ]
    },
    {
        label: "code_cid",
        dataIndex: "code_cid",
        type: [
            "account_basic"
        ]
    },
    {
        label: "create_time",
        dataIndex: "create_time",
        type: [
            "account_basic"
        ],
        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
    },
    {
        label: "latest_transfer_time",
        dataIndex: "latest_transfer_time",
        type: [
            "account_basic"
        ],
        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
    }
];
const f4_content = [
    {
        label: "account_address",
        dataIndex: "account_address",
        type: [
            "account_basic"
        ],
        render: (text, record, tr)=>{
            var _record_account_basic;
            const owned_miners = (record === null || record === void 0 ? void 0 : (_record_account_basic = record.account_basic) === null || _record_account_basic === void 0 ? void 0 : _record_account_basic.owned_miners) || [];
            if (owned_miners.length > 0) {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    style: {
                        display: "flex",
                        alignItems: "center"
                    },
                    children: [
                        text,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Button, {
                            className: "btn-link",
                            onClick: ()=>{
                                var _record_account_basic;
                                next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/owner/${record === null || record === void 0 ? void 0 : (_record_account_basic = record.account_basic) === null || _record_account_basic === void 0 ? void 0 : _record_account_basic.account_id}`);
                            },
                            children: tr("account_detail")
                        })
                    ]
                });
            }
            return text;
        }
    },
    {
        label: "account_id",
        elasticity: true,
        dataIndex: "account_id",
        type: [
            "account_basic"
        ]
    },
    {
        label: "eth_address",
        dataIndex: "eth_address",
        type: [
            "account_basic"
        ]
    },
    {
        label: "stable_address",
        dataIndex: "stable_address",
        elasticity: true,
        type: [
            "account_basic"
        ]
    },
    {
        label: "base_account_id",
        dataIndex: "account_id",
        type: [
            "account_basic"
        ],
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(record.from_type, text)
    },
    {
        label: "account_type",
        dataIndex: "account_type",
        type: [
            "account_basic"
        ],
        isNs: true
    },
    {
        label: "balance",
        dataIndex: "account_balance",
        type: [
            "account_basic"
        ],
        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text)
            })
    },
    {
        label: "nonce",
        elasticity: true,
        dataIndex: "nonce",
        type: [
            "account_basic"
        ]
    },
    {
        label: "code_cid",
        dataIndex: "code_cid",
        type: [
            "account_basic"
        ]
    },
    {
        label: "create_time",
        dataIndex: "create_time",
        type: [
            "account_basic"
        ],
        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
    },
    {
        label: "latest_transfer_time",
        dataIndex: "latest_transfer_time",
        type: [
            "account_basic"
        ],
        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
    }
];
const general_overview_type = (type, tr)=>{
    const obj = {
        //所有者账户
        "account_type": [
            ...default_content
        ],
        "account": [
            ...default_content
        ],
        "multisig": [
            {
                label: "account_address",
                dataIndex: "account_address",
                type: [
                    "account_basic"
                ],
                render: (text, record, tr)=>{
                    var _record_account_basic, _record_account_basic1;
                    const owned_miners = (record === null || record === void 0 ? void 0 : (_record_account_basic = record.account_basic) === null || _record_account_basic === void 0 ? void 0 : _record_account_basic.owned_miners) || [];
                    const showText = text || (record === null || record === void 0 ? void 0 : (_record_account_basic1 = record.account_basic) === null || _record_account_basic1 === void 0 ? void 0 : _record_account_basic1.account_id);
                    if (owned_miners.length > 0) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            style: {
                                display: "flex",
                                alignItems: "center"
                            },
                            children: [
                                showText,
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                    className: "btn-link",
                                    onClick: ()=>{
                                        var _record_account_basic;
                                        next_router__WEBPACK_IMPORTED_MODULE_7___default().push(`/owner/${record === null || record === void 0 ? void 0 : (_record_account_basic = record.account_basic) === null || _record_account_basic === void 0 ? void 0 : _record_account_basic.account_id}`);
                                    },
                                    children: tr("account_detail")
                                })
                            ]
                        });
                    }
                    return showText;
                }
            },
            {
                label: "account_id",
                elasticity: true,
                dataIndex: "account_id",
                type: [
                    "account_basic"
                ]
            },
            {
                label: "account_type",
                dataIndex: "account_type",
                type: [
                    "account_basic"
                ],
                render: (text)=>{
                    return tr(text);
                }
            },
            {
                label: "balance",
                dataIndex: "account_balance",
                type: [
                    "account_basic"
                ],
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text)
                    })
            },
            {
                label: "Initial Balance",
                dataIndex: "initial_balance",
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text)
                    })
            },
            {
                label: "Unlock Balance",
                dataIndex: "locked_balance",
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text)
                    })
            },
            {
                label: "Locking Period ",
                dataIndex: "unlock_start_time",
                render: (text, record)=>{
                    const lastTime = record === null || record === void 0 ? void 0 : record.unlock_end_time;
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        children: [
                            " ",
                            (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm"),
                            " to  ",
                            (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(lastTime, "YYYY-MM-DD HH:mm")
                        ]
                    });
                }
            },
            {
                label: "Signers",
                dataIndex: "signers",
                render: (text)=>{
                    return Array.isArray(text) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "array_item_column",
                        children: text === null || text === void 0 ? void 0 : text.map((item, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: (0,_varible__WEBPACK_IMPORTED_MODULE_4__/* .get_account_type */ .$B)(item === null || item === void 0 ? void 0 : item.from_type, item, 0)
                            }, index);
                        })
                    }) : text;
                }
            },
            {
                label: "Approvals Threshold",
                dataIndex: "approvals_threshold"
            },
            {
                label: "nonce",
                dataIndex: "nonce",
                type: [
                    "account_basic"
                ],
                elasticity: true
            },
            {
                label: "Available Balance",
                dataIndex: "available_balance",
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text)
                    })
            },
            {
                label: "Robust Address",
                dataIndex: "account_address",
                type: [
                    "account_basic"
                ]
            },
            {
                label: "owned_miners",
                dataIndex: "owned_miners",
                type: [
                    "account_basic"
                ],
                render: (text)=>{
                    return Array.isArray(text) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "array_item",
                        children: Array.isArray(text) && (text === null || text === void 0 ? void 0 : text.map((item)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                className: "link",
                                href: `/miner/${item}`,
                                children: item
                            }, item);
                        }))
                    }) : text;
                }
            },
            {
                label: "code_cid",
                dataIndex: "code_cid",
                type: [
                    "account_basic"
                ]
            },
            {
                label: "create_time",
                dataIndex: "create_time",
                type: [
                    "account_basic"
                ],
                render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
            },
            {
                label: "latest_transfer_time",
                dataIndex: "latest_transfer_time",
                type: [
                    "account_basic"
                ],
                render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
            }
        ],
        "account_miner": [
            ...default_content
        ],
        "owner": [
            ...default_content,
            {
                label: "owned_miners",
                dataIndex: "owned_miners",
                render: (text)=>{
                    return Array.isArray(text) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "array_item",
                        children: Array.isArray(text) && (text === null || text === void 0 ? void 0 : text.map((item)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                className: "link",
                                href: `/miner/${item}`,
                                children: item
                            }, item);
                        }))
                    }) : text;
                }
            },
            {
                label: "owned_active_miners",
                dataIndex: "owned_active_miners",
                render: (text)=>{
                    return Array.isArray(text) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "array_item",
                        children: Array.isArray(text) && (text === null || text === void 0 ? void 0 : text.map((item)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                className: "link",
                                href: `/miner/${item}`,
                                children: item
                            }, item);
                        }))
                    }) : text;
                }
            }
        ],
        "evm": [
            ...f4_content
        ],
        "ethaccount": [
            ...f4_content
        ],
        "placeholder": [
            ...f4_content
        ]
    };
    return obj[type] ? obj[type] : [
        ...default_content
    ];
};
const deal = {
    title: {
        label: "deal_details"
    },
    list: [
        {
            dataIndex: "deal_id",
            label: "deal_id"
        },
        {
            dataIndex: "service_start_time",
            label: "service_start_time",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
        },
        {
            dataIndex: "epoch",
            label: "epoch",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    className: "link",
                    href: `/tipset/chain?height=${text}`,
                    children: text
                })
        },
        {
            dataIndex: "message_cid",
            label: "message_cid",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    className: "link",
                    href: `/message/${text}`,
                    children: text
                })
        },
        {
            dataIndex: "piece_cid",
            label: "piece_cid"
        },
        {
            dataIndex: "verified_deal",
            label: "verified_deal"
        }
    ],
    content: {
        left_title: "deal_left_title",
        right_title: "deal_right_title",
        value: "deal_value",
        cash: "deal_cash",
        time: "deal_time"
    }
};
const deal_hosting = {
    title: {
        label: "deal_hosting"
    }
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
exports.id = 2448;
exports.ids = [2448];
exports.modules = {

/***/ 814:
/***/ ((module) => {

// Exports
module.exports = {
	"dropdown": "dropDown_dropdown__Putmq",
	"dropdown_value": "dropDown_dropdown_value__k_4hJ",
	"dropdown_content": "dropDown_dropdown_content__Zf_Qs",
	"dropdown_content_main": "dropDown_dropdown_content_main__Uhf4u",
	"dropdown_content_item": "dropDown_dropdown_content_item__HCDCM",
	"dropdown_content_item_icon": "dropDown_dropdown_content_item_icon__POeEq"
};


/***/ }),

/***/ 2448:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$F": () => (/* binding */ minder_details),
/* harmony export */   "Hd": () => (/* binding */ indicators_overview),
/* harmony export */   "L6": () => (/* binding */ message_event_log),
/* harmony export */   "Oy": () => (/* binding */ deal),
/* harmony export */   "UW": () => (/* binding */ account_change),
/* harmony export */   "XW": () => (/* binding */ message_overview_trade),
/* harmony export */   "Xd": () => (/* binding */ message_list),
/* harmony export */   "YI": () => (/* binding */ deal_hosting),
/* harmony export */   "ZF": () => (/* binding */ message_overview_detail),
/* harmony export */   "aV": () => (/* binding */ miner_list),
/* harmony export */   "fs": () => (/* binding */ pool_overview),
/* harmony export */   "hQ": () => (/* binding */ detail_owner),
/* harmony export */   "l$": () => (/* binding */ account_overview),
/* harmony export */   "pS": () => (/* binding */ general_overview),
/* harmony export */   "qK": () => (/* binding */ default_content),
/* harmony export */   "wO": () => (/* binding */ power_trend)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9927);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_json_tree__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5288);
/* harmony import */ var react_json_tree__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_json_tree__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9997);
/* harmony import */ var _varible__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(697);
/* harmony import */ var _packages_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9744);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3775);
/* harmony import */ var _packages_dropDown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2346);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_utils__WEBPACK_IMPORTED_MODULE_2__, _varible__WEBPACK_IMPORTED_MODULE_6__]);
([_utils_utils__WEBPACK_IMPORTED_MODULE_2__, _varible__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 











const theme = {
    base00: "transparent",
    base01: "#abb2bf",
    base02: "#5c6370",
    base03: "#abb2bf",
    base04: "#5c6370",
    base05: "#abb2bf",
    base06: "#888888",
    base07: "#888888",
    base08: "#e06c75",
    base09: "#0090FF",
    base0A: "#0090FF",
    base0B: "#0090FF",
    base0C: "#56b6c2",
    base0D: "#888888",
    base0E: "#c678dd",
    base0F: "#be5046"
};
const detail_owner = {
    title: {
        label: "owner_title",
        tip: "owner_title_tip"
    },
    content: [
        {
            label: "account_name",
            dataIndex: "account_id"
        },
        {
            label: "owner_address",
            dataIndex: "account_address",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    className: "link",
                    href: `/address/${text}`,
                    children: text
                });
            }
        },
        {
            label: "owned_miners",
            dataIndex: "owned_miners",
            render: (text, record)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "array_item",
                    children: text && Array.isArray(text) && text?.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            className: "link",
                            href: `/miner/${item}`,
                            children: item
                        }, index);
                    })
                });
            }
        }
    ]
};
//储存池概览 账户余额 & 有效算力
const pool_overview = {
    title: {
        label: "owner_overview_title"
    },
    list: {
        title: "balance",
        content: [
            {
                label: "available_balance",
                dataIndex: "available_balance",
                type: [
                    "account_indicator"
                ],
                color: "#E8B61B"
            },
            {
                label: "init_pledge",
                dataIndex: "init_pledge",
                type: [
                    "account_indicator"
                ],
                color: "#4FD0A1"
            },
            {
                label: "pre_deposits",
                dataIndex: "pre_deposits",
                color: "#5D77A3",
                type: [
                    "account_indicator"
                ]
            },
            {
                label: "locked_balance",
                dataIndex: "locked_balance",
                type: [
                    "account_indicator"
                ],
                color: "#D75B42"
            }
        ]
    },
    power_list: {
        header: [
            {
                label: "quality_adjust_power",
                dataIndex: "quality_adjust_power",
                render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2) : "--"
            },
            {
                label: "quality_power_rank",
                dataIndex: "quality_power_rank",
                render: (text)=>text
            }
        ],
        content: [
            {
                label: "raw_power_percentage",
                dataIndex: "quality_power_percentage",
                render: (text)=>text ? Number(text * 100).toFixed(4) + "%" : "--"
            },
            {
                label: "raw_power",
                dataIndex: "raw_power",
                align: "right",
                render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2) : "--"
            },
            {
                label: "sector_size",
                dataIndex: "sector_size",
                render: (text)=>{
                    return text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text) : "--";
                }
            },
            {
                label: "sector_stauts",
                dataIndex: "sector_stauts",
                width: "100%",
                renderList: [
                    {
                        label: "sector_count",
                        value: "live_sector_count"
                    },
                    {
                        label: "live_sector_count",
                        value: "active_sector_count",
                        color: "#5ad8a6"
                    },
                    {
                        label: "fault_sector_count",
                        value: "fault_sector_count",
                        color: "#ff000f"
                    },
                    {
                        label: "recover_sector_count",
                        value: "recover_sector_count",
                        color: "#ffc631"
                    }
                ]
            }
        ]
    }
};
// 统计指标
const indicators_overview = {
    title: {
        label: "indicators",
        list: [
            {
                label: "24h",
                value: "24h"
            },
            {
                label: "7d",
                value: "7d"
            },
            {
                label: "30d",
                value: "1m"
            }
        ]
    },
    content: [
        {
            label: "power_increase_indicators",
            style: {
                width: "22%",
                textAlign: "left"
            },
            dataIndex: "power_increase",
            render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2) : "--"
        },
        {
            label: "precommit_deposits",
            dataIndex: "sector_deposits",
            style: {
                width: "33%",
                textAlign: "center"
            },
            render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false) : text
        },
        {
            label: "block_count",
            dataIndex: "block_count_increase",
            style: {
                width: "25%",
                textAlign: "center"
            },
            label_tip: "block_count_tip",
            render: (text)=>String(text) || "--"
        },
        {
            label: "mining_efficiency",
            dataIndex: "rewards_per_tb",
            style: {
                width: "20%",
                justifyContent: "end"
            },
            label_tip: "mining_efficiency_tip",
            render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL/TiB" : "--"
        },
        {
            label: "power_ratio",
            dataIndex: "power_ratio",
            style: {
                width: "22%",
                textAlign: "left"
            },
            render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2) + "/D" : "--"
        },
        {
            label: "gas_fee",
            dataIndex: "gas_fee",
            style: {
                width: "33%",
                textAlign: "center"
            },
            render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false) : "--"
        },
        {
            label: "block_rewards",
            dataIndex: "block_reward_increase",
            style: {
                width: "25%",
                textAlign: "center"
            },
            render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL" : "--"
        },
        {
            label: "lucky",
            dataIndex: "lucky",
            style: {
                width: "20%",
                justifyContent: "end"
            },
            render: (text)=>text !== "-1" ? Number(100 * Number(text)).toFixed(4) + " %" : "--"
        },
        {
            label: "sector_increase",
            style: {
                width: "22%",
                textAlign: "left"
            },
            dataIndex: "sector_increase",
            render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2) : "--"
        },
        {
            label: "sector_ratio",
            style: {
                width: "33%",
                textAlign: "center"
            },
            dataIndex: "sector_ratio",
            render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2) + "/D" : "--"
        },
        {
            label: "win_count",
            style: {
                width: "25%",
                textAlign: "center"
            },
            dataIndex: "win_count",
            label_tip: "win_count_tip",
            render: (text)=>String(text) || "--"
        },
        {
            label: "net_profit_per_tb",
            style: {
                width: "20%",
                justifyContent: "end"
            },
            dataIndex: "gas_fee_per_tb",
            label_tip: "net_profit_per_tb_tip",
            render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 3) : "--"
        }
    ]
};
// 账户变化
const account_change = {
    title: {
        label: "owner_account_change"
    },
    list: [
        {
            label: "available_balance",
            type: "line"
        },
        {
            label: "init_pledge",
            type: "line"
        },
        {
            label: "locked_balance",
            type: "line"
        },
        {
            label: "pre_deposits",
            type: "line"
        }
    ]
};
// miner 账户总览
const account_overview = {
    title: {
        label: "account_overview"
    },
    list: [
        {
            label: "account_type",
            dataIndex: "account_type",
            type: [
                "account_basic"
            ],
            render: (text, record, tr)=>text ? tr(text) : "--"
        },
        {
            label: "account_address",
            dataIndex: "account_address",
            type: [
                "account_basic"
            ],
            render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text) : "--"
        },
        {
            label: "owner_address",
            dataIndex: "owner_address",
            render: (text)=>{
                if (!text) return "--";
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: `/address/${text}`,
                    className: "link",
                    children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
                });
            }
        },
        {
            label: "worker_address",
            dataIndex: "worker_address",
            render: (text)=>{
                if (!text) return "--";
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: `/address/${text}`,
                    className: "link",
                    children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
                });
            }
        },
        {
            label: "beneficiary_address",
            dataIndex: "beneficiary_address",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "array_item",
                    children: text && Array.isArray(text) ? text?.map((linkItem, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: `/address/${linkItem}`,
                            className: "link",
                            children: linkItem
                        }, linkItem);
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: `/address/${text}`,
                        className: "link",
                        children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
                    }, text)
                });
            }
        },
        //   {
        //   label: 'create_time',
        //   dataIndex: 'create_time',
        //    type: ["account_basic"],
        //   render: (text: string | number) => { 
        //     return formatDateTime(text)
        //   }
        // },
        //       {
        //   label: 'area', //暂无
        //   dataIndex:'ip_address'
        // },
        {
            label: "controllers_address",
            dataIndex: "controllers_address",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "array_item_column",
                    children: text && Array.isArray(text) ? text?.map((linkItem, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: `/address/${linkItem}`,
                            className: "link",
                            children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(linkItem)
                        }, linkItem);
                    }) : "--"
                });
            }
        }
    ]
};
// 有效算力
const power_trend = {
    title: {
        label: "quality_adjust_power",
        list: [
            {
                label: "7d",
                value: "7d"
            },
            {
                label: "30d",
                value: "1m"
            }
        ]
    },
    list: [
        {
            label: "power",
            type: "line"
        },
        {
            label: "power_increase",
            type: "bar",
            backgroundColor: "#5B8FF9"
        }
    ]
};
//消息
const message_list = {
    tabs: [
        {
            label: "message_detail",
            value: "detail"
        },
        {
            label: "trade",
            value: "trade"
        },
        {
            label: "event_log",
            value: "event_log"
        }
    ]
};
// //详情概况
const message_overview_trade = [
    {
        dataIndex: "from",
        title: "from_ath",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(record.from_type, text)
    },
    {
        dataIndex: "to",
        title: "to_ath",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(record.from_type, text)
    },
    {
        dataIndex: "value",
        title: "amount",
        render: (text)=>{
            return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 4);
        }
    },
    {
        dataIndex: "method",
        title: "method"
    }
];
const message_event_log = [
    {
        title: "account_address",
        dataIndex: "address"
    },
    {
        title: "Name",
        dataIndex: "name"
    },
    {
        title: "topic",
        dataIndex: "topics",
        render: (text, record)=>{
            if (Array.isArray(text)) {
                return text.map((item, index)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: "array_item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "array_item_icon",
                                children: index
                            }),
                            item
                        ]
                    }, item);
                });
            }
            return text || "--";
        }
    },
    {
        title: "params",
        dataIndex: "data",
        render: (text)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-render",
                children: text
            });
        }
    },
    {
        title: "Log Index",
        dataIndex: "log_index"
    },
    {
        title: "Removed",
        dataIndex: "removed",
        render: (text)=>String(text)
    }
];
const message_overview_detail = {
    title: {
        label: "message_overview_detail"
    },
    content: [
        [
            {
                dataIndex: "cid",
                title: "cid",
                type: [
                    "message_basic"
                ],
                render: (text)=>{
                    return text ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex_align_center",
                        children: [
                            (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isMobile */ .tq)() ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6) : text,
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                text: text
                            })
                        ]
                    }) : text;
                }
            },
            {
                dataIndex: "eth_message",
                title: "eth_message",
                elasticity: true,
                render: (text)=>{
                    return text ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex_align_center",
                        children: [
                            (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isMobile */ .tq)() ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6) : text,
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                text: text
                            })
                        ]
                    }) : text;
                }
            },
            {
                dataIndex: "exit_code",
                title: "exit_code",
                type: [
                    "message_basic"
                ],
                render: (text)=>{
                    if (text?.startsWith("Ok")) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "antd-icon",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "success_color",
                                        children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_10__/* .getSvgIcon */ .a)("successIcon")
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    style: {
                                        color: "#059b02"
                                    },
                                    children: "Success"
                                })
                            ]
                        });
                    } else if (text?.startsWith("Pending")) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "antd-icon",
                                    children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_10__/* .getSvgIcon */ .a)("penddingIcon")
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    style: {
                                        color: "#FFBF03"
                                    },
                                    children: "Pending"
                                })
                            ]
                        });
                    }
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "antd-icon",
                                children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_10__/* .getSvgIcon */ .a)("errorIcon")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                style: {
                                    color: "#e11919"
                                },
                                children: "Error"
                            })
                        ]
                    });
                }
            },
            {
                dataIndex: "value",
                title: "value",
                type: [
                    "message_basic"
                ],
                render: (text)=>{
                    return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 4);
                }
            },
            {
                dataIndex: "height",
                title: "height",
                type: [
                    "message_basic"
                ],
                render: (text)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        className: "link",
                        href: `/tipset/chain?height=${text}`,
                        children: text
                    });
                }
            },
            {
                dataIndex: "block_time",
                title: "time",
                type: [
                    "message_basic"
                ],
                render: (text)=>{
                    return text ? dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm:ss") : "--";
                }
            },
            {
                dataIndex: "method_name",
                title: "method_name",
                type: [
                    "message_basic"
                ]
            },
            {
                dataIndex: "swap_info",
                elasticity: true,
                style: {
                    borderTop: "1px solid var(--border-color)",
                    padding: "15px 10px"
                },
                title: (tr)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        style: {
                            position: "relative",
                            paddingLeft: 25
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                style: {
                                    position: "absolute",
                                    top: "4px",
                                    left: "5px"
                                },
                                children: [
                                    " ",
                                    (0,_svgUtils__WEBPACK_IMPORTED_MODULE_10__/* .getSvgIcon */ .a)("transaction")
                                ]
                            }),
                            tr("Transaction"),
                            ":"
                        ]
                    }),
                render: (text)=>{
                    if (text) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex_align_center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "font-Weight_500",
                                    children: "Swap"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: text?.amount_out?.toLocaleString()
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: text?.amount_out_token_name.toLocaleUpperCase()
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "font-des",
                                    children: "For"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: text?.amount_in
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: text?.amount_in_token_name
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "margin-6",
                                    children: "On"
                                }),
                                text.dex_url ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "link",
                                    onClick: ()=>{
                                        window.open(text.dex_url);
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        className: "margin-6 fvm_img_url",
                                        src: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .getImgUrl */ .wD)(text?.dex),
                                        alt: "",
                                        width: 20,
                                        height: 20
                                    })
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    className: "margin-6 fvm_img_url",
                                    src: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .getImgUrl */ .wD)(text?.dex),
                                    alt: "",
                                    width: 20,
                                    height: 20
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: text?.dex
                                })
                            ]
                        });
                    }
                    return null;
                }
            },
            {
                dataIndex: "from",
                title: "from",
                style: {
                    borderTop: "1px solid var(--border-color)",
                    paddingTop: "15px"
                },
                type: [
                    "message_basic"
                ],
                render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(record.to_type, text, 0)
            },
            {
                dataIndex: "to",
                title: "to",
                type: [
                    "message_basic"
                ],
                render: (text, record)=>{
                    return (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(record.to_type, text, 0);
                }
            }
        ],
        [
            {
                label: "message_ERC20Trans",
                elasticity: true,
                dataIndex: "message_ERC20Trans",
                style: {
                    borderBottom: "1px solid var(--border-color)",
                    paddingBottom: "15px"
                },
                render: (text, record, tr)=>{
                    if (Array.isArray(text)) {
                        // return <Fold data={text} tr={ tr} />
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "array_item_column",
                            children: [
                                " ",
                                text.map((item, index)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "array_item_column_li",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex_align_center ",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "font_weight",
                                                        children: tr("from_ath")
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(item.from_type, item.from)
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex_align_center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "font_weight",
                                                        children: tr("to_ath")
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(item.to_type, item.to)
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex_align_center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "font_weight",
                                                        children: "For"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: Number(item?.amount).toFixed(4) || "--"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: item?.token_name
                                                    })
                                                ]
                                            })
                                        ]
                                    }, index);
                                })
                            ]
                        });
                    }
                    return "--";
                }
            },
            {
                label: "message_NftTrans",
                elasticity: true,
                dataIndex: "nftTrans",
                style: {
                    borderBottom: "1px solid var(--border-color)",
                    paddingBottom: "15px"
                },
                render: (text, record, tr)=>{
                    if (Array.isArray(text)) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "array_item_column",
                            children: [
                                " ",
                                text.map((item, index)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "array_item_column_li",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "array_item_column_li",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "font_weight",
                                                        children: tr("from_ath")
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(item.from_type, item.from)
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex_align_center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "font_weight",
                                                        children: tr("to_ath")
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(item.to_type, item.to)
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex_align_center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "font_weight",
                                                        children: "For"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: Number(item?.amount).toFixed(4) || "--"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: item?.token_name
                                                    })
                                                ]
                                            })
                                        ]
                                    }, index);
                                })
                            ]
                        });
                    }
                    return "--";
                }
            },
            {
                label: "message_tranf",
                dataIndex: "consume_list",
                elasticity: true,
                style: {
                    margin: "10px 0px 0px 0px"
                },
                render: (text, record, tr)=>{
                    if (Array.isArray(text)) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "array_item_column",
                            children: [
                                " ",
                                text.map((item, index)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "array_item_column_li",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex_align_center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "font_weight",
                                                        children: tr("from_ath")
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(item.from_type, item.from)
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex_align_center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "font_weight",
                                                        children: tr("to_ath")
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(item.to_type, item.to)
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex_align_center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "font_weight",
                                                        children: "For"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(item.value, false, false, 4) || "--"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        children: [
                                                            "(",
                                                            tr(item.consume_type),
                                                            ")"
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }, index);
                                })
                            ]
                        });
                    }
                    return "--";
                }
            }
        ],
        [
            {
                dataIndex: "blk_cids",
                title: "blk_cids",
                render: (text)=>{
                    if (!Array.isArray(text) || !text) return "--";
                    return text.map((item, index)=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex_align_center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    className: "link link-html",
                                    href: `/tipset/chain?cid=${item}`,
                                    children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isMobile */ .tq)() ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(item, 8) : item
                                }, index),
                                item && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    text: item
                                })
                            ]
                        });
                    });
                }
            },
            {
                dataIndex: "base_fee",
                title: "base_fee",
                style: {
                    borderTop: "1px solid var(--border-color)",
                    marginTop: 15,
                    paddingTop: 15
                },
                render: (text)=>{
                    return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 4);
                }
            },
            {
                dataIndex: "version",
                title: "version",
                render: (text)=>text
            },
            {
                dataIndex: "nonce",
                title: "nonce",
                render: (text)=>text
            },
            {
                dataIndex: "gas_fee_cap",
                title: "gas_fee_cap",
                render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 4)
            },
            {
                dataIndex: "gas_premium",
                title: "gas_premium",
                render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 4)
            },
            {
                dataIndex: "gas_limit",
                title: "gas_limit",
                render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text)
            },
            {
                dataIndex: "gas_used",
                title: "gas_used",
                render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text)
            },
            {
                dataIndex: "all_gas_fee",
                title: "all_gas_fee",
                render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 4)
            },
            {
                dataIndex: "params",
                title: "params",
                isRecord: true,
                render: (text, record)=>{
                    // "returns", "returns_detail"
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "json_box",
                        children: [
                            "params",
                            "params_detail"
                        ].map((key, index)=>{
                            const showValue = record && record[key] ? record[key] : "";
                            if (showValue) {
                                if (typeof showValue === "string") {
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-15",
                                        children: JSON.stringify(showValue, undefined, 6)
                                    });
                                }
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_json_tree__WEBPACK_IMPORTED_MODULE_4__.JSONTree, {
                                        hideRoot: true,
                                        theme: theme,
                                        data: showValue,
                                        labelRenderer: (keyPath, nodeType, expanded)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "label_text",
                                                children: [
                                                    expanded && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: "{"
                                                    }),
                                                    `"${keyPath}"`,
                                                    expanded && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "json_tree"
                                                    })
                                                ]
                                            });
                                        },
                                        valueRenderer: (valueAsString, value, keyPath, expanded)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                children: [
                                                    valueAsString || "",
                                                    expanded && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            color: "#000",
                                                            display: "block",
                                                            marginLeft: -15
                                                        },
                                                        children: "}"
                                                    })
                                                ]
                                            });
                                        }
                                    })
                                }, index);
                            }
                            return null;
                        })
                    });
                }
            },
            {
                dataIndex: "returns",
                title: "returns",
                isRecord: true,
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "json_box",
                        children: [
                            "returns",
                            "returns_detail"
                        ].map((key, index)=>{
                            const showValue = record && record[key] ? record[key] : "";
                            if (showValue) {
                                if (typeof showValue === "string") {
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-15",
                                        children: JSON.stringify(showValue, undefined, 6)
                                    });
                                }
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_json_tree__WEBPACK_IMPORTED_MODULE_4__.JSONTree, {
                                        hideRoot: true,
                                        theme: theme,
                                        data: showValue,
                                        labelRenderer: (keyPath, nodeType, expanded)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "label_text",
                                                children: [
                                                    expanded && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: "{"
                                                    }),
                                                    `"${keyPath}"`,
                                                    expanded && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "json_tree"
                                                    })
                                                ]
                                            });
                                        },
                                        valueRenderer: (valueAsString, value, keyPath, expanded)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                children: [
                                                    valueAsString || "",
                                                    expanded && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        style: {
                                                            display: "block",
                                                            marginLeft: -15
                                                        },
                                                        children: "}"
                                                    })
                                                ]
                                            });
                                        }
                                    })
                                }, index);
                            }
                            return null;
                        })
                    });
                }
            }
        ]
    ]
};
const minder_details = {
    pool_overview_title: {
        label: "account"
    }
};
//列表
const miner_list = {
    message_list_total: "message_list_total",
    title: [
        {
            value: "MessagesByAccountID",
            label: "message_list",
            show_active: "message",
            headerList: true
        },
        {
            value: "BlocksByAccountID",
            label: "block_list",
            show_active: "block"
        },
        {
            value: "TracesByAccountID",
            label: "traces_list",
            show_active: "trace",
            headerList: true,
            options: [
                {
                    label: "all",
                    value: "all"
                },
                {
                    label: "Blockreward",
                    value: "blockreward"
                },
                {
                    label: "Burn",
                    value: "burn"
                },
                {
                    label: "Transfer",
                    value: "transfer"
                },
                {
                    label: "Send",
                    value: "send",
                    isIndent: true
                },
                {
                    label: "Receive",
                    value: "receive",
                    isIndent: true
                }
            ]
        }
    ],
    columns: (type, fromList, toList)=>{
        let arr = [];
        switch(type){
            case "MessagesByAccountID":
                arr = [
                    {
                        dataIndex: "cid",
                        title: "cid",
                        render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/message/${text}`,
                                className: "link",
                                children: text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6) : ""
                            }) : "--"
                    },
                    {
                        dataIndex: "height",
                        title: "height",
                        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/tipset/chain?height=${text}`,
                                className: "link",
                                children: text
                            })
                    },
                    {
                        dataIndex: "block_time",
                        title: "time",
                        render: (text)=>dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm")
                    },
                    {
                        dataIndex: "from",
                        title: "from",
                        render: (text, record)=>{
                            if (!text) return "--";
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "table_li",
                                children: [
                                    (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(record.from_type, text),
                                    fromList?.domains && fromList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: `/domain/${fromList.domains[text]}?provider=${fromList.provider}`,
                                        children: [
                                            "(",
                                            fromList.domains[text],
                                            ")"
                                        ]
                                    })
                                ]
                            });
                        }
                    },
                    {
                        dataIndex: "to",
                        title: "to",
                        render: (text, record)=>{
                            if (!text) return "--";
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "table_li",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(record.to_type, text)
                                    }),
                                    toList?.domains && toList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: `/domain/${toList.domains[text]}?provider=${toList.provider}`,
                                        children: [
                                            "(",
                                            toList.domains[text],
                                            ")"
                                        ]
                                    })
                                ]
                            });
                        }
                    },
                    {
                        dataIndex: "value",
                        title: "value",
                        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL"
                    },
                    {
                        dataIndex: "exit_code",
                        title: "status"
                    },
                    {
                        dataIndex: "method_name",
                        title: "method_name"
                    }
                ];
                break;
            case "BlocksByAccountID":
                arr = [
                    {
                        dataIndex: "cid",
                        title: "block_cid",
                        render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/tipset/chain?cid=${text}`,
                                className: "link",
                                children: text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6) : ""
                            }) : "--"
                    },
                    {
                        dataIndex: "height",
                        title: "block_height",
                        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/tipset/chain?height=${text}`,
                                className: "link",
                                children: text
                            })
                    },
                    {
                        dataIndex: "block_time",
                        title: "block_time",
                        render: (text)=>dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm")
                    },
                    {
                        dataIndex: "messages_count",
                        title: "block_messages_count"
                    },
                    {
                        dataIndex: "miner_id",
                        title: "block_miner_id",
                        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/miner/${text}`,
                                className: "link",
                                children: text
                            })
                    },
                    {
                        dataIndex: "reward",
                        title: "block_mined_reward",
                        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 2) + " FIL"
                    }
                ];
                break;
            case "TracesByAccountID":
                arr = [
                    {
                        dataIndex: "block_time",
                        title: "time",
                        render: (text)=>dayjs__WEBPACK_IMPORTED_MODULE_3___default()(Number(text) * 1000).format("YYYY-MM-DD HH:mm")
                    },
                    {
                        dataIndex: "cid",
                        title: "cid",
                        render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/message/${text}`,
                                className: "link",
                                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6)
                            }) : "--"
                    },
                    {
                        dataIndex: "from",
                        title: "from",
                        render: (text, record)=>{
                            if (!text) return "--";
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "table_li",
                                children: [
                                    (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(record.from_type, text),
                                    fromList?.domains && fromList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: `/domain/${fromList.domains[text]}?provider=${fromList.provider}`,
                                        children: [
                                            "(",
                                            fromList.domains[text],
                                            ")"
                                        ]
                                    })
                                ]
                            });
                        }
                    },
                    {
                        dataIndex: "to",
                        title: "to",
                        render: (text, record)=>{
                            if (!text) return "--";
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "table_li",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(record.to_type, text)
                                    }),
                                    toList?.domains && toList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: `/domain/${toList.domains[text]}?provider=${toList.provider}`,
                                        children: [
                                            "(",
                                            toList.domains[text],
                                            ")"
                                        ]
                                    })
                                ]
                            });
                        }
                    },
                    {
                        dataIndex: "value",
                        title: "value",
                        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL"
                    },
                    {
                        dataIndex: "method_name",
                        title: "method_name"
                    }
                ];
                break;
            case "ERC20OwnerTokenList":
                arr = [
                    {
                        dataIndex: "token_name",
                        title: "token_name"
                    },
                    {
                        dataIndex: "contract_id",
                        title: "contract_id",
                        render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/address/${text}`,
                                className: "link",
                                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6)
                            }) : "--"
                    },
                    {
                        dataIndex: "amount",
                        title: "amount",
                        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL"
                    },
                    {
                        dataIndex: "value",
                        title: "value",
                        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL"
                    }
                ];
                break;
            case "ERC20AddrTransfers":
                arr = [
                    {
                        dataIndex: "time",
                        title: "time",
                        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
                    },
                    {
                        dataIndex: "cid",
                        title: "cid",
                        render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                className: "link",
                                href: `/message/${text}`,
                                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6)
                            }) : "--"
                    },
                    {
                        dataIndex: "from",
                        title: "from",
                        render: (text, record)=>{
                            if (!text) return "--";
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "table_li",
                                children: [
                                    (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(record.from_type, text),
                                    fromList?.domains && fromList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: `/domain/${fromList.domains[text]}?provider=${fromList.provider}`,
                                        children: [
                                            "(",
                                            fromList.domains[text],
                                            ")"
                                        ]
                                    })
                                ]
                            });
                        }
                    },
                    {
                        dataIndex: "to",
                        title: "to",
                        render: (text, record)=>{
                            if (!text) return "--";
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "table_li",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(record.to_type, text)
                                    }),
                                    toList?.domains && toList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: `/domain/${toList.domains[text]}?provider=${toList.provider}`,
                                        children: [
                                            "(",
                                            toList.domains[text],
                                            ")"
                                        ]
                                    })
                                ]
                            });
                        }
                    },
                    {
                        dataIndex: "method",
                        title: "method"
                    },
                    {
                        dataIndex: "amount",
                        title: "amount",
                        render: (text, record)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "margin-6",
                                        children: record.token_name
                                    })
                                ]
                            });
                        }
                    },
                    {
                        dataIndex: "icon_url",
                        width: 150,
                        title: "platform",
                        render: (text, record)=>{
                            if (!text) {
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    src: text,
                                    width: 25,
                                    style: {
                                        borderRadius: "50%"
                                    },
                                    height: 25
                                });
                            }
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: `/token/${record?.contract_id}`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    src: text,
                                    width: 25,
                                    height: 25,
                                    style: {
                                        borderRadius: "50%"
                                    }
                                })
                            });
                        }
                    }
                ];
                break;
            default:
                return arr;
        }
        return arr;
    },
    resultObj: (type)=>{
        switch(type){
            case "MessagesByAccountID":
                return "messages_by_account_id_list";
            case "BlocksByAccountID":
                return "blocks_by_account_id_list";
            case "TracesByAccountID":
                return "traces_by_account_id_list";
            case "ERC20OwnerTokenList":
                return "items";
            case "ERC20AddrTransfers":
                return "items";
        }
        return "";
    }
};
//general 
const general_overview = {
    title: {
        label: "general_overview_title"
    },
    list: [
        {
            label: "balance",
            type: "line",
            dataIndex: "balance"
        }
    ],
    options: [
        {
            label: "24h",
            value: "24h"
        },
        {
            label: "7d",
            value: "7d"
        },
        {
            label: "30d",
            value: "1m"
        }
    ],
    message_list: [
        {
            value: "MessagesByAccountID",
            label: "message_list",
            show_active: "message",
            headerList: true
        },
        {
            value: "TracesByAccountID",
            label: "traces_list",
            show_active: "traces",
            headerList: true,
            options: [
                {
                    label: "all",
                    value: "all"
                },
                {
                    label: "Blockreward",
                    value: "blockreward"
                },
                {
                    label: "Burn",
                    value: "burn"
                },
                {
                    label: "Transfer",
                    value: "transfer"
                },
                {
                    label: "Send",
                    value: "send",
                    isIndent: true
                },
                {
                    label: "Receive",
                    value: "receive",
                    isIndent: true
                }
            ]
        }
    ]
};
const default_content = [
    {
        label: "account_address",
        dataIndex: "account_address",
        type: [
            "account_basic"
        ],
        elasticity: true,
        render: (text, record, tr)=>{
            const owned_miners = record?.account_basic?.owned_miners || [];
            if (!text) return text;
            if (owned_miners.length > 0) {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    style: {
                        display: "flex"
                    },
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex_align_center",
                            children: [
                                (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isMobile */ .tq)() || text && text.length > 50 ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 10) : text,
                                text && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    text: text
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_8__.Button, {
                            className: "btn-link",
                            onClick: ()=>{
                                next_router__WEBPACK_IMPORTED_MODULE_9___default().push(`/owner/${record?.account_basic?.account_id}`);
                            },
                            children: tr("account_detail")
                        })
                    ]
                });
            }
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex_align_center",
                children: [
                    text && text.length > 50 || (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isMobile */ .tq)() ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 10) : text,
                    text && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        text: text
                    })
                ]
            });
        }
    },
    {
        label: "contract_name",
        dataIndex: "contract_name",
        elasticity: true,
        type: [
            "account_basic",
            "evm_contract"
        ],
        render: (text, record, tr)=>{
            if (record?.account_basic?.account_type === "evm") {
                if (text) {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex_align_center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "success_color",
                                children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_10__/* .getSvgIcon */ .a)("successIcon")
                            }),
                            text
                        ]
                    });
                }
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_8__.Button, {
                    className: " active_btn flex-center",
                    onClick: ()=>{
                        next_router__WEBPACK_IMPORTED_MODULE_9___default().push("/contract/verify");
                    },
                    children: tr("go_verify")
                });
            }
            return text;
        }
    },
    {
        label: "base_account_id",
        dataIndex: "account_id",
        type: [
            "account_basic"
        ],
        render: (text, record)=>text ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex-center",
                children: [
                    text,
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        text: text
                    })
                ]
            }) : text
    },
    {
        label: "balance",
        dataIndex: "account_balance",
        type: [
            "account_basic"
        ],
        render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text) : "--"
    },
    {
        label: "account_type",
        dataIndex: "account_type",
        type: [
            "account_basic"
        ],
        render: (text, record, tr)=>text ? tr(text) : "--"
    },
    {
        label: "eth_address",
        dataIndex: "eth_address",
        elasticity: true,
        type: [
            "account_basic"
        ],
        render: (text, record)=>text ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex-center",
                children: [
                    text,
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        text: text
                    })
                ]
            }) : text
    },
    {
        label: "stable_address",
        dataIndex: "stable_address",
        elasticity: true,
        type: [
            "account_basic"
        ],
        render: (text, record)=>text ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex-center",
                children: [
                    text,
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        text: text
                    })
                ]
            }) : text
    },
    //multiple
    {
        label: "Initial Balance",
        dataIndex: "initial_balance",
        elasticity: true,
        render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text) : "--"
    },
    {
        label: "Unlock Balance",
        dataIndex: "locked_balance",
        elasticity: true,
        render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text) : "--"
    },
    {
        label: "Locking Period ",
        dataIndex: "unlock_start_time",
        elasticity: true,
        render: (text, record)=>{
            if (!text) {
                return "--";
            }
            const lastTime = record?.unlock_end_time;
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    " ",
                    (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm"),
                    " to  ",
                    (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(lastTime, "YYYY-MM-DD HH:mm")
                ]
            });
        }
    },
    {
        label: "Approvals Threshold",
        elasticity: true,
        dataIndex: "approvals_threshold"
    },
    {
        label: "tokenList",
        elasticity: true,
        dataIndex: "tokenList",
        render: (text)=>{
            if (Array.isArray(text)) {
                const value = text[0];
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_dropDown__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    value: value,
                    content: text.slice(1)
                });
            }
        }
    },
    {
        label: "nonce",
        dataIndex: "nonce",
        type: [
            "account_basic"
        ],
        render: (text)=>text
    },
    {
        label: "Available Balance",
        dataIndex: "available_balance",
        elasticity: true,
        render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text) : "--"
    },
    {
        label: "Robust Address",
        dataIndex: "account_address",
        elasticity: true,
        type: [
            "account_basic"
        ],
        render: (text, record)=>{
            if (record.account_type === "multisig") {
                return text ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex-center",
                    children: [
                        text,
                        " ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            text: text
                        })
                    ]
                }) : text;
            }
            return "--";
        }
    },
    {
        label: "owned_miners",
        dataIndex: "owned_miners",
        elasticity: true,
        type: [
            "account_basic"
        ],
        render: (text)=>{
            return Array.isArray(text) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "array_item",
                children: Array.isArray(text) && text?.map((item)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        className: "link",
                        href: `/miner/${item}`,
                        children: item
                    }, item);
                })
            }) : text;
        }
    },
    {
        label: "user_count",
        dataIndex: "user_count",
        type: [
            "account_basic",
            "evm_contract"
        ],
        elasticity: true,
        render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text) : text
    },
    {
        label: "transfer_count",
        dataIndex: "transfer_count",
        type: [
            "account_basic",
            "evm_contract"
        ],
        elasticity: true,
        render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text) : text
    },
    {
        label: "create_time",
        dataIndex: "create_time",
        type: [
            "account_basic"
        ],
        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
    },
    {
        label: "Signers",
        dataIndex: "signers",
        elasticity: true,
        render: (text)=>{
            return Array.isArray(text) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "array_item_column array_item_over",
                children: text?.map((item, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: (0,_varible__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(item?.from_type, item, 20)
                    }, index);
                })
            }) : text;
        }
    },
    {
        label: "latest_transfer_time",
        dataIndex: "latest_transfer_time",
        type: [
            "account_basic"
        ],
        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
    }
];
const deal = {
    title: {
        label: "deal_details"
    },
    list: [
        {
            dataIndex: "deal_id",
            label: "deal_id"
        },
        {
            dataIndex: "service_start_time",
            label: "service_start_time",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
        },
        {
            dataIndex: "epoch",
            label: "epoch",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    className: "link",
                    href: `/tipset/chain?height=${text}`,
                    children: text
                })
        },
        {
            dataIndex: "message_cid",
            label: "message_cid",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    className: "link",
                    href: `/message/${text}`,
                    children: text
                })
        },
        {
            dataIndex: "piece_cid",
            label: "piece_cid"
        },
        {
            dataIndex: "verified_deal",
            label: "verified_deal"
        }
    ],
    content: {
        left_title: "deal_left_title",
        right_title: "deal_right_title",
        value: "deal_value",
        cash: "deal_cash",
        time: "deal_time"
    }
};
const deal_hosting = {
    title: {
        label: "deal_hosting"
    }
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2346:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3775);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(814);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { content , value  } = props;
    const showValue = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (value) {
            return value;
        }
        return content[0];
    }, [
        value,
        content
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().dropdown),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().dropdown_value),
                children: [
                    showValue.label,
                    (0,_svgUtils__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("down")
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().dropdown_content),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().dropdown_content_main),
                    children: content.map((v, index)=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().dropdown_content_item),
                            children: [
                                showValue.value === v.value && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__.CheckOutlined, {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().dropdown_content_item_icon),
                                    rev: undefined
                                }),
                                v.label
                            ]
                        }, index);
                    })
                })
            })
        ]
    });
});


/***/ })

};
;
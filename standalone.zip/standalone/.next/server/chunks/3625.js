exports.id = 3625;
exports.ids = [3625];
exports.modules = {

/***/ 8962:
/***/ ((module) => {

// Exports
module.exports = {
	"defaultCard": "custom_card_defaultCard__D0UYu",
	"defaultCard_title": "custom_card_defaultCard_title__tNskX",
	"bgCard": "custom_card_bgCard__bfAv9",
	"defaultCard_titleRight": "custom_card_defaultCard_titleRight__f5cfr",
	"content_item": "custom_card_content_item__JxcFN",
	"content_item_value": "custom_card_content_item_value__pQMnd"
};


/***/ }),

/***/ 3625:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7987);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8962);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_1__]);
react_i18next__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { className , header , headerRight , title , bgColor , ns ="home" , contentClass , children  } = props;
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)();
    const tr = (label)=>{
        // @ts-ignore
        return t(label, {
            ns: ns
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().defaultCard)} ${bgColor ? (_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().bgCard) : ""} ${className} `,
        children: [
            title && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().defaultCard_title)} ${headerRight ? (_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().defaultCard_titleRight) : ""}`,
                children: [
                    tr(title),
                    headerRight && headerRight
                ]
            }),
            header && header,
            children && children
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
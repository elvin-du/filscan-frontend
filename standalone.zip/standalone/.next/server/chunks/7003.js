"use strict";
exports.id = 7003;
exports.ids = [7003];
exports.modules = {

/***/ 7003:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9201);
/* harmony import */ var echarts__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(echarts__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(697);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8194);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9927);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_varible__WEBPACK_IMPORTED_MODULE_3__, _utils_utils__WEBPACK_IMPORTED_MODULE_5__]);
([_contants_varible__WEBPACK_IMPORTED_MODULE_3__, _utils_utils__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    // 1. get DOM
    const chartRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const { propsOption , className , style ={}  } = props;
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z);
    const color = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return (0,_contants_varible__WEBPACK_IMPORTED_MODULE_3__/* .getColor */ .Lq)(filscanStore.filscan.theme);
    }, [
        filscanStore.filscan.theme
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        // 2. 实例化表格对象
        const chart = echarts__WEBPACK_IMPORTED_MODULE_1__.init(chartRef.current);
        // 3. 定义数据
        const option = {
            backgroundColor: "transparent",
            color: _contants_varible__WEBPACK_IMPORTED_MODULE_3__/* .colors */ .O9,
            tooltip: {},
            grid: {
                top: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .isMobile */ .tq)() ? 100 : 50,
                left: 20,
                right: 20,
                bottom: 0,
                containLabel: true
            }
        };
        // 4. 调用表格数据
        chart.setOption({
            ...option,
            ...propsOption
        });
        const handleSize = ()=>{
            chart.resize();
        };
        window.addEventListener("resize", handleSize);
        return ()=>{
            window.removeEventListener("resize", handleSize);
        };
    }, [
        propsOption
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `${style.chart} ${className}`,
        style: style,
        ref: chartRef
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
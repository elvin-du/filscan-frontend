"use strict";
exports.id = 2196;
exports.ids = [2196];
exports.modules = {

/***/ 2196:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EJ": () => (/* binding */ ft_tabs),
/* harmony export */   "ES": () => (/* binding */ nft_tabs),
/* harmony export */   "G_": () => (/* binding */ overview),
/* harmony export */   "T": () => (/* binding */ verify),
/* harmony export */   "hh": () => (/* binding */ nfts),
/* harmony export */   "jS": () => (/* binding */ getNftsColumns),
/* harmony export */   "qs": () => (/* binding */ ft_market),
/* harmony export */   "r": () => (/* binding */ token),
/* harmony export */   "um": () => (/* binding */ nfts_market),
/* harmony export */   "ve": () => (/* binding */ getContractColumns)
/* harmony export */ });
/* unused harmony export detail */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9927);
/* harmony import */ var _varible__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(697);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_utils__WEBPACK_IMPORTED_MODULE_1__, _varible__WEBPACK_IMPORTED_MODULE_2__]);
([_utils_utils__WEBPACK_IMPORTED_MODULE_1__, _varible__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const verify = {
    content: {
        list: [
            {
                label: "content_des1"
            },
            {
                label: "content_des2"
            },
            {
                label: "content_des3"
            }
        ],
        buttons: [
            {
                label: "source_code",
                className: "custom_border_btn"
            },
            {
                label: "compile_output",
                className: "custom_border_btn"
            }
        ]
    },
    main: {
        header: {
            title: "verify_title",
            des: "verify_des"
        },
        content: {
            des: "content_des",
            list: [
                {
                    type: "Input",
                    dataIndex: "contract_address",
                    title: "address",
                    placeholder: "address_placeholder"
                },
                {
                    type: "Select",
                    title: "verify_address",
                    dataIndex: "compile_version",
                    placeholder: "verify_select_placeholder"
                },
                {
                    type: "Select",
                    title: "license_type",
                    dataIndex: "license",
                    placeholder: "verify_select_placeholder",
                    options: [
                        {
                            label: "No License(None)",
                            value: "No license(None)"
                        },
                        {
                            label: "MIT License(MIT)",
                            value: "MIT license(MIT)"
                        }
                    ]
                }
            ]
        },
        buttons: [
            {
                text: "next",
                className: "active_btn",
                disableList: [
                    "contract_address",
                    "compile_version"
                ]
            },
            {
                text: "reset",
                className: "custom_cancel_btn"
            }
        ]
    },
    contract: {
        header: {
            title: "verify_title",
            des: "step1_verify_des"
        },
        content: {
            list: [
                {
                    type: "Input",
                    disabled: true,
                    dataIndex: "contract_address",
                    title: "address_verify",
                    style: {
                        flex: 1
                    }
                },
                {
                    type: "Input",
                    disabled: true,
                    dataIndex: "compile_version",
                    title: "compile_version",
                    style: {
                        width: "30%"
                    }
                },
                {
                    type: "Select",
                    title: "Optimizations",
                    dataIndex: "optimize",
                    defaultValue: "true",
                    style: {
                        width: "10%"
                    },
                    options: [
                        {
                            label: "Yes",
                            value: "true"
                        },
                        {
                            label: "No",
                            value: "false"
                        }
                    ]
                },
                {
                    type: "Input",
                    title: "run_optimizer",
                    dataIndex: "optimize_runs",
                    defaultValue: 200,
                    style: {
                        width: "15%"
                    }
                }
            ],
            other: [
                {
                    type: "textArea",
                    title: "arguments",
                    style: {
                        textAlign: "left"
                    },
                    dataIndex: "arguments"
                }
            ]
        },
        buttons: [
            {
                text: "confirm",
                className: "active_btn"
            },
            {
                text: "reset",
                className: "custom_cancel_btn"
            },
            {
                text: "back",
                className: "custom_border_btn"
            }
        ]
    },
    output: {
        title: "byte_code",
        params: [
            {
                label: "compiler",
                title: "compiler"
            },
            {
                label: "optimize",
                title: "optimize"
            },
            {
                label: "optimize_runs",
                title: "optimize_runs"
            }
        ],
        others: [
            {
                title: "contract_name",
                dataIndex: "contract_name"
            },
            {
                title: "local_byte_code",
                dataIndex: "local_byte_code"
            }
        ]
    }
};
const overview = {
    title: {
        label: "overview"
    },
    content: [
        {
            title: "total_supply",
            dataIndex: "total_supply",
            render: (text)=>{
                return text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 4) : text || "--";
            }
        },
        {
            title: "owners",
            dataIndex: "owners"
        },
        {
            title: "transfers",
            dataIndex: "transfers"
        }
    ]
};
const ft_market = {
    title: {
        label: "market"
    },
    content: [
        {
            title: "latest_price",
            dataIndex: "latest_price",
            render: (text)=>text ? text + " FIL" : "--"
        },
        {
            title: "market_value",
            dataIndex: "market_cap",
            render: (text)=>text + " FIL"
        },
        {
            title: "token_contract",
            dataIndex: "contract_id"
        }
    ]
};
const ft_tabs = [
    {
        label: "transfer",
        value: "transfer",
        url: "ERC20Transfer",
        total: "transfer_total"
    },
    {
        label: "owner",
        value: "owner",
        url: "ERC20Owner",
        total: "owner_total"
    },
    // {
    //     label: (tr:any) => {
    //         return <span className="flex-center">
    //             { getSvgIcon('successIcon') }
    //              { tr('domain')}
    //             </span>
    //     }, value: 'domain', links: 'FnsDomainDetail'
    // },
    {
        label: "dex",
        value: "dex",
        url: "ERC20DexTrade",
        total: "dex_total"
    }
];
const token = {
    title: "token_list",
    columns: [
        {
            dataIndex: "rank",
            title: "rank",
            render: (text, record, index)=>{
                return index + 1;
            }
        },
        {
            dataIndex: "token_name",
            title: "token_name",
            render: (text, record)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    href: `/token/${record.contract_id}`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                            className: "fvm_img_url",
                            src: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .getImgUrl */ .wD)(text),
                            alt: "",
                            height: 38,
                            width: 38
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "margin-6",
                            children: [
                                " ",
                                text.toLocaleUpperCase()
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "total_supply",
            title: "total_supply",
            render: (text)=>{
                return text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 4) : "--";
            }
        },
        {
            dataIndex: "vol_24",
            title: "vol_24",
            render: (text)=>text ? text + " FIL" : "--"
        },
        {
            dataIndex: "latest_price",
            title: "latest_price",
            render: (text)=>text ? text + " FIL" : "--"
        },
        {
            dataIndex: "market_cap",
            title: "market_value",
            render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 4) + " FIL" : "--"
        },
        {
            dataIndex: "owners",
            title: "owners"
        }
    ]
};
const transfer_columns = [
    {
        dataIndex: "cid",
        title: "message_cid",
        render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                href: `/message/${text}`,
                className: "link",
                children: text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 6) : ""
            }) : "--"
    },
    {
        dataIndex: "method",
        title: "method"
    },
    {
        dataIndex: "time",
        title: "time",
        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
    },
    {
        dataIndex: "from",
        title: "from",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_2__/* .get_account_type */ .$B)(record.from_type, text)
    },
    {
        dataIndex: "to",
        title: "to",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_2__/* .get_account_type */ .$B)(record.from_type, text)
    },
    {
        dataIndex: "amount",
        title: "amount",
        render: (text, record)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 4) : text || "--"
    }
];
const owner_columns = [
    {
        dataIndex: "rank",
        title: "rank"
    },
    {
        dataIndex: "owner",
        title: "owner"
    },
    {
        dataIndex: "amount",
        title: "amount",
        render: (text, record)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 4) : text || "--"
    },
    {
        dataIndex: "rate",
        title: "percentage",
        render: (text, record)=>text ? Number(text).toFixed(4) + "%" : text || "--"
    },
    {
        dataIndex: "value",
        title: "Value",
        render: (text)=>text ? text + " FIL" : ""
    }
];
const Dex_columns = [
    {
        dataIndex: "cid",
        title: "message_cid",
        render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                href: `/message/${text}`,
                className: "link",
                children: text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 6) : ""
            }) : "--"
    },
    {
        dataIndex: "time",
        title: "time",
        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
    },
    {
        dataIndex: "action",
        title: "Action",
        render: (text)=>{
            const color = text === "buy" ? "green" : "red";
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                style: {
                    color
                },
                children: text ? text[0].toUpperCase() + text.substr(1) : text
            });
        }
    },
    {
        dataIndex: "amount_out",
        title: "Token_Amount_out",
        render: (text, record)=>{
            return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 4) + " " + (record === null || record === void 0 ? void 0 : record.amount_out_token_name);
        }
    },
    {
        dataIndex: "amount_in",
        title: "Token_Amount_in",
        render: (text, record)=>{
            return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 4) + " " + (record === null || record === void 0 ? void 0 : record.amount_in_token_name);
        }
    },
    {
        dataIndex: "swap_rate",
        title: "swapped_Rate",
        render: (text)=>text ? text + " FIL" : ""
    },
    {
        dataIndex: "value",
        title: "Txn_Value",
        render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 4) + " FIL" : ""
    },
    {
        dataIndex: "dex",
        title: "platform",
        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                className: "fvm_img_url",
                alt: "",
                width: 25,
                height: 25,
                src: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .getImgUrl */ .wD)(text)
            })
    }
];
const getContractColumns = (active)=>{
    if (active === "transfer") {
        return transfer_columns;
    } else if (active === "owner") {
        return owner_columns;
    } else if (active === "dex") {
        return Dex_columns;
    }
};
const nfts = {
    title: "nfts_list",
    columns: [
        {
            dataIndex: "rank",
            title: "rank",
            render: (text, record, index)=>{
                return index + 1;
            }
        },
        {
            dataIndex: "collection",
            title: "Collection",
            render: (text, record)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    href: `/nft/${text}`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                            className: "fvm_img_url",
                            src: record.icon,
                            alt: "",
                            height: 38,
                            width: 38
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "margin-6",
                            children: [
                                " ",
                                text.toLocaleUpperCase()
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "trading_volume",
            title: "trading_volume",
            render: (text)=>{
                return text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 4) : "--";
            }
        },
        {
            dataIndex: "holders",
            title: "owners"
        },
        {
            dataIndex: "transfers",
            title: "transfers",
            render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 4) : "--"
        }
    ]
};
const nfts_market = {
    title: {
        label: "market"
    },
    content: [
        {
            title: "token_contract",
            dataIndex: "contract"
        }
    ]
};
const nft_transfer_columns = [
    {
        dataIndex: "cid",
        title: "message_cid",
        render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                href: `/message/${text}`,
                className: "link",
                children: text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 6) : ""
            }) : "--"
    },
    {
        dataIndex: "method",
        title: "method"
    },
    {
        dataIndex: "time",
        title: "time",
        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
    },
    {
        dataIndex: "from",
        title: "from",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_2__/* .get_account_type */ .$B)(record.from_type, text)
    },
    {
        dataIndex: "to",
        title: "to",
        render: (text, record)=>(0,_varible__WEBPACK_IMPORTED_MODULE_2__/* .get_account_type */ .$B)(record.from_type, text)
    },
    {
        dataIndex: "item",
        title: "item",
        render: (text, record)=>text || "--"
    }
];
const nft_owner_columns = [
    {
        dataIndex: "rank",
        title: "rank"
    },
    {
        dataIndex: "owner",
        title: "owner"
    },
    {
        dataIndex: "amount",
        title: "amount",
        render: (text, record)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 4) : text || "--"
    },
    {
        dataIndex: "percentage",
        title: "percentage",
        render: (text, record)=>text ? Number(text).toFixed(4) + "%" : text || "--"
    }
];
const nft_tabs = [
    {
        label: "transfer",
        value: "transfer",
        url: "FnsTransfers",
        total: "transfer_total"
    },
    {
        label: "owner",
        value: "owner",
        url: "FnsOwners",
        total: "owner_total"
    }
];
const getNftsColumns = (active)=>{
    if (active === "transfer") {
        return nft_transfer_columns;
    } else if (active === "owner") {
        return nft_owner_columns;
    } else if (active === "dex") {
        return Dex_columns;
    }
};
const detail = {
    title: {
        label: "detail_title"
    },
    tabs: [
        {
            label: "in_transaction",
            value: "transaction"
        }
    ]
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
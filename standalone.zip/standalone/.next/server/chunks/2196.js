"use strict";
exports.id = 2196;
exports.ids = [2196];
exports.modules = {

/***/ 8197:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/TokenPocket.885f5773.png","height":1024,"width":1024,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAsUlEQVR42jVOuw4BARDcWqMStYTEIxR8h6/xSjju0V5P6QNEQeIDNDQ6xSUUEgoSz8RF4mQm9k4ks5vszszuSM5iPkLBYsVhyWbZoS5FK2FAEetA6pAWpIGQ0GGxpv/i9sDxnI9n2KUJiRtoDRl8OFvyfOfxwnfAqkvR02pSYX/C05U3nyuP0oZkTaRNbPZ0R/R2HEwpNWRMhM+VS3aR6iFpQLW/hOqgcoV/4qLNfCT9ArNpfEXhWTOlAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 7333:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _packages_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9744);
/* harmony import */ var _assets_images_TokenPocket_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8197);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9927);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9140);
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4325);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_utils__WEBPACK_IMPORTED_MODULE_3__, web3__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_6__]);
([_utils_utils__WEBPACK_IMPORTED_MODULE_3__, web3__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ data  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "fevm"
            });
        }
        return t(label, {
            ns: "fevm"
        });
    };
    async function getNetWork() {
        const web3 = new web3__WEBPACK_IMPORTED_MODULE_5__["default"](window.ethereum);
        const chainId = await web3.eth.getChainId();
        return Number(chainId) === 314;
    }
    const addNetwork = async ()=>{
        if (window.ethereum) {
            try {
                const res = await window.ethereum.request({
                    method: "wallet_switchEthereumChain",
                    params: [
                        {
                            chainId: "0x13a"
                        }
                    ]
                });
                return true;
            } catch (e) {
                if (e.code === 4902) {
                    try {
                        const res1 = await window.ethereum.request({
                            method: "wallet_addEthereumChain",
                            params: [
                                {
                                    chainId: "0x13a",
                                    chainName: "Filecoin - Mainnet",
                                    nativeCurrency: {
                                        name: "Mainnet",
                                        symbol: "FIL",
                                        decimals: 18
                                    },
                                    rpcUrls: [
                                        "https://api.node.glif.io/"
                                    ],
                                    blockExplorerUrls: [
                                        "https://filscan.io"
                                    ]
                                }
                            ]
                        });
                        return true;
                    } catch (addError) {
                        console.error(addError);
                    }
                }
            }
        } else {
            // if no window.ethereum then MetaMask is not installed
            alert("MetaMask is not installed. Please consider installing it: https://metamask.io/download.html");
        }
    };
    const handleClick = async ()=>{
        if (!window?.ethereum.isTokenPocket) {
            //dowm wallet 
            window.open(`https://chrome.google.com/webstore/detail/tokenpocket/mfgccjchihfkkindfppnaooecgfneiii?hl=en`);
            window.location.reload();
        } else {
            const chainId = await getNetWork();
            if (!chainId) {
                // 切换网络
                const res = await addNetwork();
                if (res) {
                    return connect_account();
                }
            }
            return connect_account();
        }
    };
    const connect_account = ()=>{
        window.ethereum.request({
            method: "eth_requestAccounts"
        }).then((res)=>{
            addToken(res[0]);
        }).catch((error)=>{
            if (error.code === 4001) {
                console.log("Please connect to TokenPocket Extension.");
            } else {
                console.error(error);
            }
        });
    };
    const addToken = async (address)=>{
        const tokenAddress = data.contract_id;
        const tokenSymbol = data?.tokenName;
        const tokenDecimals = 18;
        const tokenImage = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_3__/* .getImgUrl */ .wD)(data?.token_name);
        try {
            // wasAdded is a boolean. Like any RPC method, an error can be thrown.
            const wasAdded = await window.ethereum.request({
                method: "wallet_watchAsset",
                params: {
                    type: "ERC20",
                    options: {
                        address: tokenAddress,
                        symbol: tokenSymbol,
                        decimals: tokenDecimals,
                        image: tokenImage
                    }
                }
            });
            if (wasAdded) {
                console.log("Thanks for your interest!");
            } else {
                console.log("Your loss!");
            }
        } catch (error) {
            console.log(error);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        title: tr("tp_token"),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            onClick: handleClick,
            src: _assets_images_TokenPocket_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
            width: 18,
            alt: "tp wallet",
            className: "margin-6",
            style: {
                display: "block",
                cursor: "pointer",
                borderRadius: "50%"
            }
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2196:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EJ": () => (/* binding */ ft_tabs),
/* harmony export */   "ES": () => (/* binding */ nft_tabs),
/* harmony export */   "Fq": () => (/* binding */ contract_list),
/* harmony export */   "G_": () => (/* binding */ overview),
/* harmony export */   "JZ": () => (/* binding */ contract_detail),
/* harmony export */   "Jd": () => (/* binding */ fns_overview),
/* harmony export */   "OR": () => (/* binding */ contract_log),
/* harmony export */   "T": () => (/* binding */ verify),
/* harmony export */   "hh": () => (/* binding */ nfts),
/* harmony export */   "jS": () => (/* binding */ getNftsColumns),
/* harmony export */   "kf": () => (/* binding */ contract_rank),
/* harmony export */   "qs": () => (/* binding */ ft_market),
/* harmony export */   "r": () => (/* binding */ token),
/* harmony export */   "s3": () => (/* binding */ verify_tabs),
/* harmony export */   "um": () => (/* binding */ nfts_market),
/* harmony export */   "ve": () => (/* binding */ getContractColumns)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3775);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9927);
/* harmony import */ var _varible__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(697);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _packages_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9744);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9997);
/* harmony import */ var _components_TPWallet__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7333);
/* harmony import */ var _packages_tips__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4950);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_utils__WEBPACK_IMPORTED_MODULE_2__, _varible__WEBPACK_IMPORTED_MODULE_3__, _components_TPWallet__WEBPACK_IMPORTED_MODULE_7__]);
([_utils_utils__WEBPACK_IMPORTED_MODULE_2__, _varible__WEBPACK_IMPORTED_MODULE_3__, _components_TPWallet__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const verify = {
    content: {
        meta_list_des: [
            {
                label: "config_file_des1"
            },
            {
                label: "config_file_des1_1"
            },
            {
                label: "config_file_des1_2"
            },
            {
                label: "config_file_des2"
            },
            {
                label: "config_file_des2_1"
            },
            {
                label: "config_file_des2_2"
            }
        ],
        list: [
            {
                label: "content_des1"
            },
            {
                label: "content_des2"
            },
            {
                label: "content_des3"
            }
        ],
        buttons: [
            {
                label: "source_code",
                className: "custom_border_btn"
            },
            {
                label: "compile_output",
                className: "custom_border_btn"
            }
        ]
    },
    main: {
        header: {
            title: "verify_title",
            des: "verify_des"
        },
        content: {
            des: "content_des",
            list: [
                {
                    type: "Input",
                    dataIndex: "contract_address",
                    title: "address",
                    placeholder: "address_placeholder"
                },
                {
                    type: "Select",
                    title: "verify_address",
                    dataIndex: "compile_version",
                    placeholder: "verify_select_placeholder"
                },
                {
                    type: "Select",
                    title: "license_type",
                    dataIndex: "license",
                    placeholder: "verify_select_placeholder",
                    options: [
                        {
                            label: "No License(None)",
                            value: "No license(None)"
                        },
                        {
                            label: "MIT License(MIT)",
                            value: "MIT license(MIT)"
                        }
                    ]
                }
            ]
        },
        buttons: [
            {
                text: "next",
                className: "active_btn",
                disableList: [
                    "contract_address",
                    "compile_version"
                ]
            },
            {
                text: "reset",
                className: "custom_cancel_btn"
            }
        ]
    },
    contract: {
        header: {
            title: "verify_title",
            des: "step1_verify_des"
        },
        content: {
            list: [
                {
                    type: "Input",
                    disabled: true,
                    dataIndex: "contract_address",
                    title: "address_verify",
                    style: {
                        flex: 1
                    }
                },
                {
                    type: "Input",
                    disabled: true,
                    dataIndex: "compile_version",
                    title: "compile_version",
                    style: {
                        width: "30%"
                    }
                },
                {
                    type: "Select",
                    title: "Optimizations",
                    dataIndex: "optimize",
                    defaultValue: "true",
                    style: {
                        width: "10%"
                    },
                    options: [
                        {
                            label: "Yes",
                            value: "true"
                        },
                        {
                            label: "No",
                            value: "false"
                        }
                    ]
                },
                {
                    type: "Input",
                    title: "run_optimizer",
                    dataIndex: "optimize_runs",
                    defaultValue: 200,
                    style: {
                        width: "15%"
                    }
                }
            ],
            other: [
                {
                    type: "textArea",
                    title: "arguments",
                    style: {
                        textAlign: "left"
                    },
                    dataIndex: "arguments"
                }
            ]
        },
        buttons: [
            {
                text: "confirm",
                loading: true,
                className: "active_btn"
            },
            {
                text: "reset",
                className: "custom_cancel_btn"
            },
            {
                text: "back",
                className: "custom_border_btn"
            }
        ]
    },
    output: {
        title: "byte_code",
        params: [
            {
                dataIndex: "compiler",
                title: "compiler"
            },
            {
                dataIndex: "optimize",
                title: "optimize"
            },
            {
                dataIndex: "optimize_runs",
                title: "optimize_runs"
            }
        ],
        others: [
            {
                title: "contract_name",
                dataIndex: "contract_name",
                style: {
                    height: "36px"
                }
            },
            {
                title: "local_byte_code",
                dataIndex: "local_byte_code"
            }
        ]
    }
};
const verify_tabs = [
    {
        label: "Verify_code",
        value: "Verify_code"
    },
    {
        label: "Verify_read",
        value: "Verify_read"
    },
    {
        label: "Verify_write",
        value: "Verify_write"
    }
];
const overview = {
    title: {
        label: "overview"
    },
    content: [
        {
            title: "total_supply",
            dataIndex: "total_supply",
            render: (text)=>{
                return text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 4) : text || "--";
            }
        },
        {
            title: "owners",
            dataIndex: "owners"
        },
        {
            title: "transfers",
            dataIndex: "transfers"
        }
    ]
};
const fns_overview = {
    title: {
        label: "overview"
    },
    content: [
        {
            title: "Items",
            dataIndex: "total_supply",
            render: (text)=>{
                return text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 4) : text || "--";
            }
        },
        {
            title: "owners",
            dataIndex: "owners"
        },
        {
            title: "transfers",
            dataIndex: "transfers"
        }
    ]
};
const ft_market = {
    title: {
        label: "market"
    },
    content: [
        {
            title: "latest_price",
            dataIndex: "latest_price",
            render: (text)=>text ? "$" + text : "--"
        },
        {
            title: "market_value",
            dataIndex: "market_cap",
            render: (text)=>text ? "$" + (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 4) : text || "--"
        },
        {
            title: "token_contract",
            dataIndex: "contract_id",
            render: (text, record)=>{
                if (text) {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: `/address/${text}`,
                                className: "link",
                                children: text
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                text: text
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_TPWallet__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                data: record
                            })
                        ]
                    });
                }
                return "--";
            }
        }
    ]
};
const ft_tabs = [
    {
        label: "transfer",
        value: "transfer",
        url: "ERC20Transfer",
        total: "transfer_total"
    },
    {
        label: "owner",
        value: "owner",
        url: "ERC20Owner",
        total: "owner_total"
    },
    // {
    //     label: (tr:any) => {
    //         return <span className="flex-center">
    //             { getSvgIcon('successIcon') }
    //              { tr('domain')}
    //             </span>
    //     }, value: 'domain', links: 'FnsDomainDetail'
    // },
    {
        label: "dex",
        value: "dex",
        url: "ERC20DexTrade",
        total: "dex_total"
    }
];
const token = {
    title: "token_list",
    columns: (tr)=>[
            {
                dataIndex: "rank",
                title: "rank",
                render: (text, record, index)=>{
                    return index + 1;
                }
            },
            {
                dataIndex: "token_name",
                title: "token_name",
                render: (text, record)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: `/token/${record.contract_id}`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                className: "fvm_img_url",
                                src: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .getImgUrl */ .wD)(text),
                                alt: "",
                                height: 38,
                                width: 38
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "margin-6",
                                children: text
                            })
                        ]
                    });
                }
            },
            {
                dataIndex: "total_supply",
                title: ()=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex_align_center",
                        children: [
                            tr("total_supply"),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tips__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                context: tr("total_supply_tip")
                            })
                        ]
                    });
                },
                render: (text)=>{
                    return text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 4) : "--";
                }
            },
            {
                dataIndex: "vol_24",
                title: "vol_24",
                render: (text)=>text ? "$" + (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 4) : "--"
            },
            {
                dataIndex: "latest_price",
                title: "latest_price",
                render: (text)=>text ? "$" + text : "--"
            },
            {
                dataIndex: "market_cap",
                title: "market_value",
                render: (text)=>text ? "$" + (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 4) : "--"
            },
            {
                dataIndex: "owners",
                title: "owners"
            }
        ]
};
const transfer_columns = (fromList, toList)=>{
    return [
        {
            dataIndex: "cid",
            title: "message_cid",
            render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    href: `/message/${text}`,
                    className: "link",
                    children: text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6) : ""
                }) : "--"
        },
        {
            dataIndex: "method",
            title: "method",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "bg-render",
                    children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .titleCase */ .Qs)(text)
                })
        },
        {
            dataIndex: "time",
            title: "time",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
        },
        {
            dataIndex: "from",
            title: "from",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "table_li",
                    children: [
                        (0,_varible__WEBPACK_IMPORTED_MODULE_3__/* .get_account_type */ .$B)(record.from_type, text),
                        fromList?.domains && fromList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            href: `/domain/${fromList.domains[text]}?provider=${fromList.provider}`,
                            children: [
                                "(",
                                fromList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "to",
            title: "to",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "table_li",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: (0,_varible__WEBPACK_IMPORTED_MODULE_3__/* .get_account_type */ .$B)(record.to_type, text)
                        }),
                        toList?.domains && toList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            href: `/domain/${toList.domains[text]}?provider=${toList.provider}`,
                            children: [
                                "(",
                                toList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "amount",
            title: "amount",
            render: (text, record)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 4) : text || "--"
        }
    ];
};
const owner_columns = (fromList)=>{
    return [
        {
            dataIndex: "rank",
            title: "rank"
        },
        {
            dataIndex: "owner",
            title: "owner",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "table_li",
                    children: [
                        text,
                        fromList?.domains && fromList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            href: `/domain/${fromList.domains[text]}?provider=${fromList.provider}`,
                            children: [
                                "(",
                                fromList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "amount",
            title: "amount",
            render: (text, record)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 4) : text || "--"
        },
        {
            dataIndex: "rate",
            title: "percentage",
            render: (text, record)=>text ? Number(text).toFixed(4) + "%" : text || "--"
        },
        {
            dataIndex: "value",
            title: "Value",
            render: (text)=>text ? "$ " + (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 4) : ""
        }
    ];
};
const Dex_columns = [
    {
        dataIndex: "cid",
        title: "message_cid",
        render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                href: `/message/${text}`,
                className: "link",
                children: text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6) : ""
            }) : "--"
    },
    {
        dataIndex: "time",
        title: "time",
        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
    },
    {
        dataIndex: "action",
        title: "Action",
        render: (text)=>{
            const color = text === "buy" ? "green" : text === "sell" ? "red" : "";
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                style: {
                    color
                },
                children: text ? text[0].toUpperCase() + text.substr(1) : text
            });
        }
    },
    {
        dataIndex: "amount_out",
        title: "Token_Amount_out",
        render: (text, record)=>{
            return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 4) + " " + record?.amount_out_token_name;
        }
    },
    {
        dataIndex: "amount_in",
        title: "Token_Amount_in",
        render: (text, record)=>{
            return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 4) + " " + record?.amount_in_token_name;
        }
    },
    {
        dataIndex: "swap_rate",
        title: "swapped_Rate",
        render: (text, record)=>text ? text + " " + record.swap_token_name : ""
    },
    {
        dataIndex: "value",
        title: "Txn_Value",
        render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .get$Number */ .Uy)(text)
    },
    {
        dataIndex: "dex",
        title: "platform",
        render: (text, record)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "link",
                onClick: ()=>{
                    if (record.dex_url) {
                        window.open(record.dex_url);
                    }
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    className: "fvm_img_url",
                    alt: "",
                    width: 25,
                    height: 25,
                    src: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .getImgUrl */ .wD)(text)
                })
            });
        }
    }
];
const getContractColumns = (active, fromList, toList)=>{
    if (active === "transfer") {
        return transfer_columns(fromList, toList);
    } else if (active === "owner") {
        return owner_columns(fromList);
    } else if (active === "dex") {
        return Dex_columns;
    }
};
const nfts = {
    title: "nfts_list",
    columns: (active, lang)=>{
        return [
            {
                dataIndex: "rank",
                title: "rank",
                render: (text, record, index)=>{
                    return index + 1;
                }
            },
            {
                dataIndex: "collection",
                title: "Collection",
                render: (text, record)=>{
                    //   const activeLink: any = active[text.toLocaleUpperCase().replaceAll(' ', '')];    
                    //   const showLang = lang === 'zh' ? 'zh' : 'en';// 存在韩语
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex_align_center",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            href: `/nft/${record.provider}`,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    className: "fvm_img_url",
                                    src: record.icon,
                                    alt: "",
                                    height: 38,
                                    width: 38
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "margin-6",
                                    children: [
                                        " ",
                                        text
                                    ]
                                })
                            ]
                        })
                    }, text + lang);
                }
            },
            // {
            //       dataIndex: 'trading_volume', title: 'trading_volume', render: (text: string | number) => { 
            //       return text? formatNumber(text,4) : '--'
            //       }
            //   },
            {
                dataIndex: "holders",
                title: "owners"
            },
            {
                dataIndex: "transfers",
                title: "transfers",
                render: (text)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 4) : "--"
            }
        ];
    }
};
const nfts_market = {
    title: {
        label: "market"
    },
    content: [
        {
            title: "token_contract",
            dataIndex: "contract",
            render: (text)=>{
                if (text) {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: `/address/${text}`,
                                className: "link",
                                children: text
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                text: text
                            })
                        ]
                    });
                }
                return "--";
            }
        }
    ]
};
const nft_transfer_columns = (fromList, toList)=>{
    return [
        {
            dataIndex: "cid",
            title: "message_cid",
            render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    href: `/message/${text}`,
                    className: "link",
                    children: text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6) : ""
                }) : "--"
        },
        {
            dataIndex: "method",
            title: "method",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "bg-render",
                    children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .titleCase */ .Qs)(text)
                })
        },
        {
            dataIndex: "time",
            title: "time",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
        },
        {
            dataIndex: "from",
            title: "from",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "table_li",
                    children: [
                        (0,_varible__WEBPACK_IMPORTED_MODULE_3__/* .get_account_type */ .$B)(record.from_type, text),
                        fromList?.domains && fromList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            href: `/domain/${fromList.domains[text]}?provider=${fromList.provider}`,
                            children: [
                                "(",
                                fromList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "to",
            title: "to",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "table_li",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: (0,_varible__WEBPACK_IMPORTED_MODULE_3__/* .get_account_type */ .$B)(record.to_type, text)
                        }),
                        toList?.domains && toList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            href: `/domain/${toList.domains[text]}?provider=${toList.provider}`,
                            children: [
                                "(",
                                toList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "item",
            title: "item",
            render: (text, record)=>{
                if (record.url) {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        className: "fvm_img_url",
                        alt: "",
                        width: 25,
                        height: 25,
                        src: record.url
                    });
                }
                return text || "--";
            }
        }
    ];
};
const nft_owner_columns = (fromList, toList)=>{
    return [
        {
            dataIndex: "rank",
            title: "rank"
        },
        {
            dataIndex: "owner",
            title: "owner",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "table_li",
                    children: [
                        text,
                        fromList?.domains && fromList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            href: `/domain/${fromList.domains[text]}?provider=${fromList.provider}`,
                            children: [
                                "(",
                                fromList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "amount",
            title: "amount",
            render: (text, record)=>text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 4) : text || "--"
        },
        {
            dataIndex: "percentage",
            title: "percentage",
            render: (text, record)=>text ? Number(Number(text) * 100).toFixed(4) + "%" : text || "--"
        }
    ];
};
const nft_tabs = [
    {
        label: "transfer",
        value: "transfer",
        url: "NFTTransfers",
        total: "transfer_total"
    },
    {
        label: "owner",
        value: "owner",
        url: "NFTOwners",
        total: "owner_total"
    }
];
const getNftsColumns = (active, fromList, toList)=>{
    if (active === "transfer") {
        return nft_transfer_columns(fromList, toList);
    } else if (active === "owner") {
        return nft_owner_columns(fromList, toList);
    } else if (active === "dex") {
        return Dex_columns;
    }
};
// contract list 
const contract_list = {
    title: "contract_list",
    total: "contract_list_total",
    columns: [
        {
            dataIndex: "contract_address",
            title: "contract_address",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    className: "link",
                    href: `/address/${text}`,
                    children: text
                });
            }
        },
        {
            dataIndex: "contract_name",
            title: "contract_name",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    href: `/address/${record.contract_address}`,
                    children: text
                });
            }
        },
        {
            dataIndex: "language",
            title: "language"
        },
        {
            dataIndex: "compiler",
            title: "compile_version"
        },
        {
            dataIndex: "optimize_runs",
            title: "Optimizations"
        },
        {
            dataIndex: "license",
            title: "license",
            render: (text)=>text || "No License(None)"
        }
    ]
};
const contract_rank = {
    title: "contract_rank",
    title_des: "contract_rank_des",
    options: [
        {
            label: "transaction_count",
            value: "transfer_count"
        },
        {
            label: "actor_balance",
            value: "actor_balance"
        },
        {
            label: "gas_cost",
            value: "gas_cost"
        },
        {
            label: "user_count",
            value: "user_count"
        }
    ],
    total_msg: "contract_rank_total",
    columns: [
        {
            dataIndex: "rank",
            title: "rank",
            width: "5%"
        },
        {
            dataIndex: "contract_address",
            width: "15%",
            title: "contract_address",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    className: "link",
                    href: `/address/${text}`,
                    children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 8)
                });
            }
        },
        {
            dataIndex: "contract_name",
            title: "contract_name"
        },
        {
            dataIndex: "transfer_count",
            width: "15%",
            title: "transaction_count",
            sorter: true,
            defaultSortOrder: "descend",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text)
        },
        {
            dataIndex: "user_count",
            width: "15%",
            title: "user_count",
            sorter: true,
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text)
        },
        {
            dataIndex: "actor_balance",
            width: "15%",
            title: "actor_balance",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text),
            sorter: true
        },
        {
            dataIndex: "gas_cost",
            width: "15%",
            title: "gas_cost",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text),
            sorter: true
        }
    ]
};
const contract_detail = {
    overview: {
        title: (tr)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex_align_center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "success_color",
                        children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("successIcon")
                    }),
                    tr("verify_contract")
                ]
            }),
        list: [
            [
                {
                    dataIndex: "contract_name",
                    title: "contract_name"
                },
                {
                    dataIndex: "optimize",
                    title: "optimize",
                    render: (text, record)=>{
                        return text ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .titleCase */ .Qs)(text) + ` with (${record.optimize_runs}) runs` : (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .titleCase */ .Qs)(text);
                    }
                }
            ],
            [
                {
                    dataIndex: "compiler",
                    title: "compiler"
                },
                {
                    dataIndex: "license",
                    title: "license"
                }
            ]
        ]
    },
    code: {
        title: "source_code",
        content: "source_code",
        copy: true,
        link: true
    },
    abi: {
        title: "source_abi",
        copy: "true",
        options: {
            placeholder: "source_abi_default",
            list: [
                {
                    label: "Json_Format",
                    value: "json"
                },
                {
                    label: "Text_Format",
                    value: "text"
                }
            ]
        },
        text: "ABI"
    },
    byte_code: {
        noVerify: "byte_code_no_verify",
        title: "source_code_create",
        copy: "true",
        text: "byte_code"
    }
};
const contract_log = [
    {
        dataIndex: "epoch",
        label: "epoch"
    },
    {
        dataIndex: "cid",
        label: "cid",
        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                href: `/message/${text}`,
                className: "link",
                children: text
            })
    },
    {
        dataIndex: "event_name",
        label: "event_name"
    },
    {
        dataIndex: "topics",
        label: "topics",
        render: (text, record)=>{
            if (Array.isArray(text)) {
                return text.map((item, index)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: "array_item",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "array_item_icon",
                                children: index
                            }),
                            item
                        ]
                    }, item);
                });
            }
            return text || "--";
        }
    },
    {
        dataIndex: "data",
        label: "coompoent_data",
        render: (text)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-render",
                children: text
            });
        }
    },
    {
        dataIndex: "log_index",
        label: "log_index",
        render: (text)=>text
    },
    {
        dataIndex: "removed",
        label: "removed",
        render: (text)=>String(text)
    }
];

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9744:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9189);




const ImageWithFallback = (props)=>{
    const { src , fallbackSrc =_contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .fvmUrl */ .d + `/images/default.png` , ...rest } = props;
    const [imgSrc, setImgSrc] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(src);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setImgSrc(src);
    }, [
        src
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        ...rest,
        src: imgSrc,
        onError: ()=>{
            setImgSrc(fallbackSrc);
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageWithFallback);


/***/ })

};
;
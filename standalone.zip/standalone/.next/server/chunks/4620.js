"use strict";
exports.id = 4620;
exports.ids = [4620];
exports.modules = {

/***/ 4620:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7003);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9189);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(697);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8194);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1311);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9927);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_echarts__WEBPACK_IMPORTED_MODULE_1__, _contants_varible__WEBPACK_IMPORTED_MODULE_3__, _store_server__WEBPACK_IMPORTED_MODULE_5__, _utils_utils__WEBPACK_IMPORTED_MODULE_6__, react_i18next__WEBPACK_IMPORTED_MODULE_9__]);
([_components_echarts__WEBPACK_IMPORTED_MODULE_1__, _contants_varible__WEBPACK_IMPORTED_MODULE_3__, _store_server__WEBPACK_IMPORTED_MODULE_5__, _utils_utils__WEBPACK_IMPORTED_MODULE_6__, react_i18next__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_8__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z);
    const { address , type , list , interval  } = props;
    const color = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return (0,_contants_varible__WEBPACK_IMPORTED_MODULE_3__/* .getColor */ .Lq)(filscanStore.filscan.theme);
    }, [
        filscanStore.filscan.theme
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return {
            ...(0,_contants_varible__WEBPACK_IMPORTED_MODULE_3__/* .defaultOpt */ .Re)("line", filscanStore.filscan.theme),
            yAxis: {
                type: "value",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle,
                    align: "left"
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                axisLabel: {
                    show: true,
                    lineStyle: {
                        color: color.lineStyle
                    },
                    textStyle: {
                        color: color.textStyle
                    },
                    formatter (v) {
                        return v + " FIL";
                    }
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            tooltip: {
                trigger: "axis",
                position: "right",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (p) {
                    let result = p[0].data.showTime || p[0].name;
                    p.forEach((item, index)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + item.seriesName + ": " + item.data.amount + " " + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    }, [
        filscanStore.filscan.theme
    ]);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_9__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "detail"
        });
    };
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({});
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (address) {
            (0,_store_server__WEBPACK_IMPORTED_MODULE_5__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .apiUrl.account_change */ .J.account_change, {
                account_id: address,
                filters: {
                    interval: interval,
                    account_type: type
                }
            }).then((res)=>{
                const seriesObj = {
                    available_balance: [],
                    pre_deposits: [],
                    locked_balance: [],
                    init_pledge: [],
                    balance: []
                };
                let newOpt = {
                    ...defaultOptions
                };
                newOpt.series = [];
                const timeData = [];
                res?.result?.balance_trend_by_account_id_list?.reverse()?.forEach((value)=>{
                    if (value) {
                        const { block_time , available_balance , balance , precommit_deposits , locked_funds , initial_pledge  } = value;
                        let showTime = "";
                        showTime = interval === "24h" ? dayjs__WEBPACK_IMPORTED_MODULE_7___default()(block_time * 1000).format("HH:mm") : dayjs__WEBPACK_IMPORTED_MODULE_7___default()(block_time * 1000).format("YYYY-MM-DD HH:mm");
                        timeData.push(showTime);
                        const [balance_amount, balance_unit] = balance ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFilNum */ .Nm)(balance, false, false, 4, false)?.split(" ") : [];
                        const [available_balance_amount, available_balance_unit] = available_balance ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFilNum */ .Nm)(available_balance, false, false, 4, false)?.split(" ") : [];
                        const [precommit_deposits_amount, precommit_deposits_unit] = precommit_deposits ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFilNum */ .Nm)(precommit_deposits, false, false, 4, false)?.split(" ") : [];
                        const [locked_funds_amount, locked_funds_unit] = locked_funds ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFilNum */ .Nm)(locked_funds, false, false, 4, false)?.split(" ") : [];
                        const [initial_pledge_amount, initial_pledge_unit] = initial_pledge ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFilNum */ .Nm)(initial_pledge, false, false, 4, false)?.split(" ") : [];
                        if (available_balance) {
                            seriesObj.available_balance.push({
                                amount: available_balance_amount,
                                value: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(available_balance, "FIL", 4),
                                unit: available_balance_unit,
                                showTime: dayjs__WEBPACK_IMPORTED_MODULE_7___default()(block_time * 1000).format("YYYY-MM-DD HH:mm:ss")
                            });
                        }
                        if (precommit_deposits) {
                            seriesObj.pre_deposits.push({
                                amount: precommit_deposits_amount,
                                value: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(precommit_deposits, "FIL", 4),
                                unit: precommit_deposits_unit,
                                showTime: dayjs__WEBPACK_IMPORTED_MODULE_7___default()(block_time * 1000).format("YYYY-MM-DD HH:mm:ss")
                            });
                        }
                        if (locked_funds) {
                            seriesObj.locked_balance.push({
                                amount: locked_funds_amount,
                                value: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(locked_funds, "FIL", 4),
                                unit: locked_funds_unit,
                                showTime: dayjs__WEBPACK_IMPORTED_MODULE_7___default()(block_time * 1000).format("YYYY-MM-DD HH:mm:ss")
                            });
                        }
                        if (initial_pledge) {
                            seriesObj.init_pledge.push({
                                amount: initial_pledge_amount,
                                value: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(initial_pledge, "FIL", 4),
                                unit: initial_pledge_unit,
                                showTime: dayjs__WEBPACK_IMPORTED_MODULE_7___default()(block_time * 1000).format("YYYY-MM-DD HH:mm:ss")
                            });
                        }
                        if (balance) {
                            seriesObj.balance.push({
                                amount: balance_amount,
                                value: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(balance, "FIL", 4),
                                unit: balance_unit,
                                showTime: dayjs__WEBPACK_IMPORTED_MODULE_7___default()(block_time * 1000).format("YYYY-MM-DD HH:mm:ss")
                            });
                        }
                    }
                });
                const legendList = [];
                list.forEach((item)=>{
                    legendList.push(tr(item.label));
                    const dataIndex = item?.dataIndex || item.label;
                    newOpt.series.push({
                        type: item.type,
                        smooth: true,
                        data: seriesObj[dataIndex],
                        name: tr(item.label),
                        symbol: "circle",
                        barMaxWidth: "30"
                    });
                });
                newOpt.legend.data = legendList;
                newOpt.xAxis.data = timeData;
                setOptions(newOpt);
            });
        }
    }, [
        address,
        interval,
        filscanStore.filscan.theme
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        className: "chart_content",
        propsOption: {
            ...options
        }
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
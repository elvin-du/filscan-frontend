"use strict";
exports.id = 697;
exports.ids = [697];
exports.modules = {

/***/ 9997:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3775);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var copy_to_clipboard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8887);
/* harmony import */ var copy_to_clipboard__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(copy_to_clipboard__WEBPACK_IMPORTED_MODULE_3__);




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ text , icon , className  })=>{
    const handleClick = ()=>{
        //copynavigator
        copy_to_clipboard__WEBPACK_IMPORTED_MODULE_3___default()(text);
        return antd__WEBPACK_IMPORTED_MODULE_2__.message.success("clipboard successfully");
    // navigator?.clipboard?.writeText(text).then(function() {
    //     /* clipboard successfully set */
    //     message.success('clipboard successfully')
    //     }, function() {
    //     /* clipboard write failed */
    //     message.warning('clipboard failed')
    //     });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        style: {
            cursor: "pointer",
            color: "rgb(154,154,154)"
        },
        className: `flex-center ${className}`,
        onClick: handleClick,
        children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)(icon || "copy")
    });
});


/***/ }),

/***/ 697:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$B": () => (/* binding */ get_account_type),
/* harmony export */   "Lq": () => (/* binding */ getColor),
/* harmony export */   "O9": () => (/* binding */ colors),
/* harmony export */   "P5": () => (/* binding */ pageLimit),
/* harmony export */   "Re": () => (/* binding */ defaultOpt)
/* harmony export */ });
/* unused harmony export account_link */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9927);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1311);
/* harmony import */ var _apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9189);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9997);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_utils__WEBPACK_IMPORTED_MODULE_1__, _store_server__WEBPACK_IMPORTED_MODULE_2__]);
([_utils_utils__WEBPACK_IMPORTED_MODULE_1__, _store_server__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






//base charts colors
const colors = [
    "#F7C739",
    "#5AD8A6",
    "#5B8FF9",
    "#9270CA"
];
const lightStyle = {
    lineStyle: "rgba(0,0,0,0.15)",
    splitLine: "rgba(0,0,0,0.15)",
    textStyle: "#000000",
    itemBorder: "#ffffff",
    toolbox: "rgba(0,0,0,0.4)"
};
const blackStyle = {
    lineStyle: "rgba(255,255,255,0.15)",
    splitLine: "rgba(255,255,255,0.15)",
    textStyle: "#ffffff",
    itemBorder: "#ffffff",
    toolbox: "rgba(0,0,0,0.4)"
};
const defaultOpt = (type, theme = "light")=>{
    const color = getColor(theme);
    switch(type){
        case "line":
            return {
                xAxis: {
                    type: "category",
                    axisLabel: {
                        textStyle: {
                            color: color.textStyle
                        }
                    },
                    axisLine: {
                        lineStyle: {
                            color: color.splitLine
                        }
                    },
                    lightStyle: {
                        color: color.lineStyle
                    },
                    axisTick: {
                        show: false
                    },
                    data: []
                },
                legend: {
                    // data: this.tr("yAxisName"),
                    lineStyle: {
                        color: "#ffffff"
                    },
                    textStyle: {
                        // fontSize: this.fontSize,
                        color: color.textStyle
                    },
                    formatter (v) {
                        return v;
                    },
                    icon: "circle"
                }
            };
    }
};
const getColor = (theme)=>{
    return theme === "light" ? lightStyle : blackStyle;
};
const pageLimit = 20;
//不同账户 ,
const get_account_type = (type, value = "", unit = 6)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex_align_center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "link",
                onClick: ()=>{
                    account_link(value, type);
                },
                children: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(value, (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__/* .isMobile */ .tq)() ? 6 : unit)
            }),
            value && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                text: value
            })
        ]
    });
};
const account_link = async (value, type)=>{
    let show_type = type;
    if (!type || type === "") {
        const result = await (0,_store_server__WEBPACK_IMPORTED_MODULE_2__/* .postAxios */ .xW)(_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl.searchInfo */ .J.searchInfo, {
            input: value
        });
        show_type = result?.result?.result_type;
    }
    switch(show_type){
        case "miner":
            return next_router__WEBPACK_IMPORTED_MODULE_4___default().push(`/miner/${value}`);
        case "storageminer":
            return next_router__WEBPACK_IMPORTED_MODULE_4___default().push(`/miner/${value}`);
        default:
            return next_router__WEBPACK_IMPORTED_MODULE_4___default().push(`/address/${value}`);
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
exports.id = 2670;
exports.ids = [2670];
exports.modules = {

/***/ 6954:
/***/ ((module) => {

// Exports
module.exports = {
	"banner_wrap": "banner_banner_wrap__Nf_Ci",
	"banner_wrap_icon": "banner_banner_wrap_icon___QHnI",
	"banner_wrap_leftIcon": "banner_banner_wrap_leftIcon__IbUfs",
	"banner_wrap_rightIcon": "banner_banner_wrap_rightIcon__M27UO"
};


/***/ }),

/***/ 2670:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9189);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6954);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);







function Banner({ banner =[] , lang  }) {
    var _ref;
    const carousel = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(banner);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        setData(banner);
    }, [
        banner
    ]);
    const showLang = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        return lang === "kr" ? "en" : lang;
    }, [
        lang
    ]);
    if (data.length === 0) {
        return null;
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().banner_wrap),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().banner_wrap_icon)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().banner_wrap_leftIcon)}`,
                onClick: ()=>{
                    if (carousel.current) {
                        var _carousel_current;
                        carousel === null || carousel === void 0 ? void 0 : (_carousel_current = carousel.current) === null || _carousel_current === void 0 ? void 0 : _carousel_current.prev();
                    }
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__.LeftOutlined, {
                    rev: undefined
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Carousel, {
                dots: false,
                arrows: true,
                autoplay: true,
                ref: carousel,
                className: "custom-carousel",
                children: (_ref = [
                    ...data
                ]) === null || _ref === void 0 ? void 0 : _ref.map((item, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: ()=>{
                            if (item.link) {
                                window.open(item.link);
                            }
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Image, {
                            preview: false,
                            src: `${_contants_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .fvmUrl */ .d}/banner/image/${showLang}/${item.pic}`,
                            alt: "",
                            width: "100%"
                        })
                    }, index);
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().banner_wrap_icon)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().banner_wrap_rightIcon)}`,
                onClick: ()=>{
                    if (carousel.current) {
                        var _carousel_current;
                        carousel === null || carousel === void 0 ? void 0 : (_carousel_current = carousel.current) === null || _carousel_current === void 0 ? void 0 : _carousel_current.next();
                    }
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__.RightOutlined, {
                    rev: undefined
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Banner);


/***/ })

};
;
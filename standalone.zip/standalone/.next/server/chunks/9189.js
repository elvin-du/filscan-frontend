"use strict";
exports.id = 9189;
exports.ids = [9189];
exports.modules = {

/***/ 9189:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ apiUrl),
/* harmony export */   "d": () => (/* binding */ fvmUrl)
/* harmony export */ });
const mianUrl = "https://api-v2.filscan.io/api/v1";
const fvmUrl = "https://filscan-v2.oss-accelerate.aliyuncs.com/fvm_manage";
const testUrl = "http://192.168.19.3:17000/api/v1";
const apiUrl = {
    searchInfo: mianUrl + "/SearchInfo",
    home_meta: mianUrl + "/TotalIndicators",
    line_trend: mianUrl + "/BaseLineTrend",
    static_gas: mianUrl + "/BaseFeeTrend",
    static_gas_24: mianUrl + "/GasDataTrend",
    static_fil_chart: mianUrl + "/FilCompose",
    static_block_trend: mianUrl + "/BlockRewardTrend",
    static_active_miner: mianUrl + "/ActiveMinerTrend",
    static_message_trend: mianUrl + "/MessageCountTrend",
    rank_pool: mianUrl + "/OwnerRank",
    rank_provider: mianUrl + "/MinerRank",
    rank_growth: mianUrl + "/MinerPowerRank",
    rank_rewards: mianUrl + "/MinerRewardRank",
    tipset_chain: mianUrl + "/LatestBlocks",
    tipset_chain_FinalHeight: mianUrl + "/FinalHeight",
    tipset_BlockDetails: mianUrl + "/BlockDetails",
    tipset_Block_meaages: mianUrl + "/MessagesByBlock",
    tipset_message_opt: mianUrl + "/AllMethods",
    tipset_message_pool_opt: mianUrl + "/AllMethodsByMessagePool",
    tipset_block_message_opt: mianUrl + "/AllMethodsByBlock",
    tipset_message: mianUrl + "/LatestMessages",
    tipset_address: mianUrl + "/RichAccountRank",
    tipset_transfer: mianUrl + "/LargeTransfers",
    tipset_Dsn: mianUrl + "/SearchMarketDeals",
    tipset_pool: mianUrl + "/MessagesPool",
    detail_account: mianUrl + "/AccountInfoByID",
    detail_owner: mianUrl + "/AccountOwnerByID",
    detail_message: mianUrl + "/MessageDetails",
    detail_message_event: mianUrl + "/EventsInMessage",
    detail_message_trans: mianUrl + "/InternalTransfer",
    detail_miner_list: mianUrl,
    detail_list_method: mianUrl + "/AllMethodByAccountID",
    detail_deal: mianUrl + "/DealDetails",
    account_change: mianUrl + "/BalanceTrendByAccountID",
    account_trend: mianUrl + "/PowerTrendByAccountID",
    detail_Indicators: mianUrl + "/IndicatorsByAccountID",
    contract_verify: mianUrl + "/VerifyContract",
    contract_verify_list: mianUrl + "/VerifiedContractList",
    contract_verify_logs: mianUrl + "/ActorEventsList",
    contract_rank: mianUrl + "/EvmContractList",
    contract_verify_des: mianUrl + "/VerifiedContractByActorID",
    contract_solidity: mianUrl + "/SolidityVersions",
    contract_Licenses: mianUrl + "/Licenses",
    contract_transferInMessage: mianUrl + "/ERC20TransferInMessage",
    contract_transferInMessageNft: mianUrl + "/NFTMessageTransfers",
    contract_swap: mianUrl + "/SwapInfoInMessage",
    contract_ERC20List: mianUrl + "/ERC20List",
    contract_ERC20TokenList: mianUrl + "/ERC20OwnerTokenList",
    contract_ERC20Transfers: mianUrl + "/ERC20AddrTransfers",
    contract_ERC20Summary: mianUrl + "/ERC20Summary",
    contract_ERC20Market: mianUrl + "/ERC20Market",
    contract_detailList: mianUrl,
    contract_nfts: mianUrl + "/NFTTokens",
    contract_fnsUrl: mianUrl + "/FnsBindDomains",
    contract_FnsSummary: mianUrl + "/NFTSummary",
    contract_domain: mianUrl + "/FnsDomainDetail",
    contract_domain_address: mianUrl + "/FnsAddressDomains",
    fevm_defiSummary: mianUrl + "/DefiSummary",
    fevm_defiList: mianUrl + "/DefiProtocolList"
};


/***/ })

};
;
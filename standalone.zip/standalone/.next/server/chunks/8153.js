exports.id = 8153;
exports.ids = [8153];
exports.modules = {

/***/ 2533:
/***/ ((module) => {

// Exports
module.exports = {
	"statis": "statistics_statis__D_ZSz",
	"fil": "statistics_fil__M1NJj",
	"fil_chart": "statistics_fil_chart__AB3cD",
	"fil_ul": "statistics_fil_ul__hQwYq",
	"fil_ul_li": "statistics_fil_ul_li___KSLm",
	"fil_ul_li_label": "statistics_fil_ul_li_label__8ZNlH",
	"fil_ul_li_value": "statistics_fil_ul_li_value__7d4Rq",
	"fil_ul_li_des": "statistics_fil_ul_li_des__L4IuY",
	"fil_chart_pie": "statistics_fil_chart_pie__iGZyX",
	"charts": "statistics_charts__sRoot",
	"statis_trend": "statistics_statis_trend__04iTi",
	"statis_trend_title": "statistics_statis_trend_title__PeRcf",
	"statis_chart": "statistics_statis_chart__cDiL3",
	"gas_header": "statistics_gas_header__lw6BR",
	"gas_header_left": "statistics_gas_header_left__xHW95",
	"gas_header_left_IconSvg": "statistics_gas_header_left_IconSvg__9Gdym"
};


/***/ }),

/***/ 4950:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3775);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { context  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
        overlayClassName: "custom-tooltip-wrap",
        title: context,
        children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("tip")
    });
});


/***/ })

};
;
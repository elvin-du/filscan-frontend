"use strict";
exports.id = 9927;
exports.ids = [9927];
exports.modules = {

/***/ 9927:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EA": () => (/* binding */ isIndent),
/* harmony export */   "IC": () => (/* binding */ getShowData),
/* harmony export */   "Nm": () => (/* binding */ formatFilNum),
/* harmony export */   "Uk": () => (/* binding */ formatFil),
/* harmony export */   "dN": () => (/* binding */ unitConversion),
/* harmony export */   "mr": () => (/* binding */ formatTime),
/* harmony export */   "o0": () => (/* binding */ formatDateTime),
/* harmony export */   "tq": () => (/* binding */ isMobile),
/* harmony export */   "uf": () => (/* binding */ formatNumber),
/* harmony export */   "wD": () => (/* binding */ getImgUrl)
/* harmony export */ });
/* unused harmony exports attoFormatFil, numFormat, f_Scientific, calcAmount, zeroCalc */
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9766);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9189);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([bignumber_js__WEBPACK_IMPORTED_MODULE_0__]);
bignumber_js__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const unitConversion = (item, len, num = 0)=>{
    let showItem = Number(item);
    let sizes = [
        "Bytes",
        "KiB",
        "MiB",
        "GiB",
        "TiB",
        "PiB",
        "EiB",
        "ZiB",
        "YiB"
    ];
    let positive = true;
    if (showItem == 0) {
        let unit = sizes[num];
        if (unit === "Bytes") {
            unit = "Byte";
        }
        return "0" + " " + unit;
    }
    if (showItem < 0) {
        positive = false;
        showItem = Math.abs(showItem);
    }
    let k = 1024;
    let c = num || Math.floor(Math.log(showItem) / Math.log(k));
    if (c < 0) {
        showItem = 0;
    } else {
        let units = sizes[c];
        if (!showItem && units === "Bytes") {
            units = "Byte";
        }
        showItem = (showItem / Math.pow(k, c)).toFixed(len) + " " + units;
    }
    return positive ? `${showItem}` : `-${showItem}`;
};
function formatFilNum(showNum, atto = false, pure = false, len = 4, toLocal = true) {
    let num = showNum;
    let flag = "";
    if (atto) {
        return num + (pure ? "" : " attoFIL");
    }
    if (showNum < 0) {
        num = Math.abs(Number(showNum));
        flag = "-";
    }
    let dot = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](Number(num)).dividedBy(Math.pow(10, 18)).toFixed().split(".")[1];
    const num1 = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](Number(num)).dividedBy(Math.pow(10, 18)).toFixed().split(".")[0];
    const num2 = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](Number(num)).dividedBy(Math.pow(10, 9)).toFixed(len).split(".")[0];
    let zero = 1;
    let res = num;
    let unit = " attoFIL";
    if (atto) {
        unit = " attoFIL";
        num = num;
    }
    if (dot) {
        for (let v of dot){
            if (Number(v) !== 0) {
                break;
            } else {
                zero++;
            }
        }
    }
    if (zero <= 5 && Number(num1) || num2.length > 6) {
        res = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](Number(num)).dividedBy(Math.pow(10, 18)).toFixed(len);
        unit = " FIL";
    //return num + " FIL";
    } else if (zero <= 13 && Number(num) > Math.pow(10, 7)) {
        res = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](Number(num)).dividedBy(Math.pow(10, 9)).toFixed(len);
        unit = " nanoFIL";
    } else {
        res = num;
        unit = " attoFIL";
    }
    return toLocal ? flag + Number(res).toLocaleString() + (pure ? "" : unit) : flag + res + (pure ? "" : unit);
}
function formatFil(num, unit, len = 0) {
    if (unit === "FIL") {
        var _Number;
        const showNum = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](num).dividedBy(Math.pow(10, 18));
        return Number((_Number = Number(showNum)) === null || _Number === void 0 ? void 0 : _Number.toFixed(len));
    } else if (unit === "nanoFiL") {
        var _Number1;
        const showNum1 = new bignumber_js__WEBPACK_IMPORTED_MODULE_0__["default"](num).dividedBy(Math.pow(10, 9));
        return Number(Number((_Number1 = Number(showNum1)) === null || _Number1 === void 0 ? void 0 : _Number1.toFixed(len)));
    }
    return Number(num);
}
function attoFormatFil(num, len) {
    const showLen = len || len === 0;
    let showNum = new BigNumber(num).dividedBy(Math.pow(10, 18));
    const showLenNum = showLen ? showNum.toFixed(len) : showNum;
    if (!Number(showLenNum)) {
        showNum = new BigNumber(num).dividedBy(Math.pow(10, 9));
        return len ? showNum.toFixed(len) : showNum + " nanoFil";
    }
    return showNum + " FIL";
}
function formatNumber(v, len = 5) {
    return Number(v).toLocaleString("en", {
        maximumFractionDigits: len
    });
}
function formatDateTime(time, str = "YYYY-MM-DD HH:mm:ss") {
    if (!time) return "--";
    return typeof time === "number" ? dayjs__WEBPACK_IMPORTED_MODULE_1___default()(time * 1000).format(str) : dayjs__WEBPACK_IMPORTED_MODULE_1___default()(time).format(str);
}
function formatTime(from, to, ago = true) {
    let startTime = from; // 开始时间
    let endTime = to || new Date().getTime(); // 结束时间
    let usedTime = endTime - startTime; // 相差的毫秒数
    //timeDifference(usedTime)
    // let days = Math.floor(usedTime / (24 * 3600 * 1000)); // 计算出天数
    // let leavel = usedTime % (24 * 3600 * 1000); // 计算天数后剩余的时间
    // let hours = Math.floor(leavel / (3600 * 1000)); // 计算剩余的小时数
    // let leavel2 = leavel % (3600 * 1000); // 计算剩余小时后剩余的毫秒数
    //  let minutes = Math.floor(leavel2 / (60 * 1000)); // 计算剩余的分钟数
    // let second = runTime % 60
    //计算出相差天数
    let days = Math.floor(usedTime / (24 * 3600 * 1000));
    //计算出小时数
    let leave1 = usedTime % (24 * 3600 * 1000);
    //计算天数后剩余的毫秒数
    let hours = Math.floor(leave1 / (3600 * 1000));
    //计算相差分钟数
    let leave2 = leave1 % (3600 * 1000); //计算小时数后剩余的毫秒数
    let minutes = Math.floor(leave2 / (60 * 1000)); // 分
    //计算相差秒数
    let leave3 = leave2 % (60 * 1000); //计算分钟数后剩余的毫秒数
    let seconds = Math.round(leave3 / 1000); // 秒
    //let second = runTime % 60
    return {
        days,
        hours,
        minutes,
        seconds
    };
}
function getImgUrl(name, active) {
    const showname = name === null || name === void 0 ? void 0 : name.replaceAll(" ", "");
    return active ? _contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .fvmUrl */ .d + `${active}/images/${showname === null || showname === void 0 ? void 0 : showname.toLocaleUpperCase()}.png` : _contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .fvmUrl */ .d + `/images/${showname === null || showname === void 0 ? void 0 : showname.toLocaleUpperCase()}.png`;
}
function isIndent(str, unit = 12) {
    return str && unit && str.length > unit * 2 ? (str === null || str === void 0 ? void 0 : str.slice(0, unit)) + "..." + (str === null || str === void 0 ? void 0 : str.slice(-unit)) : str;
}
function getShowData(item, data) {
    const [first, second] = item.type || [];
    let showData = data;
    if (first) {
        if (second) {
            showData = data && data[first] && data[first][second];
        } else {
            showData = data && data[first];
        }
    }
    return showData;
}
function isMobile() {
    if (false) {}
}
function numFormat(num) {
    if (!num) {
        return num;
    }
    let res = num.toString().replace(/\d+/, function(n) {
        return n.replace(/(\d)(?=(\d{3})+$)/g, function($1) {
            return $1 + ",";
        });
    });
    return res;
}
/*  @author zgli
 * @param precision 默认的最大精度
 *  添加对数字格式化，如果小数点后面有值，
 *  则按照精度处理，没有则去掉多余 0
 *  */ function f_Scientific(cellValue, precision) {
    /* 添加对数字格式化，如果小数点后面有值，则按照精度处理，没有则去掉0*/ cellValue = Number(cellValue).toFixed(precision);
    var array = cellValue.toString().split(".");
    var index = -1;
    if (array.length > 1) {
        for(var i = 0; i < array[1].length && i < precision; i++){
            if (array[1].charAt(i) != "0") {
                index = i + 1;
            }
        }
    }
    if (index != -1) {
        cellValue = Number(cellValue).toFixed(index);
    } else {
        cellValue = parseInt(cellValue);
    }
    return cellValue;
}
function calcAmount(amount, len = 4) {
    if (amount < Math.pow(10, 6)) {
        return amount;
    }
    let num1 = new BigNumber(amount).dividedBy(Math.pow(10, 6)); //M
    let unit = 0;
    const sizes = [
        "M",
        "G",
        "T",
        "P",
        "E",
        "Z",
        "Y"
    ];
    if (Number(num1) > Math.pow(10, 4)) {
        unit = 1;
        num1 = new BigNumber(amount).dividedBy(Math.pow(10, 9)); //G
    }
    if (Number(num1) > Math.pow(10, 4)) {
        unit = 2;
        num1 = new BigNumber(amount).dividedBy(Math.pow(10, 12)); // T
    }
    if (Number(num1) > Math.pow(10, 4)) {
        unit = 3;
        num1 = new BigNumber(amount).dividedBy(Math.pow(10, 15)); // P
    }
    if (Number(num1) > Math.pow(10, 4)) {
        unit = 4;
        num1 = new BigNumber(amount).dividedBy(Math.pow(10, 18)); //E
    }
    if (Number(num1) > Math.pow(10, 4)) {
        unit = 5;
        num1 = new BigNumber(amount).dividedBy(Math.pow(10, 21)); //Z
    }
    if (Number(num1) > Math.pow(10, 4)) {
        unit = 6;
        num1 = new BigNumber(amount).dividedBy(Math.pow(10, 24)); //Y
    }
    return Number(num1).toFixed(len) + sizes[unit];
}
function zeroCalc(value) {
    const num = String(value);
    const [main, other] = num.split(".");
    let str = "";
    if (!other || (other === null || other === void 0 ? void 0 : other.length) === 0) {
        return num;
    }
    const getOther = getCode(other);
    if (typeof getOther === "boolean") {
        return Number(value).toFixed(4);
    }
    const startIndex = getOther.start + 1;
    const endIndex = getOther.end;
    const showUnit = endIndex - startIndex;
    const other_a = other.slice(0, startIndex);
    const other_b = other.slice(endIndex + 1);
    if (other_a) {
        str = `${main}.${other_a}{${showUnit}}`;
    } else {
        str = `${main}.{${showUnit}}`;
    }
    if (other_b) {
        str = `${str}${other_b}`;
    }
    return str;
}
function getCode(Str) {
    let calcNum = {};
    let isZero = 0;
    const strArr = Str.split("");
    if (strArr.length < 4) {
        return true;
    }
    for(let index = 0; index < strArr.length; index++){
        const i = Number(strArr[index]);
        if (index < 4 && Number(i) > 0) {
            return true;
        }
        if (i === 0 && !isZero) {
            isZero = `${index}`;
            calcNum[isZero] = {
                start: index
            };
        } else if (i !== 0 && isZero) {
            calcNum[isZero] = {
                ...calcNum[isZero],
                end: index
            };
            isZero = 0;
        }
    }
    if (Object.keys(calcNum).length > 0) {
        let showObj = {
            num: 0
        };
        Object.keys(calcNum).forEach((v)=>{
            const obj = calcNum[v];
            const num = obj.end - obj.start;
            if (showObj.num < num) {
                showObj.num = num;
                showObj.key = v;
            }
        });
        return calcNum[showObj.key];
    }
    return true;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
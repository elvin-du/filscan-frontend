exports.id = 1891;
exports.ids = [1891];
exports.modules = {

/***/ 2601:
/***/ ((module) => {

// Exports
module.exports = {
	"chain_card": "chain-card_chain_card__wdi0D",
	"chain_card_header": "chain-card_chain_card_header__3mY7e",
	"chain_card_header_item": "chain-card_chain_card_header_item__cPJut",
	"chain_card_content": "chain-card_chain_card_content__X5PqZ",
	"chain_card_content_item": "chain-card_chain_card_content_item___079Q"
};


/***/ }),

/***/ 3617:
/***/ ((module) => {

// Exports
module.exports = {
	"chain_chart": "chain-charts_chain_chart__J9_DN",
	"chain_chart_container": "chain-charts_chain_chart_container___3LIn",
	"chain_chart_container_card": "chain-charts_chain_chart_container_card__nKRw_",
	"chain_chart_container_card_miner": "chain-charts_chain_chart_container_card_miner__3klaj",
	"chain_chart_container_card_miner_tip": "chain-charts_chain_chart_container_card_miner_tip__J0Qxu",
	"chain_chart_container_card_miner_tip_item": "chain-charts_chain_chart_container_card_miner_tip_item__QwSdv",
	"chain_chart_container_card_height": "chain-charts_chain_chart_container_card_height__7DEpC",
	"chain_chart_container_card_height_icon": "chain-charts_chain_chart_container_card_height_icon__VI_h3",
	"jumpSafeHeight": "chain-charts_jumpSafeHeight__5zlyg",
	"jumpSafeHeight_height": "chain-charts_jumpSafeHeight_height__hpS3k",
	"tipset_list": "chain-charts_tipset_list__bC1YB",
	"tipset_list_dot": "chain-charts_tipset_list_dot__Aopy4",
	"tipset_list_dot_value": "chain-charts_tipset_list_dot_value__c5gZO"
};


/***/ }),

/***/ 6872:
/***/ ((module) => {

// Exports
module.exports = {
	"chain_chart": "chain_chain_chart__AX6S3",
	"chain_chart_leftIcon": "chain_chain_chart_leftIcon__HSkuZ",
	"chain_chart_rightIcon": "chain_chain_chart_rightIcon__QU6Oe",
	"chain_content": "chain_chain_content__gqCdL",
	"chain_content_loading": "chain_chain_content_loading__vZqih"
};


/***/ }),

/***/ 1905:
/***/ ((module) => {

// Exports
module.exports = {
	"message_list": "style_message_list__E_P_2",
	"message_list_header": "style_message_list_header__6lzGf",
	"cid_detail": "style_cid_detail__laHMm"
};


/***/ }),

/***/ 4993:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_tipset__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6801);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2601);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_tipset__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
([_contants_tipset__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ data  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "tipset"
            });
        }
        return t(label, {
            ns: "tipset"
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().chain_card),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().chain_card_header),
                children: _contants_tipset__WEBPACK_IMPORTED_MODULE_1__/* .chain_columns.map */ .vG.map((v, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().chain_card_header_item),
                        children: tr(v.title)
                    }, `header-${index}`);
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().chain_card_content),
                children: _contants_tipset__WEBPACK_IMPORTED_MODULE_1__/* .chain_columns.map */ .vG.map((v, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().chain_card_content_item)}`,
                        children: v.render ? v.render(data.block_basic, data[v.dataIndex]) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: data[v.dataIndex]
                        })
                    }, `${index}_${v.dataIndex}`);
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7780:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_tipset__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6801);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7987);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3617);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_tipset__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_5__]);
([_contants_tipset__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "tipset"
            });
        }
        return t(label, {
            ns: "tipset"
        });
    };
    const { data , jumpSafeHeight , maxHeight , record  } = props;
    const tipset_list = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const ruleWidth = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        if (tipset_list && tipset_list.current) {
            return tipset_list.current.clientWidth;
        }
        return 0;
    }, [
        tipset_list === null || tipset_list === void 0 ? void 0 : tipset_list.current
    ]);
    const mask = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        if (!maxHeight) {
            return [];
        }
        const str = String(maxHeight);
        const unit = Math.pow(10, str.length - 2) * Number(str[0]);
        const len = Math.floor(maxHeight / unit);
        let res = [];
        for(let i = 0; i < len; i++){
            res.push((i + 1) * unit);
        }
        res.unshift(0) //add Genesis
        ;
        return res;
    }, [
        maxHeight
    ]);
    const renderContent = (item)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().chain_chart_container_card_miner_tip),
            children: _contants_tipset__WEBPACK_IMPORTED_MODULE_1__/* .basic_height.map */ .bE.map((row)=>{
                const { dataIndex , title , render  } = row;
                const text = render ? render(item[dataIndex], item) : item[dataIndex];
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().chain_chart_container_card_miner_tip_item),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            children: [
                                tr(title),
                                " :"
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: text
                        })
                    ]
                }, dataIndex);
            })
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().chain_chart),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().chain_chart_container),
                children: data === null || data === void 0 ? void 0 : data.reverse().map((item, index)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().chain_chart_container_card),
                        style: {
                            width: `${100 / (data.length - 1)}%`,
                            borderWidth: jumpSafeHeight === item.height ? "1px" : "0px"
                        },
                        children: [
                            item.block_basic.map((resultObj)=>{
                                var _record_block_basic, _record_block_basic1;
                                const record_show = (record === null || record === void 0 ? void 0 : (_record_block_basic = record.block_basic) === null || _record_block_basic === void 0 ? void 0 : _record_block_basic.miner_id) === (resultObj === null || resultObj === void 0 ? void 0 : resultObj.miner_id) && (record === null || record === void 0 ? void 0 : (_record_block_basic1 = record.block_basic) === null || _record_block_basic1 === void 0 ? void 0 : _record_block_basic1.height) === (resultObj === null || resultObj === void 0 ? void 0 : resultObj.height);
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().chain_chart_container_card_miner),
                                    style: {
                                        background: record_show ? `var(--link-color)` : ""
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Popover, {
                                        trigger: "hover",
                                        overlayClassName: "custom-popover-wrap",
                                        content: renderContent(resultObj),
                                        placement: "right",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: `/tipset/chain?cid=${resultObj.cid}`,
                                            style: {
                                                color: record_show ? "#fff" : ""
                                            },
                                            children: (resultObj === null || resultObj === void 0 ? void 0 : resultObj.miner_id) || ""
                                        })
                                    })
                                }, resultObj === null || resultObj === void 0 ? void 0 : resultObj.miner_id);
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().chain_chart_container_card_height),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: `/tipset/chain?height=${item.height}`,
                                        style: {
                                            background: jumpSafeHeight === item.height ? `var(--link-color)` : ``
                                        },
                                        children: item.height
                                    }),
                                    index !== data.length - 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().chain_chart_container_card_height_icon)} iconfont`
                                    })
                                ]
                            })
                        ]
                    }, index);
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().jumpSafeHeight),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().jumpSafeHeight_height),
                    children: maxHeight
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().tipset_list),
                ref: tipset_list,
                children: data.length > 0 && mask.map((item, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().tipset_list_dot),
                        style: {
                            left: `${item * 100 / maxHeight}%`
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().tipset_list_dot_value),
                            children: item
                        })
                    }, index);
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4950:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3775);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { context  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
        overlayClassName: "custom-tooltip-wrap",
        title: context,
        children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("tip")
    });
});


/***/ }),

/***/ 2306:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9189);
/* harmony import */ var _contants_tipset__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6801);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1905);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _packages_card__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4304);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _packages_content__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8202);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1311);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _packages_table__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7691);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7987);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8194);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(697);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_tipset__WEBPACK_IMPORTED_MODULE_2__, _packages_card__WEBPACK_IMPORTED_MODULE_3__, _packages_content__WEBPACK_IMPORTED_MODULE_5__, _store_server__WEBPACK_IMPORTED_MODULE_6__, _packages_table__WEBPACK_IMPORTED_MODULE_8__, react_i18next__WEBPACK_IMPORTED_MODULE_9__, _contants_varible__WEBPACK_IMPORTED_MODULE_11__]);
([_contants_tipset__WEBPACK_IMPORTED_MODULE_2__, _packages_card__WEBPACK_IMPORTED_MODULE_3__, _packages_content__WEBPACK_IMPORTED_MODULE_5__, _store_server__WEBPACK_IMPORTED_MODULE_6__, _packages_table__WEBPACK_IMPORTED_MODULE_8__, react_i18next__WEBPACK_IMPORTED_MODULE_9__, _contants_varible__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ cid , onChange  })=>{
    var _filscanStore_filscan, _filscanStore_filscan1;
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_9__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "tipset"
            });
        }
        return t(label, {
            ns: "tipset"
        });
    };
    const [total, setTotal] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(0);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)([]);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(1);
    const [detail, setDetail] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)([]);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false);
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        if (cid) {
            (0,_store_server__WEBPACK_IMPORTED_MODULE_6__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl.tipset_BlockDetails */ .J.tipset_BlockDetails, {
                block_cid: cid
            }).then((res)=>{
                var _res_result, _res_result1;
                if (onChange) onChange(res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.block_details);
                setDetail(res === null || res === void 0 ? void 0 : (_res_result1 = res.result) === null || _res_result1 === void 0 ? void 0 : _res_result1.block_details);
            });
            (0,_store_server__WEBPACK_IMPORTED_MODULE_6__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl.tipset_block_message_opt */ .J.tipset_block_message_opt, {
                cid
            }).then((res)=>{
                var _res_result;
                const opt = [];
                const newObj = (res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.method_name_list) || {};
                opt.push({
                    label: `${tr("message_list_all")}`,
                    value: "all",
                    key: "all"
                });
                Object.keys(newObj).forEach((key)=>{
                    opt.push({
                        label: `${tr(key)} (${newObj[key]})`,
                        value: key,
                        key: key
                    });
                });
                setOptions(opt);
            });
            loadMessage();
        }
    }, [
        cid
    ]);
    const loadMessage = (cur, method)=>{
        const showIndex = cur || current;
        const showMethod = method === "all" ? undefined : method;
        setLoading(true);
        (0,_store_server__WEBPACK_IMPORTED_MODULE_6__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl.tipset_Block_meaages */ .J.tipset_Block_meaages, {
            filters: {
                index: showIndex - 1,
                limit: _contants_varible__WEBPACK_IMPORTED_MODULE_11__/* .pageLimit */ .P5,
                method_name: showMethod
            },
            block_cid: cid
        }).then((res)=>{
            var _res_result, _res_result1;
            setLoading(false);
            setData((res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.message_list) || []);
            setTotal(res === null || res === void 0 ? void 0 : (_res_result1 = res.result) === null || _res_result1 === void 0 ? void 0 : _res_result1.total_count);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        if (options) {
            const newOptios = options.map((v)=>{
                return {
                    ...v,
                    label: tr(v.key)
                };
            });
            setOptions(newOptios);
        }
    }, [
        filscanStore === null || filscanStore === void 0 ? void 0 : (_filscanStore_filscan = filscanStore.filscan) === null || _filscanStore_filscan === void 0 ? void 0 : _filscanStore_filscan.lang
    ]);
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return _contants_tipset__WEBPACK_IMPORTED_MODULE_2__/* .chain_cid.columns.map */ .DF.columns.map((v)=>{
            const newObj = {
                ...v,
                title: tr(v.title)
            };
            return newObj;
        });
    }, [
        filscanStore === null || filscanStore === void 0 ? void 0 : (_filscanStore_filscan1 = filscanStore.filscan) === null || _filscanStore_filscan1 === void 0 ? void 0 : _filscanStore_filscan1.lang
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_card__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                title: _contants_tipset__WEBPACK_IMPORTED_MODULE_2__/* .chain_cid.title */ .DF.title,
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_12___default().cid_detail),
                ns: "tipset",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_content__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    content: _contants_tipset__WEBPACK_IMPORTED_MODULE_2__/* .chain_cid.list */ .DF.list,
                    data: detail,
                    ns: "tipset"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_list_header),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: tr(_contants_tipset__WEBPACK_IMPORTED_MODULE_2__/* .chain_cid.total */ .DF.total, {
                                    value: total
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_4__.Select, {
                                options: options,
                                defaultValue: "all",
                                className: "custom_select",
                                onChange: (value)=>{
                                    setCurrent(1);
                                    loadMessage(1, value);
                                }
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_table__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        dataSource: data,
                        total: total,
                        rowKey: (record)=>`${record.cid}_${record.block_time}`,
                        columns: columns,
                        current: current,
                        loading: loading,
                        onPage: (cur)=>{
                            setCurrent(cur);
                            loadMessage(cur);
                        }
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
"use strict";
exports.id = 6571;
exports.ids = [6571];
exports.modules = {

/***/ 8838:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/chartbackup@2x.c0ea7d0a.png","height":40,"width":40,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAeFBMVEXzkxvzkhzzkhvzkhrzkRvxkhnwkhrzkBbyjx31khj0lSP0kx30kxzzkxzzkhvzkhvzkhvzkhvzkhvzkhvzkhvzkhvzkhvzkRvzkRvzkRvzkhvzkhvzkhvzkhvzkhvzkhvzkhvzkhvzkhvzkhvzkhvzkhvzkhvzkhtGJCudAAAAKHRSTlMAAAAAAAAAAAACBAoKECEsNFJgYmNmaGltbm+Mj5WWmZ2eo6StrrrODXXK8wAAAEZJREFUeNoFQAcWQCAA/b69R5IiGdH9b+iBWb+EcyDKQxrVvgO2matge+HJaT6hAmwUd0ZrCV8TpOgxuiZJJ1eAo7f3XvEHps0EgiSlOAwAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 5328:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/meta.784a5ee2.png","height":36,"width":40,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA10lEQVR42mMAgY8TZBiBmOFxlyLTqz45NiBm+DhRpu/TROn/DP+nCzICMcO5Rg0eIAYpYrjTriLzqEtxClBRCwMIPOpSSnjcrbj/foey/rVWFdHHXQrL7nYoaR6uVednAKosA+KGo3Va0k+6FWaDJC81qSnfbleSfdCpMIvhTodyJhAz3O1QrL3RqioDxOJ321Xib7crxwIV1IHsy7jXqWz4sEuhBijo8KBTOekhEN/rUI572KnQAFLQcbtdxRRoZNH1VlWn220qKbfbVaNvtqlE32lXqgEAX3tjrvKu6hwAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 9079:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/trend@2x.56c507b7.png","height":38,"width":40,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAn0lEQVR42mP4MlmakQEKQOzPk2SYGIDg8yRpGyCuB0t8nSzD8W2KLAtYYqIkG1RBBRAHM0A51UDczAAFULHZnycp8MM4M4H48LfpysxAegYQlwJxI0xSAohbgDgaiPcCcTMQHwRiTwYGIPg0SdoLyKmDKr4IxHxg9mQZ9o89wowMUJ2ODLgAUHIREC8HmrQYiBcB8ZLPQAykl36eJD0LAMrzVsI7LLYnAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 6404:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QW": () => (/* binding */ home_tend),
/* harmony export */   "g9": () => (/* binding */ no_result),
/* harmony export */   "nW": () => (/* binding */ home_meta)
/* harmony export */ });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9927);
/* harmony import */ var _assets_images_home_meta_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5328);
/* harmony import */ var _assets_images_home_chartbackup_2x_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8838);
/* harmony import */ var _assets_images_home_trend_2x_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9079);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_utils__WEBPACK_IMPORTED_MODULE_0__]);
_utils_utils__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const home_meta = {
    title: {
        label: "meta_title",
        icon: _assets_images_home_meta_png__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
        rightIcon: "mata_show"
    },
    list: [
        {
            label: "latest_height",
            render: (v)=>{
                return Number(v).toLocaleString();
            }
        },
        {
            label: "latest_block_time",
            returnType: "React_Node"
        },
        {
            label: "power_increase_24h",
            render: (v)=>{
                return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .unitConversion */ .dN)(v, 4);
            }
        },
        //最新区块时间
        // {
        //     label: 'total_blocks',
        //     render: (v: number | string) => formatNumber(v, 2)
        // }, //全网出块数量
        {
            label: "total_quality_power",
            tip: "total_quality_power_tip",
            render: (v)=>{
                return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .unitConversion */ .dN)(v, 4);
            }
        },
        {
            label: "rewards_increase_24h",
            render: (v)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatNumber */ .uf)((0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(v, "FIL"), 2) + " FIL"
        },
        {
            label: "miner_initial_pledge",
            render: (v)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatNumber */ .uf)((0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(v, "FIL", 4)) + " FIL/TiB"
        },
        {
            label: "base_fee",
            render: (v)=>{
                return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFilNum */ .Nm)(Number(v), false, false) //  Number(formatFil(v,'attoFIL'))+' attoFIL'
                ;
            }
        },
        {
            label: "gas_in_32g",
            tip: "gas_in_32g_tip",
            render: (v)=>Number(v) < 0.0001 ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(v, "nanoFIL", 4) + "nanoFIL/TiB" : (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(v, "FIL", 4) + " FIL/TiB"
        },
        {
            label: "add_power_in_32g",
            tip: "add_power_in_32g_tip",
            render: (v)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(v, "FIL", 4) + " FIL/TiB"
        },
        {
            label: "fil_per_tera_24h",
            tip: "fil_per_tera_24h_tip",
            render: (v)=>{
                return (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(v, "FIL", 4) + " FIL/TiB";
            }
        },
        {
            label: "total_rewards",
            render: (v)=>{
                return Number((0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(v, "FIL")).toLocaleString() + " FIL";
            }
        },
        {
            label: "win_count_reward",
            render: (v)=>Number((0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(v, "FIL", 4)).toLocaleString() + " FIL"
        },
        {
            label: "gas_in_64g",
            tip: "gas_in_64g_tip",
            render: (v)=>Number(v) < 0.0001 ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(v, "nanoFIL", 4) + "nanoFIL/TiB" : (0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(v, "FIL", 4) + " FIL/TiB"
        },
        {
            label: "add_power_in_64g",
            tip: "add_power_in_64g_tip",
            render: (v)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(v, "FIL", 4) + " FIL/TiB"
        },
        {
            label: "avg_block_count",
            tip: "avg_block_count_tip",
            render: (v)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatNumber */ .uf)(v)
        },
        {
            label: "avg_message_count",
            tip: "avg_message_count_tip",
            render: (v)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatNumber */ .uf)(v)
        },
        {
            label: "active_miners",
            render: (v)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatNumber */ .uf)(v)
        },
        {
            label: "burnt",
            render: (v)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatNumber */ .uf)((0,_utils_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(v, "FIL"), 4) + " FIL"
        },
        {
            label: "circulating_percent",
            render: (v)=>Number(v * 100).toFixed(2) + "%"
        }
    ]
};
const home_tend = [
    {
        label: "power",
        // tip: 'power_tips',
        icon: _assets_images_home_chartbackup_2x_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
        right: {
            title: "show_more",
            link: "/statistics/power"
        }
    },
    {
        label: "gas",
        icon: _assets_images_home_trend_2x_png__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
        right: {
            title: "show_more",
            link: "/statistics/gas"
        }
    }
];
const no_result = {
    title: "search_notFound",
    warn_text: "warn_text",
    warn_details: "warn_details",
    go_home: "go_home"
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
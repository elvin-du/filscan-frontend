exports.id = 7692;
exports.ids = [7692];
exports.modules = {

/***/ 1150:
/***/ ((module) => {

// Exports
module.exports = {
	"table_content": "newTable_table_content__8WmFk",
	"table_content_total": "newTable_table_content_total__5u5Wh",
	"table_content_table": "newTable_table_content_table__wU9OX"
};


/***/ }),

/***/ 7692:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(697);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1150);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9927);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_varible__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _utils_utils__WEBPACK_IMPORTED_MODULE_5__]);
([_contants_varible__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _utils_utils__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ total_msg , ns , dataSource , columns , current , onPage , wrapClassName , className , onChange , loading , total =0 , rowKey  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns
            });
        }
        return t(label, {
            ns
        });
    };
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (loading) {
            setData([]);
        } else {
            setData(dataSource);
        }
    }, [
        dataSource,
        loading
    ]);
    if ((0,_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .isMobile */ .tq)()) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "mobile_table",
            children: data.map((dataSource, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mobile_table_card",
                    children: columns.map((item, index)=>{
                        const { title , dataIndex , render  } = item;
                        const showTitle = typeof item.title === "function" ? item.title() : item.title;
                        let showValue = dataSource[dataIndex];
                        if (render) {
                            showValue = render(dataSource[dataIndex], dataSource, index);
                        }
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mobile_table_card_item",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mobile_table_card_item_label",
                                    children: showTitle
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mobile_table_card_item_value",
                                    children: showValue
                                })
                            ]
                        }, index);
                    })
                }, index);
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().table_content)} ${wrapClassName}`,
        children: [
            total_msg && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().table_content_total),
                children: tr(total_msg, {
                    value: total
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Table, {
                className: `custom-table ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_6___default().table_content_table)} ${total_msg ? "" : "no_height_border_table"} ${className}`,
                dataSource: [
                    ...data
                ],
                columns: columns,
                rowKey: rowKey || `${new Date().getTime()}`,
                loading: loading,
                onChange: (pagination, filters, sorter)=>{
                    if (onChange) onChange(pagination, filters, sorter);
                },
                pagination: total > _contants_varible__WEBPACK_IMPORTED_MODULE_2__/* .pageLimit */ .P5 ? {
                    position: [
                        "bottomCenter"
                    ],
                    current: current,
                    showQuickJumper: true,
                    pageSize: _contants_varible__WEBPACK_IMPORTED_MODULE_2__/* .pageLimit */ .P5,
                    showSizeChanger: false,
                    total,
                    onChange: (cur)=>{
                        if (onPage) {
                            onPage(cur);
                        }
                    }
                } : false
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
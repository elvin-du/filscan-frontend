"use strict";
exports.id = 9285;
exports.ids = [9285];
exports.modules = {

/***/ 9285:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _device_detect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(29676);
/* harmony import */ var _assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45903);
/* harmony import */ var _copy__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(25174);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(23495);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(72305);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_4__]);
_utils__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { value = "", unit = 6, tagText } = props;
    // const { axiosData } = useAxiosData()
    // const router = useRouter()
    // const account_link = async (value: string) => {
    //   let show_type;
    //   const result = await axiosData(apiUrl.searchInfo, { input: value });
    //   show_type = result?.result_type;
    //   switch (show_type) {
    //   case 'miner':
    //     return router.push(`/miner/${value}`, `/miner/${value}`, {scroll:true});
    //   case 'storageminer':
    //     return router.push(`/miner/${value}`, `/miner/${value}`, {scroll:true});
    //   default:
    //     return router.push(`/address/${value}`, `/address/${value}`, {scroll:true});
    //   }
    // }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_device_detect__WEBPACK_IMPORTED_MODULE_1__/* .MobileView */ .$, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "copy-row",
                    children: [
                        tagText ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-fit cursor-pointer rounded-[5px] bg-bg_hover px-2 py-1 text-primary",
                            children: tagText
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text w-28",
                            onClick: ()=>{
                                (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .account_link */ .H_)(value);
                            },
                            children: value
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            text: value,
                            icon: _assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                            className: "copy"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_device_detect__WEBPACK_IMPORTED_MODULE_1__/* .BrowserView */ .I, {
                children: [
                    tagText ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        context: value,
                        icon: false,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "cursor-pointer rounded-[5px] bg-bg_hover px-2 py-1 text-primary",
                            children: tagText
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "link_text",
                        onClick: ()=>{
                            (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .account_link */ .H_)(value);
                        },
                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .isIndent */ .EA)(value, unit)
                    }),
                    value && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        className: "!w-[13px]",
                        text: value
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 72305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7947);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(69348);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { context, icon = true } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default()), {
        overlayClassName: "custom-tooltip-wrap",
        title: context,
        children: [
            icon ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "cursor-pointer",
                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("tip")
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: props.children
            })
        ]
    });
});


/***/ })

};
;
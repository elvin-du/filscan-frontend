exports.id = 2451;
exports.ids = [2451];
exports.modules = {

/***/ 42451:
/***/ ((module) => {

// Exports
module.exports = {
	"fund": "fund_fund__8lsZ9",
	"fund_loading": "fund_fund_loading__yMZ02",
	"fund_title": "fund_fund_title__w96cW",
	"fund_contain": "fund_fund_contain__Tm76d",
	"fund_contain_left": "fund_fund_contain_left__Qc0oQ",
	"fund_contain_chart": "fund_fund_contain_chart__tPV_s",
	"fund_contain_chart_icon": "fund_fund_contain_chart_icon__FashC",
	"fund_contain_chart_input": "fund_fund_contain_chart_input__xm0_5",
	"fund_card": "fund_fund_card__jAmsV",
	"fund_card_main": "fund_fund_card_main__s45L3",
	"fund_card_topBorder": "fund_fund_card_topBorder__0_H_Q",
	"fund_card_bottomBorder": "fund_fund_card_bottomBorder__e1IRR",
	"fund_card_after": "fund_fund_card_after__LYlSF",
	"fund_card_hr": "fund_fund_card_hr__gKIIm",
	"fund_card_item": "fund_fund_card_item__kyg6h",
	"fund_card_item_title": "fund_fund_card_item_title__FP5FU",
	"fund_card_item_value": "fund_fund_card_item_value__hAuRI",
	"fund_card_item_value_otherValue": "fund_fund_card_item_value_otherValue__BT_9m",
	"fund_card_item_base": "fund_fund_card_item_base__G_dtm",
	"fundContain": "fund_fundContain__4IlH3",
	"fundContain_bg": "fund_fundContain_bg__PCvvF",
	"fundContain_main": "fund_fundContain_main__L9QP_",
	"fundContain_main_title": "fund_fundContain_main_title__2_Il_",
	"fundContain_main_input": "fund_fundContain_main_input__c3NrO",
	"fundContain_main_input_suffix": "fund_fundContain_main_input_suffix__xrpVk",
	"fundContain_main_topSvg": "fund_fundContain_main_topSvg__4qI8L",
	"fundContain_main_svg": "fund_fundContain_main_svg__bKnr_"
};


/***/ })

};
;
"use strict";
exports.id = 1311;
exports.ids = [1311];
exports.modules = {

/***/ 1311:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "xW": () => (/* binding */ postAxios)
/* harmony export */ });
/* unused harmony exports getAxios, account_detail */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9189);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



// 拦截器
axios__WEBPACK_IMPORTED_MODULE_0__["default"].interceptors.response.use((response)=>{
    return response;
}, (err)=>{
    var _err_response, _err_response_data;
    var config = err.config;
    const errorMessage = (err === null || err === void 0 ? void 0 : (_err_response = err.response) === null || _err_response === void 0 ? void 0 : (_err_response_data = _err_response.data) === null || _err_response_data === void 0 ? void 0 : _err_response_data.message) || "";
    return antd__WEBPACK_IMPORTED_MODULE_1__.notification.error({
        className: "custom-notification",
        message: "Error",
        duration: 100,
        description: err.message + " " + errorMessage
    });
//     if (!config || !config.retry) {
//         return notification.error({
//             className: 'custom-notification',
//             message: 'Error',
//             duration: 100,
//             description: err.message + ' ' + errorMessage
//         })
//     }
//      // 设置变量以跟踪重试次数
//     config.__retryCount = config.__retryCount || 3;
//          if (config.__retryCount >= config.retry) {
//         // 返回错误并退出自动重试   
//             return notification.error({
//                 className: 'custom-notification',
//                 message: 'Error',
//                 duration: 100,
//                 description: err.message + ' ' + errorMessage
//             })
//          }
//      // 增加重试次数
//         config.__retryCount += 1;
//  // 创建新的Promise
//     let backoff = new Promise<void>(function (resolve) {
//         setTimeout(function () {
//             resolve();
//         }, config.retryDelay || 1);
//     });
//      // 返回重试请求
//     return backoff.then(function () {
//         return axios(config);
//     });
//  return Promise.reject(error)
});
axios__WEBPACK_IMPORTED_MODULE_0__["default"].interceptors.request.use((config)=>{
    config.headers["Accept"] = "application/vnd.dpexpo.v1+json";
    //config.timeout = 10000;
    return config;
}, (error)=>{
    return Promise.reject(error);
});
// axios的get请求
function getAxios(url = "", params = {}) {
    return new Promise((resolve, reject)=>{
        axios.get(url, {
            params
        }).then((res)=>{
            resolve(res.data);
        }).catch((err)=>{
            reject(err);
        });
    });
}
// axios的post请求
async function postAxios(url = "", data = {}, config) {
    return new Promise((resolve, reject)=>{
        (0,axios__WEBPACK_IMPORTED_MODULE_0__["default"])({
            url,
            method: "post",
            data
        }).then((res)=>{
            resolve(res === null || res === void 0 ? void 0 : res.data);
        }).catch((err)=>{
            reject(err);
        });
    });
}
function retryAdapterEnhancer(adapter, options) {
    const { times =0 , delay =300  } = options;
    return async (config)=>{
        const { retryTimes =times , retryDelay =delay  } = config;
        let __retryCount = 0;
        const request = async ()=>{
            try {
                return await adapter(config);
            } catch (err) {
                // 判断是否进行重试
                if (!retryTimes || __retryCount >= retryTimes) {
                    return Promise.reject(err);
                }
                __retryCount++; // 增加重试次数
                // 延时处理
                const delay = new Promise((resolve)=>{
                    setTimeout(()=>{
                        resolve();
                    }, retryDelay);
                });
                // 重新发起请求
                return delay.then(()=>{
                    return request();
                });
            }
        };
        return request();
    };
}
function account_detail(address) {
    return new Promise((resolve, reject)=>{
        postAxios(apiUrl.detail_account, {
            account_id: address
        }).then((res)=>{
            var _res_result, _res_result1;
            const data = (res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.account_info) || {};
            const type = res === null || res === void 0 ? void 0 : (_res_result1 = res.result) === null || _res_result1 === void 0 ? void 0 : _res_result1.account_type;
            const keys = Object.keys(data);
            let content = [];
            let mainKey = "";
            if (keys.length > 0) {
                mainKey = keys[0];
                if (mainKey) {
                //  content= general_overview_type[mainKey]
                }
            }
        //    setContent(content)
        //   setType(mainKey)
        //   setData(res?.result?.account_info[mainKey]);
        });
    });
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (axios)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
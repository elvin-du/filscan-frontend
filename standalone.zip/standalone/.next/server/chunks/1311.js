"use strict";
exports.id = 1311;
exports.ids = [1311];
exports.modules = {

/***/ 1311:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "xW": () => (/* binding */ postAxios)
/* harmony export */ });
/* unused harmony exports getAxios, account_detail */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9189);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



// 拦截器
axios__WEBPACK_IMPORTED_MODULE_0__["default"].interceptors.response.use((response)=>{
    return response;
}, (err)=>{
    var config = err.config;
    const errorMessage = err?.response?.data?.message || "";
    // return notification.error({
    //     className: 'custom-notification',
    //     message: 'Error',
    //     duration: 100,
    //     description: err.message + ' ' + errorMessage
    // });
    if (!config || !config.retryTimes) {
        // 不重试 
        return antd__WEBPACK_IMPORTED_MODULE_1__.notification.error({
            className: "custom-notification",
            message: "Error",
            duration: 100,
            description: err.message + " " + errorMessage
        });
    }
    // 设置变量以跟踪重试次数
    const { __retryCount =0 , retryDelay =300 , retryTimes  } = config;
    config.__retryCount = __retryCount;
    // 判断是否超过了重试次数
    if (__retryCount > retryTimes) {
        // 返回错误并退出自动重试 
        return antd__WEBPACK_IMPORTED_MODULE_1__.notification.error({
            className: "custom-notification",
            message: "Error",
            duration: 100,
            description: err.message + " " + errorMessage
        });
    }
    // 增加重试次数
    config.__retryCount++;
    // 创建新的Promise
    let backoff = new Promise(function(resolve) {
        setTimeout(function() {
            resolve();
        }, retryDelay);
    });
    // 返回重试请求
    return backoff.then(function() {
        return (0,axios__WEBPACK_IMPORTED_MODULE_0__["default"])(config);
    });
//return Promise.reject(error)
});
axios__WEBPACK_IMPORTED_MODULE_0__["default"].interceptors.request.use((config)=>{
    config.headers["Accept"] = "application/vnd.dpexpo.v1+json";
    // config.timeout = 7000;
    return config;
}, (error)=>{
    return Promise.reject(error);
});
// axios的get请求
function getAxios(url = "", params = {}) {
    return new Promise((resolve, reject)=>{
        axios.get(url, {
            params
        }).then((res)=>{
            resolve(res.data);
        }).catch((err)=>{
            reject(err);
        });
    });
}
// axios的post请求
async function postAxios(url = "", data = {}, config = {}) {
    return new Promise((resolve, reject)=>{
        axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(url, data, {
            timeout: undefined,
            retryTimes: 2,
            ...config
        }).then((res)=>{
            resolve(res?.data);
        }).catch((err)=>{
            reject(err);
        });
    });
// return new Promise((resolve, reject) => {
//     axios({
//         url,
//         method: 'post',
//       data,
//     }).then(res => {
//         resolve(res?.data)
//     }).catch(err => {
//         reject(err)
//     })
// })
}
function account_detail(address) {
    return new Promise((resolve, reject)=>{
        postAxios(apiUrl.detail_account, {
            account_id: address
        }).then((res)=>{
            const data = res?.result?.account_info || {};
            const type = res?.result?.account_type;
            const keys = Object.keys(data);
            let content = [];
            let mainKey = "";
            if (keys.length > 0) {
                mainKey = keys[0];
                if (mainKey) {
                //  content= general_overview_type[mainKey]
                }
            }
        //    setContent(content)
        //   setType(mainKey)
        //   setData(res?.result?.account_info[mainKey]);
        });
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axios__WEBPACK_IMPORTED_MODULE_0__["default"]);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
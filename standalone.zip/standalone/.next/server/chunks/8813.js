"use strict";
exports.id = 8813;
exports.ids = [8813];
exports.modules = {

/***/ 9997:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3775);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ text , icon , className  })=>{
    const handleClick = ()=>{
        var //copy
        _navigator_clipboard;
        (_navigator_clipboard = navigator.clipboard) === null || _navigator_clipboard === void 0 ? void 0 : _navigator_clipboard.writeText(text).then(function() {
            /* clipboard successfully set */ antd__WEBPACK_IMPORTED_MODULE_2__.message.success("clipboard successfully");
        }, function() {
        /* clipboard write failed */ });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        style: {
            cursor: "pointer"
        },
        className: className,
        onClick: handleClick,
        children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)(icon || "copy")
    });
});


/***/ }),

/***/ 8767:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ domain_card)
/* harmony export */ });
/* unused harmony export domain_name_catd */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3775);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9927);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5063);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9997);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_utils__WEBPACK_IMPORTED_MODULE_2__]);
_utils_utils__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const domain_card = {
    title: "domain_title",
    content: [
        {
            dataIndex: "",
            title: (tr, ns)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font_16 font_weight",
                    children: tr("domain_title")
                });
            },
            render: (text)=>null
        },
        {
            dataIndex: "resolved_address",
            title: "resolved_address"
        },
        {
            dataIndex: "expired_at",
            title: "expired_at",
            render: (text)=>(0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
        },
        {
            dataIndex: "registrant",
            title: "registrant",
            render: (text, record)=>{
                if (!text) {
                    return "--";
                }
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            className: "link",
                            href: `/address/${text}`,
                            children: [
                                text,
                                " "
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            text: text,
                            className: "mt-2"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: `/name/${text}?type=registrant`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        style: {
                                            textDecoration: "underline"
                                        },
                                        children: "Lookup Names "
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "mt-10 margin-10",
                                    children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("search")
                                })
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "controller",
            title: "controller",
            render: (text, record)=>{
                if (!text) {
                    return "--";
                }
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            className: "link",
                            href: `/address/${text}`,
                            children: [
                                text,
                                " "
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            text: text,
                            className: "mt-2"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: `/name/${text}?type=controller`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        style: {
                                            textDecoration: "underline"
                                        },
                                        children: "Lookup Names "
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "mt-10 margin-10",
                                    children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("search")
                                })
                            ]
                        })
                    ]
                });
            }
        }
    ]
};
const domain_name_catd = {
    content: [
        {
            dataIndex: "",
            title: (tr)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font_16 font_weight",
                    children: tr("domain_title")
                });
            },
            render: (text)=>null
        },
        {
            dataIndex: "resolvedAddress",
            title: "resolved_address"
        },
        {
            dataIndex: "registrant",
            title: "registrant",
            render: (text)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    className: "link",
                    href: `/address/${text}`,
                    children: [
                        text,
                        " "
                    ]
                });
            }
        }
    ]
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4950:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3775);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { context  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
        overlayClassName: "custom-tooltip-wrap",
        title: context,
        children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("tip")
    });
});


/***/ })

};
;
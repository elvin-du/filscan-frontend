exports.id = 1163;
exports.ids = [1163];
exports.modules = {

/***/ 83644:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _linearGradient, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgAuthor = function SvgAuthor(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 32 32"
  }, props), _linearGradient || (_linearGradient = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "author_svg__a",
    x1: "92.855%",
    x2: "-13.765%",
    y1: "76.652%",
    y2: "27.567%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#1764ff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#4093ed"
  }))), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#fff",
    d: "M-572-470H935V554H-572z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 15.592,
    cy: 15.592,
    r: 15.592,
    fill: "url(#author_svg__a)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#fff",
    d: "M12.486 17.444a.89.89 0 0 1 .374-.02c.085.013.19.046.315.099.295-.02.518-.007.669.045.223.08.328.177.387.328a.509.509 0 0 1 0 .328.662.662 0 0 0-.302-.144c-.138-.013-.203.013-.413.092-.144.052-.25.124-.335.196l-2.19 1.889-.413 2.197c-.183.61-.433 1.095-.734 1.462-.46.55-.767.695-1.318.99a3.58 3.58 0 0 1-1.266.387c.236-.046.479-.243.741-.584a1.99 1.99 0 0 0 .433-.964c.085-.53.131-1.783.138-3.757l-1.41-.498c3.475-1.338 5.252-2.02 5.324-2.046zm10.951-4.131c.42 1.2.138 3.055-.531 4.63a7.862 7.862 0 0 1-10.308 4.163 4.992 4.992 0 0 1-.525-.269l-.328-.196c-.072-.04-.072-.04-.13-.08l1.317-2.124.131.079c.112.072.19.118.263.157.105.06.19.105.255.132a5.356 5.356 0 0 0 7.03-2.84c.446-1.056.643-2.34.472-2.833zM8.44 11.79A7.862 7.862 0 0 1 18.75 7.627a7.838 7.838 0 0 1 4.072 3.98l4.046-.773-20 7.948.793-4.282.17-.033c.047-.905.243-1.81.61-2.676zm9.332-1.855a5.356 5.356 0 0 0-7.03 2.839c-.164.393-.275.8-.347 1.207l9.862-1.882a5.342 5.342 0 0 0-2.485-2.164z"
  })))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgAuthor);

/***/ }),

/***/ 80913:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgDown = function SvgDown(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 10 6"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "none",
    stroke: "#000",
    strokeWidth: 1.3,
    d: "m1 1 3.944 4L9 1",
    opacity: 0.6
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgDown);

/***/ }),

/***/ 15177:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgIconClose = function SvgIconClose(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 46 46"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M0 0h46v46H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#333",
    fillRule: "nonzero",
    d: "m23.697 26.408-9.758 9.758a1.917 1.917 0 0 1-2.71-2.71l9.758-9.759-9.758-9.758a1.917 1.917 0 0 1 2.71-2.71l9.758 9.758 9.759-9.758a1.917 1.917 0 0 1 2.71 2.71l-9.758 9.758 9.758 9.759a1.917 1.917 0 1 1-2.71 2.71z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgIconClose);

/***/ }),

/***/ 58644:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgIconOpen = function SvgIconOpen(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 46 46"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M0 0h46v46H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#333",
    fillRule: "nonzero",
    d: "M7.283 7.667h31.434c.847 0 1.533.686 1.533 1.533v.767c0 .847-.686 1.533-1.533 1.533H7.283A1.533 1.533 0 0 1 5.75 9.967V9.2c0-.847.686-1.533 1.533-1.533zm0 13.416h31.434c.847 0 1.533.687 1.533 1.534v.766c0 .847-.686 1.534-1.533 1.534H7.283a1.533 1.533 0 0 1-1.533-1.534v-.766c0-.847.686-1.534 1.533-1.534zM7.667 34.5h30.666a1.917 1.917 0 1 1 0 3.833H7.667a1.917 1.917 0 0 1 0-3.833z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgIconOpen);

/***/ }),

/***/ 51779:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgIconSearch = function SvgIconSearch(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 28 28"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M0 0h28v28H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#333",
    fillRule: "nonzero",
    d: "m20.952 19.336 4.088 4.087a1.143 1.143 0 0 1-1.617 1.617l-4.087-4.088a10.244 10.244 0 0 1-6.422 2.251c-5.68 0-10.289-4.61-10.289-10.289 0-5.68 4.61-10.289 10.29-10.289 5.679 0 10.288 4.61 10.288 10.29 0 2.427-.842 4.66-2.25 6.42zm-2.293-.849a7.976 7.976 0 0 0 2.258-5.573 8 8 0 0 0-8.003-8.003 8 8 0 0 0-8.003 8.003 8 8 0 0 0 8.003 8.003c2.167 0 4.133-.86 5.573-2.258z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgIconSearch);

/***/ }),

/***/ 22643:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgActiveBalance = function SvgActiveBalance(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 28 24"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#FFF",
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M26.6 8c.773 0 1.4.597 1.4 1.333v13.334c0 .736-.627 1.333-1.4 1.333H1.4C.627 24 0 23.403 0 22.667V9.6A1.6 1.6 0 0 1 1.6 8h25Zm-4.2 6.667h-4.2v2.666h4.2v-2.666ZM1.4 0h19.4a1.6 1.6 0 0 1 1.6 1.6v2.133a1.6 1.6 0 0 1-1.6 1.6H0v-4C0 .597.627 0 1.4 0Z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgActiveBalance);

/***/ }),

/***/ 10155:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgActivePower = function SvgActivePower(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 32 28"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#FFF",
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M1.6 15.556H8a1.6 1.6 0 0 1 1.6 1.6V26.4A1.6 1.6 0 0 1 8 28H1.6A1.6 1.6 0 0 1 0 26.4v-9.244a1.6 1.6 0 0 1 1.6-1.6ZM12.8 0h6.4a1.6 1.6 0 0 1 1.6 1.6v24.8a1.6 1.6 0 0 1-1.6 1.6h-6.4a1.6 1.6 0 0 1-1.6-1.6V1.6A1.6 1.6 0 0 1 12.8 0ZM24 7.778h6.4a1.6 1.6 0 0 1 1.6 1.6V26.4a1.6 1.6 0 0 1-1.6 1.6H24a1.6 1.6 0 0 1-1.6-1.6V9.378a1.6 1.6 0 0 1 1.6-1.6Z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgActivePower);

/***/ }),

/***/ 1530:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgActiveSector = function SvgActiveSector(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 28 28"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#FFF",
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M12.631 0v13.369a2 2 0 0 0 2 2H28C27.296 22.46 21.312 28 14.035 28 6.284 28 0 21.717 0 13.965 0 6.688 5.539.705 12.631 0Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M15.438 0C22.068.658 27.342 5.931 28 12.562H16.238a.8.8 0 0 1-.8-.8V0Z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgActiveSector);

/***/ }),

/***/ 82829:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgActiveWarn = function SvgActiveWarn(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 28 30"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#FFF",
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M14 6c6.73 0 12.184 5.373 12.184 12v9h1.523v3H.293v-3h1.523v-9C1.816 11.373 7.271 6 14 6Zm-.5 4A7.5 7.5 0 0 0 6 17.5v.205l.014.203A1.5 1.5 0 0 0 9 17.705V17.5l.01-.308A4.5 4.5 0 0 1 13.5 13a1.5 1.5 0 0 0 0-3ZM14 0c.841 0 1.523.682 1.523 1.523v1.454a1.523 1.523 0 1 1-3.046 0V1.523C12.477.682 13.159 0 14 0ZM26.923 5.272a1.489 1.489 0 0 1 0 2.121l-1.077 1.061a1.535 1.535 0 0 1-2.154 0 1.489 1.489 0 0 1 0-2.121l1.077-1.06a1.535 1.535 0 0 1 2.154 0ZM1.077 5.272a1.535 1.535 0 0 1 2.154 0l1.077 1.06a1.489 1.489 0 0 1 0 2.122 1.535 1.535 0 0 1-2.154 0l-1.077-1.06a1.489 1.489 0 0 1 0-2.122Z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgActiveWarn);

/***/ }),

/***/ 49629:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgBalance = function SvgBalance(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 16 16"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M0 0h16v16H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#a56b3b",
    d: "M1.8 6h12.5c.387 0 .7.298.7.667v6.666c0 .369-.313.667-.7.667H1.7c-.387 0-.7-.298-.7-.667V6.8a.8.8 0 0 1 .8-.8z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#ddb28e",
    d: "M1.7 2h9.7a.8.8 0 0 1 .8.8v1.067a.8.8 0 0 1-.8.8H1v-2C1 2.298 1.313 2 1.7 2z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#d9be9f",
    d: "M10.1 9.333v1.334h2.1V9.333z"
  })))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgBalance);

/***/ }),

/***/ 78416:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgBgMore = function SvgBgMore(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 54 52"
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "bgMore_svg__a",
    x1: "63.615%",
    x2: "39.394%",
    y1: "13.293%",
    y2: "89.163%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "0%",
    stopColor: "#FF842D"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "100%",
    stopColor: "#FF2D2D"
  })))), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "url(#bgMore_svg__a)",
    fillRule: "evenodd",
    stroke: "#FFF",
    d: "M32.491 3.353a5.518 5.518 0 0 1 3.53-.038 5.518 5.518 0 0 1 2.833 2.106l1.02 1.47a8.5 8.5 0 0 0 4.534 3.294l1.712.515A5.518 5.518 0 0 1 49 12.744a5.518 5.518 0 0 1 1.054 3.368l-.04 1.789a8.5 8.5 0 0 0 1.733 5.33l1.082 1.424A5.518 5.518 0 0 1 53.956 28a5.518 5.518 0 0 1-1.128 3.345l-1.082 1.424a8.5 8.5 0 0 0-1.732 5.33l.039 1.789a5.518 5.518 0 0 1-1.054 3.368A5.518 5.518 0 0 1 46.12 45.3l-1.712.515a8.5 8.5 0 0 0-4.535 3.295l-1.02 1.47a5.518 5.518 0 0 1-2.832 2.105 5.518 5.518 0 0 1-3.53-.038l-1.689-.59a8.5 8.5 0 0 0-5.604 0l-1.69.59a5.518 5.518 0 0 1-3.529.038 5.518 5.518 0 0 1-2.833-2.106l-1.02-1.47a8.5 8.5 0 0 0-4.534-3.294L9.88 45.3A5.518 5.518 0 0 1 7 43.256a5.518 5.518 0 0 1-1.054-3.368l.04-1.789a8.5 8.5 0 0 0-1.733-5.33l-1.082-1.424A5.518 5.518 0 0 1 2.044 28c0-1.178.376-2.357 1.128-3.345l1.082-1.424a8.5 8.5 0 0 0 1.732-5.33l-.039-1.789a5.518 5.518 0 0 1 1.054-3.368A5.518 5.518 0 0 1 9.88 10.7l1.712-.515a8.5 8.5 0 0 0 4.535-3.295l1.02-1.47a5.518 5.518 0 0 1 2.832-2.105 5.518 5.518 0 0 1 3.53.038l1.689.59a8.5 8.5 0 0 0 5.604 0Z",
    transform: "translate(-1 -2)"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgBgMore);

/***/ }),

/***/ 89626:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgCompanies = function SvgCompanies(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 14 14"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#a56b3b",
    d: "M5.61.102A2.091 2.091 0 0 0 3.106 1.14l-.562 1.1a.697.697 0 0 1-.304.303l-1.099.562A2.091 2.091 0 0 0 .102 5.61l.38 1.174c.045.14.045.29 0 .43l-.38 1.174a2.091 2.091 0 0 0 1.038 2.506l1.1.562c.13.067.236.173.303.304l.562 1.099a2.091 2.091 0 0 0 2.506 1.038l1.174-.38a.697.697 0 0 1 .43 0l1.174.38a2.091 2.091 0 0 0 2.506-1.038l.562-1.1a.698.698 0 0 1 .304-.303l1.099-.562a2.091 2.091 0 0 0 1.038-2.506l-.38-1.174a.697.697 0 0 1 0-.43l.38-1.174a2.091 2.091 0 0 0-1.038-2.506l-1.1-.562a.697.697 0 0 1-.303-.304l-.562-1.099A2.091 2.091 0 0 0 8.39.102l-1.174.38a.697.697 0 0 1-.43 0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#fff",
    d: "M3.84 6.338a.697.697 0 0 1 .986 0l1.337 1.337a.2.2 0 0 0 .283 0l3.309-3.309a.697.697 0 0 1 .986.986L7.01 9.081a1 1 0 0 1-1.413 0L3.84 7.324a.697.697 0 0 1 0-.986z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgCompanies);

/***/ }),

/***/ 7729:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgEmail = function SvgEmail(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 16 16"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M0 0h16v16H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#a56b3b",
    d: "M1.7 2h12.6c.387 0 .7.298.7.667v10.666c0 .369-.313.667-.7.667H1.7c-.387 0-.7-.298-.7-.667V2.667C1 2.298 1.313 2 1.7 2z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#ddb28e",
    d: "M7.788 7.583 4.082 4.587a.714.714 0 0 0-.982.08.649.649 0 0 0 .076.936l4.24 3.428a1 1 0 0 0 1.265-.005l4.151-3.422a.649.649 0 0 0 .068-.937.715.715 0 0 0-.984-.071L8.294 7.58a.4.4 0 0 1-.506.002z"
  })))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgEmail);

/***/ }),

/***/ 35520:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgLeft = function SvgLeft(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 6 13"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#6d3f1a",
    fillRule: "evenodd",
    d: "M4.263.098c.66.639.69 1.746.068 2.427l-.1-.097C3.57 1.788 3.538.68 4.16 0zM3.225 3.996c.234-1.171-.485-2.317-1.577-2.51l-.168-.03c-.234 1.172.486 2.317 1.578 2.51zm-3.032.262c1.256-.172 2.39.831 2.485 2.2l-.193.026c-1.257.173-2.39-.83-2.485-2.2zM4.1 9.932C3.865 8.205 2.342 7.045.763 7.388l-.242.052c.236 1.727 1.758 2.888 3.338 2.545zM6 12.537c-.789-1.592-2.637-2.161-4.081-1.256l-.05.032c.788 1.592 2.636 2.161 4.08 1.256z"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgLeft);

/***/ }),

/***/ 36594:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgMemberBalance = function SvgMemberBalance(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 64 64"
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "memberBalance_svg__a",
    x1: "50%",
    x2: "50%",
    y1: "0%",
    y2: "100%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "0%",
    stopColor: "#6D3F1A"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "100%",
    stopColor: "#6D3F1A",
    stopOpacity: 0.2
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "memberBalance_svg__c",
    x1: "40.665%",
    x2: "50%",
    y1: "34.43%",
    y2: "70.429%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "0%",
    stopColor: "#FED7A8"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "100%",
    stopColor: "#F2C37E"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "memberBalance_svg__b",
    x1: "17.936%",
    x2: "70.619%",
    y1: "33.545%",
    y2: "66.878%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "0%",
    stopColor: "#FFF2E2"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "100%",
    stopColor: "#DEB17F"
  })))), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 32,
    cy: 32,
    r: 32,
    fill: "url(#memberBalance_svg__a)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "url(#memberBalance_svg__c)",
    fillRule: "nonzero",
    stroke: "url(#memberBalance_svg__b)",
    strokeWidth: 0.875,
    d: "M18.545 26.545h26.91A2.545 2.545 0 0 1 48 29.091v15.364A2.545 2.545 0 0 1 45.455 47h-26.91A2.545 2.545 0 0 1 16 44.455V29.09a2.545 2.545 0 0 1 2.545-2.546Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#BE9568",
    fillRule: "nonzero",
    d: "M17.657 17h22.86a2 2 0 0 1 2 2v2.417a2 2 0 0 1-2 2H16v-4.813c0-.886.742-1.604 1.657-1.604Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#FFF2DC",
    fillRule: "nonzero",
    d: "M39.392 32.14c0 .806.653 1.458 1.458 1.458h1.798a1.458 1.458 0 1 0 0-2.916H40.85c-.805 0-1.458.653-1.458 1.458Z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgMemberBalance);

/***/ }),

/***/ 84846:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgMemberPower = function SvgMemberPower(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 64 64"
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "memberPower_svg__a",
    x1: "50%",
    x2: "50%",
    y1: "0%",
    y2: "100%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "0%",
    stopColor: "#6D3F1A"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "100%",
    stopColor: "#6D3F1A",
    stopOpacity: 0.2
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "memberPower_svg__c",
    x1: "44.849%",
    x2: "50%",
    y1: "11.893%",
    y2: "100%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "0%",
    stopColor: "#FED7A8"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "100%",
    stopColor: "#F2C37E"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "memberPower_svg__b",
    x1: "32.306%",
    x2: "61.378%",
    y1: "9.726%",
    y2: "91.307%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "0%",
    stopColor: "#FFF2E2"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "100%",
    stopColor: "#DEB17F"
  })))), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 32,
    cy: 32,
    r: 32,
    fill: "url(#memberPower_svg__a)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M16 16h30v30H16z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#C49B6D",
    d: "M17.5 29.125h6a1.5 1.5 0 0 1 1.5 1.5v12a1.5 1.5 0 0 1-1.5 1.5h-6a1.5 1.5 0 0 1-1.5-1.5v-12a1.5 1.5 0 0 1 1.5-1.5Z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "url(#memberPower_svg__c)",
    stroke: "url(#memberPower_svg__b)",
    strokeWidth: 0.875,
    d: "M12 0h6a1.5 1.5 0 0 1 1.5 1.5v23.25a1.5 1.5 0 0 1-1.5 1.5h-6a1.5 1.5 0 0 1-1.5-1.5V1.5A1.5 1.5 0 0 1 12 0Zm10.5 7.292h6a1.5 1.5 0 0 1 1.5 1.5V24.75a1.5 1.5 0 0 1-1.5 1.5h-6a1.5 1.5 0 0 1-1.5-1.5V8.792a1.5 1.5 0 0 1 1.5-1.5Z",
    transform: "translate(16 17.875)"
  })))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgMemberPower);

/***/ }),

/***/ 5312:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgMemberSector = function SvgMemberSector(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 64 64"
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "memberSector_svg__a",
    x1: "50%",
    x2: "50%",
    y1: "0%",
    y2: "100%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "0%",
    stopColor: "#6D3F1A"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "100%",
    stopColor: "#6D3F1A",
    stopOpacity: 0.2
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "memberSector_svg__c",
    x1: "40.665%",
    x2: "50%",
    y1: "11.893%",
    y2: "100%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "0%",
    stopColor: "#FED7A8"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "100%",
    stopColor: "#F2C37E"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "memberSector_svg__b",
    x1: "17.936%",
    x2: "70.619%",
    y1: "9.726%",
    y2: "91.307%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "0%",
    stopColor: "#FFF2E2"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "100%",
    stopColor: "#DEB17F"
  })))), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 32,
    cy: 32,
    r: 32,
    fill: "url(#memberSector_svg__a)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "url(#memberSector_svg__c)",
    stroke: "url(#memberSector_svg__b)",
    d: "M15.344.066v17.59a1 1 0 0 0 1 1h17.59c-.852 8.578-8.09 15.278-16.892 15.278-9.375 0-16.976-7.6-16.976-16.976 0-8.802 6.7-16.04 15.278-16.892Z",
    transform: "translate(15 15)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#F4C685",
    d: "M33.992 15.066c7.887.783 14.159 7.055 14.942 14.942H34.392a.4.4 0 0 1-.4-.4V15.066Z",
    opacity: 0.3
  })))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgMemberSector);

/***/ }),

/***/ 92460:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgMsg = function SvgMsg(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 16 16"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M0 0h16v16H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    transform: "translate(1 1)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#ddb28e",
    d: "M0 5.5c-.022 1.928.672 3.574 2.084 4.938 1.294 1.25 3.174 2.353 5.638 3.308a.499.499 0 0 0 .679-.466v-2.684z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 14,
    height: 11,
    x: 0.001,
    fill: "#a56b3b",
    rx: 5.5
  })))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgMsg);

/***/ }),

/***/ 72715:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgPhone = function SvgPhone(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 16 16"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M0 0h16v16H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#a56b3b",
    d: "M3.714 1h8.572c.394 0 .714.313.714.7v12.6c0 .387-.32.7-.714.7H3.714A.707.707 0 0 1 3 14.3V1.7c0-.387.32-.7.714-.7z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#ddb28e"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M4.939 3h6.122c.282 0 .51.157.51.35v6.3c0 .193-.228.35-.51.35H4.94c-.282 0-.51-.157-.51-.35v-6.3c0-.193.228-.35.51-.35zM8 11.5c-.395 0-.714.313-.714.7s.32.7.714.7.714-.313.714-.7-.32-.7-.714-.7z"
  }))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgPhone);

/***/ }),

/***/ 10838:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgPower = function SvgPower(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 16 16"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M0 0h16v16H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#ddb28e",
    d: "M.8 8.778H4a.8.8 0 0 1 .8.8V14.2a.8.8 0 0 1-.8.8H.8a.8.8 0 0 1-.8-.8V9.578a.8.8 0 0 1 .8-.8z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#a56b3b"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M6.4 1h3.2a.8.8 0 0 1 .8.8v12.4a.8.8 0 0 1-.8.8H6.4a.8.8 0 0 1-.8-.8V1.8a.8.8 0 0 1 .8-.8zM12 4.889h3.2a.8.8 0 0 1 .8.8V14.2a.8.8 0 0 1-.8.8H12a.8.8 0 0 1-.8-.8V5.689a.8.8 0 0 1 .8-.8z"
  }))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgPower);

/***/ }),

/***/ 14522:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgRight = function SvgRight(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 6 13"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#6d3f1a",
    fillRule: "evenodd",
    d: "M1.737.098c-.66.639-.69 1.746-.068 2.427l.1-.097c.66-.64.692-1.747.07-2.428zm1.038 3.898c-.234-1.171.485-2.317 1.577-2.51l.168-.03c.234 1.172-.486 2.317-1.578 2.51zm3.032.262c-1.256-.172-2.39.831-2.485 2.2l.193.026c1.257.173 2.39-.83 2.485-2.2zM1.9 9.932c.236-1.727 1.759-2.887 3.338-2.544l.242.052c-.236 1.727-1.758 2.888-3.338 2.545zM0 12.537c.789-1.592 2.637-2.161 4.081-1.256l.05.032c-.788 1.592-2.636 2.161-4.08 1.256z"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgRight);

/***/ }),

/***/ 8093:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgSector = function SvgSector(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 16 16"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M0 0h16v16H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#a56b3b",
    d: "M7.316 1v6.684a1 1 0 0 0 1 1H15A7.018 7.018 0 1 1 7.316 1z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#ddb28e",
    d: "M8.72 1A7.02 7.02 0 0 1 15 7.28H9.12a.4.4 0 0 1-.4-.4z"
  })))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgSector);

/***/ }),

/***/ 62539:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgVip = function SvgVip(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 22 20"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M1 0h20v20H1z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#A56B3B",
    d: "M16.878 3c.292 0 .567.136.744.368l3.242 4.244a.936.936 0 0 1-.125 1.271l-9.112 8.019a.936.936 0 0 1-1.238 0l-9.126-8.03a.936.936 0 0 1-.137-1.256l3.096-4.232A.936.936 0 0 1 4.977 3h11.9Zm-1.394 5.543a1.032 1.032 0 0 0-1.268.086l-3.217 2.975L7.803 8.63l-.11-.088a1.032 1.032 0 0 0-1.268.086.857.857 0 0 0-.002 1.277l3.425 3.185.131.11a1.718 1.718 0 0 0 2.164-.107l3.447-3.186.095-.101a.855.855 0 0 0-.092-1.176Z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgVip);

/***/ }),

/***/ 23001:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _linearGradient, _filter, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgSearchIconB = function SvgSearchIconB(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 34 34"
  }, props), _linearGradient || (_linearGradient = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "searchIcon_b_svg__a",
    x1: "11%",
    x2: "86.397%",
    y1: "13.256%",
    y2: "85.045%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#398bef"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#1c6afd"
  }))), _filter || (_filter = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "searchIcon_b_svg__b"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feColorMatrix", {
    in: "SourceGraphic",
    values: "0 0 0 0 0.047059 0 0 0 0 0.050980 0 0 0 0 0.054902 0 0 0 1.000000 0"
  }))), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 34,
    height: 34,
    fill: "url(#searchIcon_b_svg__a)",
    rx: 5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    filter: "url(#searchIcon_b_svg__b)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#2c2c2c",
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M24.37 18.46H9.783a.594.594 0 0 1-.594-.594v-1.187c0-.328.266-.594.594-.594H24.37z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "m18.713 23.344-.838-.837a.591.591 0 0 1 0-.838l4.397-4.397-4.397-4.397a.593.593 0 0 1 0-.837l.838-.838a.593.593 0 0 1 .837 0l6.072 6.072-6.072 6.072a.593.593 0 0 1-.837 0z"
  }))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgSearchIconB);

/***/ }),

/***/ 30434:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _linearGradient, _filter, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgSearchIconW = function SvgSearchIconW(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 28 28"
  }, props), _linearGradient || (_linearGradient = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "searchIcon_w_svg__a",
    x1: "11%",
    x2: "86.397%",
    y1: "13.256%",
    y2: "85.045%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#398bef"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#1c6afd"
  }))), _filter || (_filter = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "searchIcon_w_svg__b"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feColorMatrix", {
    in: "SourceGraphic",
    values: "0 0 0 0 1.000000 0 0 0 0 1.000000 0 0 0 0 1.000000 0 0 0 1.000000 0"
  }))), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 28,
    height: 28,
    fill: "url(#searchIcon_w_svg__a)",
    rx: 5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    filter: "url(#searchIcon_w_svg__b)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#fff",
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M20.07 15.202H8.055a.489.489 0 0 1-.488-.489v-.978c0-.27.218-.489.488-.489H20.07z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "m15.41 19.224-.69-.69a.487.487 0 0 1 0-.689l3.622-3.62-3.621-3.622a.488.488 0 0 1 0-.69l.69-.69c.19-.19.499-.19.689 0l5 5.001-5 5c-.19.19-.5.19-.69 0z"
  }))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgSearchIconW);

/***/ }),

/***/ 48134:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgUser = function SvgUser(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 20 20"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 10,
    cy: 10,
    r: 10,
    fill: "#000",
    opacity: 0.301
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#fff",
    fillRule: "nonzero",
    d: "M10 3.636c.214 0 .415.109.532.288l2.388 3.652 2.51-1.32a.636.636 0 0 1 .928.64l-.822 6.85a1.89 1.89 0 0 1-1.874 1.662H6.335c-.953 0-1.759-.715-1.873-1.663l-.821-6.852a.637.637 0 0 1 .928-.639l2.51 1.32 2.388-3.65a.637.637 0 0 1 .532-.288zm0 1.8L7.826 8.758A.636.636 0 0 1 7 8.973l-1.95-1.028.677 5.65c.037.308.3.54.61.54h7.327c.31 0 .572-.232.61-.54l.678-5.65-1.95 1.026a.636.636 0 0 1-.828-.215zm2.317 4.937a.636.636 0 0 1-.023.9l-1.408 1.336a1.29 1.29 0 0 1-1.773 0l-1.408-1.336a.636.636 0 0 1 .877-.923l1.407 1.337 1.428-1.337a.636.636 0 0 1 .9.023z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgUser);

/***/ }),

/***/ 45420:
/***/ ((module) => {

// Exports
module.exports = {
	"mobile": "device-detect_mobile__LTHQ5",
	"browser": "device-detect_browser__ADyub"
};


/***/ }),

/***/ 47687:
/***/ ((module) => {

// Exports
module.exports = {
	"footer-wrap": "footer_footer-wrap__yu5YB",
	"top": "footer_top__IsQyN",
	"text": "footer_text__Jlm1r",
	"bottom": "footer_bottom__Y4FIh"
};


/***/ }),

/***/ 58327:
/***/ ((module) => {

// Exports
module.exports = {
	"header-wrap": "header_header-wrap__OUJNT",
	"header": "header_header__Vn1rR",
	"nav": "header_nav___l_aP",
	"fil": "header_fil__SLnbl",
	"body": "header_body__zAiPK",
	"menuWrap": "header_menuWrap__bXbKi",
	"login": "header_login__XJIGA",
	"log-out": "header_log-out__uT1SY",
	"active": "header_active__SFXvq"
};


/***/ }),

/***/ 83651:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "search_wrap__ZlGOI",
	"search-wrap": "search_search-wrap__RhRDF",
	"search": "search_search__Hk_10",
	"mask-wrap": "search_mask-wrap__fouyQ",
	"mask": "search_mask__y9A0k",
	"disabled": "search_disabled__KEhCc"
};


/***/ }),

/***/ 96298:
/***/ ((module) => {

// Exports
module.exports = {
	"search_input": "search_search_input__ThE72",
	"ant-input": "search_ant-input__ykxVp",
	"ant-input-suffix": "search_ant-input-suffix__EBepm",
	"banner_search": "search_banner_search__h9KfG"
};


/***/ }),

/***/ 56209:
/***/ ((module) => {

// Exports
module.exports = {
	"component": "_app_component__e_lxU",
	"home": "_app_home__DELaW",
	"other": "_app_other__079cS",
	"title": "_app_title__CL_aL",
	"search": "_app_search__M6UrI"
};


/***/ }),

/***/ 64744:
/***/ ((module) => {

// Exports
module.exports = {
	"activeShare": "share_activeShare___Aedy",
	"activeShare_save": "share_activeShare_save__1IrY4",
	"share": "share_share__O_DX1",
	"share_top": "share_share_top__ge0ci",
	"share_bottom": "share_share_bottom__rVb5D",
	"share_bottom_code": "share_share_bottom_code__hIyBf",
	"share_bottom_title": "share_share_bottom_title__ODqZR",
	"share_bottom_des": "share_share_bottom_des__eb5v_",
	"share_bottom_gift": "share_share_bottom_gift__8Wr_L",
	"share_bottom_gift_text": "share_share_bottom_gift_text__kTsYj",
	"share_main": "share_share_main__VfJ2h",
	"share_content": "share_share_content__X_xW4",
	"share_content_icon": "share_share_content_icon__PiSfs",
	"share_content_top": "share_share_content_top__m_pwA",
	"share_content_bottom": "share_share_content_bottom__DbT3A",
	"share_content_right": "share_share_content_right__gQCR0",
	"share_content_Bright": "share_share_content_Bright__TFmG_",
	"share_content_title": "share_share_content_title__kLr6S",
	"share_content_item": "share_share_content_item___uQYv",
	"share_target": "share_share_target__V4oZB",
	"share_target_image": "share_share_target_image__SlJDZ",
	"share_invite": "share_share_invite___ts0A",
	"share_invite_content": "share_share_invite_content__jzkba",
	"share_invite_item": "share_share_invite_item__1v4nk",
	"share_invite_item_value": "share_share_invite_item_value__mr_3u"
};


/***/ }),

/***/ 40945:
/***/ ((module) => {

// Exports
module.exports = {
	"member": "member_member__dVlD_",
	"member_header": "member_member_header__a_hMa",
	"member_header_close": "member_member_header_close__T0Pdi",
	"member_content_title": "member_member_content_title__OuU8r",
	"member_content_main": "member_member_content_main__7hXK6",
	"member_item": "member_member_item__4kJY_",
	"member_item_icon": "member_member_item_icon__A2mLC",
	"member_item_card": "member_member_item_card__TSzIg",
	"member_item_card_title": "member_member_item_card_title__wiI3W",
	"member_item_list": "member_member_item_list__IJ4BN",
	"member_item_li": "member_member_item_li__Z0gx4",
	"member_item_value": "member_member_item_value__3Mz91",
	"member_item_discount": "member_member_item_discount__7u4Rv",
	"member_item_priceValue": "member_member_item_priceValue__kaUWW",
	"member_item_priceItem": "member_member_item_priceItem__Nt3DX",
	"member_item0": "member_member_item0___50OJ",
	"member_item1": "member_member_item1__C09u_",
	"member_itemMain": "member_member_itemMain__dHalN",
	"member_itemMain_card": "member_member_itemMain_card__wBdfP",
	"member_itemMain_card_header": "member_member_itemMain_card_header__ndNI_",
	"member_itemMain_card_icon": "member_member_itemMain_card_icon__pbCaJ",
	"member_itemMain_card_iconBg": "member_member_itemMain_card_iconBg__x_AJd",
	"member_btns": "member_member_btns__Dwmh0",
	"member_btn": "member_member_btn___VRXJ",
	"member_btn_recommend": "member_member_btn_recommend__cQISo",
	"member_btn_recommend_icon": "member_member_btn_recommend_icon__diVBS",
	"member_btnShare": "member_member_btnShare__1hSK_",
	"member_btnShare_icon": "member_member_btnShare_icon__U6YRB",
	"memberContent": "member_memberContent__oEVFc",
	"memberContent_btns": "member_memberContent_btns__dvX6G",
	"content": "member_content__xVpli",
	"content_card": "member_content_card__L9_bs",
	"content_card_icon": "member_content_card_icon__k_Auv",
	"content_card_value": "member_content_card_value__nMPAA",
	"content_card_title": "member_content_card_title__owlq9",
	"content_newCard": "member_content_newCard__Q0y_N",
	"content_newCard_main": "member_content_newCard_main__llqb3",
	"content_newCard_item": "member_content_newCard_item__5_Xwy",
	"content_newCard_text": "member_content_newCard_text__wwGY7",
	"tg": "member_tg__Ro2hF",
	"tg_main": "member_tg_main__oBXUD",
	"tg_icon": "member_tg_icon__t_em0",
	"svg": "member_svg__dn5X2",
	"tg_title": "member_tg_title__7I08P",
	"tg_img": "member_tg_img__NiWOa",
	"tg_des": "member_tg_des__aOuzB",
	"tg_des_copy": "member_tg_des_copy__X03dL"
};


/***/ }),

/***/ 57946:
/***/ ((module) => {

// Exports
module.exports = {
	"warnContent": "warn_warnContent__nlPNb",
	"warn": "warn_warn__YkGNk",
	"warn_icon": "warn_warn_icon__no55a",
	"warn_close": "warn_warn_close__UfRhu",
	"warn_content": "warn_warn_content__hkui_",
	"warn_main": "warn_warn_main__B542W",
	"warn_main_left": "warn_warn_main_left__BfHFR",
	"warn_main_left_icon": "warn_warn_main_left_icon__oIb6j",
	"icon": "warn_icon__qhM_9",
	"warn_main_left_unit": "warn_warn_main_left_unit__IXnhi",
	"warn_list": "warn_warn_list__b0lRK",
	"warn_list_item": "warn_warn_list_item__MvJa8",
	"warn_btn": "warn_warn_btn__Iak77",
	"warn_btn_icon": "warn_warn_btn_icon__wLT5P",
	"warn_btn_icon_text": "warn_warn_btn_icon_text__z8Ana"
};


/***/ }),

/***/ 7203:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/code.8eec6dbc.png","height":210,"width":210,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA2UlEQVR42h2PS4qDQBRFa8U96S2EHrWQnjTRoFCRoJYS/4IYP0jAxIo6cCW1gbqxHDx4PO65vEMopYjjGMMwIM9z6LoOx3FkFEUwDEOQMAxRliWeW+Be13A9D0VRyFrtriuIopMkQdM0OJ/+0bcdTNOUXddhG0Fs2walF8ThDV+HI3TfwZ+mySAIwDkXZJ5neIzBvdr4/jFxOBl49L3k7zeqqtoDe/04jpj4C8dfDYyxvSHLMkHSNIV6aFkWTNO8B33fl5uRAgWxLEsdsK6rIrDpKWXZtq2CxAexa8WBVqYQgQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 97485:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/freeVip.8dd7e60f.png","height":28,"width":94,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAS0lEQVR4nGP8Whhxm0FWXeXfm9f//zGyMP77/JWBQVSSgUFQlOHXqdMMjF+zfP8zSKkx/OfmZ/jPxsnw59YNoAKp//+Bin+dPHUHAIh0GwEX6m8pAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 71062:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/logo.a9999871.png","height":62,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA5klEQVR42mMAAZFDL0IkTz35Ynjxxl/Pa2feRd86HAXEDIE3jjMwiK154yi2/dVH0VNPwxi+3+Y0vHSjwOnKhf/BN44Flt3fwscgtuj9DrGl7y6LrX6bDVS4nuvQy37p8w+6TC5dbwNiBgaxiZ9viM35+EZsxdsdYjteegIxg8jh55Uix5+dAGKggtZvU8R6vu4Tm/Q5DYgZxBa/9xbb9Pq/2K6XQUAMVFD5s0Cs9sdGoKLVQNM+ic378EJs2btsIGYQX/mWiUE852+6WO4fayBmEOv4qime+IcNiBnEdr1iEtv1igEAtSx1VidlJcoAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 67937:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/logoText.8c02cac7.png","height":32,"width":190,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAKklEQVR4nGMUS/2XxyD45xMD998XDEJ/9Bh4/r5gEvz97TPvfzUNoY8sAOtbDl0LcSBVAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":1});

/***/ }),

/***/ 29978:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/ActiveZh.d834e171.png","height":380,"width":1312,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAARklEQVR4nGP8+2tn0DdGRo7PjAy8XxkYP3xkZNzzjYEh7Csj47PPDAzsIAXpQAX/PjMysgAlfgMVvPrOwPDqAyPjQyBtCgCdSRty8HfhcQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 60258:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/active1.8c00f720.png","height":116,"width":116,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA90lEQVR42mNoPrWaiQECRLsfb+6f9Gl9OgMUlC1NZGQAgY4VwTK5u5c/DV9/43/e7TP/Mx7vaweJT/tyl4UBBCJurQupe3fyf8y5i98F+x/9c7py9T/D8T0GDDAw7dqVsvqjJ//P37Pnj/ach78ZFj3/H3H4xmIGELh7/9XK/////p9+6uEfhkkP/zM0vf/PEPDs76m7H/5/+fjxOkNg4YP9G3d++P/h07f/a459+1PRf/3Pjr3X/u89+ul/VtPTDwwMDAyMDAx3s+Krn7+9dOXj/xu33v1vm/7qDwP/o04GhoN8DAhwTphB9t4yBocHBxkYbunARAGt6oAvUU8tnQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 47334:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/active2.7eb07fff.png","height":116,"width":116,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA+0lEQVR42mOYcGcnEwMYBMr0PdsyZeLHdXEMDAwMS/7/Z2SAgc71SWoZu1a9C9lw83/BvdP/0x7trWRgYGDofnudBaL3/ubkrnen/mceu/iNYcqT/67Xrvxn2L9NmQEG2i5fbum+ePn/vBPn/jDMev5bZtmz//GHb0xjAIFHj99u////z/9Jpx7/NZx+9z9Dzfv/DBHP/lx+/On/p/cfTjOElT46t2P/x//vPn77v/jA1z/V/Vf+7Dl46/+uQ5/+p9Q9ecLAwDCXhYHhfnF204tP1258/H/1xrv/DZNe/WBgeNjAwLCdiwEBrkgyaN5bz2D7cBcDww0VmCgAu/OC9bluITsAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 37107:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/active3.07672255.png","height":116,"width":116,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA70lEQVR42l3KPUgCcQCG8ZdqbHBsammKmoyGhqBobosc2yUIItdW06CgPQripgxaosElusrwONRAKtA7vTvU8+MEP0H836s3iOBvfHhwrMfmMBb8kMIHD9E4gCXMCn3FV48SKgMZhbvPUmMT+/7ABZenx+3jIqTsk//F5Mq7SgA7ABf6Q2MeHjWdOrySjT/EbAaVBLP5TLpV72zBU7Ebd+SAv7rDjWvHxcmPa5VMekrl6j3OIpYuJ9scc4WgeH2zRdOpi+9Uj6dh0wCQ9AGFSOiyMtSKXVrlHs9vagLQo4Diw1RuDXuajG3tE/hfn9QR9UWAzlmGzj0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 61941:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/activeEn.b4dbf21e.png","height":380,"width":1314,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAPElEQVR4nBWKsQ2AMAzA7Ip/WHiel1jTdkBKS9gs2+Z7n1Mz5OiYQ1sAXRmw/+EquYY8gbO49Qqhe8L6AJ98HA5FI2qXAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 39747:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/activeKr.bb2656ce.png","height":382,"width":1314,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAQUlEQVR4nBXKOwqAMBjA4ERwdPRAjh7ZMwkOfYi2FPydQuBztGO/NSUdD5yX2qFFl/j1B1uAN4sVzToVmEu4Cv0DtNYaSf/i5C4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 42906:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/companiesV.988fed47.png","height":192,"width":240,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAg0lEQVR42mMgCvz//5/l06VVSu+vbl72ZH3JwjcbWxRAYnAFz3bOnPRyX93/t9e3/78zJfz/nVnp/1/sndUFV3BnWsb0x2uS/7+/vOz/y4X5/290+f6/Ozu9jwEODl9lvjkhaNLJqTlPjnTEPjnf7N4Nl7u/tpaRAQHEwRgKrq+tZwQAtdVCy1qdf/sAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 87164:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/companiesVPro.a3accadd.png","height":192,"width":244,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAnklEQVR42mO4++c/IwMOsPIbVO7M1/9xl979lD99/39v/+r/YQc//be8+O2/C1jy////3FMv/Xqx6eSv/8dOvfw/a/37/93bfv5ffe/PDLhRs07/OLn06M//+4+//Ld7w4f/vdu+/V9161sxXMHCE29DuzY+uT5p0e0nLQtvP+nZ9fLg0gMXlMGSG77DHakOxP5A7AXEMkDM+P//f0YAkrFYqadI/GEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 3711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/gift.190e7bff.png","height":29,"width":26,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA2UlEQVR42g3Mvy4EURSA8e/cPbM7wtpmEoUt/IlS4yF4A1GIVxFvoJZoPILSA1DYTkhEQiQiixV2Jpa5d+49pviar/hJuDud0/L9mOX1FZrq3savaywW18CR6lK+ap/zm1zebpDNtlE7o7MwxCZ99Rf1IY/Vlo4akY8msjc4oCx92n8aqr0878rbGIsZEj38uEQv60LccXxXI4qcFCwxCVBkrTgD0pWa9P5EI9I+utqWm7iAoUGl8QMaAx86+AgpdiwlwPrORX/ikn+QWE8RP6X+/RLvb4R4/g/44GfFf6twSwAAAABJRU5ErkJggg==","blurWidth":7,"blurHeight":8});

/***/ }),

/***/ 80363:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/member_bg.8add5d92.png","height":96,"width":183,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAh0lEQVR42i3JQQrCMBAAwM1uibGIerOo1Is3oxcRBd/hazz2WX7FDwiWYg1pEpqsIJ3rCBjcqi9unyHXllZlj4dZwhMJWNI/Hx4/JijPvPAA2gq+GIJji1zQvYrYuqR6CYVTYm9GcG0kn9+Sy5fkkLmaaUxiGufZpsuFtjLuukla144zCtz8AAHINVKE+85WAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 4156:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/step.c91c8721.png","height":16,"width":196,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAKUlEQVR4nGOUyfrL81/gLz9jGyvTvwMv3RiAgMlBfNf/qt//GN8zfQQA0GUNj67aqPkAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":1});

/***/ }),

/***/ 69295:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/tgCode.96f4d115.png","height":184,"width":184,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA+UlEQVR42mOQlpbuERMTq5CTk49UVFTyFRMTT5KSkgkVEhKuEhYS7mYAghIuTq5sdTV1O1lZuTRJSckaoKYwURHRDDFRsQqGysrKrICAAGdmZlZvoGJrIE6SkJDIUFBQNJeXV4hkcHZ2adfS1CoFSqQ5OTnNdnNzmwNk94uLi5cArbVlAIIEUVGxBCAd6urqOhmIJwHZEUAFpfLy8lYMcrJyYbIyclFA1VlAiUYgLgJKzhYRFmkGuiWIQVxcolJaSjpdSVHJWUJcohbo0GB+Pv42Hh6eOjExoCOlJKU6ZGVkS4AmxUtKSNYCrcvj5OA8KSwsXC4tLeMNADKWLvcPDXr3AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 78980:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/** @format */ 
class ErrorBoundary extends react__WEBPACK_IMPORTED_MODULE_0__.Component {
    static getDerivedStateFromError(_) {
        // Update state so the next render will show the fallback UI.
        return {
            hasError: true
        };
    }
    componentDidCatch(error, errorInfo) {
        console.error("Uncaught error:", error, errorInfo);
    }
    render() {
        if (this.state.hasError) {
            return this.props.fallback;
        }
        return this.props.children;
    }
    constructor(...args){
        super(...args);
        this.state = {
            hasError: false
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorBoundary);


/***/ }),

/***/ 45973:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ QRCodePage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var qrcode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1121);
/* harmony import */ var qrcode__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(qrcode__WEBPACK_IMPORTED_MODULE_2__);



function QRCodePage(props) {
    const { link } = props;
    const canvasRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const imgRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const generateQRCode = async ()=>{
            try {
                // 生成二维码数据
                const qrCodeData = await qrcode__WEBPACK_IMPORTED_MODULE_2___default().toDataURL(link, {
                    margin: 3
                });
                // 加载Logo图片
                const logoImage = new Image();
                logoImage.crossOrigin = "anonymous";
                logoImage.src = "https://filscan-v2.oss-accelerate.aliyuncs.com/client/logo.ico" // 替换为你的Logo图片路径
                ;
                // 在Canvas上绘制二维码和Logo图片
                const canvas = canvasRef.current;
                const context = canvas.getContext("2d");
                const qrCodeImage = new Image();
                qrCodeImage.crossOrigin = "anonymous";
                qrCodeImage.src = qrCodeData;
                qrCodeImage.onload = ()=>{
                    context.drawImage(qrCodeImage, 0, 0, canvas.width, canvas.height);
                    setTimeout(()=>{
                        const dataUrl = canvas.toDataURL();
                        imgRef.current.style.width = "110px";
                        imgRef.current.src = dataUrl;
                        canvas.style.display = "none";
                    });
                };
            } catch (error) {
                console.error("生成二维码时出错：", error);
            }
        };
        generateQRCode();
    }, [
        link,
        imgRef.current
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                ref: imgRef,
                width: 0,
                height: 0,
                className: "rounded-md"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("canvas", {
                ref: canvasRef,
                width: 100,
                height: 100,
                className: "rounded-md"
            })
        ]
    });
}


/***/ }),

/***/ 3175:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_1__, _hooks_Translation__WEBPACK_IMPORTED_MODULE_3__]);
([_utils__WEBPACK_IMPORTED_MODULE_1__, _hooks_Translation__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { text, ns } = props;
    const { tr } = (0,_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns
    });
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const showTime = (number)=>{
        let showText = "";
        const { days, hours, minutes, seconds } = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatTime */ .mr)(Number(number * 1000));
        if (days !== 0) {
            showText = `${days}${tr("day")} ${hours}${tr("hours")} ${minutes}${tr("minutes")} `;
        } else if (hours !== 0) {
            showText = `${hours}${tr("hours")} ${minutes}${tr("minutes")} `;
        } else if (minutes !== 0) {
            showText = `${minutes}${tr("minutes")} ${seconds}${tr("seconds")} `;
        } else {
            showText = `${seconds}${tr("seconds")} `;
        }
        setShow(showText);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (text) {
            showTime(text);
        }
        const interval = setInterval(()=>{
            showTime(text);
        }, 1000);
        return ()=>{
            clearInterval(interval);
        };
    }, [
        text
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        children: show
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 29676:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ MobileView),
/* harmony export */   I: () => (/* binding */ BrowserView)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45420);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_useWindown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31061);




const BrowserView = (props)=>{
    const { isMobile } = (0,_hooks_useWindown__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    return isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: props.children
    });
};
const MobileView = (props)=>{
    const { isMobile } = (0,_hooks_useWindown__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    return !isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().mobile)),
        children: props.children
    });
};


/***/ }),

/***/ 44753:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7947);
/* harmony import */ var _device_detect__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(29676);
/* harmony import */ var _components_mobile_footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16151);
/* harmony import */ var _assets_images_code_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7203);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _components_mobile_footer__WEBPACK_IMPORTED_MODULE_4__]);
([_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _components_mobile_footer__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 






const footerLinks = [
    {
        label: "twitter",
        type: "_blank",
        link: "https://twitter.com/FilscanOfficial"
    },
    {
        label: "telegram",
        type: "_blank",
        link: "https://t.me/+bI9fUEkmPjMzYjg1"
    },
    {
        label: "outlook",
        type: "_self",
        link: "mailto:filscanteam@outlook.com"
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "common"
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_device_detect__WEBPACK_IMPORTED_MODULE_3__/* .MobileView */ .$, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_mobile_footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_device_detect__WEBPACK_IMPORTED_MODULE_3__/* .BrowserView */ .I, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "h-[140px] w-screen bg-footerColor",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "custom_footer flex flex-col justify-between bg-footerColor",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                //href={'/'}
                                className: "text_color flex cursor-pointer items-center gap-x-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        src: "https://filscan-v2.oss-cn-hongkong.aliyuncs.com/fvm_manage/images/logo.png",
                                        width: 40,
                                        height: 40,
                                        alt: "logo"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        src: "https://filscan-v2.oss-cn-hongkong.aliyuncs.com/fvm_manage/images/logoText.png",
                                        alt: "logo",
                                        width: 95,
                                        height: 16
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-end justify-between text-border_des",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col gap-y-1 text-xs",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: tr("footer_des1")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: tr("footer_des2")
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex ",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                        className: "flex justify-end gap-x-5 pr-[10px] text-white",
                                                        children: footerLinks.map((linkItem)=>{
                                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                className: "h-5 w-5 rounded bg-white",
                                                                target: linkItem.type,
                                                                style: {
                                                                    color: "#fff"
                                                                },
                                                                href: linkItem.link,
                                                                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_2__/* .getSvgIcon */ .a)(linkItem.label)
                                                            }, linkItem.label);
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "mt-5",
                                                        children: "filscanteam@outlook.com"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "ml-4 flex h-[50] w-[50px] justify-center rounded-[5px] bg-white p-1",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    src: _assets_images_code_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                                    alt: "",
                                                    width: 50
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6509:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _assets_images_author_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(83644);
/* harmony import */ var _assets_images_down_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(80913);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27701);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _store_modules_user__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(63414);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _store_modules_user__WEBPACK_IMPORTED_MODULE_7__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _store_modules_user__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 








//已登录状态
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_8__.observer)(()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const { userInfo } = _store_modules_user__WEBPACK_IMPORTED_MODULE_7__["default"];
    const { superVip } = userInfo;
    const { name, mail } = userInfo;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const showName = name || mail || "";
    if (!showName) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
            href: "/admin/login",
            as: "/admin/login",
            scroll: false,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "border_color main_bg_color primary_btn flex  h-[46px] items-center  justify-center !rounded-none border",
                children: tr("login")
            })
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "group relative text-sm",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: " flex cursor-pointer items-center gap-x-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_author_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        width: 32,
                        height: 32,
                        className: "rounded-full"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: showName?.length > 5 ? showName?.slice(0, 5) + "..." : showName
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_down_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        width: 8,
                        height: 4
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: "select_shadow main_bg_color border_color absolute inset-y-full z-50 hidden h-fit  w-max  list-none rounded-[5px] border p-4  group-hover:block",
                children: _contents_account__WEBPACK_IMPORTED_MODULE_4__/* .account_manager */ .Hp.map((item, index)=>{
                    if (!item?.href) {
                        return null;
                    }
                    if (item.key === "logout") {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            onClick: ()=>{
                                //logout
                                localStorage.removeItem(`mail`);
                                localStorage.removeItem(`token-${mail}`);
                                _store_modules_user__WEBPACK_IMPORTED_MODULE_7__["default"].clearUserInfo();
                                router.push("/admin/login");
                            },
                            className: "text_color  flex h-10 cursor-pointer items-center rounded-[5px] font-normal  hover:bg-bg_hover hover:text-primary",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-center gap-x-2 px-4",
                                children: [
                                    item.icon,
                                    tr(item.label)
                                ]
                            })
                        }, index);
                    }
                    if (item.vip) {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            onClick: ()=>{
                                //vip
                                if (!superVip) {
                                    _store_modules_user__WEBPACK_IMPORTED_MODULE_7__["default"].setVipModal(true);
                                } else {
                                    router.push(`/account/#${item.href}`);
                                }
                            },
                            className: "text_color  flex h-10 cursor-pointer items-center rounded-[5px] font-normal  hover:bg-bg_hover hover:text-primary",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-center gap-x-1 px-4",
                                children: [
                                    item.icon,
                                    tr(item.label),
                                    item.sufIcon
                                ]
                            })
                        }, index);
                    }
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                        href: `/account/#${item.href}`,
                        scroll: false,
                        className: "text_color  flex h-10 cursor-pointer items-center rounded-[5px] font-normal  hover:bg-bg_hover hover:text-primary",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex items-center gap-x-2 px-4",
                            children: [
                                item.icon,
                                tr(item.label),
                                item.sufIcon
                            ]
                        })
                    }, index);
                })
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 27011:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contents_nav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17978);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Search__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(29655);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7947);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _Search__WEBPACK_IMPORTED_MODULE_5__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _Search__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "nav"
    });
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const renderChild = (children, num)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            className: "select_shadow main_bg_color border_color absolute inset-y-full z-50 -ml-8 hidden h-fit  w-max list-none rounded-[5px] border px-4  font-HarmonyOS  group-hover:block",
            children: children.map((item, index)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    href: `${item.link}`,
                    className: "text_color relative flex h-10 cursor-pointer items-center rounded-[5px] font-normal  first:mt-4 last:mb-4 hover:bg-bg_hover hover:text-primary",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "px-4",
                            children: tr(item.key)
                        }),
                        item.sufIcon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "absolute -right-2 -top-[2px]",
                            children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)(item.sufIcon)
                        })
                    ]
                }, index);
            })
        }, num);
    };
    const isHome = router.asPath === "/home" || router.asPath === "/";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "custom_header m-auto flex h-[60px] items-center justify-between  text-sm font-medium",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                href: "/",
                className: "text_color mt-1 flex cursor-pointer items-center gap-x-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        src: "https://filscan-v2.oss-cn-hongkong.aliyuncs.com/fvm_manage/images/logo.png",
                        width: 40,
                        height: 40,
                        alt: "logo"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        src: "https://filscan-v2.oss-cn-hongkong.aliyuncs.com/fvm_manage/images/logoText.png",
                        alt: "logo",
                        width: 95,
                        height: 16
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "ml-5 mr-10 flex-1",
                children: !isHome && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Search__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    className: "!h-10 !max-w-lg "
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative flex h-full items-center justify-between gap-x-9",
                children: _contents_nav__WEBPACK_IMPORTED_MODULE_2__/* .navMenu */ .$.map((nav, index)=>{
                    if (nav?.children) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "group relative flex  h-full cursor-pointer items-center gap-x-1  font-HarmonyOS_Medium hover:text-primary ",
                            children: [
                                tr(nav.key),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("downIcon")
                                }),
                                nav.sufIcon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "absolute -right-[12px] top-[8px]",
                                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)(nav.sufIcon)
                                }),
                                renderChild(nav.children, index)
                            ]
                        }, index);
                    }
                    if (nav.outLink) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative",
                            onClick: ()=>{
                                window?.open(nav.outLink);
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "text_color cursor-pointer list-none  hover:text-primary",
                                    children: tr(nav.key)
                                }),
                                nav.sufIcon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "absolute -right-6 -top-[8px]",
                                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)(nav.sufIcon)
                                })
                            ]
                        }, nav.key);
                    }
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: `${nav.link || nav.outLink}`,
                                className: "text_color cursor-pointer  hover:text-primary",
                                children: tr(nav.key)
                            }),
                            nav.sufIcon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "absolute -right-6 -top-[8px]",
                                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)(nav.sufIcon)
                            })
                        ]
                    }, nav.key);
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 29655:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_search__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1519);
/* harmony import */ var _contents_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5934);
/* harmony import */ var _assets_images_searchIcon_w_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(30434);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(68108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8054);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _ant_design_icons_lib_icons_LoadingOutlined__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(77529);
/* harmony import */ var _ant_design_icons_lib_icons_LoadingOutlined__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons_lib_icons_LoadingOutlined__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_search__WEBPACK_IMPORTED_MODULE_1__, _contents_common__WEBPACK_IMPORTED_MODULE_2__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__]);
([_components_search__WEBPACK_IMPORTED_MODULE_1__, _contents_common__WEBPACK_IMPORTED_MODULE_2__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ origin, className = "" })=>{
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([]);
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)("");
    const [searchLoading, setSearchLoading] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (router.asPath.includes("address/miner")) {
            const addressValue = router.asPath.split("?")[1];
            const showValue = addressValue.split("=")[1];
            handleSearch(showValue);
        }
    }, [
        router
    ]);
    const handleSearch = async (value)=>{
        const showInput = value.trim();
        if (showInput) {
            setSearchLoading(true);
            const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_6__/* .apiUrl */ .JW.searchInfo, {
                input: showInput
            });
            setSearchLoading(false);
            const type = result?.result_type;
            if (type) {
                if (type === "owner") {
                    //owner
                    router.push(`/owner/${showInput}`);
                } else if (type === "address") {
                    router.push(`/address/${showInput}`);
                } else if (type === "height") {
                    router.push(`/height/${showInput}`);
                } else if (type === "message_details") {
                    router.push(`/message/${showInput}`);
                } else if (type === "miner") {
                    router.push(`/miner/${showInput}`);
                } else if (type === "block_details") {
                    router.push(`/cid/${showInput}`);
                } else if (type === "fns") {
                    if (result?.fns_tokens.length > 0) {
                        setOptions(result?.fns_tokens || []);
                        setActive(type);
                    } else {
                        router.push(`/domain/${showInput}`);
                    }
                } else {
                    router.push(`/address/${showInput}`);
                }
            } else {
                //404
                router.push(`/noResult/${showInput}`);
            }
        }
    };
    const handleClick = (item)=>{
        router.push(`/domain/${item.name}?provider=${item.provider}`);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "group relative w-auto",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_search__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                className: `${className} focus:outline-none`,
                ns: "common",
                placeholder: _contents_common__WEBPACK_IMPORTED_MODULE_2__/* .search */ .yC.holder,
                onSearch: handleSearch,
                origin: origin,
                onClick: handleSearch,
                suffix: searchLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex items-center justify-center rounded-[5px] bg-primary",
                    style: {
                        width: origin === "banner" ? 40 : 21,
                        height: origin === "banner" ? 40 : 21
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_ant_design_icons_lib_icons_LoadingOutlined__WEBPACK_IMPORTED_MODULE_9___default()), {
                        className: "custom-icon text-xs"
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_searchIcon_w_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    width: origin === "banner" ? 40 : 21,
                    height: origin === "banner" ? 40 : 21
                })
            }),
            active === "fns" && options && options.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: `card_shadow border_color  absolute flex h-fit w-full  flex-col gap-y-2 border p-3 opacity-0 group-focus-within:opacity-100 ${origin === "home" ? "" : "!max-w-lg"}`,
                children: options.map((item)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: "flex cursor-pointer items-center gap-x-1 rounded-[5px] p-2 hover:bg-bg_hover",
                        onClick: ()=>handleClick(item),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                src: item.icon,
                                alt: "",
                                width: 45,
                                height: 45,
                                className: "logo_img rounded-[5px]"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: item.name
                            })
                        ]
                    }, item.value);
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3340:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5934);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62881);
/* harmony import */ var _assets_images_code_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7203);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(25572);
/* harmony import */ var _Account__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6509);
/* harmony import */ var _Nav__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(27011);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _packages_select__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(76423);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7947);
/* harmony import */ var _i18n__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(21091);
/* harmony import */ var _device_detect__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(29676);
/* harmony import */ var _components_mobile_header_index__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(79733);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(68108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8054);
/* harmony import */ var _TimerHtml__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3175);
/* harmony import */ var _hooks_useInterval__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(39447);
/* harmony import */ var _store_modules_Cw__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(85166);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_20__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contents_common__WEBPACK_IMPORTED_MODULE_1__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _Account__WEBPACK_IMPORTED_MODULE_5__, _Nav__WEBPACK_IMPORTED_MODULE_6__, _packages_select__WEBPACK_IMPORTED_MODULE_8__, _i18n__WEBPACK_IMPORTED_MODULE_11__, _components_mobile_header_index__WEBPACK_IMPORTED_MODULE_13__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_14__, _TimerHtml__WEBPACK_IMPORTED_MODULE_16__]);
([_contents_common__WEBPACK_IMPORTED_MODULE_1__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _Account__WEBPACK_IMPORTED_MODULE_5__, _Nav__WEBPACK_IMPORTED_MODULE_6__, _packages_select__WEBPACK_IMPORTED_MODULE_8__, _i18n__WEBPACK_IMPORTED_MODULE_11__, _components_mobile_header_index__WEBPACK_IMPORTED_MODULE_13__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_14__, _TimerHtml__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 




















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_20__.observer)(()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "common"
    });
    const { headerShow, theme, lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_4__["default"];
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)();
    const [fil, setFilData] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [finalHeight, setFinalHeight] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [lastScrollTop, setLastScrollTop] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        const handleScroll = ()=>{
            const st = window.pageYOffset || document.documentElement.scrollTop;
            if (st > lastScrollTop) {
                _store_modules_filscan__WEBPACK_IMPORTED_MODULE_4__["default"].setHeaderShow(false);
            } else {
                _store_modules_filscan__WEBPACK_IMPORTED_MODULE_4__["default"].setHeaderShow(true);
            }
            setLastScrollTop(st <= 0 ? 0 : st);
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>window.removeEventListener("scroll", handleScroll);
    }, [
        lastScrollTop
    ]);
    (0,_hooks_useInterval__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z)(()=>{
        loadFilPrice();
    }, 15000);
    const loadFilPrice = async ()=>{
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_15__/* .FilPrice */ .lR);
        if (result && result.price) {
            setFilData(result || {});
        }
        const finalHeight = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_15__/* .FinalHeight */ .kY);
        _store_modules_Cw__WEBPACK_IMPORTED_MODULE_18__["default"].setFinalHeight(finalHeight?.height);
        if (finalHeight?.height) {
            setFinalHeight(finalHeight || {});
        }
    };
    const handleLangChange = (value)=>{
        localStorage.setItem("lang", value);
        _i18n__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z.changeLanguage(lang) // 更改i18n语言
        ;
        _store_modules_filscan__WEBPACK_IMPORTED_MODULE_4__["default"].setLang(value);
        router.push(router.asPath, router.asPath, {
            locale: value
        });
    };
    const handleNetwork = (value)=>{
        if (value === "Calibration") {
            window.open("https://calibration.filscan.io/");
        } else if (value === "Mainnet") {
            window.open("https://filscan.io/");
        }
    };
    const apiFlag = "Mainnet";
    // px-24
    const headerFade = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        let clsStr = "";
        if (router.asPath.startsWith("/statistics/charts/")) {
            clsStr = "fixed top-0";
            return clsStr;
        }
        if (headerShow) {
            clsStr = "header-fade-in visible fixed top-0 ";
        } else {
            clsStr = "absolute top-0";
        }
        if (lastScrollTop > 100) {
            clsStr = clsStr + "header-fade-in ";
        }
        return clsStr;
    }, [
        headerShow,
        lastScrollTop,
        router
    ]);
    // const showTheme = document.documentElement.getAttribute('theme')
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_device_detect__WEBPACK_IMPORTED_MODULE_12__/* .MobileView */ .$, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_mobile_header_index__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                    data: {
                        ...fil,
                        ...finalHeight
                    }
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_device_detect__WEBPACK_IMPORTED_MODULE_12__/* .BrowserView */ .I, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `${headerFade} main_bg_color  top-0 z-50 h-[110px] w-full`,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "custom_header flex h-[45px] w-full items-center justify-between text-xs",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: "flex list-none gap-x-5",
                                    children: _contents_common__WEBPACK_IMPORTED_MODULE_1__/* .header_top */ .cK.left.map((item, index)=>{
                                        const { title, dataIndex, render } = item;
                                        const data = {
                                            ...fil,
                                            ...finalHeight
                                        };
                                        const value = data && data[dataIndex] || "";
                                        let renderDom = render && render(value, data);
                                        if (dataIndex === "block_time") {
                                            renderDom = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TimerHtml__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                ns: "home",
                                                text: value
                                            });
                                        }
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "flex gap-x-1",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    children: [
                                                        tr(title),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: renderDom || value
                                                })
                                            ]
                                        }, index);
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center gap-x-2.5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_select__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                            ns: "",
                                            wrapClassName: "main_bg_color",
                                            className: "!-inset-x-1/2 ",
                                            value: apiFlag || "Mainnet",
                                            header: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "main_bg_color border_color flex h-7 w-7 cursor-pointer  items-center justify-center rounded-[5px] border ",
                                                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_10__/* .getSvgIcon */ .a)("code")
                                            }),
                                            onChange: handleNetwork,
                                            // options={ []}
                                            optionsCard: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: `flex w-[120px] flex-col items-center `,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_19___default()), {
                                                        src: _assets_images_code_png__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                                                        alt: "",
                                                        width: 120,
                                                        className: `${theme === "dark" ? "rounded-[5px] bg-white p-2" : ""}`
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "text_des mt-2.5 flex flex-col items-center  text-center text-xs",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "mb-[2px] ",
                                                                children: tr("mobile_code_1")
                                                            }),
                                                            tr("mobile_code_2")
                                                        ]
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_select__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                            ns: "",
                                            wrapClassName: "main_bg_color",
                                            className: "!-inset-x-1/2 ",
                                            value: apiFlag || "Mainnet",
                                            header: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "main_bg_color border_color flex h-7 w-7 cursor-pointer  items-center justify-center rounded-[5px] border ",
                                                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_10__/* .getSvgIcon */ .a)("network")
                                            }),
                                            onChange: handleNetwork,
                                            options: _contents_common__WEBPACK_IMPORTED_MODULE_1__/* .networkOptions */ .Dc
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_select__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                            ns: "",
                                            wrapClassName: "main_bg_color",
                                            className: "!-inset-x-1/2 ",
                                            header: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "main_bg_color border_color flex h-7 w-7 cursor-pointer items-center  justify-center rounded-[5px] border",
                                                children: tr(lang)
                                            }),
                                            value: lang,
                                            onChange: handleLangChange,
                                            options: _contents_common__WEBPACK_IMPORTED_MODULE_1__/* .langOptions */ .YH
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: theme === "dark" ? "border_color h-7 w-7 cursor-pointer rounded-[5px] border text-white" : "cursor-pointer",
                                            onClick: (e)=>{
                                                e.stopPropagation();
                                                if (!router.pathname.startsWith("/analysis/fund")) {
                                                    localStorage.setItem("theme", theme === "dark" ? "light" : "dark");
                                                    _store_modules_filscan__WEBPACK_IMPORTED_MODULE_4__["default"].setTheme(theme === "dark" ? "light" : "dark");
                                                }
                                            },
                                            children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_10__/* .getSvgIcon */ .a)(theme === "dark" ? "sun" : "moon")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Account__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                            className: "border_color"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Nav__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                    ]
                })
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 62881:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W: () => (/* binding */ Translation)
/* harmony export */ });
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25572);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Translation = (props)=>{
    const { ns } = props;
    const { lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_0__["default"];
    const { t, i18n } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)(ns);
    // 当 lang 状态改变时，重新设置语言
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        i18n.changeLanguage(lang);
    }, [
        lang
    ]);
    const tr = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: ns
            });
        }
        return t(label, {
            ns: ns
        });
    }, [
        i18n.language
    ]);
    return {
        tr
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 39447:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/** @format */ 
function useInterval(callback, delay) {
    const savedCallback = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
    // 保存新回调
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        savedCallback.current = callback;
    }, [
        callback
    ]);
    // 设置 interval
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        function tick() {
            if (savedCallback.current !== null) {
                savedCallback.current();
            }
        }
        if (delay !== null) {
            tick();
            let id = setInterval(tick, delay);
            return ()=>clearInterval(id);
        }
    }, [
        delay
    ]);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useInterval);


/***/ }),

/***/ 31061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store_DeviceContext__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42707);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const useWindow = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_store_DeviceContext__WEBPACK_IMPORTED_MODULE_0__/* .DeviceContext */ .T);
    const [isMobile, setIsMobile] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const calcWidth = ()=>{
        let windowHeight = document.documentElement.clientHeight;
        let elements = document.getElementsByClassName("container_body");
        for(let i = 0; i < elements.length; i++){
            elements[i].style.minHeight = windowHeight + "px" // 将高度值转换为字符串，并添加单位
            ;
        }
    };
    const onResize = ()=>{
        calcWidth();
        setIsMobile(window.innerWidth <= 1000);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        window.addEventListener("resize", onResize);
        calcWidth();
        setIsMobile(window.innerWidth <= 1000);
        return ()=>{
            window.removeEventListener("resize", onResize);
        };
    }, []);
    return {
        isMobile: isMobile ?? context.isMobile
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useWindow);


/***/ }),

/***/ 16151:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(47687);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57987);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7947);
/* harmony import */ var _assets_images_logo_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(71062);
/* harmony import */ var _assets_images_logoText_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(67937);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const links = [
    {
        label: "twitter",
        type: "_blank",
        link: "https://twitter.com/FilscanOfficial"
    },
    {
        label: "telegram",
        type: "_blank",
        link: "https://t.me/+bI9fUEkmPjMzYjg1"
    },
    {
        label: "outlook",
        type: "_self",
        link: "mailto:filscan@ipfsforce.com"
    }
];
const Header = ()=>{
    const { t } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)("common");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["footer-wrap"]),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default().top),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                        src: _assets_images_logo_png__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                        alt: "logo"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                        src: _assets_images_logoText_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                        alt: "logo"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default().text)),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: t("footer_des1")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: t("footer_des2")
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default().bottom)),
                children: links.map((item, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        target: item.type,
                        style: {
                            color: "#fff"
                        },
                        href: item.link,
                        children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_3__/* .getSvgIcon */ .a)(item.label)
                    }, item.label);
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 79733:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _assets_images_header_icon_close_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(15177);
/* harmony import */ var _assets_images_header_icon_open_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(58644);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(58327);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var antd_lib_menu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(10274);
/* harmony import */ var antd_lib_menu__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd_lib_menu__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57987);
/* harmony import */ var _contents_nav__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(17978);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1712);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_get__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _assets_images_logo_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(71062);
/* harmony import */ var _assets_images_logoText_png__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(67937);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(62881);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _contents_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5934);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(25572);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _store_modules_user__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(63414);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_18__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_6__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_12__, _contents_common__WEBPACK_IMPORTED_MODULE_14__, _store_modules_user__WEBPACK_IMPORTED_MODULE_17__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_6__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_12__, _contents_common__WEBPACK_IMPORTED_MODULE_14__, _store_modules_user__WEBPACK_IMPORTED_MODULE_17__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




















const rootSubmenuKeys = [
    "1",
    "2",
    "3",
    "4",
    "5"
];
const Header = (props)=>{
    const { t } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)("nav");
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_12__/* .Translation */ .W)({
        ns: "common"
    });
    const { tr: trr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_12__/* .Translation */ .W)({
        ns: "account"
    });
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [openKeys, setOpenKeys] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const [selectKeys, setSelectKeys] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const { lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_15__["default"];
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        document.body.style.overflow = open ? "hidden" : "auto";
    }, [
        open
    ]);
    const onOpen = ()=>{
        setSelectKeys([]);
        setOpenKeys([]);
        setOpen(!open);
    };
    const onOpenChange = (keys)=>{
        const latestOpenKey = keys.find((key)=>openKeys.indexOf(key) === -1);
        if (latestOpenKey && rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
            setOpenKeys(keys);
        } else {
            setOpenKeys(latestOpenKey ? [
                latestOpenKey
            ] : []);
        }
    };
    const onSelect = (select)=>{
        setOpen(false);
        setSelectKeys(select.selectedKeys);
        const child = lodash_get__WEBPACK_IMPORTED_MODULE_9___default()(_contents_nav__WEBPACK_IMPORTED_MODULE_7__/* .mobileNavMenu */ .s, select.key);
        if (child.value) {
            const value = child.value;
            if (child.type === "lang") {
                localStorage.setItem("lang", value);
                _store_modules_filscan__WEBPACK_IMPORTED_MODULE_15__["default"].setLang(value);
                router.push(router.asPath, router.asPath, {
                    locale: value
                });
                return;
            }
            if (child.type === "network") {
                if (value === "Calibration") {
                    window.open("https://calibration.filscan.io/");
                } else if (value === "Mainnet") {
                    window.open("https://filscan.io/");
                }
                return;
            }
        }
        router.push(child.link);
    };
    function getItem(label, key, children, type) {
        return {
            key,
            children,
            label,
            type
        };
    }
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        let _items = [];
        _contents_nav__WEBPACK_IMPORTED_MODULE_7__/* .mobileNavMenu */ .s.filter((value, index)=>{
            if (_store_modules_user__WEBPACK_IMPORTED_MODULE_17__["default"].isLogin) {
                return true;
            }
            return value.type !== "account";
        }).forEach((value0, index0)=>{
            if (value0.children) {
                let __items = [];
                value0.children.forEach((value1, index1)=>{
                    if (value1.children) {
                        let label = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                        if (value1.key === "overview") {
                            label = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: `${value0.type === "account" ? trr(value1.key) : t(value1.key)}`
                            });
                        } else {
                            label = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: `${value0.type === "account" ? trr(value1.key) : t(value1.key)}`
                            });
                        }
                        __items.push(getItem(label, `[${index0}].children[${[
                            index1
                        ]}]`, value1.children.map((value2, index2)=>{
                            return getItem(`${value0.type === "account" ? trr(value2.key) : t(value2.key)}`, `[${index0}].children[${[
                                index1
                            ]}].children[${[
                                index2
                            ]}]`);
                        })));
                    } else {
                        let label = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                        if (value1.key === "overview") {
                            label = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: `${value0.type === "account" ? trr(value1.key) : t(value1.key)}`
                            });
                        } else {
                            label = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: `${value0.type === "account" ? trr(value1.key) : t(value1.key)}`
                            });
                        }
                        __items.push(getItem(label, `[${index0}].children[${[
                            index1
                        ]}]`));
                    }
                });
                _items.push(getItem(`${value0.type === "account" ? trr(value0.key) : t(value0.key)}`, index0, __items));
            } else {
                _items.push(getItem(`${t(value0.key)}`, `[${index0}]`));
            }
        });
        setItems(_items);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        lang,
        t,
        trr,
        _store_modules_user__WEBPACK_IMPORTED_MODULE_17__["default"].isLogin
    ]);
    const onClick = ()=>{
        router.push("/");
    };
    const onMaskClick = ()=>{
        setOpen(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_19___default()["header-wrap"]),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_19___default().header),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_19___default().nav),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_19___default().logo),
                                onClick: onClick,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_13___default()), {
                                        src: _assets_images_logo_png__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                                        alt: "logo"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_13___default()), {
                                        src: _assets_images_logoText_png__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z,
                                        alt: "logo"
                                    })
                                ]
                            }),
                            open ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_header_icon_close_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                onClick: onOpen
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_header_icon_open_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                onClick: onOpen
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_19___default().fil),
                        children: _contents_common__WEBPACK_IMPORTED_MODULE_14__/* .header_top */ .cK.left.filter((value)=>{
                            return value.dataIndex === "base_fee" || value.dataIndex === "price";
                        }).map((item, index)=>{
                            const { title, dataIndex, render } = item;
                            const value = props.data && props.data[dataIndex];
                            let renderDom = render && render(value, props.data);
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "flex gap-x-1",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        children: [
                                            tr(title),
                                            ":"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: renderDom || value
                                    })
                                ]
                            }, dataIndex);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "mask",
                onClick: onMaskClick,
                className: classnames__WEBPACK_IMPORTED_MODULE_4___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_19___default().body), open ? (_index_module_scss__WEBPACK_IMPORTED_MODULE_19___default().active) : ""),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    onClick: (e)=>{
                        e.stopPropagation();
                    },
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_19___default().menuWrap),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_menu__WEBPACK_IMPORTED_MODULE_5___default()), {
                            mode: "inline",
                            selectedKeys: selectKeys,
                            openKeys: openKeys,
                            onOpenChange: onOpenChange,
                            onSelect: onSelect,
                            items: items
                        }),
                        !_store_modules_user__WEBPACK_IMPORTED_MODULE_17__["default"].isLogin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_18___default()), {
                            href: "/admin/login",
                            onClick: ()=>{
                                setOpen(false);
                            },
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_19___default().login),
                            children: t("login")
                        }),
                        _store_modules_user__WEBPACK_IMPORTED_MODULE_17__["default"].isLogin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            onClick: ()=>{
                                localStorage.removeItem(`mail`);
                                localStorage.removeItem(`token-${_store_modules_user__WEBPACK_IMPORTED_MODULE_17__["default"].userInfo.mail}`);
                                _store_modules_user__WEBPACK_IMPORTED_MODULE_17__["default"].clearUserInfo();
                                router.reload();
                                setOpen(false);
                            },
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_19___default()["log-out"]),
                            children: t("logout")
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_16__.observer)(Header));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8825:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _assets_images_header_icon_search_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(51779);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(83651);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(30675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(68108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8054);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_8__]);
([_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const Search = (props)=>{
    const [isSearch, setIsSearch] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const { t } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_8__.useTranslation)("common");
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)();
    const onMaskClick = ()=>{
        setIsSearch(true);
        ref.current.focus();
    };
    const onCancelClick = ()=>{
        setIsSearch(false);
    };
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const onSearch = async (value)=>{
        const showInput = value.trim();
        if (showInput) {
            const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_6__/* .apiUrl */ .JW.searchInfo, {
                input: showInput
            });
            const type = result?.result_type;
            if (type) {
                if (type === "owner") {
                    //owner
                    router.push(`/owner/${showInput}`);
                } else if (type === "address") {
                    router.push(`/address/${showInput}`);
                } else if (type === "height") {
                    router.push(`/height/${showInput}`);
                } else if (type === "message_details") {
                    router.push(`/message/${showInput}`);
                } else if (type === "miner") {
                    router.push(`/miner/${showInput}`);
                } else if (type === "block_details") {
                    router.push(`/cid/${showInput}`);
                } else if (type === "fns") {
                    router.push(`/domain/${showInput}`);
                } else {
                    router.push(`/address/${showInput}`);
                }
            } else {
                //404
                router.push(`/noResult/${showInput}`);
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().wrap), props.className),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default()["search-wrap"]), isSearch ? "" : (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().disabled)),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().search),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                            action: "",
                            id: "search-form",
                            onSubmit: (e)=>{
                                onSearch(ref.current.input.value);
                                e.preventDefault();
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default()), {
                                type: "search",
                                allowClear: true,
                                ref: ref,
                                prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_header_icon_search_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
                                onBlur: (e)=>{
                                    setIsSearch(false);
                                }
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: onCancelClick,
                        children: t("cancel")
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                onClick: onMaskClick,
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default()["mask-wrap"]), isSearch ? (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().disabled) : ""),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().mask)),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_header_icon_search_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: t("search_holder")
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Search);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1519:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(30675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(96298);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62881);
/* harmony import */ var _assets_images_searchIcon_b_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(23001);
/* harmony import */ var _assets_images_searchIcon_w_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(30434);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(93908);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__]);
_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ className, origin, onSearch, onClick, onBlur, ns, placeholder = "", suffix, clear, disabled = false, value })=>{
    const { tr } = (0,_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns
    });
    const [inputValue, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        if (value) {
            setValue(value.trim());
        }
    }, [
        value
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_1___default()), {
            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default().search_input)} text-color custom_input  ${className} ${origin === "banner" ? `custom_input_banner ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default().banner_search)}` : ""}`,
            placeholder: tr(placeholder),
            value: inputValue,
            onChange: (e)=>{
                if (!disabled) {
                    setValue(e.target.value.trim());
                }
            },
            onPressEnter: lodash_debounce__WEBPACK_IMPORTED_MODULE_6___default()(()=>{
                if (clear) {
                    setValue("");
                }
                onSearch(inputValue);
            }, 300),
            onBlur: ()=>{
                if (onBlur) {
                    onBlur();
                }
            },
            suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "cursor-pointer",
                onClick: lodash_debounce__WEBPACK_IMPORTED_MODULE_6___default()(()=>{
                    if (onClick && inputValue?.length > 0) {
                        if (clear) {
                            setValue("");
                        }
                        onSearch(inputValue);
                    }
                }, 300),
                children: suffix
            }) || /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: origin === "banner" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_searchIcon_b_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_searchIcon_w_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            })
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 27701:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AW: () => (/* binding */ userType),
/* harmony export */   Ay: () => (/* binding */ active_member_detail),
/* harmony export */   GK: () => (/* binding */ personal_setting),
/* harmony export */   G_: () => (/* binding */ overview),
/* harmony export */   Gu: () => (/* binding */ account_power),
/* harmony export */   Hp: () => (/* binding */ account_manager),
/* harmony export */   JQ: () => (/* binding */ account_gas),
/* harmony export */   Jd: () => (/* binding */ account_power_mobile),
/* harmony export */   Oy: () => (/* binding */ account_miners),
/* harmony export */   RA: () => (/* binding */ member_main),
/* harmony export */   TM: () => (/* binding */ member_list_1),
/* harmony export */   Vl: () => (/* binding */ active_member),
/* harmony export */   W6: () => (/* binding */ active_member_share),
/* harmony export */   ZE: () => (/* binding */ vipList),
/* harmony export */   dc: () => (/* binding */ account_gas_mobile),
/* harmony export */   i5: () => (/* binding */ monitor_list),
/* harmony export */   j_: () => (/* binding */ account_balance),
/* harmony export */   lI: () => (/* binding */ defaultWarn),
/* harmony export */   lg: () => (/* binding */ account_reward_mobile),
/* harmony export */   n1: () => (/* binding */ account_lucky),
/* harmony export */   nS: () => (/* binding */ account_expired),
/* harmony export */   tI: () => (/* binding */ active_member_list),
/* harmony export */   vw: () => (/* binding */ account_reward),
/* harmony export */   wD: () => (/* binding */ member_list_2)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7947);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(23495);
/* harmony import */ var _src_account_monitor_ActiveRules__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5039);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _packages_textTooltip__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(92642);
/* harmony import */ var _assets_images_member_memberPower_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(84846);
/* harmony import */ var _assets_images_member_memberBalance_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(36594);
/* harmony import */ var _assets_images_member_memberSector_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5312);
/* harmony import */ var _assets_images_member_email_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7729);
/* harmony import */ var _assets_images_member_msg_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(92460);
/* harmony import */ var _assets_images_member_phone_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(72715);
/* harmony import */ var _assets_images_member_power_svg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(10838);
/* harmony import */ var _assets_images_member_balance_svg__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(49629);
/* harmony import */ var _assets_images_member_sector_svg__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8093);
/* harmony import */ var _assets_images_member_activePower_svg__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(10155);
/* harmony import */ var _assets_images_member_activeBalance_svg__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(22643);
/* harmony import */ var _assets_images_member_activeSector_svg__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1530);
/* harmony import */ var _assets_images_member_activeWarn_svg__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(82829);
/* harmony import */ var _assets_images_member_companies_svg__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(89626);
/* harmony import */ var _assets_images_member_companiesV_png__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(42906);
/* harmony import */ var _assets_images_member_companiesVPro_png__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(87164);
/* harmony import */ var _assets_images_member_active1_png__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(60258);
/* harmony import */ var _assets_images_member_active2_png__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(47334);
/* harmony import */ var _assets_images_member_active3_png__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(37107);
/* harmony import */ var _assets_images_step_png__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(4156);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _assets_images_member_vip_svg__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(62539);
/* harmony import */ var _assets_images_freeVip_png__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(97485);
/* harmony import */ var _assets_images_user_svg__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(48134);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_3__, _src_account_monitor_ActiveRules__WEBPACK_IMPORTED_MODULE_4__]);
([_utils__WEBPACK_IMPORTED_MODULE_3__, _src_account_monitor_ActiveRules__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 






























const userType = {
    NormalVIP: {
        title: "default_user",
        bgColor: "",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_user_svg__WEBPACK_IMPORTED_MODULE_30__/* ["default"] */ .Z, {
            width: 20,
            height: 20
        })
    },
    EnterpriseVIP: {
        title: "companies",
        bgColor: "rgba(214, 156, 98, 1)",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_27___default()), {
            src: _assets_images_member_companiesV_png__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z,
            width: 32,
            alt: ""
        })
    },
    EnterpriseProVIP: {
        title: "companiesPro",
        bgColor: "rgba(15, 24, 51, 1)",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_27___default()), {
            src: _assets_images_member_companiesVPro_png__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z,
            width: 32,
            alt: ""
        })
    }
};
const vipList = [
    "EnterpriseVIP",
    "EnterpriseProVIP"
];
const account_manager = [
    {
        label: "overview",
        icon: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("account_panel"),
        href: "overview",
        key: "overview"
    },
    {
        label: "data_details",
        icon: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("account_overview"),
        key: "data_details",
        children: [
            {
                label: "power",
                key: "power"
            },
            {
                label: "gas",
                key: "gas"
            },
            {
                label: "expired",
                key: "expired"
            },
            {
                label: "reward",
                key: "reward"
            },
            {
                label: "lucky",
                key: "lucky"
            },
            {
                label: "balance",
                key: "balance"
            }
        ]
    },
    {
        label: "monitor",
        icon: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("monitor"),
        href: "monitorBalance",
        key: "monitor",
        sufIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_vip_svg__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z, {
            width: 16
        }),
        vip: true,
        children: [
            {
                label: "monitorBalance",
                key: "monitorBalance"
            },
            {
                label: "monitorSector",
                key: "monitorSector"
            },
            {
                label: "monitorPower",
                key: "monitorPower"
            }
        ]
    },
    {
        label: "miners",
        icon: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("account_miners"),
        key: "miners",
        href: "miners"
    },
    {
        label: "active",
        href: "active",
        sufIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_27___default()), {
            src: _assets_images_freeVip_png__WEBPACK_IMPORTED_MODULE_29__/* ["default"] */ .Z,
            alt: "",
            height: 13
        }),
        icon: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("member_active"),
        key: "active"
    },
    {
        label: "personal",
        icon: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("account_personal"),
        key: "personal",
        href: "personal"
    },
    {
        label: "logout",
        href: "logout",
        // titleIcon:'',
        icon: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("account_logout"),
        key: "logout"
    }
];
const personal_setting = [
    // {
    //   title: 'personal_name',
    //   dataIndex: 'name',
    //   placeholder: 'personal_name_holder',
    // },
    {
        title: "old_password",
        placeholder: "old_placeholder",
        dataIndex: "old_password",
        rules: [
            {
                required: true,
                message: "old_placeholder is required"
            }
        ]
    },
    {
        title: "new_password",
        placeholder: "new_placeholder",
        dataIndex: "new_password",
        rules: [
            {
                required: true,
                message: "${new_password} is required"
            }
        ]
    },
    {
        title: "confirm_password",
        dataIndex: "confirm_password",
        placeholder: "confirm_password",
        rules: [
            {
                required: true,
                message: "${confirm_password} is required"
            }
        ]
    }
];
const overview = {
    headerList: [
        [
            {
                title: "quality_power_24",
                icon: "power",
                dataIndex: "sum_quality_adj_power",
                render: (text, record, tr)=>{
                    const changeText = record?.sum_power_change_24h ? Number(record.sum_power_change_24h) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(text, 2).split(" ");
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex h-full w-full flex-col justify-between",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text_des text-sm",
                                        children: tr("quality_power_24")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: className,
                                        children: changeText ? flag + (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(changeText, 2) : "--"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text_clip flex items-baseline gap-x-1 font-HarmonyOS_Bold text-xl font-semibold",
                                children: [
                                    textValue,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text_color text-sm",
                                        children: unit
                                    })
                                ]
                            })
                        ]
                    });
                }
            },
            {
                title: "total_reward_24",
                icon: "reward",
                dataIndex: "sum_reward_change_24h",
                render: (text, record, tr)=>{
                    // const changeText = record?.sum_reward_change_24h
                    //   ? Number(record.sum_reward_change_24h)
                    //   : '';
                    // const flag = changeText ? (changeText > 0 ? '+' : '-') : '';
                    // const className = changeText
                    //   ? changeText > 0
                    //     ? 'text_green'
                    //     : 'text_red'
                    //   : '';
                    const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatFil */ .Uk)(text, "FIL", 4, true).split(" ");
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex h-full w-full flex-col justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "flex flex-col",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text_des text-sm",
                                    children: tr("total_reward_24")
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text_clip flex items-baseline gap-x-1 font-HarmonyOS_Bold text-xl font-semibold",
                                children: [
                                    textValue,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm",
                                        children: unit
                                    })
                                ]
                            })
                        ]
                    });
                }
            }
        ],
        [
            {
                title: "total_out_come_gas",
                icon: "gas",
                dataIndex: "sum_outlay",
                render: (text, record, tr)=>{
                    const changeText = record?.sum_gas ? Number(record.sum_gas) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "text_des_unit";
                    const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatFil */ .Uk)(text, "FIL", 4, true).split(" ");
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex h-full w-full flex-col justify-between",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text_des text-sm",
                                        children: tr("total_out_come_gas")
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: className,
                                        children: [
                                            flag,
                                            changeText ? (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatFil */ .Uk)(Math.abs(Number(changeText)), "FIL", 4, true) : "--"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text_clip flex items-baseline gap-x-1 font-HarmonyOS_Bold text-xl font-semibold",
                                children: [
                                    textValue,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm",
                                        children: unit
                                    })
                                ]
                            })
                        ]
                    });
                }
            },
            {
                title: "pledge_amount_24",
                icon: "pledge",
                dataIndex: "sum_pledge",
                render: (text, record, tr)=>{
                    const changeText = record?.sum_pledge_change_24h ? Number(record.sum_pledge_change_24h) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatFil */ .Uk)(text, "FIL", 4, true).split(" ");
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex h-full w-full flex-col justify-between",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text_des text-sm",
                                        children: tr("pledge_amount_24")
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: className,
                                        children: [
                                            flag,
                                            changeText ? (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatFil */ .Uk)(Math.abs(Number(changeText)), "FIL", 2, true) : "--"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text_clip flex items-baseline gap-x-1 font-HarmonyOS_Bold text-xl font-semibold",
                                children: [
                                    textValue,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm",
                                        children: unit
                                    })
                                ]
                            })
                        ]
                    });
                }
            },
            {
                title: "balance_24",
                icon: "balance",
                dataIndex: "sum_balance",
                render: (text, record, tr)=>{
                    const changeText = record?.sum_balance_change_24h ? Number(record.sum_balance_change_24h) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatFil */ .Uk)(text, "FIL", 4, true).split(" ");
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex h-full w-full flex-col justify-between",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text_des text-sm",
                                        children: tr("balance_24")
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: className,
                                        children: [
                                            flag,
                                            changeText ? (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatFil */ .Uk)(Math.abs(Number(changeText)), "FIL", 2, true) : "--"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text_clip flex items-baseline gap-x-1 font-HarmonyOS_Bold text-xl font-semibold",
                                children: [
                                    textValue,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm",
                                        children: unit
                                    })
                                ]
                            })
                        ]
                    });
                }
            }
        ]
    ],
    columns: (tr)=>[
            // {
            //   title: 'tag',
            //   dataIndex: 'tag',
            //   fixed: 'left',
            //   width: 100,
            //   ellipsis: {
            //     showTitle: false,
            //   },
            //   render: (text: string, record: any) => {
            //     return <TagInput text={text} isEdit={false} record={record} />;
            //   },
            // },
            {
                title: "group_name",
                dataIndex: "group_name",
                width: 100,
                fixed: "left",
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-fit rounded-[5px]  p-2 ",
                        children: showText
                    });
                }
            },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: 150,
                fixed: "left",
                render: (text, record)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: `/miner/${text}`,
                                className: "link_text",
                                children: text
                            }),
                            record?.tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "w-fit max-w-[60px] rounded-[5px] bg-bg_hover px-2 py-1 text-xs  text-primary",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    text: record?.tag,
                                    className: "whitespace-nowrap"
                                })
                            })
                        ]
                    });
                }
            },
            {
                title: "quality_power",
                dataIndex: "total_quality_adj_power",
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "raw_power",
                dataIndex: "total_raw_byte_power",
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "total_reward_24",
                dataIndex: "reward_change_24h",
                //  exports: ['reward_change_24h'],
                amountUnit: {
                    reward_change_24h: {
                        unit: "fil"
                    }
                },
                render: (text)=>renderFil(text)
            },
            {
                title: "total_out_come_gas",
                dataIndex: "total_outlay",
                exports: [
                    "total_gas"
                ],
                amountUnit: {
                    total_outlay: {
                        unit: "fil",
                        number: 2
                    },
                    total_gas: {
                        unit: "fil",
                        number: 2
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.total_gas ? Number(record.total_gas) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "pledge_amount_24",
                dataIndex: "total_pledge_amount",
                exports: [
                    "pledge_change_24h"
                ],
                amountUnit: {
                    pledge_change_24h: {
                        unit: "fil",
                        number: 2
                    },
                    total_pledge_amount: {
                        unit: "fil",
                        number: 2
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.pledge_change_24h ? Number(record.pledge_change_24h) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "balance_24",
                dataIndex: "total_balance",
                exports: [
                    "balance_change_24h"
                ],
                amountUnit: {
                    balance_change_24h: {
                        unit: "fil",
                        number: 2
                    },
                    total_balance: {
                        unit: "fil",
                        number: 2
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.balance_change_24h ? Number(record.balance_change_24h) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            }
        ]
};
const account_lucky = {
    columns: (tr)=>[
            {
                title: "group_name",
                dataIndex: "group_name",
                width: 100,
                ellipsis: {
                    showTitle: false
                },
                fixed: "left",
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text_color text_color w-fit rounded-[5px] p-2 font-normal",
                        children: showText
                    });
                }
            },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: 100,
                fixed: "left",
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center gap-x-[1px]",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: `/miner/${text}`,
                                    className: "link_text",
                                    children: text
                                }),
                                record?.tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "w-fit max-w-[60px] rounded-[5px] bg-bg_hover px-2 py-1 text-xs  text-primary",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        text: record?.tag,
                                        className: "whitespace-nowrap"
                                    })
                                })
                            ]
                        })
                    });
                }
            },
            {
                title: "24h_lucky",
                dataIndex: "lucky_rate_24h",
                width: "15%",
                amountUnit: {
                    lucky_rate_24h: {
                        unit: "%",
                        number: 2
                    }
                },
                render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatNumberPercentage */ .Fy)(text) + "%" : text
            },
            {
                title: "7d_lucky",
                dataIndex: "lucky_rate_7d",
                width: "15%",
                amountUnit: {
                    lucky_rate_7d: {
                        unit: "%",
                        number: 2
                    }
                },
                render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatNumberPercentage */ .Fy)(text) + "%" : text
            },
            {
                title: "30d_lucky",
                dataIndex: "lucky_rate_30d",
                amountUnit: {
                    lucky_rate_30d: {
                        unit: "%",
                        number: 2
                    }
                },
                width: "15%",
                render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatNumberPercentage */ .Fy)(text) + "%" : text
            }
        ]
};
const account_balance = {
    columns: (tr)=>[
            // {
            //   title: 'tag',
            //   dataIndex: 'tag',
            //   fixed: 'left',
            //   width: 100,
            //   ellipsis: {
            //     showTitle: false,
            //   },
            //   render: (text: string, record: any) => {
            //     return <TagInput isEdit={false} text={text} record={record} />
            //   },
            // },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: 100,
                fixed: "left",
                render: (text, record)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center gap-x-[1px]",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: `/miner/${text}`,
                                className: "link_text",
                                children: text
                            }),
                            record?.tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "w-fit max-w-[60px] rounded-[5px] bg-bg_hover px-2 py-1 text-xs  text-primary",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    text: record?.tag,
                                    className: "whitespace-nowrap"
                                })
                            })
                        ]
                    })
            },
            {
                title: "group_name",
                dataIndex: "group_name",
                width: 100,
                fixed: "left",
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text_color w-fit p-2 font-normal text-mobile_font",
                        children: showText
                    });
                }
            },
            {
                title: "miner_balance",
                dataIndex: "miner_balance",
                exports: [
                    "miner_balance_changed"
                ],
                amountUnit: {
                    miner_balance_changed: {
                        unit: "fil",
                        number: 2
                    },
                    miner_balance: {
                        unit: "fil",
                        number: 0
                    }
                },
                //width: 170,
                render: (text, record)=>{
                    const changeText = record?.miner_balance_changed ? Number(record.miner_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                //   (
                //   <span className='flex flex-col'>
                //     <span>{formatFilNum(text, false, false, 2)}</span>
                //     <span className={`${className}`}>
                //       {flag +
                //         formatFilNum(Math.abs(Number(changeText)), false, false, 2)}
                //     </span>
                //   </span>
                // );
                }
            },
            {
                title: "owner_balance",
                dataIndex: "owner_balance",
                exports: [
                    "Owner_balance_changed"
                ],
                amountUnit: {
                    owner_balance: {
                        unit: "fil",
                        number: 0
                    },
                    Owner_balance_changed: {
                        unit: "fil",
                        number: 0
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.Owner_balance_changed ? Number(record.Owner_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "worker_balance",
                dataIndex: "worker_balance",
                //width: 170,
                exports: [
                    "Worker_balance_changed"
                ],
                amountUnit: {
                    worker_balance: {
                        unit: "fil"
                    },
                    Worker_balance_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.Worker_balance_changed ? Number(record.Worker_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "controller_0_balance",
                dataIndex: "controller_0_balance",
                // width: 200,
                exports: [
                    "Controller_0_balance_changed"
                ],
                amountUnit: {
                    controller_0_balance: {
                        unit: "fil"
                    },
                    Controller_0_balance_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.Controller_0_balance_changed ? Number(record.Controller_0_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "controller_1_balance",
                dataIndex: "controller_1_balance",
                // width: 200,
                exports: [
                    "controller_1_balance_changed"
                ],
                amountUnit: {
                    controller_1_balance: {
                        unit: "fil"
                    },
                    controller_1_balance_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.controller_1_balance_changed ? Number(record.controller_1_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "controller_2_balance",
                dataIndex: "controller_2_balance",
                // width: 200,
                exports: [
                    "controller_2_balance_changed"
                ],
                amountUnit: {
                    controller_2_balance: {
                        unit: "fil"
                    },
                    controller_2_balance_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.controller_2_balance_changed ? Number(record.controller_2_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "beneficiary_balance",
                dataIndex: "beneficiary_balance",
                // width: 200,
                exports: [
                    "beneficiary_balance_changed"
                ],
                amountUnit: {
                    beneficiary_balance: {
                        unit: "fil"
                    },
                    beneficiary_balance_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.beneficiary_balance_changed ? Number(record.beneficiary_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "market_balance",
                dataIndex: "market_balance",
                // width: 200,
                exports: [
                    "market_balance_changed"
                ],
                amountUnit: {
                    market_balance: {
                        unit: "fil"
                    },
                    market_balance_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.market_balance_changed ? Number(record.market_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            }
        ]
};
const account_reward = {
    columns: (tr, type)=>{
        let arr = [
            {
                title: "group_name",
                dataIndex: "group_name",
                width: 100,
                ellipsis: {
                    showTitle: false
                },
                fixed: "left",
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text_color w-fit p-2 font-normal text-mobile_font",
                        children: showText
                    });
                }
            },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: 100,
                fixed: "left",
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center gap-x-[1px]",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: `/account#reward?miner=${text}`,
                                    className: "link_text",
                                    children: text
                                }),
                                record?.tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "w-fit max-w-[60px] rounded-[5px] bg-bg_hover px-2 py-1 text-xs  text-primary",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        text: record?.tag,
                                        className: "whitespace-nowrap"
                                    })
                                })
                            ]
                        })
                    });
                }
            },
            {
                title: "block_count",
                dataIndex: "block_count",
                width: "20%"
            },
            {
                title: "win_count",
                dataIndex: "win_count",
                width: "20%"
            },
            {
                title: "block_reward",
                dataIndex: "block_reward",
                width: "20%",
                amountUnit: {
                    block_reward: {
                        unit: "fil",
                        number: 4
                    }
                },
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatFilNum */ .Nm)(text)
            }
        ];
        if (type && type === "detail") {
            arr.unshift({
                title: "date",
                dataIndex: "date",
                fixed: "left",
                width: "15%",
                render: (text)=>{
                    if (text === "All") {
                        return text;
                    }
                    return (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD");
                }
            });
            arr[1].width = "15%";
            arr[2].width = "10%";
            arr[2].render = (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/miner/${text}`,
                    className: "link_text",
                    children: text
                });
        }
        return arr;
    }
};
const account_reward_mobile = {
    columns: (tr, type)=>{
        return {
            group_name: {
                width: "unset",
                fixed: false,
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-fit p-2 font-normal text-mobile_font",
                        children: showText
                    });
                }
            },
            miner_id: {
                width: "unset",
                fixed: false,
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center gap-x-[1px]",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: `/account#reward?miner=${text}`,
                                    className: "link_text",
                                    children: text
                                }),
                                record?.tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "w-fit max-w-[60px] rounded-[5px] bg-bg_hover px-2 py-1 text-xs  text-primary",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        text: record?.tag,
                                        className: "whitespace-nowrap"
                                    })
                                })
                            ]
                        })
                    });
                }
            },
            block_count: {
                width: "unset",
                fixed: false
            },
            win_count: {
                width: "unset",
                fixed: false
            },
            block_reward: {
                width: "unset",
                fixed: false
            },
            date: {
                width: "unset",
                fixed: false
            }
        };
    }
};
const account_power = {
    columns: (tr, type)=>{
        let arr = [
            {
                title: "group_name",
                dataIndex: "group_name",
                width: 100,
                ellipsis: {
                    showTitle: false
                },
                fixed: "left",
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text_color w-fit p-2 font-normal text-mobile_font",
                        children: showText
                    });
                }
            },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: 100,
                fixed: "left",
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center gap-x-[1px]",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: `/account#power?miner=${text}`,
                                    className: "link_text",
                                    children: text
                                }),
                                record?.tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "w-fit max-w-[60px] rounded-[5px] bg-bg_hover px-2 py-1 text-xs  text-primary",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        text: record?.tag,
                                        className: "whitespace-nowrap"
                                    })
                                })
                            ]
                        })
                    });
                }
            },
            {
                title: "quality_power",
                dataIndex: "quality_power",
                amountUnit: {
                    quality_power: {
                        unit: "power",
                        number: 2
                    }
                },
                //width: 150,
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "raw_power",
                dataIndex: "raw_power",
                /// width: 100,
                amountUnit: {
                    raw_power: {
                        unit: "power",
                        number: 2
                    }
                },
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "dc_power",
                dataIndex: "dc_power",
                //  width: 100,
                amountUnit: {
                    dc_power: {
                        unit: "power",
                        number: 2
                    }
                },
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "cc_power",
                dataIndex: "cc_power",
                //// width: 200,
                amountUnit: {
                    cc_power: {
                        unit: "power",
                        number: 2
                    }
                },
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "sector_size",
                dataIndex: "sector_size",
                //// width: 200,
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "sector_power_change",
                dataIndex: "sector_count_change",
                exports: [
                    "sector_power_change"
                ],
                titleTip: "sector_power_change_tip",
                amountUnit: {
                    sector_power_change: {
                        unit: "power",
                        number: 2
                    }
                },
                //width: 200,
                render: (text, record)=>{
                    const flag = text ? Number(text) > 0 ? "+" : "-" : "";
                    const className = Number(text) ? Number(text) > 0 ? "text_green" : "text_red" : "";
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: className,
                                children: [
                                    flag,
                                    (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatNumber */ .uf)(Math.abs(text))
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    "/",
                                    (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(record?.sector_power_change, 2)
                                ]
                            })
                        ]
                    });
                }
            },
            {
                title: "pledge_changed",
                dataIndex: "pledge_changed",
                titleTip: "pledge_changed_tip",
                //width: 200,
                amountUnit: {
                    pledge_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>renderFil(text)
            },
            {
                title: "pledge_changed_per_t",
                dataIndex: "pledge_changed_per_t",
                titleTip: "pledge_changed_per_t_tip",
                //width: 200,
                amountUnit: {
                    pledge_changed_per_t: {
                        unit: "fil/T"
                    }
                },
                render: (text, record)=>{
                    return renderFil(text, undefined, undefined, undefined, "FIL/T");
                }
            },
            {
                title: "penalty",
                dataIndex: "penalty",
                titleTip: "penalty_tip",
                //// width: 200,
                amountUnit: {
                    penalty: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>renderFil(text)
            },
            {
                title: "fault_sectors",
                dataIndex: "fault_sectors",
                titleTip: "fault_sectors_tip",
                //width: 200,
                render: (text, record)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: Number(text) ? "" : "text_des_unit",
                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatNumber */ .uf)(text)
                    })
            }
        ];
        if (type && type === "detail") {
            arr.unshift({
                title: "date",
                dataIndex: "date",
                fixed: "left",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD")
            });
            arr[2].render = (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/miner/${text}`,
                    className: "link_text",
                    children: text
                });
        }
        return arr;
    }
};
const account_power_mobile = {
    columns: (tr)=>{
        return {
            group_name: {
                width: "unset",
                fixed: false,
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-fit p-2 font-normal text-mobile_font",
                        children: showText
                    });
                }
            },
            miner_id: {
                width: "unset",
                fixed: false,
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center gap-x-[1px]",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: `/account#power?miner=${text}`,
                                    className: "link_text",
                                    children: text
                                }),
                                record?.tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "w-fit max-w-[60px] rounded-[5px] bg-bg_hover px-2 py-1 text-xs  text-primary",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        text: record?.tag,
                                        className: "whitespace-nowrap"
                                    })
                                })
                            ]
                        })
                    });
                }
            },
            quality_power: {
                width: "unset",
                fixed: false
            },
            raw_power: {
                width: "unset",
                fixed: false
            },
            dc_power: {
                width: "unset",
                fixed: false
            },
            cc_power: {
                width: "unset",
                fixed: false
            },
            sector_size: {
                width: "unset",
                fixed: false
            },
            pledge_changed: {
                width: "unset",
                fixed: false
            },
            pledge_changed_per_t: {
                width: "unset",
                fixed: false
            },
            penalty: {
                width: "unset",
                fixed: false,
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "box-border flex flex-shrink-0",
                        children: renderFil(text)
                    });
                }
            },
            fault_sectors: {
                fixed: false,
                render: (text, record)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()(Number(text) ? "" : "text_des_unit"),
                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatNumber */ .uf)(text)
                    })
            },
            date: {
                width: "unset",
                fixed: false
            }
        };
    }
};
const account_gas = {
    columns: (tr, type)=>{
        let arr = [
            {
                title: "group_name",
                dataIndex: "group_name",
                width: 100,
                fixed: "left",
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text_color w-fit rounded-[5px] p-2 font-normal",
                        children: showText
                    });
                }
            },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: 100,
                fixed: "left",
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center gap-x-[1px]",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: `/account#gas?miner=${text}`,
                                    className: "link_text",
                                    children: text
                                }),
                                record?.tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "w-fit max-w-[60px] rounded-[5px] bg-bg_hover px-2 py-1 text-xs  text-primary",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        text: record?.tag,
                                        className: "whitespace-nowrap"
                                    })
                                })
                            ]
                        })
                    });
                }
            },
            {
                title: "sector_power_change",
                dataIndex: "sector_count_change",
                titleTip: "sector_power_change_tip",
                exports: [
                    "sector_power_change"
                ],
                amountUnit: {
                    sector_power_change: {
                        unit: "power",
                        number: 2
                    }
                },
                render: (text, record)=>{
                    const flag = text ? Number(text) > 0 ? "+" : "-" : "";
                    const className = Number(text) ? Number(text) > 0 ? "text_green" : "text_red" : "";
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: className,
                                children: [
                                    flag,
                                    (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatNumber */ .uf)(Math.abs(text))
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    "/",
                                    (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(record?.sector_power_change, 2)
                                ]
                            })
                        ]
                    });
                }
            },
            {
                title: "total_gas_cost",
                dataIndex: "total_gas_cost",
                titleTip: "total_gas_cost_tip",
                // width: 200,
                amountUnit: {
                    total_gas_cost: {
                        unit: "fil"
                    }
                },
                render: (text)=>renderFil(text)
            },
            {
                title: "seal_gas_cost",
                dataIndex: "seal_gas_cost",
                titleTip: "seal_gas_cost_tip",
                // width: 200,
                amountUnit: {
                    total_gas_cost: {
                        unit: "fil"
                    }
                },
                render: (text)=>renderFil(text, undefined, undefined, undefined, "FIL")
            },
            {
                title: "seal_gas_per_t",
                dataIndex: "seal_gas_per_t",
                titleTip: "seal_gas_per_t_tip",
                // width: 200,
                amountUnit: {
                    total_gas_cost: {
                        unit: "fil/T"
                    }
                },
                render: (text)=>renderFil(text, undefined, undefined, undefined, "FIL/T")
            },
            {
                title: "deal_gas_cost",
                dataIndex: "deal_gas_cost",
                titleTip: "deal_gas_cost_tip",
                // width: 200,
                amountUnit: {
                    deal_gas_cost: {
                        unit: "fil"
                    }
                },
                render: (text)=>renderFil(text)
            },
            {
                title: "wd_post_gas_cost",
                titleTip: "wd_post_gas_cost_tip",
                dataIndex: "wd_post_gas_cost",
                // width: 200,
                amountUnit: {
                    wd_post_gas_cost: {
                        unit: "fil"
                    }
                },
                render: (text)=>renderFil(text)
            },
            {
                title: "wd_post_gas_per_t",
                dataIndex: "wd_post_gas_per_t",
                titleTip: "wd_post_gas_per_t_tip",
                // width: 200,
                amountUnit: {
                    wd_post_gas_per_t: {
                        unit: "fil/T"
                    }
                },
                render: (text)=>renderFil(text, undefined, undefined, undefined, "FIL/T")
            }
        ];
        if (type && type === "detail") {
            arr.unshift({
                title: "date",
                dataIndex: "date",
                fixed: "left",
                // width: 200,
                render: (text)=>{
                    if (text === "All") {
                        return text;
                    }
                    return (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD");
                }
            });
            arr[2].render = (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/miner/${text}`,
                    className: "link_text",
                    children: text
                });
        }
        return arr;
    }
};
const account_gas_mobile = {
    columns: (tr)=>{
        return {
            group_name: {
                width: "unset",
                fixed: false,
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-fit p-2 font-normal text-mobile_font",
                        children: showText
                    });
                }
            },
            miner_id: {
                width: "unset",
                fixed: false,
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center gap-x-[1px]",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: `/account#power?miner=${text}`,
                                    className: "link_text",
                                    children: text
                                }),
                                record?.tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "w-fit max-w-[60px] rounded-[5px] bg-bg_hover px-2 py-1 text-xs  text-primary",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        text: record?.tag,
                                        className: "whitespace-nowrap"
                                    })
                                })
                            ]
                        })
                    });
                }
            },
            sector_count_change: {
                width: "unset",
                fixed: false
            },
            total_gas_cost: {
                width: "unset",
                fixed: false
            },
            seal_gas_cost: {
                width: "unset",
                fixed: false
            },
            seal_gas_per_t: {
                width: "unset",
                fixed: false
            },
            deal_gas_cost: {
                width: "unset",
                fixed: false
            },
            wd_post_gas_cost_tip: {
                width: "unset",
                fixed: false
            },
            wd_post_gas_per_t: {
                width: "unset",
                fixed: false
            },
            date: {
                width: "unset",
                fixed: false
            }
        };
    }
};
const account_expired = {
    headerList: [
        {
            title: "exp_month",
            dataIndex: "exp_month",
            width: "20%",
            render: (text, record, tr)=>{
                const [year, month] = text.split("-");
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatDateTime */ .o0)(text, "YYYY-MM")
                });
            // return <span>{tr('exp_month', { year, month })}</span>;
            }
        },
        {
            title: "miner_count",
            dataIndex: "total_miner_count",
            width: "20%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatNumber */ .uf)(text)
        },
        {
            title: "exp_power",
            dataIndex: "total_exp_power",
            width: "15%",
            render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(text, 2)
        },
        {
            title: "sector_count",
            dataIndex: "total_exp_sector_count",
            width: "15%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatNumber */ .uf)(text)
        },
        {
            title: "exp_dc",
            dataIndex: "total_exp_dc",
            width: "15%",
            render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(text, 2)
        },
        {
            title: "exp_pledge",
            dataIndex: "total_exp_pledge",
            width: "15%",
            render: (text)=>renderFil(text)
        }
    ],
    columns: (tr, type)=>{
        let arr = [
            {
                title: "group_name",
                dataIndex: "group_name",
                width: 100,
                fixed: "left",
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text_color w-fit rounded-[5px] p-2 font-normal",
                        children: showText
                    });
                }
            },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: 100,
                fixed: "left",
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center gap-x-[1px]",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: `/account#expired?miner=${text}`,
                                    className: "link_text",
                                    children: text
                                }),
                                record?.tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "w-fit max-w-[60px] rounded-[5px] bg-bg_hover px-2 py-1 text-xs  text-primary",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        text: record?.tag,
                                        className: "whitespace-nowrap"
                                    })
                                })
                            ]
                        })
                    });
                }
            },
            {
                title: "exp_power",
                dataIndex: "exp_power",
                width: "15%",
                amountUnit: {
                    exp_power: {
                        unit: "power",
                        number: 2
                    }
                },
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "sector_count",
                dataIndex: "exp_sector_count",
                width: "15%",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatNumber */ .uf)(text)
            },
            {
                title: "exp_dc",
                dataIndex: "exp_dc",
                width: "15%",
                amountUnit: {
                    exp_dc: {
                        unit: "power",
                        number: 2
                    }
                },
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "exp_pledge",
                dataIndex: "exp_pledge",
                amountUnit: {
                    exp_pledge: {
                        unit: "fil",
                        number: 4
                    }
                },
                width: "15%",
                render: (text)=>renderFil(text)
            }
        ];
        if (type && type === "detail") {
            arr.unshift({
                title: "exp_time",
                dataIndex: "exp_date",
                fixed: "left",
                width: "10%",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD")
            });
            arr[1].width = "10%", arr[3].width = "10%", arr[2].render = (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/miner/${text}`,
                    className: "link_text",
                    children: text
                });
        }
        return arr;
    }
};
const account_miners = {
    groups_miners_columns: [
        {
            dataIndex: "miner_tag",
            title: "custom_tag",
            width: "45%"
        },
        {
            dataIndex: "miner_id",
            title: "miner_id",
            width: "45%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/miner/${text}`,
                    className: "link_text",
                    children: text
                })
        },
        {
            dataIndex: "edit",
            title: "edit",
            width: "10%"
        }
    ]
};
function renderFil(text, changeText, flag = "", className, unit = "FIL") {
    const textValue = (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatFil */ .Uk)(text, unit, 4, true);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
        className: "flex flex-col",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: `${Number(text) ? "" : "text_des_unit"}`,
                children: textValue
            }),
            changeText !== undefined && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: `${changeText ? className : "text_des_unit"}`,
                children: [
                    flag + " ",
                    (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatFil */ .Uk)(Math.abs(Number(changeText)), unit, 4, true)
                ]
            })
        ]
    });
}
const monitorUnit = {
    ExpireSectorMonitor: "day",
    BalanceMonitor: "FIL"
};
//监控columns
const monitor_list = (tr, onChange, type)=>{
    return [
        {
            dataIndex: "group_name",
            title: "group_name",
            width: "100",
            fixed: "left",
            render: (text, record)=>{
                const showText = record.is_default ? tr("default_group") : text;
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text_color w-fit p-2 font-normal text-mobile_font",
                    children: showText
                });
            }
        },
        {
            dataIndex: "miner_id_or_all",
            title: "miner_id",
            width: "200",
            fixed: "left",
            render: (text, record)=>{
                if (text === "") {
                    return "All";
                }
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center gap-x-1",
                    children: [
                        text,
                        record.miner_tag && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "w-fit max-w-[60px] rounded-[5px] bg-bg_hover px-2 py-1 text-xs  text-primary",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                text: record.miner_tag,
                                className: "whitespace-nowrap"
                            })
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "examination",
            title: "examination",
            render: (text, record)=>{
                if (type === "power") {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "leading-7",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: tr("power_rules_1")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: tr("power_rules_2")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: tr("power_rules_3")
                            })
                        ]
                    });
                }
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: "list-none leading-7",
                    children: record.rules.map((rule, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: `${tr(rule?.account_type?.toLocaleLowerCase() || record.monitor_type)} ${tr(rule.operator)} ${tr(rule.operand)} ${tr(monitorUnit[record.monitor_type])}`
                        }, index);
                    })
                });
            }
        },
        {
            dataIndex: "alarm",
            title: "alarm",
            render: (text, record)=>{
                const mailList = record.mail_alert;
                const msgList = record.msg_alert;
                const callList = record.call_alert;
                const obj = {
                    email_warn: mailList,
                    message_warn: msgList,
                    phone_warn: callList
                };
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex list-none flex-col gap-y-2",
                    children: Object.keys(obj).map((key)=>{
                        const resList = obj[key];
                        if (Array.isArray(resList)) {
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap font-normal",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "text_des mr-2 w-fit",
                                        children: [
                                            tr(key),
                                            ":"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "",
                                        children: resList.map((warn, index)=>{
                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: warn
                                            }, index);
                                        })
                                    })
                                ]
                            }, key);
                        }
                    })
                });
            }
        },
        {
            dataIndex: "created_at",
            title: "created_at",
            render: (text, record)=>{
                return (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatDateTime */ .o0)(text);
            }
        },
        {
            dataIndex: "is_active",
            title: "status",
            render: (text, record, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_monitor_ActiveRules__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    text: text,
                    title: "isActive",
                    onChange: ()=>onChange("isActive", record, index)
                });
            }
        },
        {
            dataIndex: "edit",
            title: "edit",
            width: "100",
            fixed: "right",
            render: (text, record, index)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex gap-x-2 font-normal",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "cursor-pointer text-primary",
                            onClick: ()=>onChange("edit_write", record, index),
                            children: tr(type === "power" ? "edit_write_warn" : "edit_write")
                        }),
                        type !== "power" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_monitor_ActiveRules__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            text: text,
                            title: "edit_delete",
                            onChange: ()=>onChange("edit_delete", record, index)
                        })
                    ]
                });
            }
        }
    ];
};
//告警方式
const defaultWarn = {
    email_warn: {
        title: "email_warn",
        value: "email",
        placeholder: "email_warn_placeholder",
        inputValue: "",
        warning: false,
        warningText: "email_warn_warning",
        checked: false
    },
    message_warn: {
        title: "message_warn",
        value: "message",
        placeholder: "message_warn_placeholder",
        inputValue: "",
        warning: false,
        warningText: "phone_warn_warning",
        checked: false
    },
    phone_warn: {
        title: "phone_warn",
        value: "phone",
        placeholder: "phone_warn_placeholder",
        inputValue: "",
        warning: false,
        warningText: "phone_warn_warning",
        checked: false
    }
};
//会员
const member_list_1 = [
    {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_memberPower_svg__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
        title: "power_title",
        value: "power_text"
    },
    {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_memberBalance_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
        title: "balance_title",
        value: "balance_text"
    },
    {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_memberSector_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
        title: "sector_title",
        value: "sector_text"
    }
];
const member_list_2 = [
    {
        title: [
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_power_svg__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {}),
                title: "warn_power"
            },
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_balance_svg__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {}),
                title: "warn_balance"
            },
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_sector_svg__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {}),
                title: "warn_sector"
            }
        ],
        content: "data_text"
    },
    {
        title: [
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_email_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
                title: "warn_email"
            },
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_msg_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                title: "warn_msg"
            },
            {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_phone_svg__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
                title: "warn_phone"
            }
        ],
        content: "warn_text"
    }
];
const member_main = {
    EnterpriseVIP: {
        title: "companies",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_27___default()), {
            src: _assets_images_member_companiesV_png__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z,
            alt: "",
            width: 126
        }),
        list: [
            {
                title: "companies_1",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "icon icon-quanyiicon"
                })
            },
            {
                title: "companies_2",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "icon icon-quanyiicon"
                })
            },
            {
                title: "companies_3",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "icon icon-quanyiicon"
                })
            },
            {
                title: "companies_4",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "icon icon-quanyiicon"
                })
            },
            {
                title: "companies_5",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "icon icon-quanyiicon"
                })
            }
        ],
        priceList: [
            {
                title: "monthly",
                price: "169U"
            },
            {
                title: "quarter",
                price: "439U",
                discount: "quarter_discount"
            },
            {
                title: "year",
                price: "1599U",
                discount: "year_discount"
            }
        ]
    },
    EnterpriseProVIP: {
        title: "companiesPro",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_27___default()), {
            src: _assets_images_member_companiesVPro_png__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z,
            alt: "",
            width: 126
        }),
        list: [
            {
                title: "companies_1_pro",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "icon icon-quanyiicon "
                })
            },
            {
                title: "companies_2",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "icon icon-quanyiicon"
                })
            },
            {
                title: "companies_3",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "icon icon-quanyiicon"
                })
            },
            {
                title: "companies_4",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "icon icon-quanyiicon"
                })
            },
            {
                title: "companies_6",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "icon icon-quanyiicon"
                })
            },
            {
                title: "companies_5",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "icon icon-quanyiicon"
                })
            }
        ],
        priceList: [
            {
                title: "monthly",
                price: "269U"
            },
            {
                title: "quarter",
                price: "699U",
                discount: "quarter_discount"
            },
            {
                title: "year",
                price: "2499U",
                discount: "year_discount"
            }
        ]
    }
};
//活动
const active_member = [
    {
        title: "active_1",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_27___default()), {
            src: _assets_images_member_active2_png__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z,
            alt: "",
            width: 58
        }),
        des: "active_1_des"
    },
    {
        title: "",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_27___default()), {
            src: _assets_images_step_png__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z,
            alt: "",
            width: 98
        }),
        des: ""
    },
    {
        title: "active_2",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_27___default()), {
            src: _assets_images_member_active3_png__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z,
            alt: "",
            width: 58
        }),
        des: "active_2_des"
    },
    {
        title: "",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_27___default()), {
            src: _assets_images_step_png__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z,
            alt: "",
            width: 98
        }),
        des: ""
    },
    {
        title: "active_3",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_27___default()), {
            src: _assets_images_member_active1_png__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z,
            alt: "",
            width: 58
        }),
        des: "active_3_des"
    }
];
const active_member_detail = [
    {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_companies_svg__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {}),
        des: "companies_1"
    },
    {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_companies_svg__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {}),
        des: "active_member_1"
    },
    {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_companies_svg__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {}),
        des: "companies_5"
    }
];
const active_member_share = [
    {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_activePower_svg__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {}),
        title: "warn_power"
    },
    {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_activeSector_svg__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {}),
        title: "warn_sector"
    },
    {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_activeBalance_svg__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {}),
        title: "warn_balance"
    },
    {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_activeWarn_svg__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {}),
        title: "active_member_warn"
    }
];
const active_member_list = (tr)=>{
    return [
        {
            title: "date",
            dataIndex: "register_time",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatDateTime */ .o0)(text)
        },
        {
            title: "invitees",
            dataIndex: "user_email"
        },
        {
            title: "status",
            dataIndex: "is_valid",
            render: (text)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    className: "list-none text-sm ",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            className: "text_green flex items-center gap-x-2",
                            children: [
                                (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("successIcon"),
                                tr("success_member")
                            ]
                        }),
                        text && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            className: "text_green flex items-center gap-x-2",
                            children: [
                                (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("successIcon"),
                                tr("success_miners")
                            ]
                        }),
                        !text && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            className: "text_red flex items-center gap-x-2",
                            children: [
                                (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("errorIcon"),
                                tr("error_member")
                            ]
                        })
                    ]
                });
            }
        },
        {
            title: "is_valid",
            dataIndex: "is_valid",
            render: (text)=>{
                return text ? tr("success_active") : tr("error_active");
            }
        }
    ];
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8054:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   C1: () => (/* binding */ pendingMsg),
/* harmony export */   I3: () => (/* binding */ heightDetail),
/* harmony export */   JI: () => (/* binding */ ContractCntTrend),
/* harmony export */   JW: () => (/* binding */ apiUrl),
/* harmony export */   K3: () => (/* binding */ EvmGasTrend),
/* harmony export */   Uh: () => (/* binding */ EvmContractSummary),
/* harmony export */   _7: () => (/* binding */ ContractBalanceTrend),
/* harmony export */   _y: () => (/* binding */ metaOther),
/* harmony export */   a1: () => (/* binding */ TransMethod),
/* harmony export */   b: () => (/* binding */ DCTrend),
/* harmony export */   dE: () => (/* binding */ fvmUrl),
/* harmony export */   eU: () => (/* binding */ cwUrl),
/* harmony export */   i5: () => (/* binding */ EvmTxsHistory),
/* harmony export */   kY: () => (/* binding */ FinalHeight),
/* harmony export */   lR: () => (/* binding */ FilPrice),
/* harmony export */   tl: () => (/* binding */ ContractUsersTrend),
/* harmony export */   vA: () => (/* binding */ tokenName)
/* harmony export */ });
/* unused harmony export proApi */
const mainUrl = "https://api-v2.filscan.io/api/v1";
// const testUrl = 'http://192.168.19.80:17000/api/v1'
const proUrl = "https://api-v2.filscan.io/pro/v1" || 0;
const fvmUrl = "https://filscan-v2.oss-accelerate.aliyuncs.com/fvm_manage";
const proApi = {
    //登录注册
    mail_exists: proUrl + "/MailExists",
    resetPassword: proUrl + "/ResetPasswordByCode",
    send_code: proUrl + "/SendVerificationCode",
    byCode: proUrl + "/ResetPasswordByCode",
    login: proUrl + "/Login",
    userInfo: proUrl + "/UserInfo",
    updateInfo: proUrl + "/UpdateUserInfo",
    getOverview: proUrl + "/MinerInfoDetail",
    getGroups: proUrl + "/GetUserGroups",
    getGroupsId: proUrl + "/GetGroup",
    createGroup: proUrl + "/CreateGroup",
    saveGroup: proUrl + "/SaveGroupMiners",
    delGroup: proUrl + "/DeleteGroup",
    getLucky: proUrl + "/LuckyRateDetail",
    getBalance: proUrl + "/BalanceDetail",
    getReward: proUrl + "/RewardDetail",
    getGas: proUrl + "/GasCostDetail",
    getPower: proUrl + "/PowerDetail",
    getSector: proUrl + "/SectorDetail",
    account_miners: proUrl + "/CountUserMiners",
    saveMiner: proUrl + "/SaveUserMiners"
};
//account
const heightDetail = mainUrl + "/TipsetDetail";
const EvmContractSummary = mainUrl + "/EvmContractSummary";
const EvmTxsHistory = mainUrl + "/EvmTxsHistory";
const EvmGasTrend = mainUrl + "/EvmGasTrend";
const ContractBalanceTrend = mainUrl + "/ContractBalanceTrend";
const ContractUsersTrend = mainUrl + "/ContractUsersTrend";
const ContractCntTrend = mainUrl + "/ContractCntTrend";
const FilPrice = mainUrl + "/FilPrice";
const FinalHeight = mainUrl + "/FinalHeight";
const DCTrend = mainUrl + "/DCTrend";
const TransMethod = mainUrl + "/TransferMethodByAccountID";
const cwUrl = mainUrl + "/TipsetStateTree";
const metaOther = mainUrl + "/BannerIndicator";
const tokenName = mainUrl + "/ERC20AddrTransfersTokenTypes";
const pendingMsg = mainUrl + "/PendingMsgByAccount";
const apiUrl = {
    fvm_hot: mainUrl + "/GetFEvmHotItems",
    fvm_category: mainUrl + "/GetFEvmCategory",
    fvm_items: mainUrl + "/GetFEvmItemsByCategory",
    home_banner: mainUrl + "/GetBannerList",
    searchInfo: mainUrl + "/SearchInfo",
    home_meta: mainUrl + "/TotalIndicators",
    line_trend: mainUrl + "/BaseLineTrend",
    static_gas: mainUrl + "/BaseFeeTrend",
    static_gas_24: mainUrl + "/GasDataTrend",
    static_fil_chart: mainUrl + "/FilCompose",
    static_block_trend: mainUrl + "/BlockRewardTrend",
    static_active_miner: mainUrl + "/ActiveMinerTrend",
    static_message_trend: mainUrl + "/MessageCountTrend",
    rank_pool: mainUrl + "/OwnerRank",
    rank_provider: mainUrl + "/MinerRank",
    rank_growth: mainUrl + "/MinerPowerRank",
    rank_rewards: mainUrl + "/MinerRewardRank",
    tipset_chain: mainUrl + "/LatestBlocks",
    tipset_BlockDetails: mainUrl + "/BlockDetails",
    tipset_Block_messages: mainUrl + "/MessagesByBlock",
    tipset_message_opt: mainUrl + "/AllMethods",
    tipset_message_pool_opt: mainUrl + "/AllMethodsByMessagePool",
    tipset_block_message_opt: mainUrl + "/AllMethodsByBlock",
    tipset_message: mainUrl + "/LatestMessages",
    tipset_address: mainUrl + "/RichAccountRank",
    tipset_transfer: mainUrl + "/LargeTransfers",
    tipset_Dsn: mainUrl + "/SearchMarketDeals",
    tipset_pool: mainUrl + "/MessagesPool",
    detail_account: mainUrl + "/AccountInfoByID",
    detail_owner: mainUrl + "/AccountOwnerByID",
    detail_message: mainUrl + "/MessageDetails",
    detail_message_event: mainUrl + "/EventsInMessage",
    detail_message_trans: mainUrl + "/InternalTransfer",
    detail_miner_list: mainUrl,
    detail_list_method: mainUrl + "/AllMethodByAccountID",
    detail_message_list: mainUrl + "/MessagesByAccountID",
    detail_block_list: mainUrl + "/BlocksByAccountID",
    detail_trance_list: mainUrl + "/TracesByAccountID",
    detail_deal: mainUrl + "/DealDetails",
    account_change: mainUrl + "/BalanceTrendByAccountID",
    account_trend: mainUrl + "/PowerTrendByAccountID",
    detail_Indicators: mainUrl + "/IndicatorsByAccountID",
    contract_verify: mainUrl + "/VerifyContract",
    contract_hard_verify: mainUrl + "/VerifyHardhatContract",
    contract_verify_list: mainUrl + "/VerifiedContractList",
    contract_verify_logs: mainUrl + "/ActorEventsList",
    contract_rank: mainUrl + "/EvmContractList",
    contract_verify_des: mainUrl + "/VerifiedContractByActorID",
    contract_solidity: mainUrl + "/SolidityVersions",
    contract_Licenses: mainUrl + "/Licenses",
    contract_transferInMessage: mainUrl + "/ERC20TransferInMessage",
    contract_transferInMessageNft: mainUrl + "/NFTMessageTransfers",
    contract_swap: mainUrl + "/SwapInfoInMessage",
    contract_ERC20List: mainUrl + "/ERC20List",
    contract_ERC20TokenList: mainUrl + "/ERC20OwnerTokenList",
    contract_ERC20Transfer: mainUrl + "/ERC20Transfer",
    contract_ERC20Owner: mainUrl + "/ERC20Owner",
    contract_ERC20Dex: mainUrl + "/ERC20DexTrade",
    contract_NFTTransfers: mainUrl + "/NFTTransfers",
    contract_NFTOwners: mainUrl + "/NFTOwners",
    contract_ERC20Transfers: mainUrl + "/ERC20AddrTransfers",
    contract_ERC20Summary: mainUrl + "/ERC20Summary",
    contract_ERC20Market: mainUrl + "/ERC20Market",
    contract_detailList: mainUrl,
    contract_nfts: mainUrl + "/NFTTokens",
    contract_fnsUrl: mainUrl + "/FnsBindDomains",
    contract_FnsSummary: mainUrl + "/NFTSummary",
    contract_domain: mainUrl + "/FnsDomainDetail",
    contract_domain_address: mainUrl + "/FnsAddressDomains",
    fevm_defiSummary: mainUrl + "/DefiSummary",
    fevm_defiList: mainUrl + "/DefiProtocolList"
};


/***/ }),

/***/ 5934:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Dc: () => (/* binding */ networkOptions),
/* harmony export */   HJ: () => (/* binding */ SEO),
/* harmony export */   YH: () => (/* binding */ langOptions),
/* harmony export */   cK: () => (/* binding */ header_top),
/* harmony export */   yC: () => (/* binding */ search)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_1__]);
_utils__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 

const header_top = {
    left: [
        {
            title: "fil",
            dataIndex: "price",
            render: (text, record)=>{
                if (!text) return null;
                const changeText = record?.percent_change_24h && Number(record.percent_change_24h);
                const className = changeText ? changeText < 0 ? "text_red" : "text_green" : "";
                const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-end gap-x-1",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "text_primary",
                            children: [
                                (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get$Number */ .Uy)(text),
                                " "
                            ]
                        }),
                        changeText && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: `${className} ml-1`,
                            children: [
                                flag,
                                Math.abs(changeText).toFixed(2),
                                "%"
                            ]
                        })
                    ]
                });
            }
        },
        {
            title: "last_time",
            dataIndex: "block_time"
        },
        {
            title: "base_fee",
            dataIndex: "base_fee",
            render: (text)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "text_primary",
                    children: [
                        text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 2) : text,
                        " "
                    ]
                })
        },
        {
            title: "last_height",
            dataIndex: "height",
            render: (text)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "text_primary",
                    children: [
                        text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 2) : text,
                        " "
                    ]
                })
        }
    ],
    right: [
        {
            title: "",
            dataIndex: "network"
        },
        {
            title: "",
            dataIndex: "network"
        },
        {
            title: "",
            dataIndex: "network"
        }
    ]
};
const search = {
    holder: "search_holder",
    opt: [
        {
            label: "all",
            value: "all"
        },
        {
            label: "address",
            value: "address"
        },
        {
            label: "message_id",
            value: "message_id"
        },
        {
            label: "height",
            value: "height"
        },
        {
            label: "cid",
            value: "cid"
        },
        {
            label: "node",
            value: "node"
        }
    ]
};
const langOptions = [
    {
        value: "zh",
        label: "中文"
    },
    {
        value: "en",
        label: "English"
    },
    {
        value: "kr",
        label: "한국인"
    }
];
const networkOptions = [
    {
        value: "Mainnet",
        label: "Mainnet"
    },
    {
        value: "Calibration",
        label: "Calibration"
    }
];
const SEO = {
    zh: {
        title: "Filscan Filecoin 浏览器",
        description: "Filecoin官方区块浏览器,Filecoin官方浏览器, Filscan,Filecoin,最新区块,Filecoin Explorer,FIL,IPFS，FIL,Filecoin区块链查询浏览器,FIL浏览器,Filecoin浏览器,Filecoin区块查询,区块链搜索引擎,区块高度,区块链交易",
        keywords: "Filecoin官方区块浏览器,Filecoin官方浏览器,",
        url: "https://filscan.io/"
    },
    en: {
        title: "Filscan Filecoin Explorer",
        description: `Filscan is a blockchain explorer that serves as a fundamental tool for the Filecoin ecosystem, providing real-time on-chain data. It enables users to query information about Filecoin's blockchain, transactions, FIL tokens, wallets, etc., and synchronizes real-time information from all nodes.`,
        keywords: "Filecoin官方区块浏览器,Filecoin官方浏览器, Filecoin Explorer,fvm,Filscan,Filecoin, blockchain, crypto, currency,最新区块,FIL,IPFS，FIL,Filecoin区块链查询浏览器,FIL浏览器,Filecoin浏览器,Filecoin区块查询,区块链搜索引擎,区块高度,区块链交易",
        url: "https://filscan.io/en"
    },
    kr: {
        title: "파일코인 익스플로러",
        description: "Filecoin 공식 브라우저 ,Filecoin 공식 블록 탐색기 ,Filecoin 블록 쿼리 ,FIL 브라우저 ,FVM ,IPFS, 블록 높이,블록체인 트랜잭션,블록체인 검색 엔진,최신 블록",
        keywords: "Filecoin官方区块浏览器,Filecoin官方浏览器, Filecoin Explorer,fvm,Filscan,Filecoin, blockchain, crypto, currency,最新区块,FIL,IPFS，FIL,Filecoin区块链查询浏览器,FIL浏览器,Filecoin浏览器,Filecoin区块查询,区块链搜索引擎,区块高度,区块链交易",
        url: "https://filscan.io/kr"
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 17978:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ navMenu),
/* harmony export */   s: () => (/* binding */ mobileNavMenu)
/* harmony export */ });
const navMenu = [
    // {
    //   key: 'home',
    //   link: '/home'
    // },
    {
        key: "network_overview",
        link: "/rank",
        // sufIcon: "newIcon",
        children: [
            {
                key: "ranking",
                link: "/rank"
            },
            {
                key: "tipset_ranking",
                link: "/tipset/address-list/"
            },
            {
                key: "tipset_transfer",
                link: "/tipset/transfer/"
            },
            {
                key: "statistics_gas",
                link: "/statistics/gas"
            },
            {
                key: "statistics_charts",
                link: "/statistics/charts#networks"
            },
            {
                key: "cw",
                link: "/cw"
            }
        ]
    },
    {
        key: "analysis",
        sufIcon: "newIcon",
        children: [
            {
                key: "analysis_market",
                link: "/analysis/market/"
            },
            {
                key: "analysis_fund",
                link: "/analysis/fund/"
            }
        ]
    },
    {
        key: "tipset",
        children: [
            {
                key: "tipset_chain",
                link: "/tipset/chain/"
            },
            {
                key: "tipset_message",
                link: "/tipset/message-list/"
            },
            {
                key: "tipset_dsn",
                link: "/tipset/dsn/"
            },
            {
                key: "tipset_pool-message",
                link: "/tipset/pool-message/"
            }
        ]
    },
    {
        key: "contract",
        color: "#F44C30",
        children: [
            {
                key: "token",
                link: "/contract/token/"
            },
            {
                key: "nft",
                link: "/contract/nft/"
            },
            {
                key: "defi_dashboard",
                link: "/fevm/defi/"
            },
            {
                key: "contract_rank",
                link: "/contract/rank/"
            },
            {
                key: "contract_list",
                link: "/contract/list/"
            }
        ]
    },
    {
        key: "fvm",
        sufIcon: "freeVip",
        color: "#F44C30",
        children: [
            {
                key: "fvm_all",
                link: "/fvm"
            },
            {
                key: "active",
                link: "/active",
                sufIcon: "freeVip"
            }
        ]
    },
    {
        key: "develop",
        children: [
            {
                key: "contract_verify",
                link: "/contract/verify/"
            }
        ]
    }
];
const mobileNavMenu = [
    {
        key: "home",
        link: "/"
    },
    {
        key: "network_overview",
        link: "/rank",
        children: [
            {
                key: "ranking",
                link: "/rank"
            },
            {
                key: "tipset_ranking",
                link: "/tipset/address-list/"
            },
            {
                key: "tipset_transfer",
                link: "/tipset/transfer/"
            },
            {
                key: "statistics_gas",
                link: "/statistics/gas"
            },
            {
                key: "statistics_charts",
                link: "/statistics/charts"
            }
        ]
    },
    {
        key: "tipset",
        children: [
            {
                key: "tipset_chain",
                link: "/tipset/chain/"
            },
            {
                key: "tipset_message",
                link: "/tipset/message-list/"
            },
            {
                key: "tipset_dsn",
                link: "/tipset/dsn/"
            },
            {
                key: "tipset_pool-message",
                link: "/tipset/pool-message/"
            }
        ]
    },
    {
        key: "fvm",
        // sufIcon: "hotIcon",
        color: "#F44C30",
        link: "/fvm"
    },
    {
        key: "language",
        children: [
            {
                key: "中文",
                value: "zh",
                type: "lang"
            },
            {
                key: "English",
                value: "en",
                type: "lang"
            },
            {
                key: "한국인",
                value: "kr",
                type: "lang"
            }
        ]
    },
    {
        key: "network",
        children: [
            {
                key: "Mainnet",
                value: "Mainnet",
                type: "network"
            },
            {
                key: "Calibration",
                value: "Calibration",
                type: "network"
            }
        ]
    },
    {
        key: "account_title",
        type: "account",
        children: [
            {
                key: "overview",
                link: "account/#overview"
            },
            {
                key: "data_details",
                children: [
                    {
                        key: "power",
                        link: "account/#power"
                    },
                    {
                        key: "gas",
                        link: "account/#gas"
                    },
                    {
                        key: "expired",
                        link: "account/#expired"
                    },
                    {
                        key: "reward",
                        link: "account/#reward"
                    },
                    {
                        key: "lucky",
                        link: "account/#lucky"
                    },
                    {
                        key: "balance",
                        link: "account/#balance"
                    }
                ]
            },
            {
                key: "monitor",
                children: [
                    {
                        key: "monitorBalance",
                        link: "account/#monitorBalance"
                    },
                    {
                        key: "monitorSector",
                        link: "account/#monitorSector"
                    },
                    {
                        key: "monitorPower",
                        link: "account/#monitorPower"
                    }
                ]
            }
        ]
    }
];
// {
//   value: "Mainnet",
//   label: "Mainnet",
// },
// {
//   value: "Calibration",
//   label: "Calibration",
// },



/***/ }),

/***/ 52324:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const account = {
    date: "Date",
    copy: "Copy",
    day: "Day",
    confirm: "Confirm",
    cancel: "Cancel",
    go_home: "Back to Homepage",
    go_login: "Login",
    login: "Miner Metrics",
    back: "Back",
    account_title: "Miner Metrics",
    overview: "Overview",
    miners: "Miners",
    personal: "Account",
    data_details: "Details",
    monitor: "Monitoring",
    monitorBalance: "Balance",
    monitorSector: "Expiration",
    monitorPower: "Power",
    logout: "Logout",
    default_group: "Default Group",
    welcome: "Welcome to Filscan!",
    welcome_text1: "Congratulations! Your account has been successfully registered! Please login with your email and password.",
    welcome_text2: "Please login and have fun!",
    last_time: "Latest Update Time",
    all: "All",
    all_groups: "All Groups",
    all_miners: "All Miners",
    all_tags: "All Tags",
    edit: "Edit",
    miner_add: "Add Miner",
    //个人账户 Personal
    register_success: "Congratulations! Your account has been successfully registered!",
    register_btn: "Activate",
    select_group: "Please select a group",
    select_miner: "Please select an miner ",
    select_miner_tag: "Please select an miner tag",
    edit: "Operation",
    miner_add: "Add",
    edit_write: "Modify",
    edit_delete: "Delete",
    created_at: "Created Time",
    //数据概览 Data Overview
    // power: '算力概览',
    // gas: 'Gas 消耗',
    // expired: '到期扇区',
    // reward: '出块奖励',
    // lucky: '幸运值',
    // balance: '地址余额',
    power: "Power Overview",
    gas: "Gas",
    expired: "Sector Status",
    reward: "Reward",
    lucky: "Lucky",
    balance: "Balance Overview",
    no_node_data: "No Node",
    miners_add: "Add Miner",
    group_add: "Add Group",
    miners_group_manage: "Manage Miners Group",
    total_out_come_gas: "Total Cost/Gas Cost",
    pledge_amount_24: "FIL Pledged/24H Changes",
    balance_24: "Total Balance/24H Changes",
    quality_power_24: "Quality Power/24H Changes",
    //节点管理 Miner Manager
    delete_group: "Delete Group",
    delete_record_group: "Confirm？",
    delete_group_text: "This group will no longer be displayed in the list after deletion!",
    delete_miner: "Delete Miner",
    delete_record_miner: "Are you sure you want to delete the miner?",
    delete_miner_text: "This miner will no longer be displayed in the group",
    //添加节点 Add Miner
    custom_tag: "Custom Tag",
    miner_add_placeholder: "Please enter the Miner account ID ",
    miner_select_group_placeholder: 'Please select a group(if no group is selected, the added miner will be placed in the" Default Group")',
    //分组
    create_group: "Create Group",
    create_group_holder: "Please enter name of the group you want to create.",
    item_value: "{{value}} miner in this group",
    group_name: "Group Name",
    //幸运值 Lucky
    all: "All",
    "24h_lucky": "24H Lucky    ",
    "7d_lucky": "7D Lucky",
    "30d_lucky": "30D Lucky",
    "1year_lucky": "1 Year Lucky",
    tag: "Tag",
    miner_id: "Miner ID",
    //地址余额 Address Balance
    miner_balance: "Miner Balance/Daily Change",
    owner_balance: "Owner Balance/Daily Change",
    worker_balance: "Worker Balance/Daily Change",
    controller_0_balance: "Controller0 Balance/Daily Change",
    controller_1_balance: "Controller1 Balance/Daily Change",
    controller_2_balance: "Controller2 Balance/Daily Change",
    beneficiary_balance: "Beneficiary Balance/Daily Change",
    market_balance: "Market Balance/Daily Change",
    //奖励 Reward
    block_count: "Block Count",
    win_count: "Win Count",
    block_reward: "Block Reward",
    total_reward: "Total Reward",
    total_reward_24: "Total Reward/24H Reward",
    //算力概览 Power Overview
    quality_power: "Quality Power",
    dc_power: "DC Power",
    raw_power: "Raw Power",
    cc_power: "CC Power",
    sector_size: "Sector Size",
    sector_power_change: "Sector Change",
    sector_power_count: "Sector Count",
    sector_count_change: "Sector Count Change",
    pledge_changed: "Pledge Change",
    pledge_changed_per_t: "Pledge Change/T",
    penalty: "Penalty",
    fault_sectors: "Fault Sectors",
    sector_power_change_tip: "Sector Count/RawBytePower  The sum of additions and terminations",
    pledge_changed_tip: "The sum of changes in pledge for additions and terminations of Sector Count",
    pledge_changed_per_t_tip: "Pledge change devided by sector change.",
    penalty_tip: "The amount of FIL subjected to Penalty",
    fault_sectors_tip: "The number of newly added faulty sectors.",
    total_gas_cost_tip: "The total sum of gas consumption for all types.",
    seal_gas_cost_tip: "The total sum of gas cost for sector sealing(PreCommitSector+ProveCommitSector+PreCommitSectorBatch+ProveCommitAggregate+PreCommit Net Fee+ProveCommit Net Fee)",
    seal_gas_per_t_tip: "Gas consumption per newly sealed sector (TiB)",
    deal_gas_cost_tip: "DC consumption of PublishStorageDeals",
    wd_post_gas_cost_tip: "Consumption of SubmitWindowedPoSt",
    wd_post_gas_per_t_tip: "SubmitWindowedPoSt cost devided by RawBytePower(TiB)",
    //gas
    total_gas_cost: "Total Gas Cost",
    seal_gas_cost: "Seal Gas Cost",
    seal_gas_per_t: "Seal Gas Cost/T",
    deal_gas_cost: "Deal Gas Cost",
    wd_post_gas_cost: "Wd Post Gas Cost",
    wd_post_gas_per_t: "Wd Post Gas Cost/T",
    //到期扇区 Exp. Sector
    exp_month: "Expires in {{value}} year {{value}} month",
    exp_time: "Exp. Time",
    miner_count: "Miner Count",
    exp_power: "Exp. Power",
    sector_count: "Exp. Sector Count",
    exp_dc: "Exp.DC",
    exp_pledge: "Exp. Pledge",
    //个人中心 Personal Center
    default_user: "Regular User",
    last_login: "Last Login",
    personal_setting: "Account Setting",
    personal_name: "Account Name",
    old_placeholder: "Please enter old password",
    old_password: "Old Password",
    new_password: "New Password",
    new_placeholder: "Please enter new password",
    confirm_password: "Confirm",
    confirm_placeholder: "Please enter new password again",
    personal_name_holder: "Please enter your account name",
    //余额监控
    miner: "Miner Balance",
    owner: "Owner Balance",
    worker: "Worker Balance",
    controller_0: "Controller0 Balance",
    controller_1: "Controller1 Balance",
    controller_2: "Controller2 Balance",
    beneficiary: "Beneficiary Balance",
    //监控
    add_rules: "Add Rules",
    examination: "Rules",
    alarm: "Alert Methods",
    status: "State",
    rules_more: "A single dialog box can have a maximum of 10 rule sets. If you need to add more, please save your changes and continue",
    warn_more: "Maximum support for adding 3",
    monitor_mobile_edit_tip: "Please go to the PC version for monitoring operations such as adding, deleting, and modifying",
    //告警方式
    warn_title: "Alert Methods",
    warn_title_des: "You can choose one or a combination of alert methods based on the actual situation",
    email_warn: "Email Alert",
    email_warn_placeholder: "Please provide the alert email address  ",
    email_warn_warning: "Please enter a valid email address",
    email_warn_des: "The registered email address for the current account will be automatically sent, so there is no need to submit it again",
    message_warn: "SMS Alert",
    message_warn_placeholder: "Please provide the receiving phone number ",
    message_warn_warning: "Please enter a valid recipient number",
    phone_warn: "Phone Call Alert",
    phone_warn_placeholder: "Please provide the receiving phone number ",
    phone_warn_warning: "Please enter a valid recipient number",
    //监控
    ExpireSectorMonitor: "Sector Expiry Date",
    edit_status: "Close Rule",
    edit_status_content: "Do you confirm the disabled of this monitoring? Once disabled, you will not receive timely alerts for relevant issues",
    delete_rule: "Delete Rule",
    delete_rule_content: "Do you confirm the deletion of this monitoring?",
    //扇区监控
    reset_button: "Reset",
    edit_rules: "Modify Rules",
    rule_detail: "Rule Details",
    edit_write_warn: "Alarm Modes",
    sector_rule_title: "Sector Expiry Date",
    sector_rule_des: "Customizable; Recommended to be greater than 30.",
    sector_ruler_placeholder: "Please enter a positive integer",
    sector_ruler_warningText: "Please enter a positive integer",
    "<=": "Less than or equal to",
    ">=": "Greater than or equal to",
    //余额监控
    balance_category_placeholder: "select a balance category",
    balance_rule_des: "current {{value}} FIL",
    //算力监控
    power_rules_1: "1. Sector encountered an error",
    power_rules_2: "2. Sector terminated voluntarily",
    power_rules_3: "3. Sector expired normally",
    //会员
    member_miner_warn: "The number of current nodes has reached the limit. Upgrade your membership to enjoy more benefits.",
    member_warn: "Your membership privileges are about to expire. Please renew in a timely manner to avoid any disruptions.",
    member_header: "If you are concerned or have encountered the following issues",
    power_title: "Drop In Power",
    power_text: "Due to a large number of sector errors, power sharply decreases without timely notification, resulting in significant loss of block rewards",
    balance_title: "Insufficient Balance",
    balance_text: "Insufficient account balance without timely information access leads to failed sector sealing or maintenance",
    sector_title: "Sector Expiration",
    sector_text: "When a sector expires, power also decreases. It is only then that we realize we should have renewed earlier. A reminder would have been helpful",
    warn_power: "Power",
    warn_balance: "Balance",
    warn_sector: "Sectors",
    warn_email: "Email",
    warn_msg: "SMS",
    warn_phone: "Phone Call",
    data_text: "Comprehensive Monitoring Of Critical Information",
    warn_text: "Multiple Alert Channels, Flexible Configuration",
    member_warn_title: "Add Monitoring, Stay Ahead With Alerts",
    member_content_title: "Join Membership, Activate Instantly",
    companies: "Enterprise",
    companiesPro: "Enterprise Pro",
    companies_1: "30 Nodes Limit",
    companies_1_pro: "Unlimited Nodes",
    companies_2: "Power",
    companies_3: "Balance",
    companies_4: "Sectors",
    companies_5: "More (coming soon)",
    companies_6: "Technical support",
    monthly: "Monthly",
    quarter: "Quarterly",
    year: "Annual",
    quarter_discount: "Less than 12% off",
    year_discount: "Less than 20% off",
    share_friend: "Invite Others And Get One Month Enterprise Membership For Free",
    share_turn: "Start Now And Minimize Losses",
    tg_title: "Add Business TG For Activation",
    //活动
    success_member: "Registered successfully",
    error_member: "Unbound miners",
    success_miners: "Bound miners",
    success_active: "Valid",
    error_active: "Invitee",
    invitees: "Invitee",
    is_valid: "Validity",
    send_member: "Free VIP",
    invite_code: "Code",
    active_share: "Invite Now",
    active_member_warn: "SMS And Phone Alerts",
    active: "Invitation",
    active_rule: "Event Rules",
    active_detail: "Details",
    active_rule_detail: "Details",
    rule_content: "Accumulate invitations for 2 node managers to register and have their invited accounts bind with valid node information, and receive a one-month Enterprise Edition membership worth 169U. The invitees can also enjoy 7 days of Enterprise Edition benefits",
    active_member: "Enterprise Edition Membership Benefits:",
    active_member_1: "Full monitoring capabilities.",
    active_expired: "After the membership expires, the benefits will be automatically revoked. You can continue to enjoy the related services by renewing the membership.",
    // active_1: '邀请好友',
    active_1_des: "Send invitation posters or invitation codes to friends, they can scan the code or register on the official website with the invitation code.",
    // active_2: '注册添加',
    active_2_des: "Your friend has successfully registered and added valid nodes.",
    active_3: "邀请2个有效好友",
    active_3_des: "Invite 2 valid friends and successfully claim the reward",
    active_target_1: "Comprehensive Miner Information",
    active_target_2: "Stay One Step Ahead With Anomaly Alerts",
    scan_code: "Scan to experience immediately",
    active_des: "Filscan reserves the right to interpret the activity",
    active_gift: "New users are granted a 7-day trial of the Enterprise version",
    active_save: "Save locally",
    copy_tg: "Copy ID",
    recommend: "推荐",
    //personal
    personal_1: "Upgrade/Renew VIP",
    // personal_2: '绑定邮箱',
    personal_3: "Change Password",
    member_expired_time: "Expires on {{value}}",
    mail_success: "Bound",
    look_more: "Benefits",
    look_detail: "Check the Details",
    look_detail_member: "For Free",
    //第一次弹窗
    free_send: "Enterprise Membership For Free"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (account);


/***/ }),

/***/ 75531:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const analysis = {
    "30d": "30 Days",
    "1year": "1 Year",
    k_chart: "Candles",
    trend_chart: "Trend",
    market_value: "Market Cap",
    market_value_tip: "Circulating Supply * Current Price (FIL)",
    circulation: "Circulating Supply",
    proportion: "Circulating Ratio",
    supply: "Total Supply",
    market_total: "Total Market Cap",
    market_total_tip: "Total Supply * Current Price (FIL)",
    locked: "Locked Supply",
    locked_ratio: "Locked Ratio",
    burn: "Burned",
    burn_ratio: "Burned Ratio",
    "24_quantity": "24H Volume",
    "24_amount": "24H Trading Volume",
    turnover_rate: "Turnover Rate",
    turnover_rate_tip: 'Also known as "Trading Turnover Rate," it represents the frequency of buying and selling in the market over a certain period. The formula for 24H Turnover Rate is: 24H Trading Volume / Market Cap * 100%',
    quantity_ratio: "Volume Ratio",
    quantity_ratio_tip: "Average Trading Volume per minute in the last 1 day / Average Trading Volume per minute in the last 7 days",
    //chart
    fil_origin: "Binance",
    period_1: "1 Min",
    period_5: "5 Min",
    period_30: "30 Min",
    period_60: "1 Hour",
    period_240: "4 Hours",
    period_1440: "Day",
    period_10080: "Weekly",
    period_43200: "Monthly",
    //trend chart
    fil_title: "FIL Price Change",
    change_day: "24 Hours",
    change_week: "7 Days",
    change_month: "30 Days",
    change_threemonth: "3 Months",
    change_sixmonth: "6 Months",
    change_year: "1 Year",
    change_thisyear: "YTD",
    change_ico: "All",
    usd_price: "USD Price",
    btc_price: "BTC Price",
    market_price: "Market Cap",
    volume: "Trading Volume",
    price_origin: "Data derives from CoinMarketCap",
    market_tip: "The data is for reference only, not investment advice.",
    //流动性观察
    liquidity_watch_fil: "View FIL Market",
    liquidity_total: "Total Circulating Supply",
    liquidity_total_24: "Total Circulating Supply/24H",
    liquidity_watch: "Liquidity Observation",
    liquidity_watch_tip: "Displays the source changes and trends in the total circulating supply",
    liquidity_destruction: "Burned",
    liquidity_destruction_24: "Burned/24H",
    liquidity_freed: "Released",
    liquidity_freed_24: "Released/24H",
    liquidity_pledge: "Staked",
    liquidity_pledge_24: "Staked/24H",
    provider_rewards: "Storage Provider Rewards",
    provider_rewards_24: "Storage Provider Rewards/24H",
    lockup_freed: "Genesis Lockup Released",
    lockup_freed_24: "Genesis Lockup Released/24H",
    lockup_freed_tip: "The total daily release amount agreed upon by Filecoin Foundation and Protocol Labs during the Filecoin's Genesis",
    reserved_freed: "Reserved Supply Released",
    reserved_freed_24: "Reserved Supply Released/24H",
    sector_pledge: "Sector Staked",
    sector_pledge_24: "Sector Staked/24H",
    defi_staking: "DeFi Staking",
    defi_staking_24: "DeFi Staking/24H",
    //创世账户释放日历
    release_Calendar: "Genesis Account Release Calendar",
    account: "Account",
    total_lockup: "Total Locked",
    released: "Released",
    daily_release: "Daily Release",
    release_cycle: "Release Cycle",
    account_balance: "Account Balance",
    balance_change_7: "Balance Change (7D)",
    fund_penetration: "Fund Penetration",
    release_cycle_detail: "{{value}}% released, fully released on {{date}}",
    go_fund: "Check",
    //token
    token_list_address: "View Wealth Ranking",
    token_list: "Holder Addresses",
    token_list_tip: "Number of Addresses with Non-Zero On-Chain Token Balance, Chart Displaying 30-Day and 1-Year Data",
    token_address_total: "Number of Holders",
    token_top_10: "Top 10 Holders Amount",
    token_top_20: "Top 20 Holders Amount",
    token_top_50: "Top 50 Holders Amount",
    token_top_100: "Top 100 Holders Amount",
    //十大流动地址
    top_active_address: "Top 10 Active Addresses",
    top_active_address_tip: "Top 10 holding addresses with the largest fluctuations (in and out) in the last 7 days",
    quantity: "Holding Quantity",
    percentage: "Holding Percentage",
    change_7d: "7-Day Change",
    //资金穿透
    fund_placeholder: "Enter the address to analyze",
    fund_analysis: "Fund Flow Analysis",
    check_account: "Check",
    network_rank: "Global Ranking",
    position_ratio: "Position Ratio",
    balance_change: "Balance Change",
    related_way: "Method",
    fund_volume: "Transaction Volume",
    fund_number: "Transaction Count",
    rank: "Rank",
    rank_3: "Top 3",
    rank_5: "Top 5",
    rank_10: "Top 10",
    level: "Level",
    level_3: "Level 3",
    level_5: "Level 5",
    level_all: "All Levels",
    select_account: "Selected Account",
    total_volume: "Total Volume",
    total_number: "Total Transactions"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (analysis);


/***/ }),

/***/ 82329:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const common = {
    zh: "中",
    en: "En",
    kr: "Kr",
    login: "Login",
    cancel: "Cancel",
    confirm: "Confirm",
    open: "Unfold",
    no_open: "fold",
    lang: "中",
    fil: "FIL",
    last_time: "Latest Block",
    base_fee: "Base Fee",
    last_height: "Block Height",
    go_home: "Back to Homepage",
    go_login: "Go Login",
    mobile_code_1: "Scan QR code",
    mobile_code_2: "Experience filscan on your Mobile",
    //search
    search_holder: "Please enter address/message ID/height/block CID/miner ID/FNS",
    all: "All",
    address: "Address",
    message_id: "Message ID",
    height: "Height",
    cid: "Block CID",
    node: "Node",
    save_pic: "Save Image",
    fvm_share: "Share with friends",
    account_banner_bg: "Welcome to Miner Metrics!",
    account_banner_main: "Your Ultimate Node Management Assistant",
    time_display: "seconds ago",
    //messages
    no_account: "This email is not registered. Please register first.",
    //登录注册
    active_top_1: "Miner Information in One Glance",
    active_top_2: "",
    active_bottom_1: "Early Warning of Anomalies",
    active_bottom_2: "",
    register: "Email Registration",
    invite_placeholder: "Enter Invite Code (Optional)",
    password_login: "Password",
    verification_code: "Verification Code",
    email_placeholder: "Enter Email Address",
    password_placeholder: "Enter Password",
    code_placeholder: "Enter Verification Code",
    remember_me: "Remember me",
    forgot_password: "Forgot Password",
    get_code: "Get Verification Code",
    retry_code: "Resend Code",
    no_account: "No Account?",
    have_account: "Have account already?",
    go_register: "Register now",
    new_password: "Password Setting",
    confirm_password: "Confirm Password",
    agreement: 'Registration implies acceptance of the "Agreement" and "Privacy Policy"',
    //校验
    email_required: "Please enter your email",
    email_rules: "Invalid email format, please modify",
    code_rules: "Please enter the 6-digi verification code correctly",
    password_rules: "Please enter a password between 8-20 characters long, including numbers, letters, and special characters. The password must not be the same as your email address.",
    confirm_password_rules: "The passwords entered do not match. Please re-enter them",
    email_exists: "Email exists",
    Export: "Download Excel",
    //footer
    footer_des1: "Filscan.io is a Filecoin blockchain explorer and data service platform.",
    footer_des2: "It offers a range of one-stop data services, including mining ranking, blockchain data query, visualization charts, and FVM ecosystem data analysis.",
    active: "Activity",
    active_time: "Period",
    add_project: "Submit Project"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (common);


/***/ }),

/***/ 47889:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const contract = {
    all: "All",
    overview: "Overview",
    market: "Market",
    look_adres: "View Account",
    gohome: "Go Home",
    reset_ver: "Revalidate",
    next: "Continue",
    reset: "Reset",
    "all_token": "All Tokens",
    ">0": "With Balance",
    "=0": "No Balance",
    confirm: "Verify&Publish",
    back: "Return to Main",
    file_name: "SELECT *.SOL FILES",
    file_name_json: "SELECT *.JSON FILES",
    config_file_name: "SELECT Metadata FILES",
    config_file_des1: "> When do I need to upload a metadata file?",
    config_file_des1_1: "1. The metadata file contains various compiler settings. If you have used advanced optimization parameters or compiled your code with a compilation configuration file (e.g. compiler_config.json in Remix), you will be required to upload the metadata file for verification.",
    config_file_des1_2: "2. The hierarchical directory of imports in the contract is in the initial format (e.g. import '@openzeppelin/contracts/access/Ownable.sol') and is the same as the path under 'sources' in the metadata file. You don't need to upload the metadata file (if the hierarchical directory of import in the contract is point to the current folder)",
    config_file_des2: "> How can I obtain the metadata file?",
    config_file_des2_1: "1. By using the Solidity Compiler (solc):  solc --metadata Contract.sol -o metadata.json",
    config_file_des2_2: "2. Download it using Remix IDE: There is a download button for metadata.json after deployed on the Remix website.",
    verify_title: "Verify & Publish Contract Source Code",
    verify_des: "COMPILER TYPE AND VERSION SELECTION",
    verify_content: `Source code verification provides transparency for users interacting with smart contracts. By uploading the source code, Filscan will match the compiled code with that on the blockchain. Just like contracts, a "smart contract" should provide end users with more information on what they are "digitally signing" for and give users an opportunity to audit the code to independently verify that it actually does what it is supposed to do.`,
    content_des: `Source code verification provides transparency for users interacting with smart contracts. By uploading the source code, Filscan will match the compiled code with that on the blockchain. Just like contracts, a "smart contract" should provide end users with more information on what they are "digitally signing" for and give users an opportunity to audit the code to independently verify that it actually does what it is supposed to do. Contract verification can be performed quickly by uploading the JSON file in the "artifacts/build-info/" directory.
Hardhat stores the compilation outputs in the "artifacts/build-info/" directory within the project. The directory includes a .json file that contains the Standard JSON Input-Output for all contracts, which is the recommended approach for interacting with the Solidity compiler, especially in advanced and automated configurations. This JSON-input-output interface is uniformly supported across all compiler distributions.`,
    address: "Please Enter Contract Address to Verify",
    address_placeholder: "Please enter the Contract Address",
    verify_model: "Compiler Type",
    verify_model_placeholder: "Please select Compiler Type",
    verify_address: "Please Enter Complier Version to Verify",
    verify_address_placeholder: "Please select",
    license_type: "Please select Open Source License Type",
    content_des1: "1. If the contract compiles correctly at REMIX, it should also compile correctly here.",
    content_des2: "2. We have limited support for verifying contracts created by another contract and there is a timeout of up to 45 seconds for each contract compiled.",
    content_des3: "3. For programatic contract verification, check out the Contract API Endpoint.",
    checkbox_service: "I agree to the terms of service",
    verify_select_placeholder: "Please select",
    //logs
    ver_sucess: "Success",
    ver_err: "Error",
    has_been_verified: "Error:Has Been Verified",
    byte_code: "Compilation log",
    contract_name: " Contract Name ",
    local_byte_code: "Contract Bytecode",
    compiler: "Complier Verison",
    //step1
    address_verify: "Contract Address",
    step1_verify_des: "SELECT ONE OR MORE *.SOL FILES",
    source_code: "Contract Source Code",
    compile_version: "Complier",
    compile_output: "Complier Output",
    Optimizations: "Optimizations",
    run_optimizer: "Runs(Optimizer)",
    arguments: "Constructor Argument",
    optimize: "Optimization Enabled",
    //token list
    token_list: "All Tokens",
    token_name: "Token",
    vol_24: "Trading Volume(24h)",
    transfer_total: "Total Messages of {{value}}",
    owner_total: "From a total of {{value}} Hodlers",
    dex_total: "Total Message of {{value}} Transactions ",
    nfts_total: "Total Nfts of {{value}} Transactions ",
    // 已验证合约
    Verify_code: "Code",
    Verify_read: "Read Contract",
    Verify_write: "Write Contract",
    byte_code_no_verify: "The contract is not verified go to",
    go_to_verify: "verify the contract",
    contract_verify: "Contract verification",
    contract_verify_tips: "Please go to the PC for contract verification",
    //nft list
    nfts_list: "All NFTs",
    trading_volume: "Trading Volume",
    nfts_trans: "NFTs Transfer",
    // ft /fns dashborad
    "total_supply": "Circulating Supply",
    "total_supply_tip": "This data is the standard method return value for the contract ERC20",
    "owners": "Hodlers",
    "transfers": "Total Transfers",
    latest_price: "Price",
    market_value: "Market Cap",
    token_contract: "Token Contract",
    transfer: "Transfers",
    owner: "Hodlers",
    domain: "Contract",
    dex: "Dex Trades",
    //list
    message_cid: "Message ID",
    method: "Method",
    time: "Time",
    from: "From",
    to: "To",
    amount: "Amount",
    //拥有者
    rank: "Rank",
    percentage: "Percentage",
    //dex
    platform: "Platform",
    Txn_Value: "Txn Value",
    "swapped_Rate": "Swapped Rate",
    "Token_Amount_in": "Token Amount(In)",
    "Token_Amount_out": "Token Amount(Out)",
    Action: "Action",
    //合约列表
    contract_list: "Verified Contracts",
    contract_address: "Address",
    language: "Language",
    license: "License",
    //合约详情
    contract_list_total: "Total of {{value}} Contracts",
    verify_contract: "Contract Source Code Verified",
    source_code: "Contract Source Code",
    source_code_create: "Contract Creation Code",
    source_abi: "Contract ABI",
    source_abi_default: "Export ABI",
    nfts_list: "NFTs List",
    owner_nft: "Owner",
    item: "Item",
    controller: "Registrant",
    pleaseCheckContractWithPC: "Please check the contract details on PC",
    //rank
    contract_rank_des: "Latest Update on:{{value}}",
    contract_rank_total: "Total of {{value}} Contracts",
    contract_rank: "Contract Rank",
    actor_id: "actorID",
    actor_address: "actorAddress",
    transaction_count: "TransCount",
    user_count: "TransAddress",
    actor_balance: "Balance",
    gas_cost: "Gas Cost",
    ver_address: "Pending Verification",
    see_more: "See More",
    //log
    epoch: "Height",
    cid: "CID",
    event_name: "Method",
    topics: "Topics",
    coompoent_data: "Params",
    log_index: "Index",
    removed: "Removed"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contract);


/***/ }),

/***/ 39451:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// pool-detail
const detail = {
    "24h": "24H",
    "7d": "7D",
    "30d": "30D",
    "1year": "1Y",
    all: "All Methods",
    all_token: "All Tokens",
    //owner
    owner_title: "Pool Detail",
    owner_title_tip: "The data of mine pool is collected from the data of nodes.",
    account: "Account",
    account_title: "Account",
    owner_address: "Owner Address",
    owned_miners: "Nodes",
    account_id: "Account Address",
    look_all: "View All Data",
    transfer_records: "Transfer records",
    //account_type
    miner: "Miner",
    evm: "EVM",
    ethaddress: "ETHAddress",
    ethaccount: "ETHAccount",
    account_name: "Account",
    latest_transfer_time: "Latest Transaction",
    multisig: "MultiSign Account",
    from_ath: "From",
    to_ath: "To",
    //概览
    owner_overview_title: "Pool Overview",
    balance: "Total Balance",
    available_balance: "Available",
    init_pledge: "Initial Pledge",
    pre_deposits: "PreCommitDeposits",
    locked_balance: "Locked Rewards",
    balance_tip: "Total Balance=Available+InitialPledge+PreCommitDeposits+Locked Rewards",
    available_balance_tip: "Available spendable amount in the account excluding initial pledge and locked rewards",
    init_pledge_tip: "The actual amount pledged after the successful completion of the second phase of Proof of Replication",
    pre_deposits_tip: "The PreCommit Deposits amount during the first phase of Proof of Replication will be adjusted based on the actual pledged amount per sector after successfully submitting the proof within the specified time during the second phase; otherwise, if the proof is not submitted within the given timeframe, a penalty will be imposed",
    locked_balance_tip: "The unreleased portion of block rewards will be linearly released over time",
    sector_count: "Total",
    live_sector_count: "Active",
    fault_sector_count: "Faults",
    recover_sector_count: "Recoveries",
    eth_address: "ETH Address",
    eth_message: "ETH Hash",
    stable_address: "Stable Address",
    showContract: "Contract: {{value}}",
    showAddress: "Address: {{value}}",
    account_detail: "Account Detail",
    contract_name: "Contract Name",
    //统计指标
    indicators: "Statistical Indicator",
    power_increase_indicators: "Power Increase",
    power_ratio: "Power Growth Rate",
    sector_increase: "Sector Increase",
    precommit_deposits: "PreCommitDeposits Increase",
    gas_fee: "Gas Fee",
    block_rewards: "Block Rewards",
    block_count: "Block",
    block_count_tip: "Block= The sum of the blocks mined",
    mining_efficiency: "Efficiency",
    mining_efficiency_tip: "The ratio of node's cumulative block reward to the adjusted storage power in the selected period.",
    lucky: "Lucky",
    lucky_tip: "The ratio of the actual number of block reward to the expected number of block reward. If the QualityAdjPower is less than 1 PiB, this value has significant randomness and should be taken as a reference only",
    sector_ratio: "Sector Rate",
    win_count: "Winner Rewards",
    windowPost_gas: "Maintain computing power consumption",
    win_count_tip: "In Filecoin mining model, there may be multiple blocks under a tipset, and each block may receive multiple win counts.",
    net_profit_per_tb: "Gas Consumption/T",
    net_profit_per_tb_tip: "The gas consumption for sealing a single sector of size T within a selected period",
    //账户变化
    account_change: "Account Change",
    power: "Pool Overview",
    power_increase: "QualityAdjPower Increase",
    quality_adjust_power: "QualityAdjPower",
    quality_power_rank: "Ranking",
    raw_power_percentage: "Power Rate",
    raw_power: "RawBytePower",
    total_block_count: "30D  Blocks",
    total_block_count_tip: "Total Blocks in the past 30 days",
    total_reward: "30D  Reward",
    total_reward_tip: "Total Reward in the past 30 days",
    total_win_count: "30D  Wincount",
    total_win_count_tip: "Total Wincount in the past 30 days",
    total_balance_tip: "Total Balance=Available+Initial Pledge+PreCommitDeposits+Locked Rewards",
    sector_size: "Sector Size",
    sector_status: "Sector Status",
    contract_verify: "Contract",
    peer_detail: "Miner Detail",
    miner_owner: "Owner",
    no_area: "Unknown",
    //账户总览
    account_overview: "Account Overview",
    create_time: "Create Time",
    account_type: "Type",
    peer_id: "Peer ID",
    account_address: "Address",
    // eslint-disable-next-line no-dupe-keys
    owner_address: "Owner",
    area: "Region",
    worker_address: "Worker",
    controllers_address: "Controller",
    beneficiary_address: "Beneficiary",
    code_cid: "CODE CID",
    nonce: "Nonce Count",
    // message
    message_overview_detail: "Transaction Details",
    trade: "Internal Transaction",
    message_detail: "Overview",
    event_log: "Log",
    message_overview: "Message Overview",
    cid: "Message ID",
    height: "Height",
    time: "Time",
    blk_cids: "Block Cid",
    value: "Value",
    from: "From",
    to: "To",
    status: "Status",
    method_name: "Method",
    message_other: "Others",
    version: "Version",
    // eslint-disable-next-line no-dupe-keys
    nonce: "Nonce",
    gas_fee_cap: "Gas Fee Cap",
    gas_premium: "Gas Premium",
    gas_limit: "Gas Limit",
    gas_used: "Gas Used",
    base_fee: "BaseFee",
    all_gas_fee: "Gas Fee",
    params: "Params",
    returns: "Returns",
    message_tranf: "Transactions",
    from_tranf: "From",
    to_tranf: "To",
    consume_type: "Type",
    MinerTip: "Miner Tip",
    BaseFeeBurn: "BaseFee Burn",
    Transfer: "Transfer",
    Burn: "Burn",
    exit_code: "Status",
    err_message: "Error Message",
    replaced: "Cid is overwritten",
    replaced_detail: 'CID "{{value}}" has been overwritten by "{{newValue}}"',
    base_cid: "Overridden CID",
    //内部交易
    amount: "Value",
    method: "Method",
    topic: "Topics",
    //通证转移
    message_ERC20Trans: "Tokens Transferred",
    message_NftTrans: "NFTS Transferred",
    // 出块列表
    block_cid: "Block Cid",
    block_height: "Height",
    block_time: "Time",
    block_messages_count: "Messages",
    block_miner_id: "Storage Provider",
    block_mined_reward: "Rewards",
    //miner
    message_list: "Message",
    block_list: "Block",
    traces_list: "Transaction",
    message_list_total: "Total of {{value}} Messages",
    block_list_total: "Total of  {{value}} Blocks",
    traces_list_total: "Total of {{value}} Messages",
    erc20_transfer_total: "Total of {{value}} Transactions",
    // contract_token_list_total: 'Total of {{value}} Token',
    //general
    general_overview_title: "Account",
    base_account_id: "ID",
    tokenList: "Token Holdings",
    //dns detail
    deal_details: "dsn Detail",
    deal_id: "Dsn ID",
    epoch: "Block",
    service_start_time: "Create Time",
    message_cid: "Message",
    piece_cid: "Piece CID",
    verified_deal: "Verified",
    deal_hosting: "Storage Detail",
    deal_left_title: "Client",
    deal_right_title: "Provider",
    deal_value: "Provider",
    deal_cash: "Storage Cost",
    deal_time: "to",
    user_count: "User Count",
    transfer_count: "Transfer Count",
    go_verify: "To Verify",
    //Token
    contract_token_list: "Field",
    token_name: "Token Name",
    contract_id: "Contract Id",
    amount: "Amount",
    //erc20 transfer
    erc20_transfer: "Token Transactions",
    platform: "Platform",
    power_change: "Power Change",
    owned_active_miners: "Active Miners",
    //height
    blcok_time: "Block Time",
    message_count_deduplicate: "Block Message (Deduplication) ",
    miner_id: "Miner",
    messages_count: "Message",
    reward: "Reward",
    //cid detail
    block_list: "Block List",
    blocks_cid: "Cid",
    blocks_miner: "Miner",
    blocks_messages: "Message",
    blocks_reward: "Reward",
    win_count: "WinCount",
    blk_cids_message: "Block Message",
    //cid_details
    message_list_total: "Total of {{value}} messages",
    chain_cid_detail: "Block Details",
    cid_height: "Height",
    parent_weight: "Parent Weight",
    parents_cid: "Parent CID",
    parent_base_fee: "Parent Basefee",
    ticket_value: "Ticket",
    state_root: "State Root",
    message_count: "Message Count",
    //pendingMsg
    pending_title: "Pending Messages",
    pending_total: "Total of {{value}} messages to be processed"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (detail);


/***/ }),

/***/ 18210:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const domain = {
    domain_title: "Overview",
    resolved_address: "Resolved Address",
    expired_at: "Expiration Date",
    registrant: "Registrant",
    controller: "Controller",
    Result_for: "Result for",
    allDomains: "All Domains"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (domain);


/***/ }),

/***/ 48819:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fevm = {
    tp_token: "Add Token To TokenPocket",
    rank: "Rank",
    defi_overview: "DeFi Protocol",
    fevm_staked: "FEVM Staked",
    staked_change_in_24h: "24h Staked",
    total_user: "Total Users",
    user_change_in_24h: "24h Users",
    fil_staked: "FIL Staked",
    defi_list: "DeFi Protocol",
    Protocol: "Protocol",
    defi_list_time: "Latest Update on: {{value}}",
    tvl: "TVL",
    tvl_change_rate_in_24h: "24h Staked Change",
    tvl_change_in_24h: "24h Staked",
    tokens: "Top Tokens",
    tokens_tip: "Percentage of different tokens staked in this protocol",
    users: "Users",
    see_more: "See More"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fevm);


/***/ }),

/***/ 91475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fvm = {
    hot: "Explore FVM on FIlscan",
    all: "Filecoin Ecosystem",
    Defi: "Defi",
    Dex: "Dex",
    DID: "DID",
    NFT: "NFT",
    MarketPlace: "MarketPlace",
    Launchpad: "Launchpad",
    see_more: "See More"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fvm);


/***/ }),

/***/ 55128:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const home = {
    seconds: "s",
    minutes: "m",
    hours: "h",
    day: "D",
    meta_title: "The Filecoin Network Data Index",
    mata_show: "Unfold",
    mata_show_false: "Fold",
    latest_height: "Block Height",
    latest_block_time: "Latest Block",
    total_blocks: "Total Block",
    total_rewards: "Total Block Rewards",
    total_quality_power: "Network QualityAdjPower",
    total_quality_power_tip: "Total current effective computing power (effective storage space) of the Filecoin network",
    base_fee: "Base Fee",
    miner_initial_pledge: "Current Sector Initial Pledge",
    power_increase_24h: "Latest 24h Power Growth",
    rewards_increase_24h: "Block Rewards in 24h",
    fil_per_tera_24h: "Output Efficiency in 24h",
    fil_per_tera_24h_tip: "The average\xa0reward output\xa0for each TiB of storage capacity over the last 24 hours",
    gas_in_32g: "24H Gas Cost for Sealing 32GiB sectors/TiB",
    gas_in_32g_meta: "Gas Used of a 32GiB Sector",
    gas_in_32g_tip: "Gas used of Sealing a 32GiB Sector in the last 24 hours",
    add_power_in_32g: "Est. Cost of a 32GiB Sector",
    add_power_in_32g_tip: "The cost of sealing a 32GiB sector in the past 24 hours, including the sector’s initial pledge and message fee",
    gas_in_64g: "24H Gas Cost for Sealing 64GiB sectors/TiB",
    gas_in_64g_meta: "Gas Used of a 64GiB Sector",
    gas_in_64g_tip: "Gas used of sealing a 64GiB sector in the last 24 hours",
    add_power_in_64g: "Est. Cost of a 64GiB Sector",
    add_power_in_64g_tip: "The cost of sealing a 64GiB sector in the past 24 hours, including the sector’s initial pledge and message fee",
    win_count_reward: "Rewards per Wincount",
    win_count_reward_tip: "",
    avg_block_count: "Avg. Blocks per TipSet",
    avg_block_count_tip: "Average blocks produced per tipSet in 24h",
    avg_message_count: "Avg. Messages per TipSet",
    avg_message_count_tip: "Average messages packaged per tipSet in 24h",
    active_miners: "Active Nodes",
    burnt: "Burnt",
    circulating_percent: "Circulation Amount",
    rank: "Ranking List",
    footer_text: "Filscan browser is the filecoin blockchain browser and data service platform.It provides one-stop data services such as mining ranking, blockchain data query and visualization chart based on filecoin.",
    footer_outlook: "Email",
    footer_detail_a: "Copyright \xa9 Filecoin-Project devgrants. Distributed under the ",
    footer_detail_b: " and ",
    footer_detail_c: "license",
    search_notFound: "Search Not Found",
    warn_text: "Sorry, there are no results for the characters you entered",
    warn_details: "Sorry! This is an invalid search string",
    go_home: "Back Home",
    base_gas: "24h BaseFee",
    rank: "Rank",
    blockchain_browser: "blockchain browser",
    "quality_power/increase_24h": "Net QualityAdjPower/in 24h",
    total_contract: "Active Contract",
    "total_contract/24h_contract": "Active Contract/in 24h",
    "total_contract_24h_contract": "Active Contract in 24h",
    verified_contracts: "Verified Contracts",
    contract_transaction: "ContTransCount",
    "contract_transaction/24h_change": "ContTransCount/in 24h",
    "contract_transaction_24h_change": "ContTransCount in 24h",
    "contract_address/24h_change": "ContTransAddr/in 24h",
    "contract_address_24h_change": "ContTransAddr in 24h",
    "contract_address": "ContTransAddr",
    "total_contract/24h_contract_tip": "Total number of contracts that have had transactions in the network",
    gas_24: "24h Gas Cost",
    proportion_64G: "QualityAdjPower Ratio for 32GiB Sectors",
    proportion_32G: "QualityAdjPower Ratio for 64GiB Sectors",
    verified_contracts: "Verified Contracts",
    contract_gas: "Contract Gas Cost",
    quality_power_Cc: "Commited Capacity (CC)",
    quality_power_Dc: "DataCap (DC)",
    see_more: "See More",
    contract_balance: "Contract Balance"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (home);


/***/ }),

/***/ 24995:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const en = {
    network_title: "Current Network",
    home: "Home",
    contract: "FEVM",
    contract_verify: "Contract Verification",
    token: "Tokens",
    nft: "NFTs",
    contract_list: "Verified Contracts",
    contract_rank: "Contract Rank",
    analysis: "Data Analysis",
    analysis_market: "Project Analysis",
    analysis_fund: "Fund Flow Analysis",
    defi_dashboard: "DeFi Protocol",
    tipset: "Blockchain",
    tipset_chain: "Tipsets",
    tipset_message: "Messages",
    tipset_ranking: "Wealth Ranking",
    tipset_transfer: "Large Amount Transfer",
    tipset_dsn: "Dsn",
    "tipset_pool-message": "Pool Messages",
    ranking: "Ranking",
    statistics: "Statistics",
    cw: "ChainWatch",
    statistics_gas: "Gas Fee",
    statistics_base: "Power",
    statistics_fil: "FIL",
    statistics_charts: "Statistics",
    statistics_map: "Charts",
    resources: "Resources",
    resources_tools: "Tools",
    provider: "Storage Provider",
    fvm: "Filecoin Ecosystem",
    fvm_all: "Project Overview",
    active: "Activity",
    account: "Miner Metrics",
    network_overview: "Network Overview",
    develop: "Developer",
    language: "Language",
    network: "Network"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (en);


/***/ }),

/***/ 26735:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const rankZh = {
    rank: "Rank",
    rank_title: "Ranking",
    pool: "Storage Pool",
    provider: "Storage Provider",
    growth: "Power Growth Rate",
    rewards: "Rewards",
    "24h": "24H",
    week_days: "7D",
    month: "30D",
    select_rank_all: "All",
    select_rank_32: "32GiB",
    select_rank_64: "64GiB",
    more: "More",
    rank_time: "Latest Update on",
    see_more: "See More",
    // table columns title
    //存储池排行
    ranking: "Rank",
    pool_owner: "Owner ID",
    pool_power: "QualityAdjPower",
    pool_efficiency_24h: "Latest 24h Output Efficiency",
    pool_increase_24h: "24H Power Growth",
    pool_block_count: "Blocks Mined",
    miner: "Miner",
    pool_block_count_24h: "24h Total Block Rewards",
    // 节点排行
    provider_miner: "Storage Provider",
    provider_power_ratio: "QualityAdjPower / Rate",
    provider_block_ratio: "24H Blocks / Rate ",
    provider_rewards_ratio: "24H Wincount Rate",
    balance: "Balance",
    //算力增速
    power_ratio: "Power Growth",
    power_ratio_tip: "Daily total adj. power of the sealed sectors within selected period.",
    quality_power_increase: "Power Growth",
    quality_power_increase_tip: "Node's adjusted storage power increment in the selected period.",
    quality_adj_power: "QualityAdjPower",
    raw_power: "RawBytePower",
    sector_size: "Sector Size",
    //节点收益
    "rewards/ratio": "Rewards/Ratio",
    "rewards/ratio_tip": "The ratio of node's cumulative block reward to the adjusted storage power in the selected period.",
    block_count: "Blocks",
    block_count_tip: "In Filecoin CryptoEconomics, there may be multiple blocks under a tipset, and each block may receive multiple win counts.",
    winning_rate: "Wincount Rate"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rankZh);


/***/ }),

/***/ 88827:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const statistic = {
    gas_total: "Gas",
    show_more: "More",
    "24h": "24H",
    "7d": "7D",
    "30d": "30D",
    year: "1Y",
    // power
    power: "Storage Power Trend",
    power_tips: "The network baseline is the scale of network growth required by the Filecoin Network, which was 2.5 EiB when the Mainnet launched, with a growth rate of 100% per year",
    trend_24: "24h Base Fee Variations",
    total_raw_byte_power: "Net RawBytePower",
    base_line_power: "BaseLine",
    power_increase: "Net Power Increase",
    power_decrease: "Net Power Decrease",
    total_quality_adj_power: "QualityAdjPower",
    change_quality_adj_power: "QualityAdjPower Fluctuations",
    gas: "Base Fee Variations",
    base_fee: "Base Fee",
    gas_in_32g: "Gas Cost of Sealing a 32GiB Sector",
    gas_in_64g: "Gas Cost of Sealing a  64GiB Sector",
    //24_gas
    gas_24: "24h Gas Data",
    method_name: "Message Type",
    avg_gas_premium: "Gas Premium",
    avg_gas_limit: "Avg. Gas Limit",
    avg_gas_used: "Avg.Gas Cost",
    avg_gas_fee: "Avg. Gas Fee",
    "sum_gas_fee/ratio": "Total Fees/Percentage",
    "message_count/ratio": "Total Messages/Percentage",
    //fil
    TokenRules: "FIL Allocation",
    FilecoinFoundation: "Filecoin Foundation",
    FundraisingRemainder: "Fundraising-Remainder",
    FundraisingSAFT: "Fundraising-SAFT",
    MiningReserve: "Mining Reserve",
    TokenAllocation: "Storage Mining Allocation",
    ReservedTokens: "Mining Reserve",
    Fundraising: "Fundraising - SAFT 2017",
    Funds: "Fundraising - Remainder",
    protocolLab: "Protocol Labs",
    Contributors: "PL Team &amp; Contributors",
    Allocation: "Allocation",
    value: "Value",
    description: "Description",
    filBase: "FIL BASE",
    filBase_des: "The maximum amount of FIL that will ever be created.",
    ReservedTokens_des: "Tokens reserved for funding mining to support growth of the Filecoin Economy, whose future usage will bedecided by the Filecoin community.",
    TokenAllocation_des: "The amount of FIL allocated tostorage nodes through block rewards, network initialization, etc.",
    Fundraising_des: "2017 TOKEN SALE",
    FilecoinFoundation_des: "Allocated towards long-term community development and the management of the network.",
    Funds_des: "Allocated for ecosystem development, future fundraising",
    protocolLab_des: "Allocated for Protocol Labs",
    Contributors_des: "4.5% for the PL team & contributors",
    //charts
    pie_title: "Chart Statistics",
    block_trend: "Block Rewards",
    block_reward_per_TiB: "Output Efficiency",
    active_nodes: "Active Storage Providers",
    active_miner_count: "Node Counts",
    messages_trend: "Message Trend",
    message_count: "Message Trend of Each Block",
    all_message_count: "Messages Variation per Block",
    all_message_count_tip: "Messages Included per Block",
    acc_block_rewards: "Cumulative Block Rewards",
    pie_title_a: "Current statistics on the distribution of FIL usage",
    pie_title_a_tip: "Total FIL Rewarded + Locked Rewards Released + Reserved FIL Allocated = Currently Released Fil",
    pie_title_b: "Released FIL Usage Statistics",
    mined: "Total FIL Rewarded",
    remaining_mined: "Total FIL to Reward",
    vested: "Locked Rewards Released",
    remaining_vested: "Locked Rewards to Release",
    reserve_disbursed: "Reserved FIL Allocated(Testnet Rewards)",
    remaining_reserved: "Reserved FIL to Allocate",
    locked: "Total Sector Pledge",
    burnt: "Total FIL Burned",
    circulating: "Circulating Supply",
    //chartsnav
    cc_dc_power: "CC/DC PowerTrend",
    static_overview: "Statistics",
    contract_trend: "Contract Transaction",
    fil_overview: "FIL Overview",
    charts_title: "FIL Allocation Guidelines",
    networks_overview: "Network Overview",
    contract_con: "Trend of Contract Deployment",
    contract_counts: "Contract Deployment",
    contract_gas: "Contract Gas Cost",
    contract_addr: "Contract Transaction Address",
    contract_balance: "Contract Balance Trend",
    contract_total_balance: "Contract Balance",
    //cw
    "cw-search": "Search height/block cid",
    cw_des: "Drag To See Different Heights",
    cw_top: "Latest Height"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (statistic);


/***/ }),

/***/ 37545:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const tipset = {
    rank: "Rank",
    tag: "Tag",
    height: "Height",
    cid: "Message ID",
    block_time: "Time",
    from: "From",
    to: "To",
    value: "Value",
    method_name: "Method",
    all: "All Methods",
    //chain
    blocks_cid: "Cid",
    blocks_miner: "Storage Provider",
    blocks_messages: "Message",
    blocks_reward: "Reward",
    win_count: "WinCount",
    //cid_details
    message_list_total: "Latest {{value}} Messages",
    chain_cid_detail: "Block details",
    cid_height: "Height",
    parent_weight: "Parent Weight",
    parents_cid: "Parent CID",
    parent_base_fee: "Parent BaseFee",
    ticket_value: "Ticket",
    state_root: "State Root",
    //message
    message_list: "Message List",
    total_list: "Latest {{value}} Messages",
    message_list_all: "All Methods",
    message_list_exit_code: "Status",
    // adress
    address_all: "All Types",
    address_total_list: "Total of {{value}} Accounts",
    account: "account",
    owner: "owner",
    miner: "node",
    payment: "payment",
    multisig: "multisig",
    address_list: "Wealth Ranking",
    balance_change_7: "Balance Change",
    fund: "Fund Penetration",
    go_fund: "Check",
    account_address: "Address",
    balance_percentage: "Balance / Percentage",
    account_type: "Status",
    latest_transfer_time: "Last Seen Time",
    //transfer
    transfer_list: "Large Amount Transfer",
    transfer_total_list: "Total of {{value}} Message",
    //dsn
    dsn_list: "Order List",
    dsn_total_list: "Total of {{value}} Deals",
    dsn_placeholder: "Search Client/Provider/Deal ID",
    deal_id: "Deal ID",
    piece_cid: "Piece CID",
    piece_size: "PieceSize",
    client_address: "Client",
    provider_id: "Provider",
    service_start_time: "Start Time",
    end_time: "End Time",
    start_height: "Start Height",
    end_height: "End Height",
    storage_price_per_height: "Storage Fee",
    verified_deal: "Verified Deal",
    // pool-message
    pool_list: "Message Pool List",
    gas_fee_cap: "Gas Limit",
    gas_premium: "Gas Premium",
    block_list: "Tipsets List"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (tipset);


/***/ }),

/***/ 21091:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(22021);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57987);
/* harmony import */ var _en_nav_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(24995);
/* harmony import */ var _zh_nav_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(93124);
/* harmony import */ var _kr_nav_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7997);
/* harmony import */ var _zh_home_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3075);
/* harmony import */ var _en_home_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(55128);
/* harmony import */ var _kr_home_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(13115);
/* harmony import */ var _zh_statistic_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(76517);
/* harmony import */ var _en_statistic_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(88827);
/* harmony import */ var _kr_statistic_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(44547);
/* harmony import */ var _zh_rank_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(23074);
/* harmony import */ var _en_rank_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(26735);
/* harmony import */ var _kr_rank_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(20596);
/* harmony import */ var _zh_tipset_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(63061);
/* harmony import */ var _en_tipset__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(37545);
/* harmony import */ var _kr_tipset_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(29465);
/* harmony import */ var _zh_detail__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(19893);
/* harmony import */ var _en_detail__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(39451);
/* harmony import */ var _kr_detail__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(53341);
/* harmony import */ var _zh_fvm_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(38826);
/* harmony import */ var _en_fvm__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(91475);
/* harmony import */ var _kr_fvm__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(78589);
/* harmony import */ var _zh_contract_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(40077);
/* harmony import */ var _en_contract_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(47889);
/* harmony import */ var _kr_contract_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(64276);
/* harmony import */ var _zh_domain_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(9577);
/* harmony import */ var _en_domain_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(18210);
/* harmony import */ var _kr_domain_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(29720);
/* harmony import */ var _zh_fevm_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(83124);
/* harmony import */ var _en_fevm_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(48819);
/* harmony import */ var _kr_fevm_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(9429);
/* harmony import */ var _zh_common_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(91818);
/* harmony import */ var _en_common_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(82329);
/* harmony import */ var _kr_common_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(85387);
/* harmony import */ var _zh_account_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(9547);
/* harmony import */ var _en_account_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(52324);
/* harmony import */ var _kr_account_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(92345);
/* harmony import */ var _zh_user_js__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(98402);
/* harmony import */ var _zh_analysis_js__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(28160);
/* harmony import */ var _en_analysis_js__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(75531);
/* harmony import */ var _kr_analysis_js__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(35587);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_1__]);
([i18next__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










































i18next__WEBPACK_IMPORTED_MODULE_0__["default"].use(react_i18next__WEBPACK_IMPORTED_MODULE_1__.initReactI18next).init({
    resources: {
        en: {
            common: _en_common_js__WEBPACK_IMPORTED_MODULE_33__/* ["default"] */ .Z,
            account: _en_account_js__WEBPACK_IMPORTED_MODULE_36__/* ["default"] */ .Z,
            nav: _en_nav_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
            home: _en_home_js__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
            static: _en_statistic_js__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
            rank: _en_rank_js__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z,
            tipset: _en_tipset__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z,
            detail: _en_detail__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z,
            fvm: _en_fvm__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z,
            contract: _en_contract_js__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z,
            domain: _en_domain_js__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z,
            fevm: _en_fevm_js__WEBPACK_IMPORTED_MODULE_30__/* ["default"] */ .Z,
            analysis: _en_analysis_js__WEBPACK_IMPORTED_MODULE_40__/* ["default"] */ .Z
        },
        kr: {
            common: _kr_common_js__WEBPACK_IMPORTED_MODULE_34__/* ["default"] */ .Z,
            account: _kr_account_js__WEBPACK_IMPORTED_MODULE_37__/* ["default"] */ .Z,
            nav: _kr_nav_js__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
            home: _kr_home_js__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
            static: _kr_statistic_js__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
            rank: _kr_rank_js__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z,
            tipset: _kr_tipset_js__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z,
            detail: _kr_detail__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z,
            fvm: _kr_fvm__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z,
            contract: _kr_contract_js__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z,
            domain: _kr_domain_js__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z,
            fevm: _kr_fevm_js__WEBPACK_IMPORTED_MODULE_31__/* ["default"] */ .Z,
            analysis: _kr_analysis_js__WEBPACK_IMPORTED_MODULE_41__/* ["default"] */ .Z
        },
        zh: {
            common: _zh_common_js__WEBPACK_IMPORTED_MODULE_32__/* ["default"] */ .Z,
            account: _zh_account_js__WEBPACK_IMPORTED_MODULE_35__/* ["default"] */ .Z,
            nav: _zh_nav_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
            home: _zh_home_js__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
            static: _zh_statistic_js__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
            rank: _zh_rank_js__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z,
            tipset: _zh_tipset_js__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z,
            detail: _zh_detail__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z,
            fvm: _zh_fvm_js__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z,
            contract: _zh_contract_js__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z,
            domain: _zh_domain_js__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z,
            fevm: _zh_fevm_js__WEBPACK_IMPORTED_MODULE_29__/* ["default"] */ .Z,
            user: _zh_user_js__WEBPACK_IMPORTED_MODULE_38__/* ["default"] */ .Z,
            analysis: _zh_analysis_js__WEBPACK_IMPORTED_MODULE_39__/* ["default"] */ .Z
        }
    },
    fallbackLng: "zh",
    debug: true,
    react: {
        useSuspense: false
    },
    detection: {
        order: [
            "querystring",
            "navigator",
            "localStorage"
        ],
        lookupQuerystring: "lang"
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (i18next__WEBPACK_IMPORTED_MODULE_0__["default"]);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 92345:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const account = {
    date: "날짜",
    day: "일",
    copy: "Copy",
    confirm: "Confirm",
    cancel: "Cancel",
    go_home: "홈으로",
    go_login: "로그인하다",
    login: "노드 관리자",
    back: "뒤로",
    account_title: "마이너 지표",
    overview: "데이터 개요",
    miners: "노드 관리",
    data_details: "데이터 세부정보",
    monitor: "감시 관리",
    monitorSector: "만료 모니터링",
    monitorBalance: "잔액 모니터링",
    monitorPower: "전력 모니터링",
    personal: "계좌 정보",
    logout: "Logout",
    default_group: "기본 그룹",
    welcome: "Welcome to Filscan!",
    welcome_text1: "축하합니다! 회원 가입이 성공적으로 이루어졌습니다. 이메일 주소와 비밀번호를 사용하여 계속해서 로그인하실 수 있습니다.",
    welcome_text2: "계정에 로그인하세요!",
    last_time: "최신 업데이트 시간",
    all: "전체",
    all_groups: "All Groups",
    all_miners: "All Miners",
    all_tags: "All Tags",
    edit: "편집하다",
    miner_add: "추가하다",
    select_group: "그룹을 선택하세요",
    select_miner: "채굴자를 선택해 주세요",
    select_miner_tag: "请选择标签",
    //个人账户
    register_success: "축하합니다! 회원 가입이 성공적으로 완료되었습니다",
    register_btn: "활성화하다",
    edit: "작업",
    miner_add: "添加",
    edit_write: "수정",
    edit_delete: "삭제",
    created_at: "생성 시간",
    //数据概览
    power: "해시파워 개요",
    gas: "Gas 소비",
    expired: "만기 섹터",
    reward: "블록 보상",
    lucky: "행운값",
    balance: "잔액",
    no_node_data: "노드가 아직 추가되지 않았습니다",
    miners_add: "노드 추가",
    group_add: "그룹 추가",
    miners_group_manage: "그룹 설정",
    total_out_come_gas: "일일 비용/Gas 소비량",
    pledge_amount_24: "플레지/일일 변동",
    balance_24: "계정 잔액/일일 변동",
    quality_power_24: "파워/일일 변동",
    //节点管理
    delete_group: "그룹 삭제",
    delete_record_group: "그룹을 삭제하시겠습니까?",
    delete_group_text: "삭제 후에는 해당 그룹이 목록에 표시되지 않습니다",
    delete_miner: "마이너 삭제",
    delete_record_miner: "마이너 {{value}}를 삭제하시겠습니까?",
    delete_miner_text: "삭제 후에는 해당 노드가 그룹에 표시되지 않습니다",
    //添加节点
    custom_tag: "Tag",
    miner_add_placeholder: "노드 계정 ID를 입력하세요",
    miner_select_group_placeholder: "그룹 선택 (그룹을 선택하지 않으면 추가한 노드는 '기본 그룹'으로 모두 들어갑니다)",
    //分组
    create_group: "그룹 생성",
    create_group_holder: "생성하려는 그룹의 이름을 입력하세요",
    item_value: "해당 그룹에는 {{value}} 명의 miner가 있습니다",
    group_name: "그룹 이름",
    //幸运值
    all: "전체",
    "24h_lucky": "24H 행운값 ",
    "7d_lucky": "7D 행운값",
    "30d_lucky": "30D 행운값",
    "1year_lucky": "1년",
    tag: "Tag",
    miner_id: "Miner ID",
    //地址余额
    miner_balance: "Miner 잔액/일일 변동",
    owner_balance: "Owner 잔액/일일 변동",
    worker_balance: "Worker 잔액/일일 변동",
    controller_0_balance: "Controller0 잔액/일일 변동",
    controller_1_balance: "Controller1 잔액/일일 변동",
    controller_2_balance: "Controller2 잔액/일일 변동",
    beneficiary_balance: "Beneficiary 잔액/일일 변동",
    market_balance: "Market 잔액/일일 변동",
    //奖励
    block_count: "블록 수",
    win_count: "윈 카운트",
    block_reward: "블록 보상",
    total_reward: "전체 블록 보상",
    total_reward_24: "총 보상/24시간 보상",
    //算力概览
    quality_power: "유효 체굴 파워",
    dc_power: "DC 파워",
    raw_power: "로우바이트 체굴 파워",
    cc_power: "CC 파워",
    sector_size: "섹터 크기",
    sector_power_change: "팬섹터 변화",
    sector_power_count: "Sector Count",
    sector_count_change: "팬섹터 수량 변화",
    pledge_changed: "플레지 변경",
    pledge_changed_per_t: "플레지 변경/T",
    penalty: "벌칙",
    fault_sectors: "오류",
    sector_power_change_tip: "섹터 수/로우바이트 체굴 파워  추가 및 종료의 합계",
    pledge_changed_tip: " 섹터 수 추가 및 종료에 대한 예치금 변동의 합계",
    pledge_changed_per_t_tip: "예치금 변동을 섹터 변동으로 나눈 값.",
    penalty_tip: "처벌받은 FIL 수량",
    fault_sectors_tip: "신규 추가된 오류 섹터의 수",
    total_gas_cost_tip: "모든 유형에 대한 가스 소비의 총합",
    seal_gas_cost_tip: "섹터 봉인을 위한 가스 비용의 총합(PreCommitSector+ProveCommitSector+PreCommitSectorBatch+ProveCommitAggregate+PreCommit Net Fee+ProveCommit Net Fee)",
    seal_gas_per_t_tip: "신규 봉인된 섹터당 가스 소비량 (TiB)",
    deal_gas_cost_tip: "DC PublishStorageDeals 의 소비량",
    wd_post_gas_cost_tip: "SubmitWindowedPoSt의 소비량",
    wd_post_gas_per_t_tip: "SubmitWindowedPoSt 비용을 RawBytePower(TiB)로 나눈 값",
    //gas
    total_gas_cost: "가스 총 소비량",
    seal_gas_cost: "Seal Gas",
    seal_gas_per_t: "Seal Gas/T",
    deal_gas_cost: "PublishStorageDeals Gas",
    wd_post_gas_cost: "WindowedPoSt Gas",
    wd_post_gas_per_t: "WindowedPoSt Gas/T",
    //到期扇区 만기 섹터
    exp_month: "{{year}}年{{month}}月到期",
    exp_time: "만료 시간",
    miner_count: "노드 수",
    exp_power: "만료 파워",
    sector_count: "만기 섹터",
    exp_dc: "만료 DC",
    exp_pledge: "만료 플레지",
    //个人中心
    default_user: "일반 사용자",
    last_login: "최근 로그인 시간",
    personal_setting: "계정 설정",
    personal_name: "계정 이름",
    old_placeholder: "기존 비밀번호를 입력하세요",
    old_password: "기존 비밀번호",
    new_password: "새 비밀번호",
    new_placeholder: "새로운 비밀번호를 입력해주세요",
    confirm_password: "비밀번호를 확인해주세요",
    confirm_placeholder: "새 비밀번호를 다시 입력해주세요",
    personal_name_holder: "계정을 입력해주세요",
    //余额监控
    miner: "Miner 잔액",
    owner: "Owner 잔액",
    worker: "Worker 잔액",
    controller_0: "Controller0 잔액",
    controller_1: "Controller1 잔액",
    controller_2: "Controller2 잔액",
    beneficiary: "Beneficiary 잔액",
    //监控
    add_rules: "규칙 추가",
    examination: "규칙",
    alarm: "알람 모드",
    status: "상태",
    rules_more: "단일 대화 상자에는 최대 10개의 규칙 세트를 추가할 수 있습니다. 더 추가해야하는 경우 변경 내용을 저장한 후 계속하십시오",
    warn_more: "최대 3개까지 추가할 수 있습니다",
    monitor_mobile_edit_tip: "모니터링 추가, 삭제 및 수정과 같은 작업은 PC 버전에서 진행해 주세요",
    //告警方式
    warn_title: "알람 모드",
    warn_title_des: " 실제 상황에 따라 하나 또는 여러 가지의 경보 방법을 선택할 수 있습니다",
    email_warn: "이메일 알림",
    email_warn_placeholder: "올바른 이메일 주소를 입력해주세요",
    email_warn_warning: "알림 이메일 주소를 입력해주세요",
    email_warn_des: "현재 계정에 등록된 이메일 주소는 자동으로 전송되므로 다시 제출할 필요가 없습니다",
    message_warn: "문자 메시지 알림",
    message_warn_placeholder: "통지를 받을 전화번호를 입력해주세요",
    message_warn_warning: "올바른 수신 번호를 입력해주세요",
    phone_warn: " 전화 알림",
    phone_warn_placeholder: "통지를 받을 전화번호를 입력해주세요",
    phone_warn_warning: "통지를 받을 전화번호를 입력해주세요",
    //监控
    ExpireSectorMonitor: "섹터 만료일",
    edit_status: "규칙 닫기",
    edit_status_content: "이 모니터링을 비활성화하시겠습니까? 비활성화되면 관련된 경고를 즉시 받을 수 없게 됩니다.",
    delete_rule: "규칙 삭제",
    delete_rule_content: "이 모니터링을 삭제하시겠습니까?",
    //扇区监控
    reset_button: "초기화",
    edit_rules: "규칙 수정",
    rule_detail: "규칙 세부정보",
    edit_write_warn: "알람 모드",
    sector_rule_title: "섹터 만료일",
    sector_rule_des: " 사용자 정의 가능; 30보다 큰 값이 권장됩니다",
    sector_ruler_placeholder: "양의 정수를 입력해주세요",
    sector_ruler_warningText: "양의 정수를 입력해주세요",
    "<=": "이하",
    ">=": "이상",
    //余额监控
    balance_category_placeholder: " 잔액 카테고리",
    balance_rule_des: "현재의 {{value}} FIL",
    //算力监控
    power_rules_1: "1. 섹터에 오류가 발생했습니다",
    power_rules_2: "2. 섹터가 자발적으로 종료되었습니다",
    power_rules_3: "3. 섹터가 정상적으로 만료되었습니다",
    //会员
    member_miner_warn: "현재 노드 개수가 한도에 도달했습니다. 멤버십을 업그레이드하여 더 많은 혜택을 누려보세요.",
    member_warn: "회원님의 멤버십 혜택이 곧 만료될 예정입니다. 정상적인 이용을 위해 적시에 갱신해 주세요.",
    member_header: "다음과 같은 문제에 대해 걱정되거나 경험한 적이 있다면:",
    power_title: "컴퓨팅 파워 하락",
    power_text: "대량의 섹터 오류로 인해 컴퓨팅 파워가 급격히 감소하며, 채굴 보상 손실이 심각해질 수 있습니다. 그러나 이를 적시에 알 수 없습니다.",
    balance_title: "계정 잔액 부족",
    balance_text: "계정 잔액이 부족하지만 적시에 정보를 얻을 수 없어 섹터 봉인 또는 유지에 실패할 수 있습니다.",
    sector_title: "섹터 만료",
    sector_text: "섹터가 만료되면 컴퓨팅 파워도 함께 감소합니다. 더 일찍 갱신해야 한다는 것을 깨닫게 되었습니다. 알림이 있었다면 좋았을텐데요.",
    warn_power: "컴퓨팅 파워 모니터링",
    warn_balance: "잔액 모니터링",
    warn_sector: "섹터 모니터링",
    warn_email: "이메일 알림",
    warn_msg: "문자 메시지 알림",
    warn_phone: "전화 알림",
    data_text: "중요 정보 통합 모니터링",
    warn_text: "다양한 경고 채널과 유연한 구성",
    member_warn_title: "모니터링 추가, 경고로 빠르게 대응하기",
    member_content_title: "멤버십 가입, 즉시 시작하기",
    companies: "기업",
    companiesPro: "기업 Pro",
    companies_1: "30개 노드 한도",
    companies_1_pro: "무제한 노드",
    companies_2: "컴퓨팅 파워 모니터링",
    companies_3: "잔액 모니터링",
    companies_4: "섹터 모니터링",
    companies_5: "기타 (곧 제공 예정)",
    companies_6: "기술 지원",
    monthly: "월간 멤버십",
    quarter: "분기별 멤버십",
    year: "연간 멤버십",
    quarter_discount: "12% 미만 할인",
    year_discount: "20% 미만 할인",
    share_friend: "친구를 초대하여 한 달간의 기업 멤버십을 선물하세요",
    share_turn: "지금 시작하고 손실을 최소화하세요",
    tg_title: "비즈니스 TG 추가로 활성화",
    //活动
    success_member: "가입 성공",
    error_member: "언바운드 노드",
    success_miners: "바인딩된 노드",
    success_active: "효율적인",
    error_active: "유효하지 않은",
    invitees: "초대 받은 사람",
    is_valid: "유효 여부",
    send_member: "Free Vip",
    invite_code: "초대 코드",
    active_share: "지금 초대하기",
    active_member_warn: "문자 및 전화 알림",
    active: "초대 이벤트",
    active_rule: "이벤트 규칙",
    active_detail: "자세한 내용",
    active_rule_detail: "세부",
    rule_content: "노드 관리자 2명 이상을 초대하여 등록하고 초대된 계정이 유효한 노드 정보와 바인딩되면, 169U에 해당하는 1개월의 엔터프라이즈 에디션 회원 자격을 받게 됩니다. 초대 받은 사람들은 7일간 엔터프라이즈 에디션 혜택을 체험할 수도 있습니다.",
    active_member: "엔터프라이즈 에디션 회원 자격 혜택:",
    active_member_1: "완전한 모니터링 기능",
    active_expired: "회원 자격이 만료되면 혜택은 자동으로 회수됩니다. 회원 자격을 재신청하여 관련 서비스를 계속해서 이용할 수 있습니다.",
    active_1: "邀请好友",
    active_1_des: "친구에게 초대 포스터나 초대 코드를 보내고, 코드를 스캔하거나 공식 웹사이트에서 초대 코드로 등록하세요.",
    active_2: "注册添加",
    active_2_des: "친구가 성공적으로 등록하고 유효한 노드를 추가했습니다.",
    active_3: "邀请2个有效好友",
    active_3_des: "성공적으로 유효한 친구 2명을 초대하고 보상을 받았습니다.",
    active_target_1: "종합적인 노드 정보",
    active_target_2: "이상 경고로 한 발 앞서기",
    scan_code: "코드를 스캔하여 즉시 체험해 보세요",
    active_des: "Filscan은 이 활동에 대한 해석 권한을 보유합니다",
    active_gift: "신규 사용자에게 7일간의 엔터프라이즈 버전 체험 기회가 제공됩니다",
    active_save: "로컬에 저장",
    copy_tg: "复制ID",
    recommend: "推荐",
    //personal
    personal_1: "멤버십 업그레이드/갱신",
    personal_2: "绑定邮箱",
    personal_3: "비밀번호 변경",
    member_expired_time: "{{value}}에 만료됨",
    mail_success: "경계",
    look_more: "혜택 보기",
    look_detail: "세부 내용 확인",
    look_detail_member: "무료로",
    //第一次弹窗
    free_send: "기업 회원 자유로운 선물"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (account);


/***/ }),

/***/ 35587:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const analysis = {
    "30d": "30 일",
    "1year": "1 년",
    k_chart: "캔들 차트",
    trend_chart: "트렌드 차트",
    market_value: "시가총액",
    market_value_tip: "유통 공급 * 현재 가격 (FIL)",
    circulation: "유통 공급",
    proportion: "유통 비율",
    supply: "총 공급량",
    market_total: "총 시가총액",
    market_total_tip: "총 공급량 * 현재 가격 (FIL)",
    locked: "잠긴 공급",
    locked_ratio: "잠긴 비율",
    burn: "소각량",
    burn_ratio: "소각 비율",
    "24_quantity": "24시간 거래량",
    "24_amount": "24시간 거래 금액",
    turnover_rate: "유동성 회전율",
    turnover_rate_tip: '또한 "거래 회전율"로 알려진 이 지표는 특정 기간 동안 시장에서 매수 및 매도의 빈도를 나타냅니다. 24시간 회전율 공식은 다음과 같습니다 : 24시간 거래 금액 / 시가총액 * 100%',
    quantity_ratio: "거래량 비율",
    quantity_ratio_tip: "지난 1일간 분당 평균 거래량 / 지난 7일간 분당 평균 거래량",
    price_origin: "Data comes from CoinMarketCap",
    //chart
    fil_origin: "바이낸스",
    period_1: "1분",
    period_5: "5분",
    period_30: "30분",
    period_60: "1시간",
    period_240: "4시간",
    period_1440: "일간",
    period_10080: "주간",
    period_43200: "월간",
    //trend chart
    fil_title: "FIL 가격 변동",
    change_day: "24시간",
    change_week: "7일",
    change_month: "30일",
    change_threemonth: "3개월",
    change_sixmonth: "6개월",
    change_year: "1년",
    change_thisyear: "올해",
    change_ico: "모두",
    usd_price: "USD 가격",
    btc_price: "BTC 가격",
    market_price: "시가총액",
    volume: "거래량",
    market_tip: "TThe data is for reference only, not investment advice.",
    //유동성 관찰
    liquidity_watch_fil: "FIL 시장 보기",
    liquidity_total: "총 유통 공급",
    liquidity_total_24: "총 유통 공급 / 24시간",
    liquidity_watch: "유동성 관찰",
    liquidity_watch_tip: "총 유통 공급의 소스 변경 및 트렌드를 표시합니다",
    liquidity_destruction: "소각량",
    liquidity_destruction_24: "소각량 / 24시간",
    liquidity_freed: "해제됨",
    liquidity_freed_24: "해제량 / 24시간",
    liquidity_pledge: "스테이킹됨",
    liquidity_pledge_24: "스테이킹량 / 24시간",
    provider_rewards: "스토리지 제공자 보상",
    provider_rewards_24: "스토리지 제공자 보상 / 24시간",
    lockup_freed: "제네시스 잠긴 해제됨",
    lockup_freed_24: "제네시스 잠긴 해제량 / 24시간",
    lockup_freed_tip: "Filecoin 재단과 프로토콜 랩스 간에 Filecoin의 제네시스 기간 동안 합의된 일일 릴리스 총액",
    reserved_freed: "예약 공급 해제됨",
    reserved_freed_24: "예약 공급 해제량 / 24시간",
    sector_pledge: "섹터 스테이킹",
    sector_pledge_24: "섹터 스테이킹량 / 24시간",
    defi_staking: "DeFi 스테이킹",
    defi_staking_24: "DeFi 스테이킹량 / 24시간",
    //제네시스 계정 릴리스 캘린더
    release_Calendar: "제네시스 계정 릴리스 캘린더",
    account: "계정",
    total_lockup: "총 잠긴",
    released: "릴리스됨",
    daily_release: "일일 릴리스",
    release_cycle: "릴리스 주기",
    account_balance: "계정 잔액",
    balance_change_7: "잔액 변경 (7일)",
    fund_penetration: "자금 침투",
    release_cycle_detail: "{{value}}% released, expected to be fully released on {{date}}",
    go_fund: "Check",
    //토큰
    token_list_address: "부의 순위 보기",
    token_list: "토큰 보유 주소",
    token_list_tip: "온체인 토큰 잔액이 0이 아닌 주소 수, 30일 및 1년 데이터를 표시한 차트",
    token_address_total: "보유 주소 수",
    token_top_10: "상위 10 보유 비율",
    token_top_20: "상위 20 보유 비율",
    token_top_50: "상위 50 보유 비율",
    token_top_100: "상위 100 보유 비율",
    //상위 10 활성 주소
    top_active_address: "상위 10 활성 주소",
    top_active_address_tip: "지난 7일간 최대 변동이 있는 상위 10 보유 주소",
    quantity: "보유 수량",
    percentage: "보유 비율",
    change_7d: "7일 변동",
    //자금 침투
    fund_placeholder: "분석할 주소를 입력하세요",
    fund_analysis: "자금 침투 분석",
    check_account: "확인",
    network_rank: "글로벌 랭킹",
    position_ratio: "보유 비율",
    balance_change: "잔액 변경",
    related_way: "방법",
    fund_volume: "거래량",
    fund_number: "거래 횟수",
    rank: "순위",
    rank_3: "상위 3",
    rank_5: "상위 5",
    rank_10: "상위 10",
    level: "레벨",
    level_3: "레벨 3",
    level_5: "레벨 5",
    level_all: "모든 레벨",
    select_account: "선택한 계정",
    total_volume: "총 거래량",
    total_number: "총 거래 횟수"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (analysis);


/***/ }),

/***/ 85387:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const common = {
    zh: "中",
    en: "En",
    kr: "Kr",
    login: "로그인",
    cancel: "취소",
    confirm: "확인",
    open: "펼치기",
    no_open: "접기",
    lang: "한국어",
    fil: "FIL",
    last_time: "최신 블록 시간",
    base_fee: "기본 수수료",
    last_height: "최신 블록 높이",
    go_home: "홈으로",
    go_login: "로그인하러 가기",
    mobile_code_1: "QR 코드 스캔",
    mobile_code_2: "모바일 브라우저를 경험해보세요",
    //search
    search_holder: "주소/메시지 ID/높이/블록 CID/노드 ID/FNS를 입력하세요",
    all: "모든 필터 유형",
    address: "주소",
    message_id: "메시지 CID",
    height: "블록 높이",
    cid: "블록 CID",
    node: "노드",
    save_pic: "사진을 저장하다",
    fvm_share: "친구들과 공유",
    account_banner_bg: "노드 관리자에 오신 것을 환영합니다",
    account_banner_main: "노드 관리 도우미",
    time_display: "초 전",
    //messages
    no_account: "해당 이메일은 등록되어 있지 않습니다. 먼저 회원 가입을 진행해 주세요.",
    //登录注册
    register: "이메일 등록",
    password_login: "비밀번호 로그인",
    verification_code: "인증 코드 로그인 ",
    email_placeholder: "이메일 주소를 입력하세요",
    password_placeholder: "비밀번호를 입력하세요",
    invite_placeholder: "초대코드 입력(선택)",
    code_placeholder: "인증 코드를 입력하세요",
    remember_me: "기억하기 및 자동 로그인",
    forgot_password: "비밀번호를 잊으셨나요",
    get_code: "인증 코드 받기",
    retry_code: "다시 보내기",
    no_account: "아직 계정이 없으신가요?",
    have_account: "이미 계정이 있으신가요?",
    go_register: "지금 회원 가입하기",
    new_password: "비밀번호 설정하기",
    confirm_password: "비밀번호 확인",
    agreement: '회원가입은 "약관"과 "개인정보 처리방침"에 동의하는 것을 의미합니다',
    active_top_1: "채굴자 정보를 한 눈에",
    active_top_2: "",
    active_bottom_1: "이상 현상에 대한 조기 경고",
    active_bottom_2: "",
    //校验
    email_required: "이메일을 입력해주세요",
    email_rules: "이메일 형식이 잘못되었습니다. 수정해주세요",
    code_rules: "6자리 숫자 인증 코드를 올바르게 입력해주세요",
    password_rules: "비밀번호를 설정해주세요. 8-20자의 길이여야 하며, 숫자, 문자, 특수 문자를 모두 포함해야 합니다.",
    confirm_password_rules: "입력한 비밀번호가 일치하지 않습니다. 다시 입력해주세요",
    email_exists: "이미 해당 이메일이 존재합니다",
    Export: "엑셀 다운로드",
    //footer
    footer_des1: "Filscan 브라우저는 Filecoin 블록체인 브라우저 및 데이터 서비스 플랫폼입니다.",
    footer_des2: "Filecoin 기반의 수익 랭킹, 블록체인 데이터 조회, 시각화 차트 등의 데이터 서비스를 제공합니다",
    active: "활동",
    active_time: "Period",
    add_project: "프로젝트 신청"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (common);


/***/ }),

/***/ 64276:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const contract = {
    all: "All",
    overview: "개요",
    market: "마켓",
    look_adres: "주소 확인",
    gohome: "홈으로",
    reset_ver: "재검증",
    "all_token": "All Tokens",
    ">0": "0보다 큰 수량",
    "=0": "수량은 0입니다",
    next: "다음",
    reset: "리셋",
    confirm: "검증 및 발표",
    back: "뒤로 가기",
    file_name: "*.sol 파일 선택",
    config_file_name: "Metadata 파일 선택",
    file_name_json: "*.json 파일 선택",
    config_file_des1: "> 언제 메타데이터 파일을 업로드 할겁니까?",
    config_file_des1_1: "1. 메타데이터 파일에는 다양한 컴파일러 설정이 포함되어 있습니다. 고급 최적화 매개변수를 사용했거나 컴파일 구성 파일(예: Remix의 compiler_config.json)로 코드를 컴파일한 경우 확인을 위해 메타데이터 파일을 업로드해야 합니다.",
    config_file_des1_2: '2. 계약 안에 있는 import 계층 디렉터리는 초기화 형식(예: import "@openzeppelin/contracts/access/Ownable.sol")이며 메타데이터 파일중 sources 아래의 경로와 동일합니다(계약에 있는 import 계층 디렉터리는 현재 폴더이면 메타데이터 파일을 업로드할 필요가 없음)',
    config_file_des2: "> 메타데이터 파일은 어떻게 얻나요?",
    config_file_des2_1: "1. Solidity 컴파일러(solc)를 사용하여 획득: solc --metadata MainContract.sol -o metadata.json",
    config_file_des2_2: "2. Remix IDE를 사용하여 다운로드: Remix 웹 페이지가 게시된 후 metadata.json에 대한 다운로드 버튼이 있을겁니다.",
    verify_title: "컨트랙트 소스 코드 검증 및 발표",
    verify_des: "컴파일러 유형 및 버전 선택",
    verify_content: `소스 코드 검증은 스마트 컨트랙트와 상호작용하는 사용자에게 투명성을 제공합니다. 소스 코드를 업로드를 통하여 Filscan이 컴파일된 코드를 블록체인 상의 코드와 매칭시킵니다. 계약서 처럼 "스마트 컨트랙트"는 최종 사용자에게 "디지털 서명"의 목적에 대한 더 많은 정보를 제공하고 사용자가 코드를 검토하여 그것이 정말로 해야 할 일을 수행했는지 독립적으로 감증할 수 있도록 합니다.`,
    content_des: `소스 코드 검증은 스마트 컨트랙트와 상호작용하는 사용자에게 투명성을 제공합니다. 소스 코드를 업로드를 통하여 Filscan이 컴파일된 코드를 블록체인 상의 코드와 매칭시킵니다. 계약서 처럼 "스마트 컨트랙트"는 최종 사용자에게 "디지털 서명"의 목적에 대한 더 많은 정보를 제공하고 사용자가 코드를 검토하여 그것이 정말로 해야 할 일을 수행했는지 독립적으로 감증할 수 있도록 합니다."artifacts/build-info/" 디렉터리에 JSON 파일을 업로드하면 계약 검증을 빠르게 수행할 수 있습니다.
Hardhat은 컴파일 출력을 프로젝트 내의 "artifacts/build-info/" 디렉토리에 저장합니다. 디렉터리에는 특히 고급 및 자동화 구성에서 Solidity 컴파일러와 상호 작용하는 데 권장되는 접근 방식인 모든 계약에 대한 표준 JSON 입력-출력이 포함된 .json 파일이 포함되어 있습니다. 이 JSON 입출력 인터페이스는 모든 컴파일러 배포에서 균일하게 지원됩니다.`,
    address: "검증할 컨트랙트 주소를 입력하세요",
    address_placeholder: "컨트랙트 주소를 입력하세요",
    verify_address: "검증할 컴파일러 버전을 선택하세요",
    verify_address_placeholder: "선택하세요",
    verify_model: "편집 유형을 선택하십시오",
    verify_model_placeholder: "편집 유형을 선택하십시오",
    license_type: "오픈 소스 라이선스 유형을 입력하세요",
    content_des1: "1. 만약 컨트랙트가 REMIX에서 올바르게 컴파일 된 경우, 여기에도 올바르게 컴파일될 겁니다.",
    content_des2: "2. 다른 컨트랙트에서 생성된 컨트랙트를 검증하는 서포트는 제한되어있습니다. 각 컨트랙트의 컴파일 제한 시간은 최대 45초입니다.",
    content_des3: "3. 프로그래밍 컨트랙트 검증은 컨트랙트 API 엔드포인트를 확인하세요.",
    checkbox_service: "서비스 약관에 동의합니다",
    verify_select_placeholder: "선택하세요",
    //logs
    ver_sucess: "성공: 검증 완료",
    ver_err: "오류: 검증 실패",
    has_been_verified: "오류: 계약이 이미 검증되었습니다",
    byte_code: "컴파일 로그",
    contract_name: "계약 이름",
    local_byte_code: "컨트랙트 바이트 코드",
    compiler: "컴파일러 버전",
    //step1
    address_verify: "계약 주소",
    step1_verify_des: "*.sol 파일을 선택하세요",
    source_code: "컨트랙트 소스 코드",
    compile_version: "컴파일러",
    compile_output: "컴파일러 출력",
    Optimizations: "최적화 매개변수",
    run_optimizer: "실행（옵티마이저）",
    arguments: "Constructor 매개변수",
    optimize: "최적화 활성화",
    optimize_runs: "RUNS",
    // 已验证合约
    Verify_code: "Code",
    Verify_read: "Read Contract",
    Verify_write: "Write Contract",
    contract_verify: "계약 검증",
    contract_verify_tips: "계약 확인은 PC에서 확인하십시오.",
    //token list
    token_list: "전체 토큰",
    token_name: "토큰",
    vol_24: "24시간 거래량",
    transfer_total: "총 {{value}} 건 메시지",
    owner_total: "총 {{value}}명 보유",
    dex_total: "총 {{value}} 건 거래",
    //nft list
    nfts_list: "전체 NFTs",
    trading_volume: "전체 거래량",
    // ft /fns dashborad
    "total_supply": "유통 공급량",
    "total_supply_tip": "이 데이터는 계약 ERC20에 대한 표준 메서드 반환 값입니다",
    "owners": "보유자",
    "transfers": "총 전송 수",
    latest_price: "최신 가격",
    market_value: "시가",
    token_contract: "토큰 계약",
    transfer: "전송",
    owner: "소유자",
    owner_nft: "오너",
    domain: "계약",
    dex: "DEX 거래",
    //list
    message_cid: "메시지ID",
    method: "메소드",
    time: "시간",
    from: "보내는 주소",
    to: "받는 주소",
    amount: "수량",
    //拥有者
    //소유자
    rank: "순위",
    percentage: "비율",
    //DEX
    platform: "거래소",
    Txn_Value: "Txn 값",
    "swapped_Rate": "교환 비율",
    "Token_Amount_in": "Token 수량(들어옴)",
    "Token_Amount_out": "Token 수량(나감)",
    Action: "액션",
    //계약 목록
    contract_list: "검증된 계약",
    contract_address: "주소",
    language: "언어",
    license: "라이선스",
    //合约详情
    contract_list_total: "총 {{value}}개의 계약",
    byte_code_no_verify: "계약이 검증되지 않았습니다. 이동하러 가기",
    go_to_verify: "계약 검증",
    verify_contract: "계약 소스 코드가 검증되었습니다",
    source_code: "계약 소스 코드",
    source_code_create: "계약 생성 코드",
    source_abi: "계약 ABI",
    source_abi_default: "ABI 도출하기",
    nfts_list: "NFT 목록",
    item: "아이템",
    Items: "수량",
    pleaseCheckContractWithPC: "PC측에서 계약내역을 확인해주세요~",
    //rcontract_rank_des:'上次更新时间为:{{value}}',
    contract_rank_des: "마지막 업데이트 시간: {{value}}",
    contract_rank_total: "총 {{value}}개의 계약 ",
    contract_rank: "계약 랭킹",
    rank: "랭킹",
    actor_id: "actorID",
    ver_address: "검증 대기중",
    actor_address: "actorAddress",
    transaction_count: "거래 수",
    user_count: "거래 주소",
    actor_balance: "잔액",
    gas_cost: "Gas 소비량",
    see_more: "더보기",
    //log
    epoch: "높이",
    cid: "메시지 ID",
    event_name: "메소드",
    topics: "토픽",
    coompoent_data: "매개변수",
    log_index: "인덱스",
    removed: "제거됨"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contract);


/***/ }),

/***/ 53341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// pool-detail
const detail = {
    "24h": "24시간",
    "7d": "7일",
    "30d": "30일",
    "1year": "1년",
    look_all: "전체 데이터 보기",
    all_token: "All Tokens",
    //owner
    owner_title: "스토리지 풀 정보",
    owner_title_tip: "스토리지 풀 정보: 노드 데이터를 모아 총합한 데이터 정보",
    all: "모든 메소드",
    account: "계정",
    account_title: "계정",
    owner_address: "Owner 주소",
    owned_miners: "소유한 노드",
    owned_active_miners: "액티브한 노드",
    miner: "Miner",
    evm: "EVM",
    ethaddress: "ETH 주소",
    ethaccount: "ETH 계정",
    transfer_records: "이체 기록",
    //account_type
    account_name: "계정",
    latest_transfer_time: "최신 거래 시간",
    multisig: "멀티 사인 계정",
    account_detail: "스토리지 풀 정보",
    from_ath: "발송자",
    to_ath: "수신자",
    account_id: "계정 주소",
    //Overview
    owner_overview_title: "스토리지 풀 개요",
    balance: "계정 잔액",
    available_balance: "사용 가능한 잔액",
    init_pledge: "섹터 저당",
    pre_deposits: "선입금",
    locked_balance: "잠긴 보상",
    balance_tip: "계정 잔액=사용 가능한 잔액+섹터 저당+선입금+잠긴 보상",
    available_balance_tip: "초기 예치금 및 잠긴 보상을 제외한 계정 내 사용 가능한 지출 가능 금액",
    init_pledge_tip: "복제 검증의 두 번째 단계를 성공적으로 완료한 후 실제로 예치된 금액",
    pre_deposits_tip: "예치금액은 두 번째 단계에서 지정된 시간 내에 성공적으로 증명을 제출한 후 각 섹터별로 실제로 예치된 금액에 따라 조정됩니다. 그렇지 않을 경우, 주어진 시간 내에 증명을 제출하지 않을 경우 벌금이 부과됩니다",
    locked_balance_tip: "출출 보상의 미발행 부분은 시간에 따라 선형적으로 해제됩니다",
    sector_count: "전체",
    live_sector_count: "유효",
    fault_sector_count: "오류",
    recover_sector_count: "복구",
    eth_address: "ETH 주소",
    stable_address: "안정 주소",
    tokenList: "보유한 토큰",
    showContract: "계약: {{value}}",
    showAddress: "주소: {{value}}",
    //统计指标
    indicators: "통계 지표",
    power_increase_indicators: "채굴파워 증가량",
    power_ratio: "전력 성장률",
    sector_increase: "섹터 증가량",
    precommit_deposits: "섹터 담보",
    gas_fee: "Gas 소비",
    block_rewards: "블록 보상",
    block_count: "블록 수량",
    block_count_tip: "블록 수 = 블록 (block) 수량 총합",
    mining_efficiency: "효율성",
    mining_efficiency_tip: "선택한 주기 동안, 노드가 채굴한 총 블록 보상과 유효한 채굴 능력 비율",
    lucky: "행운값",
    lucky_tip: "행운 값: 실제 블록 보상 수와 예상 블록 보상 수의 비율입니다. QualityAdjPower가 1 PiB 미만인 경우, 이 값은 상당한 무작위성을 가지며 참고 용도로만 사용되어야 합니다",
    sector_ratio: "섹터 증가 속도",
    sector_ratio_tip: "",
    windowPost_gas: "컴퓨팅 전력 소비 유지",
    win_count: "우승자 보상",
    win_count_tip: "Filecoin 경제 모델에서 한 높이 (tipset)하에는 여러 블록 (block)이 있을 수 있으며, 각 블록 (block)은 여러 보상 (win count)을 받을 수 있습니다. 누적 블록 수 =모든 보상 수의 총합",
    net_profit_per_tb: "Gas 소비/T",
    net_profit_per_tb_tip: "선택된 기간 내에 크기가 T인 단일 섹터를 봉인하는 데 필요한 가스 소비",
    //账户变化
    account_change: "계정 변동",
    power: "파워",
    power_increase: "유효 체굴 파워 성장",
    quality_adjust_power: "유효 체굴 파워",
    quality_power_rank: "순위",
    raw_power_percentage: "체굴 파워 비율",
    raw_power: "로우바이트 체굴 파워",
    total_block_count: "30일 블록 수",
    total_block_count_tip: "최근 30일간 해당 노드에서 채굴한 블록 수의 총합",
    total_reward: "30일 보상",
    total_reward_tip: "최근 30일간 해당 노드에서 채굴한 블록의 총 보상",
    total_balance_tip: "계정 잔액=사용 가능한 잔액+섹터 저당+선입금+잠긴 보상",
    total_win_count: "30일 우승 횟수",
    total_win_count_tip: "최근 30일간 해당 노드에서 채굴한 블록의 총 우승 횟수",
    sector_size: "섹터 크기",
    sector_status: "섹터 상태",
    //账户总览
    account_overview: "계정 개요",
    create_time: "계정 생성 시간",
    account_type: "계정 유형",
    peer_id: "노드 표기",
    account_address: "주소",
    owner_address: "소유자",
    area: "지역",
    worker_address: "워커",
    controllers_address: "컨트롤러",
    beneficiary_address: "수혜자",
    code_cid: "코드 CID",
    nonce: "Nonce 값",
    contract_verify: "계약 검증",
    contract_name: "계약 명칭",
    peer_detail: "노드 세부정보",
    miner_owner: "노드 세이버",
    no_area: "Unknown",
    //miner
    //pool_overview_title:'账户',
    // message
    message_overview_detail: "거래 세부 내용",
    trade: "내부 거래",
    message_detail: "개요",
    event_log: "이벤트 로그",
    message_overview: "메시지 개요",
    eth_message: "ETH Hash",
    cid: "메시지 ID",
    height: "블록 높이",
    time: "시간",
    blk_cids: "블록",
    value: "금액",
    from: "발신 주소",
    to: "수신 주소",
    status: "상태",
    method_name: "메소드",
    message_other: "기타 정보",
    version: "버전 번호",
    // eslint-disable-next-line no-dupe-keys
    nonce: "Nonce",
    gas_fee_cap: "수수료 요금 최고 한도",
    gas_premium: "노드 팁 비율 수수료",
    gas_limit: "Gas 한도",
    gas_used: "Gas 실제 사용량",
    base_fee: "기본 수수료 요금",
    all_gas_fee: "수수료",
    params: "매개 변수",
    returns: "반환 값",
    message_tranf: "송금 정보",
    from_tranf: "보내는 사람",
    to_tranf: "받는 사람",
    consume_type: "유형",
    MinerTip: "Miner 수수료",
    BaseFeeBurn: "기초 수수료 폐기",
    Transfer: "송금",
    Burn: "취합 비용 폐기",
    exit_code: "상태",
    err_message: "에러 메시지",
    replaced: "CID를 덮어썼습니다",
    replaced_detail: "CID {{value}} 을(를) {{newValue}} 로 덮어썼습니다.",
    base_cid: "재정의된 CID",
    //内部交易
    amount: "액수",
    method: "메소드",
    topic: "토픽",
    //通证转移
    message_ERC20Trans: "토큰 전송",
    message_NftTrans: "NFT 전송",
    // 出块列表
    block_cid: "블록 CID",
    block_height: "블록 높이",
    block_time: "블록 생성 시간",
    block_messages_count: "메시지 수",
    block_miner_id: "노드 주소",
    block_mined_reward: "블록 보상",
    //miner
    message_list: "메시지 리스트",
    block_list: "블록 리스트",
    traces_list: "대체 리스트",
    message_list_total: "총 {{value}}개 메시지",
    block_list_total: "총 {{value}}개 블록",
    traces_list_total: "총 {{value}}개 메시지",
    contract_token_list_total: "총 {{value}}개 토큰",
    //general
    general_overview_title: "계정 개요",
    base_account_id: "계정 ID",
    //dns detail
    //dns detail
    deal_details: "거래 상세 정보",
    deal_id: "거래 ID",
    epoch: "블록",
    service_start_time: "생성 시간",
    message_cid: "소속 메시지",
    piece_cid: "Piece CID",
    verified_deal: "검증됨",
    deal_hosting: "호스팅 정보",
    deal_left_title: "클라이언트",
    deal_right_title: "호스팅 노드",
    deal_value: "담보 금액",
    deal_cash: "호스팅 비용",
    deal_time: " ~ ",
    user_count: "거래 주소",
    transfer_count: "거래 횟수",
    go_verify: "검증하러 가기",
    contract_token_list: "토큰",
    token_name: "토큰 이름",
    contract_id: "계약 ID",
    amount: "금액",
    platform: "거래 플랫폼",
    erc20_transfer: "토큰 거래",
    erc20_transfer_total: "총 {{value}}개 송금",
    power_change: "전원 변경",
    //height
    blcok_time: "블록 시간",
    message_count_deduplicate: "블록 메시지(중복 제거)",
    miner_id: "Miner",
    messages_count: "메시지",
    reward: "보상",
    //cid detail
    block_list: "Block List",
    blocks_cid: "Cid",
    blocks_miner: "Miner",
    blocks_messages: " 메시지",
    blocks_reward: "보상",
    win_count: "윈 카운트",
    //cid_details
    message_list_total: "Total of {{value}} Messages",
    chain_cid_detail: "블록 세부정보",
    cid_height: "높이",
    parent_weight: "Parent Block 무게",
    parents_cid: "Parent CID",
    parent_base_fee: "Parent Block 기본 수수료",
    ticket_value: "티켓 값",
    state_root: "스테이트 루트",
    message_count: "메시지 개수",
    blk_cids_message: "메시지 차단",
    //pendingMsg
    pending_title: "대기 중인 메시지",
    pending_total: "Total of {{value}} messages to be processed"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (detail);


/***/ }),

/***/ 29720:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const domain = {
    domain_title: "개요",
    resolved_address: "해석된 주소",
    expired_at: "만료일",
    registrant: "등록자",
    controller: "컨트롤러",
    allDomains: "이 주소가 소유한 도메인 총 {{value}}개",
    Result_for: "검색 결과"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (domain);


/***/ }),

/***/ 9429:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fevm = {
    tp_token: "토큰 포켓에 토큰 추가하기",
    rank: "순위",
    defi_overview: "DeFi 프로토콜",
    fevm_staked: "FEVM 스테이킹 양",
    staked_change_in_24h: "24시간 스테이킹 변경량",
    total_user: "전체 사용자 수",
    user_change_in_24h: "24시간 사용자 변경량",
    fil_staked: "FIL 스테이킹 양",
    defi_list: "DeFi Protocol",
    Protocol: "프로토콜",
    defi_list_time: "마지막 업데이트 시간: {{value}}",
    tvl: "총 잠금 가치(TVL)",
    tvl_change_rate_in_24h: "24시간 TVL 변화",
    tvl_change_in_24h: "24시간 TVL 변경량",
    tokens: "톱 토큰즈",
    tokens_tip: "계약에서 각 토큰의 담보 비율",
    users: "사용자 수",
    see_more: "더보기"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fevm);


/***/ }),

/***/ 78589:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fvm = {
    hot: "Explore FVM on FIlscan",
    all: "FVM 생태 프로젝트 개요",
    Defi: "Defi",
    Dex: "Dex",
    DID: "DID",
    NFT: "NFT",
    MarketPlace: "MarketPlace",
    Launchpad: "Launchpad",
    see_more: "더보기"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fvm);


/***/ }),

/***/ 13115:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const home = {
    seconds: "초",
    minutes: "분",
    hours: "시간",
    day: "일",
    base_gas: "24시간 기본 수수료 추세",
    //meta
    meta_title: "전체 네트워크 데이터 지표",
    mata_show: "펼치기",
    mata_show_false: "접기",
    latest_height: "최신 블록 높이",
    latest_block_time: "최신 블록 시간",
    total_blocks: "전체 블록 생성 수",
    total_rewards: "전체 블록 보상",
    total_quality_power: "전체 유효 체굴파워",
    total_quality_power_tip: "현재 전체 유효 컴퓨팅 파워(유효 저장 공간)의 총합",
    base_fee: "현재 기본 요금",
    miner_initial_pledge: "현재 섹터 저당 양",
    power_increase_24h: "최근 24시간 동안 파워 증가량",
    rewards_increase_24h: "최근 24시간 동안 생성된 블록 보상",
    fil_per_tera_24h: "최근 24시간 동안 생성 효율",
    fil_per_tera_24h_tip: "최근 24시간 동안 전체 블록 보상과 유효 체굴 파워의 비율",
    gas_in_32g: " 최근 24시간 동안 1TiB 용량의 32GiB 섹터를 봉인하기 위해 필요한 가스입니다",
    gas_in_32g_meta: "32GiB 섹터의 가스 소비량",
    gas_in_32g_tip: "최근 24시간 동안 밀봉된 32G 섹터당 소비된 가스량(TB당)",
    add_power_in_32g: "32GiB 섹터 새로 추가한 파워 비용",
    add_power_in_32g_tip: "최근 24시간 동안 32G 섹터 새로 추가한 파워를 위해 필요한 비용(섹토 저당 및 밀봉 수수료 포함)",
    gas_in_64g: "지난 24시간 동안 1TiB 용량의 64GiB 섹터를 봉인하기 위해 필요한 가스입니다",
    gas_in_64g_meta: "64GiB 섹터의 가스 소비량",
    gas_in_64g_tip: "최근 24시간 동안 밀봉된 64G 섹터당 소비된 가스량(TB당)",
    add_power_in_64g: "64GiB 섹터 새로 추가한 파워 비용",
    add_power_in_64g_tip: "최근 24시간 동안 64G 섹터 새로 추가한 파워를 위해 필요한 비용(섹토 저당 및 밀봉 수수료 포함)",
    win_count_reward: "각 티켓당 블록 보상",
    win_count_reward_tip: "최신 높이에서 각 블록의 보상 (높이마다 여러 블록이 있으며 모두 보상을 획득할 수 있음)",
    avg_block_count: "한 높이당 평균 블록 수",
    avg_block_count_tip: "최근 24시간 동안 한 높이당 평균 블록 수",
    avg_message_count: "한 높이당 평균 메시지 수",
    avg_message_count_tip: "최근 24시간 동안 한 높이당 평균 메시지 수",
    active_miners: "액티브한 노드 수",
    burnt: "소각된 토큰 수",
    circulating_percent: "유통 비율",
    rank: "순위",
    footer_text: "Filscan 브라우저는 Filecoin 블록체인 브라우저 및 데이터 서비스 플랫폼입니다. Filecoin 기반의 수익 랭킹, 블록체인 데이터 조회, 시각화 차트 등의 데이터 서비스를 제공합니다.",
    footer_outlook: "이메일",
    footer_detail_a: "판권 소유 \xa9 Filecoin 개발 보조 계획을 따르며 ",
    footer_detail_b: " 및 ",
    footer_detail_c: "저작권 계약",
    search_notFound: "검색 결과 없음",
    warn_text: "죄송합니다. 입력한 문자에 대한 결과가 없습니다",
    warn_details: "죄송합니다. 유효하지 않은 문자열입니다.",
    go_home: "홈으로 돌아가기",
    blockchain_browser: "블록 탐색기",
    "quality_power/increase_24h": "전체 유효 체굴파워",
    "total_contract": "활성 계약",
    "total_contract_24h_contract": "활성 계약 수/24시간",
    "total_contract/24h_contract": "활성 계약 수/24시간",
    verified_contracts: "검증된 스마트 계약 리스트",
    "contract_address_24h_change": "계약 거래 주소는 24시간 변경됩니다",
    "contract_transaction": "계약 거래 수",
    "contract_transaction_24h_change": "활성 계약 수 24시간 변동",
    "contract_transaction/24h_change": "계약 거래 수 24시간 변동",
    "contract_address": "거래 주소",
    "contract_address/24h_change": "계약 거래 주소 24시간 ",
    "contract_address/24h_change": "계약 거래 주소 /24시간 ",
    "total_contract/24h_contract_tip": "네트워크에서 거래가 이루어진 계약의 총 수",
    gas_24: "24시간 Gas 사용",
    proportion_64G: "32GiB 섹터의 품질 조정된 파워 비율",
    proportion_32G: "64GiB 섹터의 품질 조정된 파워 비율",
    contract_gas: "계약 가스 비용",
    quality_power_Cc: "Commited Capacity (CC)",
    quality_power_Dc: "DataCap (DC)",
    see_more: "더보기",
    contract_balance: "계약 잔액"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (home);


/***/ }),

/***/ 7997:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const zh = {
    network_title: "현재 네트워크",
    home: "홈페이지",
    contract: "FEVM",
    contract_verify: "스마트 계약 검증",
    contract_list: "검증된 스마트 계약 리스트",
    contract_rank: "스마트 계약 랭킹",
    analysis: "Data Analysis",
    analysis_market: "Filecion Analysis",
    analysis_fund: "Fund Penetration Analysis",
    defi_dashboard: "DeFi Protocol",
    network_overview: "네트워크 개요",
    token: "토큰",
    nft: "NFT",
    tipset: "블록체인",
    tipset_chain: "블록",
    tipset_message: "메시지",
    tipset_ranking: "자산 순위",
    tipset_transfer: "거액 이체",
    tipset_dsn: "주문",
    "tipset_pool-message": "메시지 풀",
    ranking: "랭킹",
    statistics: "통계",
    statistics_gas: "가스 요금 추세",
    statistics_base: "해싱 파워 추세",
    statistics_fil: "FIL",
    statistics_charts: "통계",
    statistics_map: "노드 맵",
    cw: "ChainWatch",
    resources: "자원",
    resources_tools: "자주 쓰는 도구",
    provider: "스토리지 공급자",
    fvm: "파일코인 생태계",
    fvm_all: "프로젝트 개요",
    active: "활동",
    account: "Miner Metrics",
    develop: "Developer",
    language: "언어",
    network: "회로망"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (zh);


/***/ }),

/***/ 20596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const rankZh = {
    rank_title: "Ranking",
    rank: "Rank",
    pool: "스토리지 풀 랭킹",
    provider: "노드 랭킹",
    growth: "파워 증가율",
    rewards: "노드 수익",
    "24h": "24시간",
    week_days: "7일",
    month: "30일",
    select_rank_all: "모든 섹터",
    select_rank_32: "32G 섹터",
    select_rank_64: "64G 섹터",
    more: "더보기",
    rank_time: "마지막 업데이트 시간:",
    see_more: "더보기",
    //存储池排行
    ranking: "순위",
    pool_owner: "Owner ID",
    pool_power: "유효 해시파워",
    pool_efficiency_24h: "최근 24시간 생산 효율",
    pool_increase_24h: "최근 24시간 채굴파워 증가량",
    pool_block_count: "총 블록 수",
    pool_block_count_24h: "최근 24시간 블록 수",
    miner: "노드",
    // 节点排行
    provider_miner: "스토리지 제공자",
    provider_power_ratio: "유효 채굴파워 / 비율",
    provider_block_ratio: "최근 24시간 블록 / 비율",
    provider_rewards_ratio: "최근 24시간 보상 / 비율",
    balance: "잔액",
    //算力增速
    power_ratio: "채굴파워 증가 속도",
    power_ratio_tip: "선택한 주기 내에서, 매일 평균 패키징된 섹터의 유효 해시파워 총합",
    quality_power_increase: "채굴파워 증가량",
    quality_power_increase_tip: "선택한 주기 내에서, 노드의 유효 채굴파워 증가량",
    quality_adj_power: "유효 체굴 파워",
    raw_power: "로우바이트 체굴 파워",
    sector_size: "섹터 크기",
    //节点收益
    "rewards/ratio": "블록 보상 / 비율",
    "rewards/ratio_tip": "선택한 주기 내에서, 노드 블록 보상과 누적 블록 생성 보상의 비율",
    block_count: "블록 수",
    winning_rate: "윈 카운트 확률",
    block_count_tip: "Filecoin 경제 모델에서, 높이 (tipset) 당 여러 블록 (block)이 있을 수 있으며 각 블록은 여러 보상 (win count)을 받을 수 있습니다."
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rankZh);


/***/ }),

/***/ 44547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const statistic = {
    gas_total: "Gas",
    show_more: "더 보기",
    "24h": "24시간",
    "7d": "7일",
    "30d": "30일",
    year: "1년",
    // power
    power: "스토리지 파워 추세",
    power_tips: "기준선은 Filecoin 네트워크가 요구하는 네트워크 성장 규모이며, 메인넷 출시 때는 2.5EiB이며, 연간 증가율은 100% 입니다.",
    trend_24: "24시간 기본 수수료 추세",
    total_raw_byte_power: "원래 로우바이트 파워",
    base_line_power: "기준선 추세",
    change_quality_adj_power: "연쇄 유효 체굴파워 변화",
    total_quality_adj_power: "유효 체굴파워",
    gas: "기본 수수료 추세",
    base_fee: "기본 수수료",
    gas_in_32g: "32GiB 섹터 Gas 소비",
    gas_in_64g: "64GiB 섹터 Gas 소비",
    //24_gas
    gas_24: "24시간 Gas 데이터",
    method_name: "메시지 유형",
    avg_gas_premium: "Gas 프리미엄",
    avg_gas_limit: "평균 Gas 한도",
    avg_gas_used: "평균 가스 소비",
    avg_gas_fee: "평균 수수료",
    "sum_gas_fee/ratio": "수수료 합계/비율",
    "message_count/ratio": "메시지 수 합계/비율",
    //fil
    TokenRules: "Filecoin 토큰 할당 규칙",
    FilecoinFoundation: "Filecoin 재단",
    FundraisingRemainder: "모금 - 잔여 토큰",
    FundraisingSAFT: "모금 - 미래 토큰 간단 계약",
    MiningReserve: "스토리지 서비스 제공자를 위한 예비 토큰",
    TokenAllocation: "스토리지 제공자 토큰 할당",
    ReservedTokens: "스토리지 제공자 예비 토큰",
    Fundraising: "모금 방식 - 미래 토큰 간단 계약 2017",
    Funds: "모금 방식 - 잔여 자금",
    protocolLab: "프로토콜 실험실",
    Contributors: "프로토콜 실험실 팀 및 기여자",
    Allocation: "항목 배치",
    value: "금액",
    description: "구체적 용도",
    filBase: "FIL 기본 발급",
    filBase_des: "네트워크에서 FIL 생선 상한",
    ReservedTokens_des: "미래 Filecoin 경제 성장을 위해 예비 토큰 저장, 구체적인 사용 방안은 Filecoin 커뮤니티에서 결정됩니다.",
    TokenAllocation_des: "블록 보상, 네트워크 초기화 등을 통해 스토리자 제공자에게 발급한 토큰 보상",
    FilecoinFoundation_des: "장기적인 커뮤니티 발전과 네트워크 관리를 위해 할당되었습니다",
    Fundraising_des: "2017년 판매된 토큰",
    Funds_des: "생태계 발전 및 후속 자금 용자로 쓰인다",
    protocolLab_des: "프로토콜 실험실 관련 작업용",
    Contributors_des: "4.5%는 프로토콜 실험실 팀 및 기여자에게 지급됩니다.",
    //charts
    pie_title: "차트 통계",
    block_trend: "블록 보상",
    block_reward_per_TiB: "생산 효율",
    acc_block_rewards: "누적 블록 보상",
    active_nodes: "액티브한 노드 수",
    active_miner_count: "노드 수",
    messages_trend: "메시지 수 추이 그래프",
    message_count: "블록 평균 메시지 추세",
    all_message_count: "총 메시지 추세",
    pie_title_a: "현재 FIL의 용도 분포 통계",
    pie_title_a_tip: "제공된 스토리지 제공자 보상 FIL + 해제된 잠긴 블록 보상 FIL + 배치된 보류 부분 FIL = 현재 이미 방출된 FIL",
    pie_title_b: "현재 이미 방출된 FIL 용도 통계",
    mined: "제공된 스토리지 제공자 보상 FIL",
    remaining_mined: "잔여 스토리지 제공자 보상 FIL",
    vested: "해제된 잠긴 블록 보상 FIL",
    remaining_vested: "잔여 잠긴 블록 보상 FIL",
    reserve_disbursed: "배치된 보류 부분 FIL(테스트넷 보상)",
    remaining_reserved: "잔여 보류 부분 FIL",
    locked: "섹터 담보 FIL",
    burnt: "폐기된 FIL",
    circulating: "거래 가능한 유통 FIL",
    power_increase: "순 전력 증가",
    power_decrease: "순 전력 감소",
    //chartsnav
    cc_dc_power: "CC/DC 전력 추세",
    static_overview: "차트 통계",
    fil_overview: "FIL 개요",
    contract_trend: "계약 거래",
    charts_title: "FIL 할당 지침",
    networks_overview: "전체 네트워크 데이터 지표",
    contract_con: "계약 배포 추이",
    contract_counts: "계약 거래 주소",
    contract_gas: "계약 Gas 소비",
    contract_addr: " 계약 배포",
    contract_balance: "계약 잔액 추세",
    contract_total_balance: "계약 잔액",
    //cw
    "cw-search": "높이/블록 CID 검색",
    cw_des: "다양한 높이를 보려면 드래그하세요",
    cw_top: "최신 키"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (statistic);


/***/ }),

/***/ 29465:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const tipset = {
    rank: "순위",
    tag: "태그",
    height: "블록 높이",
    cid: "메시지 CID",
    block_time: "시간",
    from: "보내는 주소",
    to: "받는 주소",
    value: "액수",
    method_name: "매소드",
    all: "모든 메소드",
    //chain
    blocks_cid: "CID",
    blocks_miner: "Miner",
    blocks_messages: "메시지",
    blocks_reward: "보상",
    win_count: "윈 카운트",
    //cid_details
    message_list_total: "총 {{value}}개 메시지",
    chain_cid_detail: "블록 정보",
    cid_height: "높이",
    parent_weight: "Parent Block 무게",
    parents_cid: "Parent Block CID",
    parent_base_fee: "Parent Block 기본 수수료",
    ticket_value: "티켓 값",
    state_root: "스테이트 루트",
    //message
    message_list: "모든 매소드",
    total_list: "총 {{value}}개 메시지",
    message_list_all: "전체 유형",
    message_list_exit_code: "상태",
    message_list_method_name: "매소드 명칭",
    // adress
    address_total_list: "총 {{value}}개 계정",
    address_list: "자산 순위",
    address_all: "전체 유형",
    account: "일반 계정",
    owner: "소유자 계정",
    miner: "노드 계정",
    payment: "지불 채널",
    multisig: "다중 서명 계정",
    balance_change_7: "잔액 변경",
    fund: "자금 침투",
    go_fund: "Check",
    account_address: "주소",
    balance_percentage: "잔액/비율",
    account_type: "유형",
    latest_transfer_time: "최근 거래 시간",
    //transfer
    transfer_list: "거액 이체 기록",
    transfer_total_list: "총 {{value}}개 기록",
    //dsn
    dsn_list: "거래 목록",
    dsn_total_list: "총 {{value}}개 거래",
    dsn_placeholder: "검색 고객/호스팅자/Deal ID",
    deal_id: "거래 ID",
    piece_cid: "파일 ID",
    piece_size: "파일 크기",
    client_address: "고객",
    provider_id: "호스팅자",
    service_start_time: "시작 시간",
    end_time: "종료 시간",
    start_height: "스타트 높이",
    end_height: "앤드 높이",
    storage_price_per_height: "저장 요금",
    verified_deal: "검증된 거래",
    // pool-message
    pool_list: "메시지 풀 목록",
    gas_fee_cap: "Gas 한도",
    gas_premium: "Gas 프리미엄",
    block_list: "Tipsets List"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (tipset);


/***/ }),

/***/ 9547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const account = {
    date: "日期",
    day: "天",
    copy: "复制",
    confirm: "确认",
    cancel: "取消",
    login: "节点管家",
    go_home: "返回首页",
    go_login: "去登录",
    back: "返回",
    select_group: "请选择分组",
    select_miner: "请选择节点",
    select_miner_tag: "请选择标签",
    account_title: "节点管家",
    all_tags: "全部标签",
    overview: "数据概览",
    data_details: "数据详情",
    miners: "节点管理",
    monitor: "监控管理",
    monitorSector: "到期监控",
    monitorBalance: "余额监控",
    monitorPower: "算力监控",
    personal: "账号信息",
    logout: "退出登录",
    default_group: "默认分组",
    welcome: "欢迎来到Filscan!",
    welcome_text1: "恭喜！您的账户已成功注册,您可以使用您的邮箱号和密码继续登录。",
    welcome_text2: "请登录您的账户并享受您的Filscan服务!",
    last_time: "最新更新时间",
    all: "全部",
    all_groups: "全部分组",
    all_miners: "全部节点",
    edit: "操作",
    miner_add: "添加",
    edit_write: "修改",
    edit_delete: "删除",
    created_at: "创建时间",
    look_more: "查看权益",
    look_detail: "查看详情",
    look_detail_member: "免费赠送",
    //个人账户
    register_success: "恭喜！您的账户已注册成功，快来开启您的专属服务!",
    register_btn: "开启服务",
    //数据概览
    power: "算力概览",
    gas: "Gas 消耗",
    expired: "到期扇区",
    reward: "出块奖励",
    lucky: "幸运值",
    balance: "地址余额",
    // overview_power: '算力概览',
    // overview_gas: 'Gas 消耗',
    // overview_expired: '到期扇区',
    // overview_reward: '出块奖励',
    // overview_lucky: '幸运值',
    // overview_balance: '地址余额',
    no_node_data: "暂未添加节点，去",
    miners_add: "添加节点",
    group_add: "添加分组",
    miners_group_manage: "分组设置",
    //total_out_come_gas: '总支出/Gas消耗',
    total_out_come_gas: "支出/Gas消耗",
    pledge_amount_24: "质押FIL/今日变化",
    balance_24: "账户余额/今日变化",
    quality_power_24: "有效算力/今日变化",
    //节点管理
    delete_group: "删除分组",
    delete_record_group: "确定删除分组“{{value}}”吗？",
    delete_group_text: "删除后该分组将不在列表中显示",
    delete_miner: "删除节点",
    delete_record_miner: "确定删除节点“{{value}}”吗？",
    delete_miner_text: "删除后该节点将不在分组中显示",
    //添加节点
    custom_tag: "自定义标签",
    miner_add_placeholder: "输入您要添加的节点账户ID",
    miner_select_group_placeholder: "选择分组（如未选择组，添加的节点将全部进入“默认分组”中",
    //分组
    create_group: "创建分组",
    create_group_holder: "输入您要创建组的名称",
    item_value: "组内 {{value}} 个节点",
    group_name: "分组名称",
    //幸运值
    all: "全部",
    "24h_lucky": "24时幸运值	",
    "7d_lucky": "7天的幸运值",
    "30d_lucky": "30天幸运值",
    "1year_lucky": "1年的幸运值",
    tag: "标签",
    miner_id: "节点ID",
    //地址余额
    miner_balance: "节点余额/今日变化",
    owner_balance: "Owner余额/今日变化",
    worker_balance: "Worker余额/今日变化",
    controller_0_balance: "Controller0余额/今日变化",
    controller_1_balance: "Controller1余额/今日变化",
    controller_2_balance: "Controller2余额/今日变化",
    beneficiary_balance: "Beneficiary余额/今日变化",
    market_balance: "MarketBalance余额/今日变化",
    //奖励
    block_count: "爆块",
    win_count: "赢票",
    block_reward: "奖励",
    total_reward: "总奖励",
    total_reward_24: "出块奖励",
    //total_reward_24:'奖励/今日变化',
    //算力概览
    quality_power: "有效算力",
    dc_power: "DC算力",
    raw_power: "原值算力",
    cc_power: "CC算力",
    sector_size: "扇区大小",
    sector_power_change: "扇区变化",
    sector_power_count: "Sector数量",
    sector_count_change: "扇区数量变化",
    pledge_changed: "质押变化",
    pledge_changed_per_t: "质押变化/T",
    penalty: "惩罚",
    fault_sectors: "错误扇区",
    sector_power_change_tip: "Sector数量/原值算力的新增及终止的总和",
    pledge_changed_tip: "Sector数量的新增及终止对应的质押变化总和",
    pledge_changed_per_t_tip: "质押变化\xf7扇区变化(TiB)",
    penalty_tip: "被惩罚的FIL数量",
    fault_sectors_tip: "新增的错误扇区数量",
    total_gas_cost_tip: "所有类型消耗Gas的总和",
    seal_gas_cost_tip: "扇区封装消耗的Gas总和（PreCommitSector+ProveCommitSector+PreCommitSectorBatch+ProveCommitAggregate+PreCommit 聚合费+ProveCommit 聚合费",
    seal_gas_per_t_tip: "封装Gas\xf7新增扇区(TiB)",
    deal_gas_cost_tip: "真实数据PublishStorageDeals消耗",
    wd_post_gas_cost_tip: "时空证明SubmitWindowedPoSt消耗",
    wd_post_gas_per_t_tip: "时空证明Gas\xf7原值算力(TiB)",
    //gas
    total_gas_cost: "Gas总消耗",
    seal_gas_cost: "封装Gas",
    seal_gas_per_t: "封装Gas/T",
    deal_gas_cost: "发单Gas",
    wd_post_gas_cost: "时空证明Gas",
    wd_post_gas_per_t: "时空证明Gas/T",
    //到期扇区
    exp_month: "{{year}}年{{month}}月到期",
    exp_time: "到期时间",
    miner_count: "节点数",
    exp_power: "到期算力",
    sector_count: "到期扇区数",
    exp_dc: "到期DC",
    exp_pledge: "到期抵押",
    //个人中心
    default_user: "普通用户",
    last_login: "上次登录时间",
    personal_setting: "账户设置",
    personal_name: "账户名称",
    old_placeholder: "输入旧密码",
    old_password: "旧密码",
    new_password: "新密码",
    new_placeholder: "输入新密码",
    confirm_password: "确认密码",
    confirm_placeholder: "重新输入新密码",
    personal_name_holder: "请输入账户名称",
    name_length: "名称长度小于10",
    //下载
    out_come_gas: "支出",
    //余额监控
    miner: "节点余额",
    owner: "Owner余额",
    worker: "Worker余额",
    controller_0: "Controller0余额",
    controller_1: "Controller1余额",
    controller_2: "Controller2余额",
    beneficiary: "Beneficiary余额",
    //监控
    add_rules: "添加规则",
    examination: "规则",
    alarm: "告警方式",
    status: "状态",
    rules_more: "单个弹框最多添加10组规则，如还需添加请保存后再继续",
    warn_more: "最多支持添加3个",
    monitor_mobile_edit_tip: "监控增删改操作请前往PC端完成",
    //告警方式
    warn_title: "告警方式",
    warn_title_des: "告警方式可根据实际情况选择一种或组合",
    email_warn: "邮箱告警",
    email_warn_placeholder: "请输入告警邮箱地址",
    email_warn_warning: "请输入正确邮箱地址",
    email_warn_des: "当前账户注册邮箱会默认发送，无需重复提交",
    message_warn: "短信告警",
    message_warn_placeholder: "请输入接收号码",
    message_warn_warning: "请输入正确的接收号码",
    phone_warn: "电话告警",
    phone_warn_placeholder: "请输入接收号码",
    phone_warn_warning: "请输入正确的接收号码",
    //监控
    ExpireSectorMonitor: "扇区到期时间",
    edit_status: "关闭规则",
    edit_status_content: "您确定关闭此监控吗？关闭后将无法及时收到相关告警",
    delete_rule: "删除规则",
    delete_rule_content: "您确定删除此监控吗?",
    //扇区监控
    reset_button: "重置",
    add_rules: "添加规则",
    edit_rules: "修改规则",
    rule_detail: "规则详情",
    edit_write_warn: "告警方式",
    sector_rule_title: "扇区到期时间",
    sector_rule_des: "可自定义,建议大于30",
    sector_ruler_placeholder: "请输入正整数",
    sector_ruler_warningText: "请输入正整数",
    "<=": "小于等于",
    ">=": "大于等于",
    //余额监控
    balance_category_placeholder: "请选择余额类目",
    balance_rule_des: "当前 {{value}} FIL",
    //算力监控
    power_rules_1: "1. 扇区发生错误",
    power_rules_2: "2. 扇区主动终止",
    power_rules_3: "3. 扇区正常到期",
    //会员
    //会员
    member_miner_warn: "当前节点个数已达上限，升级会员畅享",
    member_warn: "您的会员权益即将到期，请及时续费，以免影响正常使用",
    member_header: "如果你担心或碰到过以下问题",
    power_title: "算力掉落",
    power_text: "扇区大批出错，致使算力锐减却无法及时获知，导致出块奖励损失惨重",
    balance_title: "账户余额不足",
    balance_text: "账户余额不足，却无法及时获取信息，导致扇区封装或维持失败",
    sector_title: "扇区到期",
    sector_text: "扇区到期了算力也跟着掉落，才想起应该早点续期，有个提醒就好了",
    warn_power: "算力监控",
    warn_balance: "余额监控",
    warn_sector: "扇区监控",
    warn_email: "邮箱告警",
    warn_msg: "短信告警",
    warn_phone: "电话告警",
    data_text: "重点信息一站式监控",
    warn_text: "告警渠道多样，灵活配置",
    member_warn_title: "添加监控，告警快人一步",
    member_content_title: "加入会员，即刻开启",
    companies: "企业版",
    companiesPro: "企业Pro版",
    companies_1: "30个节点上限",
    companies_1_pro: "节点无上限",
    companies_2: "算力监控",
    companies_3: "余额监控",
    companies_4: "扇区监控",
    companies_5: "更多（敬请期待）",
    companies_6: "技术服务支持",
    monthly: "月度会员",
    quarter: "季度会员",
    year: "年度会员",
    quarter_discount: "低于8.8折",
    year_discount: "低于8折",
    share_friend: "邀请朋友，赠送一个月企业版会员",
    share_turn: "即刻开启，最大化减少损失",
    tg_title: "添加商务TG开通",
    //活动
    success_member: "已成功注册",
    error_member: "未绑定节点",
    success_miners: "已绑定节点",
    success_active: "有效",
    error_active: "无效",
    invitees: "被邀请人",
    is_valid: "是否有效",
    send_member: "送会员",
    invite_code: "邀请码",
    active_share: "去邀请",
    active_member_warn: "短信 、电话告警",
    active: "邀请活动",
    active_rule: "活动规则",
    active_detail: "详情",
    active_rule_detail: "活动规则详情",
    rule_content: "累计邀请2名节点管理者注册，且被邀请账号绑定了有效节点信息，赠送价值169U的企业版会员一个月。被邀请者也可体验7天企业版权益。",
    active_member: "企业版会员权益",
    active_member_1: "享有完整监控能力",
    active_expired: "会员到期后，权益自动回收，您可通过续费继续享用相关服务。",
    active_1: "邀请好友",
    active_1_des: "发送邀请海报或邀请码给好友，扫码或登录官网填写邀请码注册",
    active_2: "注册添加",
    active_2_des: "好友注册成功，并成功添加有效节点",
    active_3: "邀请2个有效好友",
    active_3_des: "邀请2个有效好友，成功领取奖励",
    active_target_1: "节点信息 一网打尽",
    active_target_2: "异常告警 快人一步",
    scan_code: "立即扫码体验",
    active_des: "活动解释权归FILSCAN所有",
    active_gift: "新人赠送7天企业版体验权益",
    active_save: "保存本地",
    copy_tg: "复制ID",
    recommend: "推荐",
    //personal
    personal_1: "升级/续费会员",
    personal_2: "绑定邮箱",
    personal_3: "修改密码",
    member_expired_time: "{{value}} 到期",
    mail_success: "已绑定",
    //第一次弹窗
    free_send: "企业版会员免费赠送"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (account);


/***/ }),

/***/ 28160:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const analysis = {
    "7d": "7天",
    "30d": "30天",
    "1year": "1年",
    k_chart: "K 线",
    trend_chart: "趋势图",
    market_value: "流通市值",
    market_value_tip: "FIL当前流通量*当前价格",
    circulation: "流通量",
    proportion: "流通占比",
    supply: "总供应量",
    market_total: "总市值",
    market_total_tip: "FIL总供应量*当前价格",
    locked: "锁仓量",
    locked_ratio: "锁仓占比",
    burn: "销毁量",
    burn_ratio: "销毁占比",
    "24_quantity": "24H量",
    "24_amount": "24H额",
    turnover_rate: "换手率",
    turnover_rate_tip: "换手率也称“周转率”，指在一定时间内市场中转手买卖的频率，是反映流通性强弱的指标，24H换手率计算公式：24H内的成交额/流通市值*100%",
    quantity_ratio: "量比",
    quantity_ratio_tip: "近1日平均每分钟成交量 / 近7日平均每分钟成交量",
    market_tip: "所有数据仅供参考，不构成投资建议",
    //chart
    fil_origin: "币安网",
    period_1: "1分",
    period_5: "5分",
    period_30: "30分",
    period_60: "1小时",
    period_240: "4小时",
    period_1440: "日线",
    period_10080: "周线",
    period_43200: "月线",
    //trend chart
    fil_title: "FIL阶段涨幅",
    change_day: "24小时",
    change_week: "近7天",
    change_month: "近30天",
    change_threemonth: "近3月",
    change_sixmonth: "近6月",
    change_year: "近1年",
    change_thisyear: "今年来",
    change_ico: "所有",
    usd_price: "美元价格",
    btc_price: "BTC价格",
    market_price: "流通市值",
    volume: "成交额",
    price_origin: "此数据取自CoinMarketCap",
    //流动性观察
    liquidity_watch_fil: "查看FIL概览",
    liquidity_total: "网络流通总量",
    liquidity_total_24: "网络流通总量/24H",
    liquidity_watch: "流动性观察",
    liquidity_watch_tip: "展示当前网络流动总量的来源变化及趋势",
    liquidity_destruction: "网络销毁",
    liquidity_destruction_24: "网络销毁/24H",
    liquidity_freed: "网络释放",
    liquidity_freed_24: "网络释放/24H",
    liquidity_pledge: "网络质押",
    liquidity_pledge_24: "网络质押/24H",
    provider_rewards: "存储提供者奖励",
    provider_rewards_24: "存储提供者奖励/24H",
    lockup_freed: "创世锁仓释放",
    lockup_freed_24: "创世锁仓释放/24H",
    lockup_freed_tip: "网络初创时基金会、实验室等官方组织账户约定的每日释放量总和",
    reserved_freed: "预留部分释放",
    reserved_freed_24: "预留部分释放/24H",
    sector_pledge: "扇区质押",
    sector_pledge_24: "扇区质押/24H",
    defi_staking: "Defi质押",
    defi_staking_24: "Defi质押/24H",
    //创世账户释放日历
    release_Calendar: "创世账户释放日历",
    account: "账户",
    total_lockup: "总锁仓",
    released: "已释放",
    daily_release: "每日释放",
    release_cycle: "释放周期",
    account_balance: "账户余额",
    balance_change_7: "余额变化(7D)",
    fund_penetration: "资金穿透",
    release_cycle_detail: "已释放{{value}}%，预计{{date}}释放完",
    go_fund: "去查看",
    //token
    token_list_address: "查看富豪榜",
    token_list: "持有Token地址",
    token_list_tip: "链上token数量大于0的地址数，图表展示30天和一年数据",
    token_address_total: "持有地址数",
    token_top_10: "前10持仓占比",
    token_top_20: "前20持仓占比",
    token_top_50: "前50持仓占比",
    token_top_100: "前100持仓占比",
    //十大流动地址
    top_active_address: "10大流动地址",
    top_active_address_tip: "7天内波动（转入或者转出）数量最大的前10持仓地址",
    quantity: "持仓数量",
    percentage: "持仓占比",
    change_7d: "7天变化",
    //资金穿透
    fund_placeholder: "请输入想要分析的账户",
    fund_analysis: "资金穿透分析",
    check_account: "查询账户",
    network_rank: "全网排名",
    position_ratio: "持仓比例",
    balance_change: "余额变化",
    related_way: "关联方式",
    fund_volume: "交易数量",
    fund_number: "交易次数",
    rank: "排 名",
    rank_3: "前3",
    rank_5: "前5",
    rank_10: "前10",
    level: "层 级",
    level_3: "3级",
    level_5: "5级",
    level_all: "不限",
    select_account: "选中账户",
    total_volume: "交易总量",
    total_number: "交易总数"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (analysis);


/***/ }),

/***/ 91818:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const common = {
    zh: "中",
    en: "En",
    kr: "Kr",
    login: "登录",
    cancel: "取消",
    confirm: "确认",
    open: "展开",
    no_open: "收起",
    lang: "中",
    fil: "FIL",
    last_time: "最新区块时间",
    base_fee: "Base Fee",
    last_height: "最新区块高度",
    go_home: "返回首页",
    go_login: "去登录",
    //search
    search_holder: "请输入地址/消息ID/高度/区块Cid/节点ID/FNS",
    all: "全部筛选类型",
    address: "地址",
    message_id: "消息ID",
    height: "高度",
    cid: "区块CID",
    node: "节点",
    save_pic: "保存图片",
    fvm_share: "分享给朋友",
    account_banner_bg: "欢迎使用节点管家",
    account_banner_main: "您的节点管理好帮手",
    mobile_code_1: "扫描二维码",
    mobile_code_2: "体验手机浏览器",
    time_display: "秒前",
    //messages
    no_account: "该邮箱未注册,请先注册",
    //登录注册
    active_top_1: "节点信息",
    active_top_2: "一网打尽",
    active_bottom_1: "异常告警",
    active_bottom_2: "快人一步",
    register: "邮箱注册",
    password_login: "密码登录",
    reset_password: "重置密码",
    verification_code: "验证码登录",
    email_placeholder: "输入邮箱号",
    password_placeholder: "输入密码",
    invite_placeholder: "输入邀请码(选填)",
    code_placeholder: "输入验证码",
    remember_me: "记住并自动登录",
    forgot_password: "忘记密码",
    get_code: "获取验证码",
    retry_code: "重新发送",
    no_account: "还没有账号?",
    have_account: "已有账号?",
    go_register: "立即注册",
    new_password: "密码，8-20个字符，需同时包含数字、字母及特殊字符",
    confirm_password: "确认密码",
    agreement: "注册即代表同意《协议》、《隐私政策》",
    //校验
    email_required: "请输入您的邮箱",
    email_rules: "邮箱格式有误,请修改",
    code_rules: "请正确输入6位数字验证码",
    password_rules: "请输入 8-20 个字符，需同时包含数字、字母以及特殊符号,密码不能与您的邮箱地址相同",
    confirm_password_rules: "两次输入的密码不一致，请重新输入",
    email_exists: "邮箱已存在",
    Export: "下载Excel",
    //footer
    footer_des1: "Filscan 是 Filecoin 区块链浏览器及其数据服务平台",
    footer_des2: "提供基于 Filecoin 的各类数据查询、可视化图表以及FVM生态数据统计分析的一站式数据服务",
    active: "活动",
    active_time: "Period",
    add_project: "项目申请"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (common);


/***/ }),

/***/ 40077:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/*

什么时候需要上传MetaData文件?
1. 多文件合约
2. 合约内import的层级目录为原生状态且与metadata文件中sources下的路径相同 (若合约内import的层级目录为当前文件夹则不需要上传metadata文件)
如何获取metaData文件？
1. 通过使用Solidity编译器（solc）获取：
    solc --metadata MainContract.sol -o metadata.json
2. 通过使用Remix IDE下载：
    在Remix网页端发布之后有提供metadata.json的下载按钮
*/ const contract = {
    all: "全部",
    overview: "概览",
    market: "Market",
    look_adres: "查看地址",
    gohome: "返回首页",
    reset_ver: "重新验证",
    "all_token": "All Tokens",
    ">0": "数量大于0",
    "=0": "数量等于0",
    next: "下一步",
    reset: "重置",
    confirm: "验证并发布",
    back: "返回",
    file_name: "选择 *.sol 文件",
    file_name_json: "选择 *.json 文件",
    config_file_name: "选择 Metadata 文件",
    config_file_des1: "> 什么时候需要上传metadata文件?",
    config_file_des1_1: "1. metadata文件包含了编译器的各种设置，如果您使用了高级优化参数，或者编译时使用了编译配置文件（e.g. remix中编译时的compiler_config.json文件），那么您需要上传metadata文件进行验证",
    config_file_des1_2: '2. 合约内import的层级目录为初始格式(e.g. import "@openzeppelin/contracts/access/Ownable.sol")并与metadata文件中sources下的路径相同 (若合约内import的层级目录为当前文件夹则不需要上传metadata文件)',
    config_file_des2: "> 如何获取metadata文件?",
    config_file_des2_1: "1. 通过使用Solidity编译器（solc）获取：solc --metadata MainContract.sol -o metadata.json",
    config_file_des2_2: "2. 通过使用Remix IDE下载：在Remix网页端发布之后有提供metadata.json的下载按钮",
    verify_title: "验证并发布合约源代码",
    verify_des: "编译器类型和版本选择",
    verify_content: "源代码验证为与智能合约交互的用户提供了透明度。通过上传源代码，filscan 将编译后的代码与区块链上的代码进行匹配。就像合同一样，“智能合同”应该为最终用户提供更多关于他们“数字签名”的目的的信息，并让用户有机会审核代码以独立验证它是否确实做了它应该做的事情。",
    content_des: `源代码验证为与智能合约交互的用户提供了透明度。通过上传源代码，Filscan 将编译后的代码与区块链上的代码进行匹配。就像合同一样，“智能合同”应该为最终用户提供更多关于他们“数字签名”的目的的信息，并让用户有机会审核代码以独立验证它是否确实做了它应该做的事情。通过上传hardhat “artifacts/build-info/”目录中的json文件，可以快速进行合约验证。
Hardhat 将编译输出存储在项目内的“artifacts/build-info/”目录中。 该目录包含一个 .json 文件，其中包含所有合约的Standard JSON Input-Outpu，这是与 Solidity 编译器交互的推荐方法，特别是在高级和自动化配置中。 所有编译器发行版都统一支持此 JSON 输入输出接口`,
    address: "请输入您要验证的合约地址",
    address_placeholder: "请输入您要验证的合约地址",
    verify_address: "请选择编译版本",
    verify_address_placeholder: "请选择",
    verify_model: "请选择编译类型",
    verify_model_placeholder: "请选择编译类型",
    license_type: "请输入开源许可证类型",
    content_des1: "1. 如果合同在 REMIX 处编译正确，则此处也应编译正确",
    content_des2: "2. 我们对验证由另一个合约创建的合约的支持有限，编译的每个合约的超时时间最多为45秒",
    content_des3: "3. 对于编程合同验证，请查看合同 API 端点",
    checkbox_service: "我同意服务条款",
    verify_select_placeholder: "请选择",
    //logs
    ver_sucess: "Success: 验证成功",
    ver_err: "Error: 验证失败",
    has_been_verified: "Error:合约已验证",
    byte_code: "编译日志",
    contract_name: "合约名",
    local_byte_code: "合约字节码",
    compiler: "编译器版本",
    contract_abi: "合约ABI",
    //step1
    address_verify: "合约地址",
    step1_verify_des: "请选择单个或多个 *.SOL 文件",
    source_code: "合约源码",
    compile_version: "编译器",
    compile_output: "编译输出",
    Optimizations: "优化参数",
    run_optimizer: "运行(优化器)",
    arguments: "构造函数参数",
    optimize: "优化开启",
    optimize_runs: "RUNS",
    // 已验证合约
    Verify_code: "Code",
    Verify_read: "Read Contract",
    Verify_write: "Write Contract",
    contract_verify: "合约验证",
    contract_verify_tips: "合约验证请前往PC端查看",
    //token list
    token_list: "全部通证",
    token_name: "Token",
    vol_24: "成交量(24h)",
    transfer_total: "共 {{value}} 条消息",
    owner_total: "总共 {{value}} 人持有",
    dex_total: "共 {{value}} 条交易",
    nfts_total: "共 {{value}} 条 NFTs",
    //nft list
    nfts_list: "全部 NFTs",
    trading_volume: "全部成交量",
    nfts_trans: "NFT转移",
    // ft /fns dashborad
    "total_supply": "供应量",
    "total_supply_tip": "该数据为合约ERC20标准方法返回值",
    "owners": "持有人",
    "transfers": "总共转移",
    latest_price: "价格",
    market_value: "市值",
    token_contract: "通证合约",
    transfer: "转移",
    owner: "拥有者",
    owner_nft: "拥有者",
    domain: "合约",
    dex: "DEX 交易",
    //list
    message_cid: "消息ID",
    method: "Method",
    time: "时间",
    from: "发送地址",
    to: "接收地址",
    amount: "数量",
    //拥有者
    rank: "排行",
    percentage: "占比",
    //dex
    platform: "交易平台",
    Txn_Value: "Txn Value",
    "swapped_Rate": "Swapped Rate",
    "Token_Amount_in": "Token Amount(In)",
    "Token_Amount_out": "Token Amount(Out)",
    Action: "Action",
    //合约列表
    contract_list: "已验证合约",
    contract_address: "地址",
    language: "语言",
    license: "许可证",
    //合约详情
    contract_list_total: "共 {{value}} 个合约",
    byte_code_no_verify: "合约未验证，去",
    go_to_verify: "验证合约",
    verify_contract: "合约源代码已通过验证",
    source_code: "合约源代码",
    source_code_create: "合约创建代码",
    source_abi: "合约ABI",
    source_abi_default: "导出ABI",
    nfts_list: "NFTs List",
    item: "Item",
    Items: "数量",
    controller: "域名注册人",
    pleaseCheckContractWithPC: "合约详情请前往PC端查看~",
    //rank
    contract_rank_des: "上次更新时间为:{{value}}",
    contract_rank_total: "共 {{value}} 个合约 ",
    contract_rank: "合约排行",
    rank: "排名",
    actor_id: "actorID",
    ver_address: "待验证",
    actor_address: "actorAddress",
    transaction_count: "交易数量",
    user_count: "交易地址",
    actor_balance: "Balance",
    gas_cost: "Gas消耗",
    see_more: "查看更多",
    //log
    epoch: "高度",
    cid: "消息ID",
    event_name: "方法",
    topics: "主题",
    coompoent_data: "参数",
    log_index: "序号",
    removed: "移除"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contract);


/***/ }),

/***/ 19893:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// pool-detail
const detail = {
    "24h": "24时",
    "7d": "7天",
    "30d": "30天",
    "1year": "1年",
    look_all: "查看全部数据",
    all: "全部方法",
    all_token: "All Tokens",
    //owner
    owner_title: "存储池详情",
    owner_title_tip: "存储池详情：存储池数据由名下节点数据,汇总而成",
    all_method: "全部方法",
    account: "一般账户",
    account_title: "账户",
    owner_address: "Owner地址",
    owned_miners: "名下节点",
    owned_active_miners: "名下活跃节点",
    miner: "Miner",
    evm: "EVM",
    ethaddress: "ETHAddress",
    ethaccount: "ETHAccount",
    transfer_records: "转账记录",
    //account_type
    account_name: "账户",
    latest_transfer_time: "最新交易时间",
    multisig: "多签账户",
    account_detail: "储存池详情",
    from_ath: "发送方",
    to_ath: "接受方",
    account_id: "账户地址",
    //概览
    owner_overview_title: "存储池概览",
    balance: "账户余额",
    available_balance: "可用余额",
    init_pledge: "扇区质押",
    pre_deposits: "预质押",
    locked_balance: "锁仓奖励",
    balance_tip: "账户余额 = 可用余额 + 扇区质押 + 预质押 + 锁仓奖励",
    available_balance_tip: "账户中除质押、锁仓之外的可支出金额",
    init_pledge_tip: "复制证明第二阶段成功后实际质押的金额",
    pre_deposits_tip: "复制证明第一阶段预质押金额，待第二阶段按时提交证明成功后按扇区实际质押多退少补；反之超时未提交，则会被罚没",
    locked_balance_tip: "出块奖励未释放的部分，随着时间线性释放",
    sector_count: "全部",
    live_sector_count: "有效",
    fault_sector_count: "错误",
    recover_sector_count: "恢复",
    eth_address: "ETH Address",
    stable_address: "稳定地址",
    tokenList: "名下资产",
    showContract: "合约: {{value}}",
    showAddress: "地址: {{value}}",
    //统计指标
    indicators: "统计指标",
    power_increase_indicators: "算力增量",
    power_ratio: "算力增速",
    sector_increase: "扇区增量",
    precommit_deposits: "质押增量",
    gas_fee: "Gas消耗",
    block_rewards: "出块奖励",
    block_count: "出块数量",
    block_count_tip: "出块数 = 出块数量（block）的总和",
    mining_efficiency: "效率",
    mining_efficiency_tip: "选定周期内，节点累计出块奖励与有效算 力的比值",
    lucky: "幸运值",
    lucky_tip: "实际爆块数量和理论爆块数量的比值。若有效算力低于1PiB，则该值存在较大随机性， 仅供参考",
    sector_ratio: "扇区增速",
    sector_ratio_tip: "",
    win_count: "赢票数量",
    windowPost_gas: "维持算力消耗",
    win_count_tip: "Filecoin经济模型中，一个高度 （tipset）下可能有多个区块（block），每 个区块可能获得多份奖励（win count）。 累计出块份数=每次出块获得奖励份数的总和",
    net_profit_per_tb: "单T消耗",
    net_profit_per_tb_tip: "选定周期内单T封装扇区大小Gas消耗",
    //账户变化
    account_change: "账户变化",
    power: "有效算力",
    power_increase: "有效算力增长",
    quality_adjust_power: "有效算力",
    quality_power_rank: "排名",
    raw_power_percentage: "算力占比",
    raw_power: "原值算力",
    total_block_count: "30天出块数",
    total_block_count_tip: "近30天总出块数",
    total_reward: "30天奖励",
    total_reward_tip: "近30天奖励",
    total_win_count: "30天赢票",
    total_win_count_tip: "近30天总赢票",
    sector_size: "扇区大小",
    sector_status: "扇区状态",
    //账户总览
    account_overview: "账户总览",
    create_time: "创建时间",
    account_type: "账户类型",
    peer_id: "节点标识",
    peer_detail: "节点详情",
    account_address: "地址",
    // eslint-disable-next-line no-dupe-keys
    owner_address: "Owner",
    area: "地区",
    worker_address: "Worker",
    controllers_address: "Controller",
    beneficiary_address: "Beneficiary",
    code_cid: "代码 CID",
    nonce: "Nonce 数",
    contract_verify: "合约",
    contract_name: "合约名称",
    //miner
    //pool_overview_title:'账户',
    //power_change
    power_change: "算力变化",
    owned_active_miners: "实际工作节点",
    miner_owner: "节点存储者",
    no_area: "未知",
    // message
    message_overview_detail: "交易明细",
    trade: "内部交易",
    message_detail: "概况",
    event_log: "事件日志",
    message_overview: "消息概览",
    eth_message: "ETH Hash",
    cid: "消息ID",
    height: "高度",
    time: "时间",
    blk_cids: "区块",
    value: "金额",
    from: "发送地址",
    to: "接收地址",
    status: "状态",
    method_name: "方法",
    message_other: "其他信息",
    version: "版本编号",
    // eslint-disable-next-line no-dupe-keys
    nonce: "Nonce",
    gas_fee_cap: "手续费率上限",
    gas_premium: "节点小费费率",
    gas_limit: "Gas用量上限",
    gas_used: "Gas实际用量",
    base_fee: "基础手续费率",
    all_gas_fee: "手续费",
    params: "参数",
    returns: "返回值",
    message_tranf: "转账信息",
    from_tranf: "发送方",
    to_tranf: "接受方",
    consume_type: "类型",
    MinerTip: "节点手续费",
    BaseFeeBurn: "销毁手续费",
    // Transfer: '转账',
    // Burn: '销毁聚合费用',
    exit_code: "状态",
    err_message: "错误信息",
    replaced: "消息被覆盖",
    base_cid: "被覆盖CID",
    replaced_detail: "消息 {{value}} 已被 {{newValue}} 覆盖",
    robust_address: "Robust Address",
    //内部交易
    amount: "价值",
    method: "方法",
    topic: "主题",
    //通证转移
    message_ERC20Trans: "通证转移",
    message_NftTrans: "NFTs 转移",
    // 出块列表
    block_cid: "区块Cid",
    block_height: "区块高度",
    block_time: "出块时间",
    block_messages_count: "消息数",
    block_miner_id: "节点地址",
    block_mined_reward: "出块奖励",
    //miner
    message_list: "消息列表",
    block_list: "出块列表",
    traces_list: "转账列表",
    event_log: "事件日志",
    blk_cids_message: "区块消息",
    message_list_total: "共 {{value}} 条消息",
    block_list_total: "总计 {{value}} 区块",
    traces_list_total: "总计 {{value}} 条消息",
    contract_token_list_total: "总计 {{value}} 条Token",
    erc20_transfer_total: "总计 {{value}} 条交易",
    //general
    general_overview_title: "账户概览",
    base_account_id: "账户ID",
    message_count: "消息数",
    //dns detail
    deal_details: "订单详情",
    deal_id: "交易ID",
    epoch: "所属区块",
    service_start_time: "创建时间",
    message_cid: "所属消息",
    piece_cid: "Piece CID",
    verified_deal: "已验证",
    deal_hosting: "托管详情",
    deal_left_title: "客户",
    deal_right_title: "托管节点",
    deal_value: "质押金额",
    deal_cash: "托管费用",
    deal_time: "至",
    user_count: "交易地址",
    transfer_count: "交易次数",
    go_verify: "去验证",
    contract_token_list: "Token",
    token_name: "Token Name",
    contract_id: "Contract Id",
    amount: "Amount",
    //erc20 transfer
    erc20_transfer: "Token交易",
    platform: "交易平台",
    //height
    blcok_time: "区块时间",
    message_count_deduplicate: "区块消息 (去重)",
    miner_id: "节点",
    messages_count: "消息",
    reward: "奖励",
    //cid detail
    block_list: "区块列表",
    blocks_cid: "Cid",
    blocks_miner: "节点",
    blocks_messages: "消息",
    blocks_reward: "奖励",
    win_count: "赢票",
    //cid_details
    message_list_total: "共 {{value}} 条消息",
    chain_cid_detail: "区块详情",
    cid_height: "高度",
    parent_weight: "父块重量",
    parents_cid: "父块CID",
    parent_base_fee: "父基础费率",
    ticket_value: "票值",
    state_root: "根",
    total_balance_tip: "可用余额 + 扇区质押 + 预质押 + 锁仓奖励",
    //pendingMsg
    pending_title: "待处理消息",
    pending_total: "共 {{value}} 条消息待处理"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (detail);


/***/ }),

/***/ 9577:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const domain = {
    domain_title: "概览",
    resolved_address: "解析地址",
    expired_at: "过期时间",
    registrant: "注册人",
    controller: "控制人",
    allDomains: "此地址拥有的域名 共{{value}} 个",
    Result_for: "查询结果"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (domain);


/***/ }),

/***/ 83124:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fevm = {
    tp_token: "添加Token到TokenPocket",
    rank: "排行",
    defi_overview: "DeFi 协议",
    fevm_staked: "FEVM 质押量",
    staked_change_in_24h: "24小时质押",
    total_user: "总用户数",
    user_change_in_24h: "24小时用户数",
    fil_staked: "FIL 质押量",
    defi_list: "DeFi Protocol",
    Protocol: "协议",
    defi_list_time: "上次更新时间: {{value}}",
    tvl: "总锁仓价值",
    tvl_change_rate_in_24h: "24小时变化",
    tvl_change_in_24h: "24小时质押",
    tokens: "占比",
    tokens_tip: "质押在该协议的各Token占比",
    users: "用户数",
    see_more: "查看更多"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fevm);


/***/ }),

/***/ 38826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fvm = {
    hot: "All",
    all: "FVM生态项目总览",
    Defi: "Defi",
    Dex: "Dex",
    DID: "DID",
    NFT: "NFT",
    MarketPlace: "MarketPlace",
    Launchpad: "Launchpad",
    share: "分享FVM生态信息"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fvm);


/***/ }),

/***/ 3075:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const home = {
    seconds: "秒",
    minutes: "分",
    hours: "时",
    day: "天",
    //mata
    "quality_power/increase_24h": "全网有效算力/24h变化",
    add_power_in_32g: "32GiB扇区新增成本",
    miner_initial_pledge: "当前扇区质押量",
    fil_per_tera_24h: "近24h产出效率",
    total_contract: "活跃合约数",
    total_contract_24h_contract: "活跃合约数24h变化",
    "total_contract/24h_contract": "活跃合约数/24h变化",
    contract_transaction: "合约交易数",
    contract_transaction_24h_change: "合约交易数24h变化",
    "contract_transaction/24h_change": "合约交易数/24h变化",
    contract_address: "合约交易地址",
    contract_address_24h_change: "合约交易地址24h变化",
    "contract_address/24h_change": "合约交易地址/24h变化",
    "total_contract/24h_contract_tip": "网络中曾有过交易的合约总数",
    gas_24: "24h Gas消耗",
    verified_contracts: "已验证合约",
    contract_gas: "合约Gas消耗",
    //meta
    meta_title: "全网数据指标",
    mata_show: "展开",
    mata_show_false: "收起",
    latest_height: "最新区块高度",
    latest_block_time: "最新区块时间",
    total_blocks: "全网出块数量",
    total_rewards: "全网出块奖励",
    total_quality_power: "全网有效算力",
    total_quality_power_tip: "当前全网有效算力（有效存储空间）的总和",
    base_fee: "当前基础费率",
    power_increase_24h: "近24h增长算力",
    rewards_increase_24h: "近24h出块奖励",
    fil_per_tera_24h_tip: "最近24小时的总出块奖励与有效算力的比值",
    gas_in_32g: "24小时32G扇区封装每T所需Gas",
    gas_in_32g_meta: "32GiB扇区Gas消耗",
    gas_in_32g_tip: "近24小时密封32G扇区每T所要消耗的Gas值",
    add_power_in_32g_tip: "近24小时32G扇区新增算力所需要花费的成本，包括扇区质押和封装手续费",
    gas_in_64g: "24小时64G扇区封装每T所需Gas",
    gas_in_64g_meta: "64GiB扇区Gas消耗",
    gas_in_64g_tip: "近24小时密封64G扇区每T所要消耗的Gas值",
    add_power_in_64g: "64GiB扇区新增算力成本",
    add_power_in_64g_tip: "近24小时64G扇区新增算力所需要花费的成本，包括扇区质押和封装手续费",
    win_count_reward: "每赢票奖励",
    win_count_reward_tip: "最新高度的单位出块奖励，每个高度有多个区块，每个区块均可获得该奖励",
    avg_block_count: "平均每高度区块数量",
    avg_block_count_tip: "最近24h平均每个高度下的区块数量",
    avg_message_count: "平均每高度消息数",
    avg_message_count_tip: "最近24h平均每个高度下的消息数量",
    active_miners: "活跃节点数",
    burnt: "销毁量",
    circulating_percent: "流通率",
    proportion_64G: "32GiB扇区有效算力占比",
    proportion_32G: "64GiB扇区有效算力占比",
    contract_balance: "合约余额",
    rank: "排行榜",
    footer_text: "Filscan浏览器是 Filecoin 区块链浏览器及数据服务平台.提供基于 Filecoin 的各类节点收益排行榜、区块链数据查询、可视化图表等一站式数据服务.",
    footer_outlook: "邮箱",
    footer_detail_a: "版权所有 \xa9 Filecoin开发补助计划 遵循",
    footer_detail_b: " 和 ",
    footer_detail_c: "版权协议",
    search_notFound: "搜索无结果",
    warn_text: "很遗憾，您输入的字符暂无结果",
    warn_details: "对不起！这是一个无效的字符串",
    go_home: "返回首页",
    quality_power_Cc: "Commited Capacity (CC)",
    quality_power_Dc: "DataCap (DC)",
    base_gas: "24h基础手续费走势",
    rank: "排行榜",
    contract_rank: "合约排行",
    defi_list: "DeFi Protocol",
    blockchain_browser: "区块浏览器",
    see_more: "查看更多"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (home);


/***/ }),

/***/ 93124:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const zh = {
    network_title: "当前网络",
    home: "首页",
    contract: "FEVM",
    login: "登录",
    contract_verify: "合约验证",
    contract_list: "已验证合约",
    contract_rank: "合约排行",
    defi_dashboard: "DeFi Protocol",
    analysis: "数据分析",
    analysis_market: "项目分析",
    analysis_fund: "资金穿透分析",
    token: "Tokens",
    nft: "NFTs",
    tipset: "区块链",
    tipset_chain: "区块",
    tipset_message: "消息",
    tipset_ranking: "富豪榜",
    tipset_transfer: "大额转账",
    tipset_dsn: "订单",
    "tipset_pool-message": "消息池",
    ranking: "排行榜",
    network_overview: "网络概览",
    statistics: "统计",
    statistics_gas: "Gas费趋势",
    statistics_base: "算力走势",
    statistics_fil: "FIL",
    statistics_charts: "数据统计",
    statistics_map: "节点地图",
    cw: "ChainWatch",
    develop: "开发者",
    resources: "资源",
    resources_tools: "常用工具",
    provider: "存储提供者",
    fvm: "Filecoin生态",
    fvm_all: "项目总览",
    active: "活动",
    account: "节点管家",
    language: "语言",
    network: "网络"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (zh);


/***/ }),

/***/ 23074:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const rankZh = {
    rank_title: "排行榜",
    rank: "排行榜",
    pool: "存储池排行",
    provider: "节点排行",
    growth: "算力增速",
    rewards: "节点收益",
    "24h": "24时",
    week_days: "7天",
    month: "30天",
    select_rank_all: "全部扇区",
    select_rank_32: "32G 扇区",
    select_rank_64: "64G 扇区",
    more: "更多",
    rank_time: "上次更新时间为",
    see_more: "查看更多",
    //存储池排行
    ranking: "排名",
    pool_owner: "Owner ID",
    pool_power: "有效算力",
    pool_efficiency_24h: "近24h产出效率",
    pool_increase_24h: "近24h算力增量",
    pool_block_count: "出块总数",
    pool_block_count_24h: "近24h出块总数",
    miner: "节点",
    // 节点排行
    provider_miner: "节点",
    provider_power_ratio: "有效算力/占比",
    provider_block_ratio: "近24h 出块/占比",
    provider_rewards_ratio: "近24h 奖励/占比",
    balance: "余额",
    //算力增速
    power_ratio: "算力增速",
    power_ratio_tip: "选定周期内，平均每天完成封装扇区的有效算力总和",
    quality_power_increase: "算力增量",
    quality_power_increase_tip: "选定周期内，节点的有效算力增量",
    quality_adj_power: "有效算力",
    raw_power: "原值算力",
    sector_size: "扇区大小",
    //节点收益
    "rewards/ratio": "出块奖励/占比",
    "rewards/ratio_tip": "在选定周期内，节点获得出块奖励与累计产出区块奖励的比值。",
    block_count: "出块数",
    winning_rate: "赢票率",
    block_count_tip: "Filecoin经济模型中，一个高度（tipset）下可能有多个区块（block），每个区块可能获得多份奖励（win count）。"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rankZh);


/***/ }),

/***/ 76517:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const statistic = {
    gas_total: "Gas 统计",
    show_more: "更多",
    "24h": "24时",
    "7d": "7天",
    "30d": "30天",
    "1year": "1年",
    // power
    power: "算力走势",
    power_tips: "基线标准即是FILecoin网络要求的网络增长规模，主网上线时2.5EiB，每年100%增长率。",
    trend_24: "24h基础手续费走势",
    total_raw_byte_power: "原值算力",
    base_line_power: "基线走势",
    power_increase: "算力净增",
    power_decrease: "算力损失",
    change_quality_adj_power: "环比有效算力变化",
    total_quality_adj_power: "有效算力",
    gas: "基础手续费走势",
    base_fee: "基础手续费",
    gas_in_32g: "32GiB 扇区Gas消耗",
    gas_in_64g: "64GiB 扇区Gas消耗",
    //24_gas
    gas_24: "24h Gas 数据",
    method_name: "消息类型",
    avg_gas_premium: "Gas Premium",
    avg_gas_limit: "平均Gas限额",
    avg_gas_used: "平均Gas消耗",
    avg_gas_fee: "平均手续费",
    "sum_gas_fee/ratio": "手续费合计/占比",
    "message_count/ratio": "消息数合计/占比",
    //fil
    TokenRules: "FILecoin通证分配细则",
    FILecoinFoundation: "FILecoin基金会",
    FundraisingRemainder: "募资 – 剩余通证",
    FundraisingSAFT: "募资 – 未来通证简单协议",
    MiningReserve: "为存储服务提供者预留通证",
    TokenAllocation: "存储提供者通证分配",
    ReservedTokens: "存储提供者预留通证",
    Fundraising: "募资形式 – 未来通证简单协议 2017",
    Funds: "募资形式 – 剩余资金",
    protocolLab: "协议实验室",
    Contributors: "协议实验室团队和贡献者",
    Allocation: "分配项目",
    value: "数额",
    description: "具体用途",
    filBase: "FIL的基础发放",
    filBase_des: "网络FIL铸造上限",
    ReservedTokens_des: "为未来FILecoin经济增长而预留的通证储备，具体未来使用方案由FILecoin社区决定",
    TokenAllocation_des: "通过区块奖励、网络初始化等方式分给存储提供者的通证奖励",
    FILecoinFoundation_des: "作为长期社区建设，网络管理费用等",
    Fundraising_des: "2017年出售的通证",
    Funds_des: "用作生态发展和后续融资",
    protocolLab_des: "用作协议实验室的相关工作",
    Contributors_des: "4.5%给协议实验室团队和贡献者",
    //chartsnav
    cc_dc_power: "CC/DC算力走势",
    static_overview: "数据统计",
    contract_trend: "合约交易",
    //charts
    pie_title: "图表统计",
    fil_overview: "FIL概览",
    block_trend: "区块奖励",
    block_reward_per_TiB: "产出效率",
    acc_block_rewards: "累计区块奖励",
    active_nodes: "活跃节点数",
    active_miner_count: "节点数量",
    messages_trend: "消息数走势图",
    message_count: "区块平均消息走势",
    all_message_count: "总消息走势",
    pie_title_a: "当前FIL的用途分布统计",
    pie_title_a_tip: "已提供存储者奖励的FIL + 已释放锁仓奖励的FIL + 已分配保留部分的FIL = 当前已释放的FIL",
    pie_title_b: "当前已释放的FIL用途统计",
    charts_title: "FIL分配细则",
    mined: "已提供存储者奖励的FIL",
    remaining_mined: "剩余存储者奖励的FIL",
    vested: "已释放锁仓奖励的FIL	",
    remaining_vested: "剩余锁仓奖励的FIL",
    reserve_disbursed: "已分配保留部分的FIL(测试网奖励)",
    remaining_reserved: "剩余保留部分的FIL",
    locked: "扇区抵押的FIL",
    burnt: "已销毁的FIL",
    circulating: "可交易流通的FIL",
    dc_trend: "DC",
    cc_trend: "CC",
    networks_overview: "全网指标",
    contract_con: "合约部署走势",
    contract_counts: "合约部署",
    contract_gas: "合约Gas消耗",
    contract_addr: "合约交易地址",
    contract_balance: "合约余额走势",
    contract_total_balance: "合约余额",
    //cw
    "cw-search": "搜索高度/区块cid",
    cw_des: "拖拽以查看不同高度",
    cw_top: "最新高度"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (statistic);


/***/ }),

/***/ 63061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const tipset = {
    rank: "排名",
    tag: "标签",
    height: "区块高度",
    cid: "消息ID",
    block_time: "时间",
    from: "发送地址",
    to: "接收地址",
    value: "数额",
    method_name: "方法",
    all: "全部方法",
    //chain
    block_list: "区块列表",
    blocks_cid: "Cid",
    blocks_miner: "节点",
    blocks_messages: "消息",
    blocks_reward: "奖励",
    win_count: "赢票",
    //cid_details
    message_list_total: "共 {{value}} 条消息",
    chain_cid_detail: "区块详情",
    cid_height: "高度",
    parent_weight: "父块重量",
    parents_cid: "父块CID",
    parent_base_fee: "父基础费率",
    ticket_value: "票值",
    state_root: "根",
    //message
    message_list: "消息列表",
    total_list: "共 {{value}} 条消息",
    message_list_all: "全部方法",
    message_list_exit_code: "状态",
    message_list_method_name: "方法名称",
    // adress
    address_total_list: "共有 {{value}} 账户",
    address_list: "富豪榜",
    address_all: "全部类型",
    balance_change_7: "余额变化",
    fund: "资金穿透",
    go_fund: "去查看",
    account: "一般账户",
    owner: "所有者账户",
    miner: "节点账户",
    payment: "支付通道",
    multisig: "多签账户",
    account_address: "地址",
    balance_percentage: "余额/占比",
    account_type: "类型",
    latest_transfer_time: "最新交易时间",
    //transfer
    transfer_list: "大额转账",
    transfer_total_list: "共有 {{value}} 条信息",
    //dsn
    dsn_list: "订单列表",
    dsn_total_list: "共 {{value}} 条交易",
    dsn_placeholder: "搜索 客户/托管者/交易ID",
    deal_id: "交易ID",
    piece_cid: "文件ID",
    piece_size: "文件大小",
    client_address: "客户",
    provider_id: "托管者",
    service_start_time: "开始时间",
    end_time: "结束时间",
    start_height: "开始高度",
    end_height: "结束高度",
    storage_price_per_height: "存储费用",
    verified_deal: "已验证",
    // pool-message
    pool_list: "消息池列表",
    gas_fee_cap: "Gas限额",
    gas_premium: "Gas Premium"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (tipset);


/***/ }),

/***/ 98402:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const user = {
    date: "日期",
    day: "天",
    confirm: "确认",
    cancel: "取消",
    //会员
    member_header: "如果你担心或碰到过以下问题",
    power_title: "算力掉落",
    power_text: "扇区大批出错，致使算力锐减却无法及时获知，导致出块奖励损失惨重",
    balance_title: "账户余额不足",
    balance_text: "账户余额不足，却无法及时获取信息，导致扇区封装或维持失败",
    sector_title: "扇区到期",
    sector_text: "扇区到期了算力也跟着掉落，才想起应该早点续期，有个提醒就好了",
    warn_power: "算力监控",
    warn_balance: "余额监控",
    warn_sector: "扇区监控",
    warn_email: "邮箱告警",
    warn_msg: "短信告警",
    warn_phone: "电话告警",
    data_text: "重点信息一站式监控",
    warn_text: "告警渠道多样，灵活配置",
    member_content_title: "会员等级",
    companies: "企业会员",
    companiesPro: "企业Pro版",
    companies_1: "30个节点上限",
    companies_2: "算力监控",
    companies_3: "余额监控",
    companies_4: "扇区监控",
    companies_5: "更多（敬请期待）",
    companies_6: "技术服务支持",
    monthly: "月度会员",
    quarter: "季度会员",
    year: "年度会员",
    quarter_discount: "低于8.8折",
    year_discount: "低于8.0折",
    share_friend: "邀请朋友，赠送一个月黄金会员",
    share_turn: "即刻开启，最大化减少损失"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (user);


/***/ }),

/***/ 50275:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7947);
/* harmony import */ var antd_lib_message__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17369);
/* harmony import */ var antd_lib_message__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_message__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


// 创建一个全局的消息管理器
const messageManager = {
    hideMessage: null,
    showMessage: ({ type, duration = 10, content, icon, suffix })=>{
        if (messageManager.hideMessage) {
            messageManager.hideMessage();
        }
        const show_config = {};
        if (icon) {
            show_config.icon = icon;
        }
        messageManager.hideMessage = antd_lib_message__WEBPACK_IMPORTED_MODULE_2___default().open({
            content: suffix ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex items-center gap-x-4",
                children: [
                    content,
                    " ",
                    suffix
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex items-center gap-x-4",
                children: [
                    content,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "cursor-pointer",
                        onClick: ()=>{
                            messageManager.hide();
                        },
                        children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("closeIcon")
                    })
                ]
            }),
            duration,
            type,
            ...show_config
        });
    },
    hide: ()=>{
        if (messageManager.hideMessage) {
            messageManager.hideMessage();
            messageManager.hideMessage = null;
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (messageManager);


/***/ }),

/***/ 76423:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7947);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__]);
_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ options, ns = "home", onChange, header, wrapClassName, className, value, suffix, optionsCard })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns
    });
    const [showLabel, setShowLabel] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(value);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (value && Array.isArray(options)) {
            const file = options.find((v)=>v.value === value);
            setActive(value);
            if (file) setShowLabel(file?.label);
        } else if (options && options.length > 0) {
            setShowLabel(options[0]?.label);
            setActive(options[0]?.value);
        }
    }, [
        options,
        value
    ]);
    const handleClick = (item)=>{
        setShowLabel(item.label);
        setActive(item.value);
        onChange(item.value);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `group relative flex h-fit w-fit cursor-pointer items-center rounded-[5px]  ${wrapClassName}`,
        children: [
            header ? header : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "des_bg_color border_color flex !h-8 w-full min-w-[82px] items-center justify-between gap-x-2 rounded-[5px] border px-2 font-HarmonyOS  text-xs font-medium",
                children: [
                    tr(showLabel),
                    (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_3__/* .getSvgIcon */ .a)("downIcon")
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                style: {
                    padding: "15px"
                },
                className: `select_shadow border_color invisible absolute inset-y-full z-10 h-fit w-max list-none rounded-[5px]  border  group-hover:visible ${className}`,
                children: [
                    Array.isArray(options) && options?.map((item)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            onClick: ()=>handleClick(item),
                            className: `rounded-[5px] p-2 hover:text-primary ${item.value === active ? "bg-bg_hover text-primary" : ""}`,
                            children: tr(item.label)
                        }, item.value);
                    }),
                    optionsCard && optionsCard
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 92642:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(69348);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


const EllipsisText = ({ text, className })=>{
    const textRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const [isOverflowing, setIsOverflowing] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const checkOverflow = ()=>{
            const element = textRef.current;
            if (element) {
                const computedStyle = window.getComputedStyle(element);
                const paddingLeft = parseFloat(computedStyle.paddingLeft);
                const paddingRight = parseFloat(computedStyle.paddingRight);
                setIsOverflowing(element.offsetWidth < element.scrollWidth + paddingLeft + paddingRight || element.offsetHeight < element.scrollHeight);
            }
        };
        window.addEventListener("resize", checkOverflow);
        checkOverflow();
        return ()=>window.removeEventListener("resize", checkOverflow);
    }, [
        text
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default()), {
        title: isOverflowing ? text : "",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            ref: textRef,
            className: ` overflow-hidden text-ellipsis ${className} ${isOverflowing ? "cursor-pointer" : "cursor-default"}`,
            children: text
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EllipsisText);


/***/ }),

/***/ 44178:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _styles_iconfont_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16836);
/* harmony import */ var _styles_iconfont_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_iconfont_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(86764);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_common_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57526);
/* harmony import */ var _styles_common_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_common_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_custom_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(66333);
/* harmony import */ var _styles_custom_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_custom_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _styles_mixins_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(41387);
/* harmony import */ var _styles_mixins_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_mixins_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var antd_lib_config_provider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(92616);
/* harmony import */ var antd_lib_config_provider__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(antd_lib_config_provider__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var antd_lib_theme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(86653);
/* harmony import */ var antd_lib_theme__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(antd_lib_theme__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var antd_lib_locale_zh_CN__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(79353);
/* harmony import */ var antd_lib_locale_zh_CN__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd_lib_locale_zh_CN__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var antd_lib_locale_en_US__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4946);
/* harmony import */ var antd_lib_locale_en_US__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(antd_lib_locale_en_US__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_header__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3340);
/* harmony import */ var _components_Bounday__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(78980);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(16641);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_footer__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(44753);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(29676);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _components_mobile_search__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8825);
/* harmony import */ var _app_module_scss__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(56209);
/* harmony import */ var _app_module_scss__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(_app_module_scss__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var _store_DeviceContext__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(42707);
/* harmony import */ var _i18n__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(21091);
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(7544);
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(next_app__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _contents_common__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(5934);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(6991);
/* harmony import */ var _src_account_member__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(27312);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(25572);
/* harmony import */ var _src_user_Warn__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(11758);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_header__WEBPACK_IMPORTED_MODULE_11__, _components_footer__WEBPACK_IMPORTED_MODULE_15__, _components_mobile_search__WEBPACK_IMPORTED_MODULE_18__, _i18n__WEBPACK_IMPORTED_MODULE_20__, _contents_common__WEBPACK_IMPORTED_MODULE_22__, _src_account_member__WEBPACK_IMPORTED_MODULE_26__, _src_user_Warn__WEBPACK_IMPORTED_MODULE_28__]);
([_components_header__WEBPACK_IMPORTED_MODULE_11__, _components_footer__WEBPACK_IMPORTED_MODULE_15__, _components_mobile_search__WEBPACK_IMPORTED_MODULE_18__, _i18n__WEBPACK_IMPORTED_MODULE_20__, _contents_common__WEBPACK_IMPORTED_MODULE_22__, _src_account_member__WEBPACK_IMPORTED_MODULE_26__, _src_user_Warn__WEBPACK_IMPORTED_MODULE_28__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 





























const antdTheme = (antd_lib_theme__WEBPACK_IMPORTED_MODULE_7___default());
App.getInitialProps = async (context)=>{
    const initialProps = await next_app__WEBPACK_IMPORTED_MODULE_21___default().getInitialProps(context);
    const regex = RegExp("Android|iPhone");
    if (context.ctx.req) {
        return {
            ...initialProps,
            isMobile: regex.test(context.ctx.req.headers["user-agent"])
        };
    }
    return {
        isMobile: window.innerWidth < 1000,
        ...initialProps
    };
};
//@ts-ignore
function App({ Component, pageProps, isMobile }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_14__.useRouter)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(true);
    const { theme, lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_27__["default"];
    const [wallet, setWallet] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)({
        wallet: "",
        account: ""
    });
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        loadTheme(theme);
    }, [
        theme
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        const theme_Local = localStorage.getItem("theme");
        let lang_Local = localStorage.getItem("lang");
        const wallet_local = localStorage.getItem("wallet");
        const wallet_store = JSON.parse(wallet_local || "{}");
        if (!wallet?.account) {
            setWallet(wallet_store);
        }
        if (router.locale) {
            lang_Local = router.locale;
        }
        if (!lang_Local) {
            lang_Local = navigator.language.startsWith("zh") ? "zh" : "en";
        }
        loadTheme(theme_Local);
        if (theme_Local) _store_modules_filscan__WEBPACK_IMPORTED_MODULE_27__["default"].setTheme(theme_Local);
        _i18n__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z.changeLanguage(lang_Local) // 更改i18n语言
        ;
        if (lang_Local) _store_modules_filscan__WEBPACK_IMPORTED_MODULE_27__["default"].setLang(lang_Local);
        setLoading(false);
        if (true) {
            window.addEventListener("resize", onResize);
            return ()=>{
                window.removeEventListener("resize", onResize);
            };
        }
    }, []);
    const onResize = ()=>{
        // const theme_Local = localStorage.getItem('theme')
        if (window.innerWidth < 1000) {
            isMobile = true;
            loadTheme("light");
            return;
        }
        isMobile = false;
    // loadTheme(theme_Local)
    };
    const loadTheme = (theme_Local)=>{
        if (theme_Local === "dark" && !isMobile) {
            document.documentElement.setAttribute("theme", "dark");
        } else {
            document.documentElement.setAttribute("theme", "light");
        }
    };
    if (loading) {
        return null;
    }
    const seo = _contents_common__WEBPACK_IMPORTED_MODULE_22__/* .SEO */ .HJ[lang];
    let themeProps = {};
    if (theme === "dark") {
        themeProps = {
            algorithm: antdTheme.darkAlgorithm
        };
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_13__.NextSeo, {
                title: seo.title,
                description: seo.description,
                canonical: seo.url,
                additionalMetaTags: [
                    {
                        name: "keywords",
                        content: seo.keywords
                    }
                ],
                languageAlternates: [
                    {
                        hrefLang: "en",
                        href: "https://filscan.io/en"
                    },
                    {
                        hrefLang: "zh",
                        href: "https://filscan.io/zh"
                    }
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_23___default()), {
                async: true,
                src: "https://www.googletagmanager.com/gtag/js?id=G-PTPP25W83T"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_23___default()), {
                id: "google-analytics",
                children: `
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());

          gtag('config', 'G-PTPP25W83T');
        `
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(mobx_react__WEBPACK_IMPORTED_MODULE_24__.Provider, {
                ..._store__WEBPACK_IMPORTED_MODULE_25__,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Bounday__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_store_DeviceContext__WEBPACK_IMPORTED_MODULE_19__/* .DeviceContext */ .T.Provider, {
                        value: {
                            isMobile
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_config_provider__WEBPACK_IMPORTED_MODULE_6___default()), {
                            locale: lang === "zh" ? (antd_lib_locale_zh_CN__WEBPACK_IMPORTED_MODULE_8___default()) : (antd_lib_locale_en_US__WEBPACK_IMPORTED_MODULE_9___default()),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_17___default()(`container_body text-sm ${theme}`),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_header__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_16__/* .MobileView */ .$, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_mobile_search__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                            className: (_app_module_scss__WEBPACK_IMPORTED_MODULE_29___default().search)
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_17___default()((_app_module_scss__WEBPACK_IMPORTED_MODULE_29___default().home), (_app_module_scss__WEBPACK_IMPORTED_MODULE_29___default().component), "chart-wrapper"),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                                ...pageProps
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_user_Warn__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z, {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_member__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {})
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footer__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {})
                                ]
                            })
                        })
                    })
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_router__WEBPACK_IMPORTED_MODULE_14__.withRouter)((0,mobx_react__WEBPACK_IMPORTED_MODULE_24__.observer)(App)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 13162:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52727);
/* harmony import */ var _ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(56859);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_3__);




const MyDocument = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_3__.Html, {
        lang: "en",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_3__.Head, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Filscan Filecoin Explorer"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        httpEquiv: "X-UA-Compatible",
                        content: "IE=edge,chrome=1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0, minimum-scale=1,user-scalable=no"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Filscan.io is a Filecoin blockchain explorer and data service platform.It offers a range of one-stop data services, including mining ranking, blockchain data query, visualization charts, and FVM ecosystem data analysis."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "keywords",
                        content: "Filecoin官方区块浏览器,Filecoin官方浏览器, Filecoin Explorer,fvm,Filscan,Filecoin, blockchain,filfox,飞狐浏览器,filutils, crypto, starboard,currency,最新区块,FIL,IPFS，FIL,Filecoin区块链查询浏览器,FIL浏览器,Filecoin浏览器,Filecoin区块查询,区块链搜索引擎,区块高度,区块链交易"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "alternate",
                        href: "https://filscan.io/kr",
                        hrefLang: "kr-US"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "alternate",
                        href: "https://filscan.io/en",
                        hrefLang: "en-US"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "alternate",
                        href: "https://filscan.io",
                        hrefLang: "zh-CN"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "https://filscan-v2.oss-accelerate.aliyuncs.com/client/logo.ico"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        href: "https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css",
                        rel: "stylesheet"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
                        async: true,
                        src: "https://www.googletagmanager.com/gtag/js?id=G-PTPP25W83T"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
                        dangerouslySetInnerHTML: {
                            __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', 'G-PTPP25W83T');
            `
                        }
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("body", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_3__.Main, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_3__.NextScript, {})
                ]
            })
        ]
    });
MyDocument.getInitialProps = async (ctx)=>{
    const cache = (0,_ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_2__.createCache)();
    const originalRenderPage = ctx.renderPage;
    ctx.renderPage = ()=>originalRenderPage({
            enhanceApp: (App)=>(props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_2__.StyleProvider, {
                        cache: cache,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(App, {
                            ...props
                        })
                    })
        });
    const initialProps = await next_document__WEBPACK_IMPORTED_MODULE_3___default().getInitialProps(ctx);
    const style = (0,_ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_2__.extractStyle)(cache, true);
    return {
        ...initialProps,
        styles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                initialProps.styles,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("style", {
                    dangerouslySetInnerHTML: {
                        __html: style
                    }
                })
            ]
        })
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyDocument);


/***/ }),

/***/ 85857:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(76418);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_modal__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _share_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(64744);
/* harmony import */ var _share_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_share_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27701);
/* harmony import */ var _components_QR__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45973);
/* harmony import */ var html2canvas__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7276);
/* harmony import */ var html2canvas__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(html2canvas__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _assets_images_member_ActiveZh_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(29978);
/* harmony import */ var _assets_images_member_activeEn_png__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(61941);
/* harmony import */ var _assets_images_member_activeKr_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(39747);
/* harmony import */ var _assets_images_member_gift_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3711);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _store_modules_filscan__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(25572);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_account__WEBPACK_IMPORTED_MODULE_4__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_account__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_13__.observer)((props)=>{
    const { inviteCode, show, onChange } = props;
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const { lang } = _store_modules_filscan__WEBPACK_IMPORTED_MODULE_12__["default"] // 使用你的 store 获取 lang 状态
    ;
    const shareRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null);
    const handleSave = ()=>{
        if (shareRef.current) {
            html2canvas__WEBPACK_IMPORTED_MODULE_6___default()(shareRef?.current, {
                useCORS: true,
                scrollY: 0,
                allowTaint: false,
                backgroundColor: "transparent"
            }).then((canvas)=>{
                const imgData = canvas.toDataURL("image/png");
                const link = document.createElement("a");
                link.href = imgData;
                link.download = `filscan-active.png`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            });
        }
    };
    const imgSrc = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (lang === "zh") {
            return _assets_images_member_ActiveZh_png__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z;
        } else if (lang === "kr") {
            return _assets_images_member_activeKr_png__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z;
        }
        return _assets_images_member_activeEn_png__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z;
    }, [
        lang
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().detail),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_modal__WEBPACK_IMPORTED_MODULE_2___default()), {
            destroyOnClose: true,
            closeIcon: false,
            wrapClassName: "custom_modal noPaddingModal " //noTopModal
            ,
            open: show,
            width: 416,
            footer: null,
            onCancel: ()=>{
                onChange(false);
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().activeShare),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share),
                        ref: shareRef,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_top),
                                style: {
                                    width: "416px",
                                    height: "580px"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_main),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_content),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: `${(_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_content_icon)} ${(_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_content_top)}`
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: `${(_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_content_icon)} ${(_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_content_top)} ${(_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_content_right)}`
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: `${(_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_content_icon)} ${(_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_content_bottom)}`
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: `${(_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_content_icon)} ${(_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_content_bottom)} ${(_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_content_Bright)}`
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_content_title),
                                                    children: tr("account_title")
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                    children: _contents_account__WEBPACK_IMPORTED_MODULE_4__/* .active_member_share */ .W6.map((v, index)=>{
                                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                            className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_content_item),
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    children: v.icon
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        children: tr(v.title)
                                                                    })
                                                                })
                                                            ]
                                                        }, index);
                                                    })
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_target),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            src: imgSrc,
                                            alt: "",
                                            className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_target_image)
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_invite),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: tr("invite_code")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_invite_content),
                                                children: inviteCode?.split("")?.map((v, index)=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_invite_item),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_invite_item_value),
                                                            children: String(v)
                                                        })
                                                    }, index);
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_bottom),
                                style: {
                                    width: "416px",
                                    height: "146px"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_bottom_code),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_QR__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            link: `https://filscan.io/admin/register/?inviteCode=${inviteCode}`
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_bottom_title),
                                                children: tr("scan_code")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_bottom_des),
                                                children: tr("active_des")
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_bottom_gift),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                        src: _assets_images_member_gift_png__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                                                        alt: "",
                                                        width: 20
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().share_bottom_gift_text),
                                                        children: tr("active_gift")
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_share_module_scss__WEBPACK_IMPORTED_MODULE_14___default().activeShare_save),
                        onClick: handleSave,
                        children: tr("active_save")
                    })
                ]
            })
        })
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 15788:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(76418);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_modal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd_lib_message__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17369);
/* harmony import */ var antd_lib_message__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_message__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(40945);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(62881);
/* harmony import */ var _assets_images_tgCode_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(69295);
/* harmony import */ var copy_to_clipboard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(68887);
/* harmony import */ var copy_to_clipboard__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(copy_to_clipboard__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7947);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_4__]);
_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_4__/* .Translation */ .W)({
        ns: "account"
    });
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const handleCopy = ()=>{
        copy_to_clipboard__WEBPACK_IMPORTED_MODULE_6___default()("Filscan.io");
        return antd_lib_message__WEBPACK_IMPORTED_MODULE_2___default().success("Clipboard Successfully");
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().member_btn)}  ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().member_btn_recommend)}`,
                onClick: ()=>setShow(true),
                children: tr("share_turn")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_modal__WEBPACK_IMPORTED_MODULE_1___default()), {
                title: "",
                width: 300,
                destroyOnClose: true,
                closeIcon: false,
                wrapClassName: "custom_modal noPaddingModal",
                open: show,
                onCancel: ()=>setShow(false),
                footer: null,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().tg_main),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().tg_icon),
                            children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_8__/* .getSvgIcon */ .a)("memberBg")
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().tg),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().tg_title),
                                    children: tr("tg_title")
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().tg_img),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        src: _assets_images_tgCode_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                        alt: ""
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().tg_des),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: "TG：@Filscan.io"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().tg_des_copy),
                                            onClick: handleCopy,
                                            children: tr("copy_tg")
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 27312:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(76418);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_modal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(40945);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62881);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(27701);
/* harmony import */ var _assets_images_member_left_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(35520);
/* harmony import */ var _assets_images_member_right_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(14522);
/* harmony import */ var _assets_images_member_vip_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(62539);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7947);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store_modules_user__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(63414);
/* harmony import */ var _assets_images_member_member_bg_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(80363);
/* harmony import */ var _addTg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(15788);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _active_Share__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(85857);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_3__, _store_modules_user__WEBPACK_IMPORTED_MODULE_9__, _addTg__WEBPACK_IMPORTED_MODULE_11__, _active_Share__WEBPACK_IMPORTED_MODULE_13__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_3__, _store_modules_user__WEBPACK_IMPORTED_MODULE_9__, _addTg__WEBPACK_IMPORTED_MODULE_11__, _active_Share__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_8__.observer)(()=>{
    const { vipModal } = _store_modules_user__WEBPACK_IMPORTED_MODULE_9__["default"];
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "account"
    });
    const { inviteCode, userInfo } = _store_modules_user__WEBPACK_IMPORTED_MODULE_9__["default"];
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_14__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_14__.useEffect)(()=>{
        if (userInfo?.mail) {
            _store_modules_user__WEBPACK_IMPORTED_MODULE_9__["default"].getInviteList();
        }
    }, [
        userInfo?.mail
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_modal__WEBPACK_IMPORTED_MODULE_1___default()), {
        title: ``,
        width: 880,
        destroyOnClose: true,
        closeIcon: false,
        wrapClassName: "custom_modal noPaddingModal LagerModal",
        open: vipModal,
        onOk: ()=>_store_modules_user__WEBPACK_IMPORTED_MODULE_9__["default"].setVipModal(false),
        onCancel: ()=>_store_modules_user__WEBPACK_IMPORTED_MODULE_9__["default"].setVipModal(false),
        footer: null,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().memberContent),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_header),
                            children: [
                                tr("member_header"),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_header_close),
                                    onClick: ()=>{
                                        _store_modules_user__WEBPACK_IMPORTED_MODULE_9__["default"].setVipModal(false);
                                    },
                                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("closeIcon")
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().content),
                            children: _contents_account__WEBPACK_IMPORTED_MODULE_3__/* .member_list_1 */ .TM.map((item)=>{
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().content_card),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().content_card_icon),
                                            children: item.icon
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().content_card_title),
                                            children: tr(item.title)
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().content_card_value),
                                            children: tr(item.value)
                                        })
                                    ]
                                }, item.title);
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_content_title),
                            children: tr("member_warn_title")
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().content),
                            children: _contents_account__WEBPACK_IMPORTED_MODULE_3__/* .member_list_2 */ .wD.map((item, index)=>{
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().content_card)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().content_newCard)}`,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().content_newCard_main)}`,
                                            children: item.title.map((v)=>{
                                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().content_newCard_item),
                                                    children: [
                                                        v.icon,
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: tr(v.title)
                                                        })
                                                    ]
                                                }, v.title);
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().content_newCard_text),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_left_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                                                tr(item.content),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_right_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                                            ]
                                        })
                                    ]
                                }, index);
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_content)}`,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_content_title)}`,
                                    children: tr("member_content_title")
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_content_main),
                                    children: Object.keys(_contents_account__WEBPACK_IMPORTED_MODULE_3__/* .member_main */ .RA).map((key, index)=>{
                                        const item = _contents_account__WEBPACK_IMPORTED_MODULE_3__/* .member_main */ .RA[key];
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_item)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default())[`member_item${index}`]}`,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_item_icon),
                                                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("memberBg")
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_itemMain),
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_itemMain_card),
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_itemMain_card_header),
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_item_card)}`,
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_item_card_title)}`,
                                                                                children: tr(item.title)
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_itemMain_card_icon),
                                                                                children: item.icon
                                                                            })
                                                                        ]
                                                                    }),
                                                                    index === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_12___default()), {
                                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_itemMain_card_iconBg),
                                                                        src: _assets_images_member_member_bg_png__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                                                                        alt: ""
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_item_list),
                                                                children: item.list.map((v)=>{
                                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_item_li),
                                                                        children: [
                                                                            v.icon,
                                                                            tr(v.title)
                                                                        ]
                                                                    }, v.title);
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_item_price),
                                                                children: item.priceList.map((priceItem, index)=>{
                                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_item_priceItem),
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                children: tr(priceItem.title)
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_item_priceValue),
                                                                                children: [
                                                                                    priceItem.discount && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_item_discount),
                                                                                        children: tr(priceItem.discount)
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_item_value),
                                                                                        children: priceItem.price
                                                                                    })
                                                                                ]
                                                                            })
                                                                        ]
                                                                    }, index);
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }, index);
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_btns)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().memberContent_btns)}`,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_btn)} ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_btnShare)}`,
                            onClick: ()=>{
                                setShow(true);
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().member_btnShare_icon),
                                    children: "Free VIP"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_vip_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                tr("share_friend")
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_active_Share__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            inviteCode: inviteCode,
                            show: show,
                            onChange: (value)=>{
                                setShow(value);
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_addTg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                    ]
                })
            ]
        })
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5039:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(53800);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(76418);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_lib_modal__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd_lib_switch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(32024);
/* harmony import */ var antd_lib_switch__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd_lib_switch__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__]);
_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ text, onChange, title })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const handleClick = ()=>{
        setShow(false);
        onChange();
    };
    const content = (0,react__WEBPACK_IMPORTED_MODULE_5__.useMemo)(()=>{
        if (title === "isActive") {
            return [
                "edit_status",
                "edit_status_content"
            ];
        } else if (title === "edit_delete") {
            return [
                "delete_rule",
                "delete_rule_content"
            ];
        }
        return [];
    }, [
        title
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            title === "edit_delete" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "cursor-pointer text-primary",
                onClick: ()=>setShow(true),
                children: tr("edit_delete")
            }),
            title === "isActive" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_switch__WEBPACK_IMPORTED_MODULE_4___default()), {
                className: "custom_switch",
                checked: !!text,
                onChange: ()=>{
                    if (title === "isActive" && !text) {
                        onChange();
                    } else {
                        setShow(true);
                    }
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_modal__WEBPACK_IMPORTED_MODULE_3___default()), {
                title: `${tr(content[0])}`,
                destroyOnClose: true,
                width: title === "isActive" ? 500 : 400,
                closeIcon: false,
                wrapClassName: "custom_modal custom_center_modal",
                open: show,
                onOk: handleClick,
                footer: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_2___default()), {
                        className: "cancel_btn",
                        onClick: ()=>{
                            setShow(false);
                        },
                        children: tr("cancel")
                    }, "cancel_btn"),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_2___default()), {
                        className: "primary_btn",
                        onClick: handleClick,
                        children: tr("confirm")
                    }, "confirm_btn")
                ],
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex justify-center ",
                    children: tr(content[1])
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 11758:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _store_modules_user__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63414);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(76418);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_modal__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _warn_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(57946);
/* harmony import */ var _warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_warn_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7947);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27701);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(62881);
/* harmony import */ var _assets_images_member_bgMore_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(78416);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_modules_user__WEBPACK_IMPORTED_MODULE_1__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_5__]);
([_store_modules_user__WEBPACK_IMPORTED_MODULE_1__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_7__.observer)(()=>{
    const { firstWarn } = _store_modules_user__WEBPACK_IMPORTED_MODULE_1__["default"];
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const item = _contents_account__WEBPACK_IMPORTED_MODULE_4__/* .member_main */ .RA.EnterpriseVIP;
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_5__/* .Translation */ .W)({
        ns: "account"
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_modal__WEBPACK_IMPORTED_MODULE_2___default()), {
        title: ``,
        width: 420,
        destroyOnClose: true,
        closeIcon: false,
        wrapClassName: "custom_modal noPaddingModal",
        open: firstWarn,
        onOk: ()=>_store_modules_user__WEBPACK_IMPORTED_MODULE_1__["default"].setVipModal(false),
        onCancel: ()=>_store_modules_user__WEBPACK_IMPORTED_MODULE_1__["default"].setVipModal(false),
        footer: null,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warnContent),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warn),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warn_icon),
                        children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_3__/* .getSvgIcon */ .a)("memberBg")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warn_close),
                        onClick: ()=>{
                            _store_modules_user__WEBPACK_IMPORTED_MODULE_1__["default"].setFirstWarn(false);
                        },
                        children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_3__/* .getSvgIcon */ .a)("closeIcon")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warn_content),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warn_main),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warn_main_left),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warn_main_left_icon),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "icon icon-logo"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: tr("free_send")
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                "7",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warn_main_left_unit),
                                                    children: tr("day")
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: item.icon
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warn_list),
                        children: _contents_account__WEBPACK_IMPORTED_MODULE_4__/* .active_member_share */ .W6.map((v, index)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warn_list_item),
                                children: [
                                    v.icon,
                                    tr(v.title)
                                ]
                            }, index);
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warn_btn),
                        onClick: ()=>{
                            _store_modules_user__WEBPACK_IMPORTED_MODULE_1__["default"].setFirstWarn(false);
                            router.push("/account/#monitorBalance");
                        },
                        children: [
                            tr("look_detail"),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warn_btn_icon),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_member_bgMore_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_warn_module_scss__WEBPACK_IMPORTED_MODULE_9___default().warn_btn_icon_text),
                                        children: tr("look_detail_member")
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 68446:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $c: () => (/* binding */ getRules),
/* harmony export */   BO: () => (/* binding */ minerCategory),
/* harmony export */   Cu: () => (/* binding */ saveRules),
/* harmony export */   FK: () => (/* binding */ ValidInvite),
/* harmony export */   Iq: () => (/* binding */ fundTransaction),
/* harmony export */   JE: () => (/* binding */ inviteList),
/* harmony export */   NK: () => (/* binding */ deleteRules),
/* harmony export */   Pn: () => (/* binding */ rewardData),
/* harmony export */   SM: () => (/* binding */ balanceData),
/* harmony export */   Sq: () => (/* binding */ fileTrend),
/* harmony export */   U8: () => (/* binding */ expiredData),
/* harmony export */   V9: () => (/* binding */ fileVestList),
/* harmony export */   VP: () => (/* binding */ verifyCode),
/* harmony export */   Vl: () => (/* binding */ filecoinValue),
/* harmony export */   Xz: () => (/* binding */ fileBase),
/* harmony export */   YA: () => (/* binding */ fileTokenTrend),
/* harmony export */   YB: () => (/* binding */ eventsList),
/* harmony export */   ZF: () => (/* binding */ saveGroup),
/* harmony export */   ZW: () => (/* binding */ deleteMiners),
/* harmony export */   _E: () => (/* binding */ fileTokens),
/* harmony export */   bl: () => (/* binding */ rulesActive),
/* harmony export */   c0: () => (/* binding */ resetPassword),
/* harmony export */   eF: () => (/* binding */ fileNetwork),
/* harmony export */   eY: () => (/* binding */ userInfo),
/* harmony export */   fc: () => (/* binding */ fileActive),
/* harmony export */   i0: () => (/* binding */ luckyData),
/* harmony export */   jQ: () => (/* binding */ inviteCode),
/* harmony export */   k5: () => (/* binding */ fileNetworkTrend),
/* harmony export */   ku: () => (/* binding */ countMiners),
/* harmony export */   nq: () => (/* binding */ powerData),
/* harmony export */   pp: () => (/* binding */ fundAddress),
/* harmony export */   rM: () => (/* binding */ fundInfo),
/* harmony export */   rc: () => (/* binding */ delGroup),
/* harmony export */   rn: () => (/* binding */ updateInfo),
/* harmony export */   rx: () => (/* binding */ saveMiner),
/* harmony export */   te: () => (/* binding */ minerOverview),
/* harmony export */   uy: () => (/* binding */ gasData),
/* harmony export */   wp: () => (/* binding */ marketKline),
/* harmony export */   wt: () => (/* binding */ UserGroups),
/* harmony export */   x4: () => (/* binding */ login)
/* harmony export */ });
/* unused harmony export fvmUrl */
const mainUrl = "https://api-v2.filscan.io/api/v1";
const testUrl = "http://192.168.19.80:17000/api/v1";
const testMain = "https://api-v2.filscan.io/pro/v1";
const proUrl = "https://api-v2.filscan.io/pro/v1";
const fvmUrl = (/* unused pure expression or super */ null && ("https://filscan-v2.oss-accelerate.aliyuncs.com/fvm_manage"));
//用户信息
const login = proUrl + "/Login";
const userInfo = proUrl + "/UserInfo";
const verifyCode = proUrl + "/SendVerificationCode";
const resetPassword = proUrl + "/ResetPasswordByCode";
const inviteCode = proUrl + "/UserInviteCode";
const inviteList = proUrl + "/UserInviteRecord";
const ValidInvite = proUrl + "/ValidInvite";
const updateInfo = proUrl + "/UpdateUserInfo";
//pro 项目分析
const fileBase = mainUrl + "/FilecoinBaseData";
const marketKline = mainUrl + "/GetFilecoinKLine";
const filecoinValue = mainUrl + "/GetFilecoinChange";
const fileTrend = mainUrl + "/GetFilecoinTrend";
const fileNetwork = mainUrl + "/NetworkCapital";
const fileNetworkTrend = mainUrl + "/NetworkCapitalFigure";
const fileVestList = mainUrl + "/VestReleaseDate";
const fileTokens = mainUrl + "/TokenHolderAddress";
const fileTokenTrend = mainUrl + "/TokenHolderTrend";
const fileActive = mainUrl + "/TopActiveAddress";
//资金穿透
const fundAddress = proUrl + "/EvaluateAddr";
const fundInfo = proUrl + "/CapitalAddrInfo";
const fundTransaction = proUrl + "/CapitalAddrTransaction";
//活动
const eventsList = mainUrl + "/GetEventsList";
//节点管家
const countMiners = proUrl + "/CountUserMiners";
const UserGroups = proUrl + "/GetUserGroups";
const saveMiner = proUrl + "/SaveUserMiners";
const delGroup = proUrl + "/DeleteGroup";
const saveGroup = proUrl + "/SaveGroupMiners";
const minerOverview = proUrl + "/MinerInfoDetail";
const powerData = proUrl + "/PowerDetail";
const gasData = proUrl + "/GasCostDetail";
const expiredData = proUrl + "/SectorDetail";
const rewardData = proUrl + "/RewardDetail";
const luckyData = proUrl + "/LuckyRateDetail";
const balanceData = proUrl + "/BalanceDetail";
const minerCategory = proUrl + "/GetRuleMinerInfo";
const saveRules = proUrl + "/SaveUserRules";
const getRules = proUrl + "/GetUserRules";
const rulesActive = proUrl + "/UpdateRuleActiveState";
const deleteRules = proUrl + "/DeleteUserRule";
const deleteMiners = proUrl + "/DeleteGroupMiners" //k线
;


/***/ }),

/***/ 42707:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   T: () => (/* binding */ DeviceContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const DeviceContext = react__WEBPACK_IMPORTED_MODULE_0___default().createContext({
    isMobile: false
});


/***/ }),

/***/ 24345:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   e: () => (/* binding */ axiosServer)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(99648);
/* harmony import */ var _packages_message__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(50275);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const axiosServer = async (url, payload = {}, requestConfig = {})=>{
    const { retryCount = 3, timeout } = requestConfig;
    let cancelTokenSource = axios__WEBPACK_IMPORTED_MODULE_0__["default"].CancelToken.source();
    const asPath = (next_router__WEBPACK_IMPORTED_MODULE_2___default().router)?.asPath;
    const cancelPreviousRequests = ()=>{
        cancelTokenSource.cancel("Request cancelled due to route change");
        cancelTokenSource = axios__WEBPACK_IMPORTED_MODULE_0__["default"].CancelToken.source();
    };
    const request = async (retry)=>{
        try {
            const mail =  false ? 0 : null;
            const token =  false ? 0 : null // 在客户端使用 localStorage
            ;
            const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].request({
                url,
                method: "POST",
                data: payload,
                cancelToken: cancelTokenSource.token,
                timeout,
                headers: {
                    "Content-Type": "application/json",
                    Authorization: token ? `${token}` : null
                }
            });
            if (response.data.code) {
                _packages_message__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.showMessage({
                    type: "error",
                    content: response.data.message
                });
            }
            return {
                data: response?.data?.result || response.data || {},
                error: null
            };
        } catch (error) {
            if (axios__WEBPACK_IMPORTED_MODULE_0__["default"].isCancel(error)) {
                return {
                    data: error,
                    error: "Request cancelled"
                };
            }
            if (retry > 0) {
                return request(retry - 1);
            }
            return {
                data: error,
                error: "Request failed"
            };
        }
    };
    // Cancel previous requests when route changes
    const handleRouteChange = (e)=>{
        if (e !== asPath) {
            cancelPreviousRequests();
            next_router__WEBPACK_IMPORTED_MODULE_2___default().router?.events.off("hashChangeStart", handleRouteChange);
            next_router__WEBPACK_IMPORTED_MODULE_2___default().router?.events.off("beforeHistoryChange", handleRouteChange);
        }
    };
    // Listen for route change events
    if (false) {} else {}
    try {
        const result = await request(retryCount);
        return result;
    } finally{
        // Remove the route change event listener
        if (false) {}
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6991:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//@ts-ignore
const modulesFiles = __webpack_require__(32434);
const modules = modulesFiles.keys().reduce((modules, modulePath)=>{
    const moduleName = modulePath.replace(/^\.\/(.*)\.\w+$/, "$1");
    const value = modulesFiles(modulePath);
    // @ts-ignore
    modules[moduleName] = value.default;
    return modules;
}, {});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (modules);


/***/ }),

/***/ 85166:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(36211);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_0__);

class CWStore {
    constructor(){
        this.finalHeight = 0;
        (0,mobx__WEBPACK_IMPORTED_MODULE_0__.makeObservable)(this, {
            finalHeight: mobx__WEBPACK_IMPORTED_MODULE_0__.observable
        });
    }
    setFinalHeight(value) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_0__.runInAction)(()=>{
            this.finalHeight = value;
        });
    }
}
const cwStore = new CWStore();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cwStore);


/***/ }),

/***/ 48257:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(68446);
/* harmony import */ var _store_axiosServer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(24345);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36211);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _packages_message__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(50275);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__]);
_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
//监控管理




class AccountStore {
    constructor(){
        this.countMiners = {
            miners_count: 0,
            max_miners_count: 0,
            loading: true
        };
        this.groupMiners = undefined;
        this.defaultGroup = undefined;
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.makeObservable)(this, {
            countMiners: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            groupMiners: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            defaultGroup: mobx__WEBPACK_IMPORTED_MODULE_2__.observable
        });
    }
    //用户名下节点数
    async getAccountMinersNumber() {
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .countMiners */ .ku);
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.countMiners = {
                ...result.data,
                loading: false
            } || {};
        });
    }
    //用户名下分组
    async getAccountGroup() {
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .UserGroups */ .wt);
        if (!result.error) {
            await this.getAccountMinersNumber();
        }
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.groupMiners = (result?.data?.group_info_list || []).map((groups)=>{
                // const miners = (groups?.miners_info||[]).map(v => {
                //   return {...v,label:String(v.miner_id),value:String(v.miner_id)}
                // })
                return {
                    ...groups,
                    label: groups.group_name,
                    value: String(groups.group_id)
                };
            });
            this.defaultGroup = result?.data?.group_info_list?.find((v)=>v.is_default);
        });
    }
    //修改保存名下节点
    async saveMiners(groupItem) {
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .saveMiner */ .rx, groupItem);
        if (!result.error) {
            await this.getAccountGroup();
            return true;
        }
    }
    //保存分组
    async saveGroups(payload) {
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .saveGroup */ .ZF, payload);
        if (!result.error) {
            if (!result?.data?.code) {
                await this.getAccountGroup();
                return {
                    error: null
                };
            } else {
                _packages_message__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.showMessage({
                    type: "error",
                    content: result?.data?.message || ""
                });
                return {
                    ...result.data,
                    error: "error saving"
                };
            }
        }
    }
    //删除某个分组
    async delGroups(group_id) {
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .delGroup */ .rc, {
            group_id
        });
        if (!result.error) {
            await this.getAccountGroup();
        }
    }
    //删除某个分组内节点
    async delMiners(miner_id) {
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .deleteMiners */ .ZW, {
            miner_id
        });
        if (!result.error) {
            await this.getAccountGroup();
            return _packages_message__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.showMessage({
                type: "success",
                content: "delete miner successfully"
            });
        } else {
            return _packages_message__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.showMessage({
                type: "error",
                content: "delete miner error"
            });
        }
    }
}
const accountStore = new AccountStore();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (accountStore);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 51678:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(68446);
/* harmony import */ var _store_axiosServer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(24345);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36211);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__]);
_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



class ManageStore {
    constructor(){
        this.powerData = {};
        this.powerDetailData = {};
        this.gasData = {};
        this.gasDetailData = {};
        this.expiredData = {};
        this.expiredDetailData = {};
        this.rewardData = {};
        this.rewardDetailData = {};
        this.luckyData = {};
        this.balanceData = {};
        this.powerLoading = true;
        this.powerDetailLoading = true;
        this.gasLoading = true;
        this.gasDetailLoading = true;
        this.expiredLoading = true;
        this.expiredDetailLoading = true;
        this.rewardLoading = true;
        this.rewardDetailLoading = true;
        this.luckyLoading = true;
        this.balanceLoading = true;
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.makeObservable)(this, {
            powerData: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            powerDetailData: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            gasData: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            expiredData: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            expiredDetailData: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            rewardData: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            rewardDetailData: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            luckyData: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            balanceData: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            powerLoading: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            powerDetailLoading: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            gasLoading: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            gasDetailLoading: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            expiredLoading: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            expiredDetailLoading: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            rewardLoading: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            rewardDetailLoading: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            luckyLoading: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            balanceLoading: mobx__WEBPACK_IMPORTED_MODULE_2__.observable
        });
    }
    async getPowerData(payload) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.powerLoading = true;
        });
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .powerData */ .nq, {
            ...payload
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.powerData = result?.data || {};
            this.powerLoading = false;
        });
    }
    async getPowerDetailData(payload) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.powerDetailLoading = true;
        });
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .powerData */ .nq, {
            ...payload
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.powerDetailData = result?.data || {};
            this.powerDetailLoading = false;
        });
    }
    //gas
    async getGasData(payload) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.gasLoading = true;
        });
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .gasData */ .uy, {
            ...payload
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.gasData = result?.data || {};
            this.gasLoading = false;
        });
    }
    async getGasDetailData(payload) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.gasDetailLoading = true;
        });
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .gasData */ .uy, {
            ...payload
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.gasDetailData = result?.data || {};
            this.gasDetailLoading = false;
        });
    }
    //expired
    async getExpiredData(payload) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.expiredLoading = true;
        });
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .expiredData */ .U8, {
            ...payload
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            const data = result?.data || {};
            if (data.sector_detail_month) {
                data.sector_detail_month = data.sector_detail_month.map((item, index)=>{
                    return {
                        ...item,
                        id: index
                    };
                });
            }
            this.expiredData = data;
            this.expiredLoading = false;
        });
    }
    async getExpiredDetailData(payload) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.expiredDetailLoading = true;
        });
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .gasData */ .uy, {
            ...payload
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.expiredDetailData = result?.data || {};
            this.expiredDetailLoading = false;
        });
    }
    //reward
    async getRewardData(payload) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.rewardLoading = true;
        });
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .rewardData */ .Pn, {
            ...payload
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.rewardData = result?.data || {};
            this.rewardLoading = false;
        });
    }
    async getRewardDetailData(payload) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.rewardDetailLoading = true;
        });
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .rewardData */ .Pn, {
            ...payload
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.rewardDetailData = result?.data || {};
            this.rewardDetailLoading = false;
        });
    }
    //lucky
    async getLuckyData(payload) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.luckyLoading = true;
        });
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .luckyData */ .i0, {
            ...payload
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.luckyData = result?.data || {};
            this.luckyLoading = false;
        });
    }
    //balance
    async getBalanceData(payload) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.balanceLoading = true;
        });
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .balanceData */ .SM, {
            ...payload
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.balanceData = result?.data || {};
            this.balanceLoading = false;
        });
    }
}
const manageStore = new ManageStore();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (manageStore);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 81829:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _packages_message__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(50275);
/* harmony import */ var _store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68446);
/* harmony import */ var _store_axiosServer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(24345);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(36211);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_axiosServer__WEBPACK_IMPORTED_MODULE_2__]);
_store_axiosServer__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const defaultPayload = {
    ExpireSectorMonitor: {
        monitor_type: "ExpireSectorMonitor",
        group_id_or_all: -1,
        miner_or_all: "",
        miner_tag: ""
    },
    BalanceMonitor: {
        category: undefined,
        operand: "",
        addr: "",
        balance: "",
        placeholder: "sector_ruler_placeholder",
        warning: false,
        operator: "<=",
        warningText: "sector_ruler_warningText"
    }
};
const defaultMiners = {
    beneficiary: "beneficiary_balance",
    owner: "owner_balance",
    worker: "worker_balance"
};
class MonitorStore {
    constructor(){
        this.saveLoading = false;
        this.rulesLoading = false;
        this.minersCategory = {};
        this.rules = [];
        (0,mobx__WEBPACK_IMPORTED_MODULE_3__.makeObservable)(this, {
            saveLoading: mobx__WEBPACK_IMPORTED_MODULE_3__.observable,
            rulesLoading: mobx__WEBPACK_IMPORTED_MODULE_3__.observable,
            rules: mobx__WEBPACK_IMPORTED_MODULE_3__.observable,
            minersCategory: mobx__WEBPACK_IMPORTED_MODULE_3__.observable
        });
    }
    async getMinerCategory(miner_id) {
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_2__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__/* .minerCategory */ .BO, {
            miner_id
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_3__.runInAction)(()=>{
            this.minersCategory = {
                [miner_id]: result?.data?.miner_detail?.accounts || []
            };
        });
    }
    async getUserRules(payload) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_3__.runInAction)(()=>{
            this.rulesLoading = true;
        });
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_2__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__/* .getRules */ .$c, {
            ...payload
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_3__.runInAction)(()=>{
            this.rulesLoading = false;
            this.rules = result?.data?.items || [];
        });
    }
    async saveUserRules(payload) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_3__.runInAction)(()=>{
            this.saveLoading = true;
        });
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_2__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__/* .saveRules */ .Cu, {
            ...payload
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_3__.runInAction)(()=>{
            this.saveLoading = false;
        });
        if (!result.error) {
            _packages_message__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.showMessage({
                type: "success",
                content: "Save Rules successfully"
            });
        }
        return true;
    }
    async ruleActive(payload) {
        await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_2__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__/* .rulesActive */ .bl, {
            ...payload
        });
        return true;
    }
    async deleteRules(payload) {
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_2__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__/* .deleteRules */ .NK, {
            ...payload
        });
        if (!result.error) {
            _packages_message__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.showMessage({
                type: "success",
                content: "Delete Rule successfully"
            });
        }
        return true;
    }
}
const monitorStore = new MonitorStore();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (monitorStore);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 62154:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(68446);
/* harmony import */ var _store_axiosServer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(24345);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36211);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__]);
_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



class OverviewStore {
    constructor(){
        this.overviewData = {};
        this.loading = true;
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.makeObservable)(this, {
            overviewData: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            loading: mobx__WEBPACK_IMPORTED_MODULE_2__.observable
        });
    }
    async getOverViewData(groupId) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.loading = true;
        });
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_0__/* .minerOverview */ .te, {
            group_id: groupId
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.loading = false;
            this.overviewData = result?.data || {};
        });
    }
}
const overviewStore = new OverviewStore();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (overviewStore);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 68994:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 1736:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(36211);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _axiosServer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(24345);
/* harmony import */ var _ApiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(68446);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axiosServer__WEBPACK_IMPORTED_MODULE_1__]);
_axiosServer__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



class Active {
    constructor(){
        this.activeList = [];
        (0,mobx__WEBPACK_IMPORTED_MODULE_0__.makeObservable)(this, {
            activeList: mobx__WEBPACK_IMPORTED_MODULE_0__.observable
        });
    // this.getActiveList()
    }
    async getActiveList() {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_1__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_2__/* .eventsList */ .YB);
        (0,mobx__WEBPACK_IMPORTED_MODULE_0__.runInAction)(()=>{
            this.activeList = result?.data?.items || [];
        });
    }
}
const activeStore = new Active();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (activeStore);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 56854:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23495);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59591);
/* harmony import */ var lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36211);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _axiosServer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(24345);
/* harmony import */ var _ApiUrl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(68446);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_0__, _axiosServer__WEBPACK_IMPORTED_MODULE_3__]);
([_utils__WEBPACK_IMPORTED_MODULE_0__, _axiosServer__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





class Analysis {
    constructor(){
        this.calcSize = (level, value)=>{
            let baseSize = 80 //最大的size 等差20
            ;
            if (!Number(value)) return baseSize;
            if (level) {
                baseSize = baseSize - level * 20;
            } else {
                baseSize = Math.floor(Number(baseSize) * Number(value));
            }
            return baseSize < 8 ? 8 : baseSize;
        };
        this.calcOrigin = (type)=>{
            return type === "x" ? Math.abs(Math.ceil(Math.random() * 300)) : Math.ceil(Math.random() * 300);
        };
        this.marketData = {};
        this.chartKOptions = {};
        this.filValueList = {};
        this.fileNetwork = {};
        this.fileNetworkTrend = {};
        this.filTrend = {};
        this.fundAddrData = {};
        this.fundInfo = {};
        this.fundTrans = {};
        this.fileTokens = {};
        this.fileActiveList = [];
        this.fileTokensTrend = {};
        this.releaseData = [];
        this.fundList = new Set();
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.makeObservable)(this, {
            marketData: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            chartKOptions: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            filValueList: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            filTrend: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            fileNetwork: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            fileNetworkTrend: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            fundAddrData: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            fundInfo: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            fundTrans: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            fileTokens: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            fileActiveList: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            fileTokensTrend: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            releaseData: mobx__WEBPACK_IMPORTED_MODULE_2__.observable
        });
    }
    async getFilBase() {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_3__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_4__/* .fileBase */ .Xz);
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.marketData = result.data || {};
        });
    }
    async getNetWork() {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_3__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_4__/* .fileNetwork */ .eF);
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.fileNetwork = result.data || {};
        });
    }
    async getNetWorkTrend(interval) {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_3__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_4__/* .fileNetworkTrend */ .k5, {
            interval
        });
        const fileNetworkTrendResult = result?.data?.list || [];
        const date = [];
        const seriesObj = {
            circulating: [],
            produced: [],
            locked: [],
            burn: []
        };
        if (fileNetworkTrendResult && fileNetworkTrendResult.length > 0) {
            fileNetworkTrendResult.forEach((value)=>{
                const { epoch, block_time, circulating, produced, locked, burn } = value;
                const time = (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD");
                date.push(time);
                //amount
                seriesObj.circulating.push({
                    value: (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(circulating),
                    showTime: time,
                    unit: ""
                });
                seriesObj.produced.push({
                    value: (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(produced),
                    showTime: time,
                    unit: ""
                });
                seriesObj.locked.push({
                    value: (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(locked),
                    showTime: time,
                    unit: ""
                });
                seriesObj.burn.push({
                    value: (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFil */ .Uk)(burn),
                    showTime: epoch,
                    unit: ""
                });
            });
        }
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.fileNetworkTrend = {
                date,
                seriesObj
            };
        });
    }
    async getReleaseDate() {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_3__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_4__/* .fileVestList */ .V9);
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.releaseData = result?.data?.account_list || [];
        });
    }
    async getTokens() {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_3__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_4__/* .fileTokens */ ._E);
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.fileTokens = result.data || {};
        });
    }
    //fileTokenTrend
    async getTokensTrend(interval) {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_3__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_4__/* .fileTokenTrend */ .YA, {
            interval
        });
        const fileTokensTrend = result.data || {};
        const date = [];
        const seriesObj = {
            top10rate: [],
            top20rate: [],
            top50rate: [],
            top100rate: []
        };
        if (fileTokensTrend && fileTokensTrend.length > 0) {
            fileTokensTrend.forEach((value)=>{
                const { timpstamp, top10rate, top20rate, top50rate, top100rate } = value;
                date.push(timpstamp);
                //amount
                seriesObj.top10rate.push({
                    value: top10rate,
                    showTime: timpstamp,
                    unit: ""
                });
                seriesObj.top20rate.push({
                    value: top20rate,
                    showTime: timpstamp,
                    unit: ""
                });
                seriesObj.top50rate.push({
                    value: top50rate,
                    showTime: timpstamp,
                    unit: ""
                });
                seriesObj.top100rate.push({
                    value: top100rate,
                    showTime: timpstamp,
                    unit: ""
                });
            });
        }
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.fileTokensTrend = {
                date,
                seriesObj
            };
        });
    }
    async getActiveList() {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_3__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_4__/* .fileActive */ .fc);
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.fileActiveList = result.data || [];
        });
    }
    splitData(rawData) {
        // let categoryData = []
        let dataValues = [];
        for(let i = 0; i < rawData.length; i++){
            const [time, high, open, low, close, other, volume] = rawData[i];
            //categoryData.push(time) //time
            // const change = Number(((close - open) / open) * 100).toFixed(2)
            dataValues.push({
                timestamp: time * 1000,
                open,
                close,
                low,
                high,
                volume: Number(volume)
            });
        }
        return {
            //categoryData: categoryData,
            dataValues: dataValues
        };
    }
    async getKline(payload) {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_3__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_4__/* .marketKline */ .wp, payload);
        const newResult = result?.data && JSON.parse(result?.data?.data || "{}");
        if (newResult.data) {
            const data = this.splitData(lodash_cloneDeep__WEBPACK_IMPORTED_MODULE_1___default()(newResult.data?.kline || []));
            const newOptions = {};
            const updateInfo = data?.dataValues && data?.dataValues[data.dataValues?.length - 1];
            newOptions.dataValues = data.dataValues;
            newOptions.data = newResult.data?.kline || [];
            newOptions.updateInfo = updateInfo;
            (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
                this.chartKOptions = newOptions;
            });
        }
    }
    //trend chart
    splitTrendData(data) {
        let categoryData = [];
        let usdData = [];
        let btcData = [];
        let marketData = [];
        let volumeData = [];
        let maxNum = 0;
        let minNum;
        let volume_max = 0;
        let volume_min;
        let btc_max = 0;
        let btc_min;
        for(let i = 0; i < data.length; i++){
            const [time, usd, btc, market, volumeValue] = data[i];
            const marketValue = market / Math.pow(10, 8);
            const volume = volumeValue / Math.pow(10, 8);
            categoryData.push((0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatDateTime */ .o0)(Number(time) / 1000));
            usdData.push(usd);
            btcData.push(btc);
            marketData.push(marketValue) //亿
            ;
            volumeData.push(volume);
            maxNum = Math.max(maxNum, Number(usd), Number(marketValue));
            minNum = minNum ? Math.min(minNum, Number(usd), Number(marketValue)) : Math.min(Number(usd), Number(marketValue));
            volume_max = Math.max(volume_max, Number(volume));
            volume_min = volume_min ? Math.min(volume_min, Number(volume)) : Number(volume);
            btc_max = Math.max(btc_max, Number(marketValue));
            btc_min = btc_min ? Math.min(btc_min, Number(marketValue)) : Number(marketValue);
        }
        return {
            categoryData,
            usd: usdData,
            btc: btcData,
            market: marketData,
            volume: volumeData,
            usdNum: {
                max: maxNum,
                min: minNum
            },
            btcNum: {
                max: btc_max,
                min: btc_min
            },
            volumeNum: {
                max: volume_max,
                min: volume_min
            }
        };
    }
    async getFilValues() {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_3__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_4__/* .filecoinValue */ .Vl, {
            code: "filecoinnew",
            webp: 1
        });
        const newResult = result?.data && JSON.parse(result?.data?.data || "{}");
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.filValueList = newResult?.data || {};
        });
    }
    async getFilTrend(payload) {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_3__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_4__/* .fileTrend */ .Sq, payload);
        const newResult = result?.data && JSON.parse(result?.data?.data || "{}");
        const data = newResult.value;
        if (data) {
            const dataArr = (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .convertStringToArray */ .f)(data);
            const newOptions = this.splitTrendData(dataArr);
            (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
                this.filTrend = newOptions;
            });
        }
        return true;
    }
    async getFundAddress(payload) {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_3__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_4__/* .fundAddress */ .pp, {
            ...payload
        });
        const fundAddrData = result.data || [];
        let seriesData = [];
        let linkData = [];
        let nodesObj = {};
        if (fundAddrData && fundAddrData?.nodes?.length > 0) {
            fundAddrData.nodes.forEach((node)=>{
                const { level, address, tag, proportion_with_father_node } = node;
                const size = this.calcSize(level, proportion_with_father_node);
                let itemColor = {};
                let itemSelect = {};
                nodesObj[address] = true;
                if (!!level) {
                    itemColor = {
                        color: "rgba(95,219,194,0.2)",
                        borderColor: "#5FDBC2"
                    };
                    itemSelect = {
                        color: "rgba(95,219,194,0.8)",
                        borderColor: "#5FDBC2"
                    };
                } else {
                    itemColor = {
                        color: "rgba(28,106,253,0.2)",
                        borderColor: "#1C6AFD"
                    };
                    itemSelect = {
                        color: "rgba(28,106,253,0.8)",
                        borderColor: "#1C6AFD"
                    };
                }
                if (node.tag !== "") {
                    itemColor = {
                        color: {
                            type: "linear",
                            x: 0,
                            y: 0,
                            x2: 1,
                            y2: 1,
                            colorStops: [
                                {
                                    offset: 0,
                                    color: "#A2E7A2"
                                },
                                {
                                    offset: 0.61,
                                    color: "#16CDE5"
                                },
                                {
                                    offset: 1,
                                    color: "#1764FF"
                                }
                            ],
                            globalCoord: false
                        }
                    };
                    itemSelect = {
                        borderWidth: 2,
                        borderColor: "#ffffff"
                    };
                }
                const obj = {
                    name: address,
                    seriesName: address,
                    symbolSize: size,
                    x: !!level ? this.calcOrigin("x") : 150,
                    y: !!level ? this.calcOrigin("y") : 100,
                    itemStyle: {
                        ...itemColor
                    },
                    label: {
                        show: !!node.tag,
                        position: "bottom",
                        color: "rgba(255,255,255,0.6)",
                        fontSize: "14px",
                        formatter: ()=>{
                            return "Exchange Address";
                        },
                        force: {
                            repulsion: 80
                        }
                    },
                    emphasis: {
                        focus: "adjacency",
                        itemStyle: {
                            borderWidth: 2
                        }
                    },
                    select: {
                        itemStyle: {
                            ...itemSelect
                        }
                    },
                    ...node
                };
                seriesData.push(obj);
            });
            fundAddrData.edges.forEach((linkNode)=>{
                const { from, to } = linkNode;
                if (nodesObj[from] && nodesObj[to]) {
                    const linkObj = {
                        source: linkNode.from,
                        target: linkNode.to
                    };
                    linkData.push(linkObj);
                }
            });
        }
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.fundAddrData = {
                series: [
                    {
                        type: "graph",
                        layout: "none",
                        symbolSize: 50,
                        selectedMode: true,
                        roam: true,
                        data: seriesData,
                        links: linkData,
                        force: {
                            // 节点排斥力设置
                            repulsion: 400,
                            gravity: 0.01,
                            edgeLength: 200
                        },
                        edgeSymbol: [
                            "circle",
                            "arrow"
                        ],
                        edgeSymbolSize: [
                            4,
                            8
                        ],
                        lineStyle: {
                            width: 1,
                            color: "rgba(100, 100, 100, 1)",
                            curveness: 0.2,
                            type: "solid"
                        }
                    }
                ]
            };
        });
    }
    async getFundAddrInfo(payload) {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_3__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_4__/* .fundInfo */ .rM, {
            ...payload
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.fundInfo = {
                address: payload.address,
                ...result?.data || {}
            };
        });
    }
    async getFundTransaction(address) {
        const result = await (0,_axiosServer__WEBPACK_IMPORTED_MODULE_3__/* .axiosServer */ .e)(_ApiUrl__WEBPACK_IMPORTED_MODULE_4__/* .fundTransaction */ .Iq, {
            address
        });
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.fundTrans = {
                address: address,
                ...result?.data || {}
            };
        });
    }
}
const analysisStore = new Analysis();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (analysisStore);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 25572:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(36211);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_0__);

class FilscanStore {
    constructor(){
        this.headerShow = true;
        this.lang = "zh";
        this.theme = "light";
        (0,mobx__WEBPACK_IMPORTED_MODULE_0__.makeObservable)(this, {
            theme: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            lang: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            headerShow: mobx__WEBPACK_IMPORTED_MODULE_0__.observable
        });
    }
    setTheme(theme) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_0__.runInAction)(()=>{
            this.theme = theme;
        });
    }
    setLang(lang) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_0__.runInAction)(()=>{
            this.lang = lang;
        });
    }
    setHeaderShow(show) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_0__.runInAction)(()=>{
            this.headerShow = show;
        });
    }
}
const filscanStore = new FilscanStore();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (filscanStore);


/***/ }),

/***/ 60170:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(36211);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _server__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(50785);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);



class HomeStore {
    constructor(){
        this.meta = {
            power_increase_24h: "0",
            add_power_in_32g: "0",
            miner_initial_pledge: "0",
            fil_per_tera_24h: "0",
            total_contract: "0",
            contract_transaction: "0",
            contract_address: "0",
            gas_24: "0"
        };
        this.fee = [];
        this.defiData = undefined;
        this.contractData = undefined;
        this.minerPowerRankData = undefined;
        this.maxPower = "1";
        (0,mobx__WEBPACK_IMPORTED_MODULE_0__.makeObservable)(this, {
            meta: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            fee: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            defiData: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            contractData: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            minerPowerRankData: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            maxPower: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            fetchContractRank: mobx__WEBPACK_IMPORTED_MODULE_0__.action
        });
    }
    /**
   *
   * @param params
   */ async fetchHomeDefi(params) {
        params.page = params.page - 1;
        const result = await (0,_server__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.fevm_defiList, params);
        if (!result.error) {
            this.defiData = result;
        }
    }
    async fetchContractRank(data) {
        data.page = data.page - 1;
        const res = await (0,_server__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_rank, data);
        if (!res.error) {
            (0,mobx__WEBPACK_IMPORTED_MODULE_0__.runInAction)(()=>{
                this.contractData = res;
            });
        }
    }
    async fetchMinerPowerRank(data) {
        data.index = data.index - 1;
        const res = await (0,_server__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.rank_growth, data);
        if (!res.error) {
            (0,mobx__WEBPACK_IMPORTED_MODULE_0__.runInAction)(()=>{
                this.minerPowerRankData = res;
                if (this.minerPowerRankData?.items && this.minerPowerRankData?.items.length > 0) {
                    if (this.minerPowerRankData?.items[0].power_ratio > this.maxPower) {
                        this.maxPower = this.minerPowerRankData?.items[0].power_ratio;
                    }
                }
            });
        }
    }
}
const homeStore = new HomeStore();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (homeStore);


/***/ }),

/***/ 63414:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store_axiosServer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(24345);
/* harmony import */ var _store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68446);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36211);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _packages_message__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(50275);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_axiosServer__WEBPACK_IMPORTED_MODULE_0__, _utils__WEBPACK_IMPORTED_MODULE_5__]);
([_store_axiosServer__WEBPACK_IMPORTED_MODULE_0__, _utils__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const defaultUser = {
    name: "",
    mail: "",
    last_login: 0,
    superVip: false,
    membership_type: "",
    expired_time: ""
};
class UserStore {
    constructor(){
        this.userInfo = {
            ...defaultUser,
            loading: true
        };
        this.verifyCode = "";
        this.vipModal = false;
        this.recordList = [];
        this.showMemberWarn = false;
        this.memberWarn = false;
        this.firstWarn = false;
        this.inviteCode = "";
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.makeObservable)(this, {
            isLogin: mobx__WEBPACK_IMPORTED_MODULE_2__.computed,
            inviteCode: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            userInfo: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            verifyCode: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            vipModal: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            recordList: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            showMemberWarn: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            memberWarn: mobx__WEBPACK_IMPORTED_MODULE_2__.observable,
            firstWarn: mobx__WEBPACK_IMPORTED_MODULE_2__.observable
        });
    }
    get isLogin() {
        return !(!this.userInfo.mail || !localStorage.getItem(`token-${this.userInfo.mail}`));
    }
    setMemberWarn(isShow) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.showMemberWarn = isShow;
        });
    }
    // 关闭第一次弹窗
    setFirstWarn(value) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.firstWarn = value;
        });
    }
    setVipModal(isShow) {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.vipModal = isShow;
        });
    }
    //验证码登录，获取验证码
    async getVerifyCode(mail) {
        const result = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_0__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__/* .verifyCode */ .VP, {
            mail: mail
        });
        localStorage.setItem("send_code", result?.data?.token);
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.verifyCode = result?.data?.token;
        });
    }
    //重置密码
    async resetPassword(payload) {
        const userData = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_0__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__/* .resetPassword */ .c0, {
            ...payload
        });
        if (userData.error) {
            return false;
        }
        if (!userData.error) {
            if (false) {}
        }
    }
    //更新用户信息
    async resetUser(payload) {
        const userData = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_0__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__/* .updateInfo */ .rn, {
            ...payload
        });
        if (userData.error) {
            return false;
        } else {
            this.clearUserInfo();
            _packages_message__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.showMessage({
                type: "success",
                content: "Update successful"
            });
        }
        return true;
    }
    //获取用户登录信息
    async getUserInfo() {
        const userData = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_0__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__/* .userInfo */ .eY);
        if (!userData.error) {
            await this.getUserCode();
            await this.getInviteList();
            (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
                const superVip = userData?.data?.membership_type?.startsWith("Enterprise");
                if (superVip && userData.data.expired_time && (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatTime */ .mr)(userData.data.expired_time * 1000).days > -15 && (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatTime */ .mr)(userData.data.expired_time * 1000).days < 0) {
                    //会员还有不超过15天到期
                    this.showMemberWarn = true;
                    this.memberWarn = true;
                }
                this.userInfo = {
                    ...userData?.data || {},
                    superVip: superVip && (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatTime */ .mr)(userData.data.expired_time * 1000).days < 0,
                    last_login: userData?.data?.last_login_at || "",
                    loading: false
                };
            });
        } else {
            (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
                this.userInfo = {
                    ...defaultUser,
                    loading: false
                };
            });
            return true;
        }
    }
    //获取我的邀请码
    async getUserCode() {
        const userData = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_0__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__/* .inviteCode */ .jQ);
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.inviteCode = userData?.data?.invite_code || "";
        });
    }
    //邀请记录
    async getInviteList() {
        const list = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_0__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__/* .inviteList */ .JE);
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.recordList = list?.data?.items || [];
        });
    }
    //登录
    async loginUserInfo(payload) {
        if (payload.invite_code) {
            const inviteData = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_0__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__/* .ValidInvite */ .FK, {
                mail: payload.mail,
                invite_code: payload.invite_code
            });
            if (!inviteData?.data?.success) {
                return _packages_message__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.showMessage({
                    type: "error",
                    content: inviteData?.data?.msg || "error"
                });
            }
        }
        const userData = await (0,_store_axiosServer__WEBPACK_IMPORTED_MODULE_0__/* .axiosServer */ .e)(_store_ApiUrl__WEBPACK_IMPORTED_MODULE_1__/* .login */ .x4, payload);
        if (userData?.data?.code) {
            return _packages_message__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.showMessage({
                type: "error",
                content: userData?.data?.message || ""
            });
        }
        if (!userData.error && !userData?.data?.code) {
            localStorage.setItem(`mail`, userData.data?.mail);
            localStorage.setItem(`token-${userData.data.mail}`, userData.data?.token);
            //await this.getUserInfo()
            if (!userData.data.is_activity) {
                this.setFirstWarn(true);
            }
            if (false) {}
            _packages_message__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.showMessage({
                type: "success",
                content: "login successful"
            });
        }
    }
    //退出登录
    clearUserInfo() {
        (0,mobx__WEBPACK_IMPORTED_MODULE_2__.runInAction)(()=>{
            this.userInfo = {
                ...defaultUser,
                loading: false
            };
        });
        if (false) {}
    }
}
const userStore = new UserStore();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (userStore);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 46782:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(36211);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_0__);

class WalletStore {
    constructor(){
        this.wallet = "";
        this.account = "";
        (0,mobx__WEBPACK_IMPORTED_MODULE_0__.makeObservable)(this, {
            //walletCard: observable,
            wallet: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            account: mobx__WEBPACK_IMPORTED_MODULE_0__.observable
        });
    }
    setWallet(walletItem) {
        //  this.walletCard = walletItem
        this.wallet = walletItem?.wallet;
        this.account = walletItem?.account;
    }
}
const walletStore = new WalletStore();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (walletStore);


/***/ }),

/***/ 50785:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/** @format */ async function fetchData(url, body, options = {
    maxRetries: 3,
    timeout: 0
}) {
    const { maxRetries, timeout } = options;
    const newBody = body || {};
    let retries = 0;
    let error = null;
    let data = null;
    const token = localStorage.getItem("token") // 从 localStorage 获取 token
    ;
    while(retries < maxRetries){
        try {
            const controller = new AbortController();
            let timeoutId;
            if (timeout > 0) {
                timeoutId = setTimeout(()=>controller.abort(), timeout);
            }
            const response = await fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `${token}`
                },
                body: JSON.stringify(newBody),
                signal: controller.signal
            });
            if (response.status === 401) {
                //message.warning('please login ');
                // Router.push('/admin/login');
                return {
                    result: null,
                    error: "Invalid credentials"
                };
            }
            data = await response.json();
            if (timeoutId) {
                clearTimeout(timeoutId);
            }
            break; // 请求成功，跳出循环
        } catch (err) {
            error = err;
            retries += 1;
        }
    }
    if (data) {
        return data?.result || data || {};
    } else {
        return {
            result: null,
            error: error ? error.message : "请求失败"
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fetchData);


/***/ }),

/***/ 68108:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(99648);
/* harmony import */ var use_deep_compare_effect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(94612);
/* harmony import */ var use_deep_compare_effect__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(use_deep_compare_effect__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _packages_message__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(50275);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const DefaultOptions = {
    method: "post",
    maxRetries: 3,
    timeout: 0,
    isCancel: true
};
// 用于存储每个 URL 和方法的取消令牌
const cancelTokenSources = {};
let current = {};
function useAxiosData(initialUrl, initialPayload = {}, initialOptions) {
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const axiosData = async (url, payload, options = DefaultOptions)=>{
        const { method = "post", maxRetries = 3, timeout = 0, flag, isCancel = true, loading = true } = {
            ...DefaultOptions,
            ...options
        };
        const body = payload || {};
        let error = null;
        let data = null;
        const token = localStorage.getItem("token") // 从 localStorage 获取 token
        ;
        if (loading) {
            setLoading(true);
        }
        // 创建一个键，包含 URL 和方法
        let key = "";
        if (isCancel) {
            key = flag ? `${method}:${url}_${flag}` : `${method}:${url}`;
        }
        // 如果这个 URL 和方法已经有一个正在进行的请求，取消它
        if (cancelTokenSources[key]) {
            cancelTokenSources[key].cancel("Cancelled because of new request");
        }
        // 创建一个新的取消令牌
        const cancelTokenSource = axios__WEBPACK_IMPORTED_MODULE_1__["default"].CancelToken.source();
        if (key) {
            cancelTokenSources[key] = cancelTokenSource;
        }
        let currentKey = `${method}:${url}`;
        if (currentKey) {
            current[currentKey] = current[currentKey] || 1;
        }
        if (currentKey) {
            while(Number(current[currentKey]) < maxRetries){
                try {
                    const response = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].request({
                        url,
                        method,
                        data: body,
                        headers: {
                            "Content-Type": "application/json",
                            Authorization: `${token}`
                        },
                        timeout: timeout,
                        cancelToken: cancelTokenSource.token
                    });
                    if (response.status === 401) {
                        current[currentKey] = 100;
                        setData({
                            result: null,
                            error: "Invalid credentials"
                        });
                        setLoading(false);
                        current[currentKey] = 0;
                        return response.data;
                    }
                    if (response.data && response.data.code) {
                        current[currentKey] = 0;
                        return _packages_message__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.showMessage({
                            type: "error",
                            content: response.data.message
                        });
                    }
                    data = response.data || response || {};
                    setData(data?.result || data || {});
                    setLoading(false);
                    current[currentKey] = 0;
                    return data?.result || data // 请求成功，跳出循环
                    ;
                } catch (thrown) {
                    current[currentKey] = current[currentKey] + 1;
                    if (axios__WEBPACK_IMPORTED_MODULE_1__["default"].isCancel(thrown)) {
                        console.log("Request canceled", thrown.message);
                        break; //取消请求，跳出循环
                    } else {
                        if (current[currentKey] < maxRetries) {
                            return axiosData(url, payload, options);
                        } else {
                            setError(thrown);
                            setLoading(false);
                            setData({
                                result: null,
                                error: "Error"
                            });
                            if (current[currentKey] === maxRetries) {
                                current[currentKey] = 0;
                                if (thrown?.response?.status === 401) {
                                    setData({
                                        result: null,
                                        error: "Invalid credentials"
                                    });
                                    return null;
                                }
                                setData({
                                    result: null,
                                    error: "Invalid credentials"
                                });
                                return null;
                            }
                        // return notification.error({
                        //   className: 'custom-notification',
                        //   message: 'Error',
                        //   duration: 100,
                        //   description: thrown?.message || 'Network Error'
                        // })
                        }
                    }
                }
            }
        }
    };
    use_deep_compare_effect__WEBPACK_IMPORTED_MODULE_2___default()(()=>{
        if (initialUrl) {
            axiosData(initialUrl, initialPayload, initialOptions);
        }
    }, [
        initialUrl,
        initialPayload,
        initialOptions
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        // 组件卸载时取消所有请求
        return ()=>{
            current = {};
            Object.values(cancelTokenSources).forEach((source)=>source.cancel("Component unmounted"));
        };
    }, []);
    return {
        data,
        loading,
        error,
        axiosData
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAxiosData);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7947:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ getSvgIcon)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/** @format */ 
const moon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("filter", {
                id: "filter-1",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feColorMatrix", {
                    in: "SourceGraphic",
                    type: "matrix",
                    values: "0 0 0 0 0.002548 0 0 0 0 0.002367 0 0 0 0 0.002367 0 0 0 1.000000 0"
                })
            })
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "页面-1",
            stroke: "none",
            strokeWidth: "1",
            fill: "none",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "月亮",
                transform: "translate(-878.000000, -22.000000)",
                filter: "url(#filter-1)",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                    transform: "translate(878.000000, 22.000000)",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                        id: "编组-16",
                        transform: "translate(0.008511, 0.001793)",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                d: "M15.678042,7 C18.7357203,7.7699021 21,10.5385734 21,13.8359161 C21,17.7288951 17.844028,20.8848671 13.951049,20.8848671 C10.4586853,20.8848671 7.55960839,18.3452867 7,15.0119161 C7.70293706,15.2645035 8.46109091,15.4023497 9.25174825,15.4023497 C12.9285594,15.4023497 15.9090909,12.4218182 15.9090909,8.74500699 C15.9090909,8.15367832 15.8319441,7.57958042 15.687049,7.03367832 L15.6776503,7 L15.678042,7 Z M17.1489231,8.90634965 L17.0823497,8.86405594 L17.0827413,8.87972028 C17.0106853,13.1431608 13.5324196,16.5771748 9.25174825,16.5771748 C9.11116084,16.5771748 8.97135664,16.5732587 8.83194406,16.5662098 L8.74422378,16.5599441 L8.78064336,16.6284755 C9.78540167,18.4848414 11.708006,19.6603143 13.8182937,19.7084755 L13.951049,19.710042 C17.1951329,19.710042 19.8251748,17.08 19.8251748,13.8359161 C19.8251748,11.7944615 18.7748811,9.96290909 17.1489231,8.90634965 L17.1489231,8.90634965 Z",
                                id: "形状",
                                fill: "currentColor",
                                fillRule: "nonzero"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                id: "矩形备份-2",
                                strokeOpacity: "0.2",
                                stroke: "currentColor",
                                strokeWidth: "0.5",
                                x: "0.25",
                                y: "0.25",
                                width: "27.5",
                                height: "27.5",
                                rx: "5"
                            })
                        ]
                    })
                })
            })
        })
    ]
});
const sun = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "#ffffff",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-801.000000, -94.000000)",
            fill: "#ffffff",
            fillRule: "nonzero",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                fill: "#ffffff",
                d: "M814.924528,113.584906 C815.237087,113.584906 815.490566,113.838384 815.490566,114.150943 L815.490566,115.283019 C815.490566,115.595578 815.237087,115.849057 814.924528,115.849057 C814.611969,115.849057 814.358491,115.595578 814.358491,115.283019 L814.358491,114.150943 C814.358491,113.838384 814.611969,113.584906 814.924528,113.584906 Z M819.893455,112.092866 L820.528125,112.727535 C820.749233,112.948644 820.749233,113.30684 820.528125,113.527948 C820.422046,113.634254 820.278009,113.693956 820.12783,113.693868 C819.98296,113.693868 819.83809,113.638679 819.727712,113.527948 L819.093042,112.893278 C818.871934,112.67217 818.871934,112.313974 819.093042,112.092866 C819.314151,111.871757 819.672347,111.871757 819.893455,112.092866 Z M810.756191,112.092866 C810.9773,112.313974 810.9773,112.67217 810.756191,112.893278 L810.121521,113.527948 C810.015479,113.634311 809.871419,113.694023 809.721226,113.693868 C809.576356,113.693868 809.431486,113.638679 809.321108,113.527948 C809.1,113.30684 809.1,112.948644 809.321108,112.727535 L809.955778,112.092866 C810.176887,111.871757 810.535083,111.871757 810.756191,112.092866 Z M814.924528,103.396226 C817.425531,103.396226 819.45283,105.423703 819.45283,107.924528 C819.45283,110.425354 817.425531,112.45283 814.924528,112.45283 C812.423526,112.45283 810.396226,110.425354 810.396226,107.924528 C810.396226,105.423703 812.423526,103.396226 814.924528,103.396226 Z M814.924528,104.528302 C813.051828,104.528302 811.528302,106.051828 811.528302,107.924528 C811.528302,109.797229 813.051828,111.320755 814.924528,111.320755 C816.797229,111.320755 818.320755,109.797229 818.320755,107.924528 C818.320755,106.051828 816.797229,104.528302 814.924528,104.528302 Z M808.698113,107.358491 C809.010672,107.358491 809.264151,107.611969 809.264151,107.924528 C809.264151,108.237087 809.010672,108.490566 808.698113,108.490566 L807.566038,108.490566 C807.253479,108.490566 807,108.237087 807,107.924528 C807,107.611969 807.253479,107.358491 807.566038,107.358491 L808.698113,107.358491 Z M822.283019,107.358491 C822.595578,107.358491 822.849057,107.611969 822.849057,107.924528 C822.849057,108.237087 822.595578,108.490566 822.283019,108.490566 L821.150943,108.490566 C820.838384,108.490566 820.584906,108.237087 820.584906,107.924528 C820.584906,107.611969 820.838384,107.358491 821.150943,107.358491 L822.283019,107.358491 Z M810.121521,102.320932 L810.756191,102.955601 C810.9773,103.17671 810.9773,103.534906 810.756191,103.756014 C810.65013,103.862348 810.506082,103.922056 810.355896,103.921934 C810.211026,103.921934 810.066156,103.866745 809.955778,103.756014 L809.321108,103.121344 C809.1,102.900236 809.1,102.54204 809.321108,102.320932 C809.542217,102.099823 809.900413,102.099823 810.121521,102.320932 Z M820.528125,102.320932 C820.749233,102.54204 820.749233,102.900236 820.528125,103.121344 L819.893455,103.756014 C819.787413,103.862377 819.643353,103.922089 819.49316,103.921934 C819.34829,103.921934 819.20342,103.866745 819.093042,103.756014 C818.871934,103.534906 818.871934,103.17671 819.093042,102.955601 L819.727712,102.320932 C819.948821,102.099823 820.307017,102.099823 820.528125,102.320932 Z M814.924528,100 C815.237087,100 815.490566,100.253479 815.490566,100.566038 L815.490566,101.698113 C815.490566,102.010672 815.237087,102.264151 814.924528,102.264151 C814.611969,102.264151 814.358491,102.010672 814.358491,101.698113 L814.358491,100.566038 C814.358491,100.253479 814.611969,100 814.924528,100 Z",
                id: "形状结合"
            })
        })
    })
});
const network = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "currentColor",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-761.000000, -94.000000)",
            fill: "currentColor",
            fillRule: "nonzero",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M774.981383,101 C771.124867,101 768,104.124867 768,107.981383 C768,111.837899 771.124867,114.962766 774.981383,114.962766 C778.837899,114.962766 781.962766,111.837899 781.962766,107.981383 C781.962766,104.124867 778.837899,101 774.981383,101 Z M780.998404,107.515957 L779.154388,107.515957 C779.074335,105.500665 778.486037,103.719947 777.596144,102.53125 C779.492287,103.442553 780.828059,105.314495 780.998404,107.515957 Z M778.21609,107.515957 L775.446809,107.515957 L775.446809,101.999734 C776.942686,102.398138 778.098803,104.684309 778.21609,107.515957 Z M774.515957,101.999734 L774.515957,107.515957 L771.746676,107.515957 C771.863963,104.684309 773.02008,102.398138 774.515957,101.999734 Z M772.367553,102.53125 C771.476729,103.719947 770.889362,105.500665 770.809309,107.515957 L768.964362,107.515957 C769.134707,105.314495 770.470479,103.442553 772.367553,102.53125 Z M768.964362,108.446809 L770.808378,108.446809 C770.888431,110.462101 771.476729,112.242819 772.366622,113.431516 C770.470479,112.520213 769.134707,110.648271 768.964362,108.446809 Z M771.746676,108.446809 L774.515957,108.446809 L774.515957,113.963032 C773.02008,113.564628 771.863963,111.278457 771.746676,108.446809 Z M775.446809,113.963032 L775.446809,108.446809 L778.21609,108.446809 C778.098803,111.278457 776.942686,113.564628 775.446809,113.963032 Z M777.595213,113.431516 C778.486037,112.242819 779.073404,110.462101 779.153457,108.446809 L780.997473,108.446809 C780.828059,110.648271 779.492287,112.520213 777.595213,113.431516 Z",
                id: "形状",
                fill: "currentColor"
            })
        })
    })
});
const downIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    width: "12px",
    height: "8px",
    viewBox: "0 0 10 6",
    version: "1.1",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        opacity: "0.6",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-706.000000, -87.000000)",
            stroke: "currentColor",
            strokeWidth: "1.3",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("polyline", {
                id: "路径-2",
                points: "707 88 710.94397 92 715 88"
            })
        })
    })
});
const uploadIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 14 14",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "所需icon",
            transform: "translate(-12.000000, -62.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "上传icon",
                transform: "translate(12.000000, 62.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        x: "0",
                        y: "0",
                        width: "14",
                        height: "14"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M7.44997704,7.82275886 L9.24986364,9.62264545 C9.49837671,9.87115853 9.49837671,10.2740778 9.24986364,10.5225909 C9.00133464,10.7711199 8.59840311,10.771164 8.34981973,10.5226894 L7.63636364,9.80954545 L7.63636364,12.7272727 C7.63636364,13.0787267 7.35145393,13.3636364 7,13.3636364 C6.64854607,13.3636364 6.36363636,13.0787267 6.36363636,12.7272727 L6.36363636,9.80827273 L5.64992037,10.5224454 C5.42640008,10.7461087 5.07778549,10.7685794 4.82913048,10.5897855 L4.75011409,10.5225909 L4.75011409,10.5225909 C4.52645259,10.298931 4.50408528,9.9502019 4.68301297,9.70152686 L4.75011462,9.62264598 L4.75011462,9.62264598 L6.55002084,7.82275674 C6.79853876,7.5742454 7.20146029,7.57424635 7.44997704,7.82275886 Z M7,0.636363636 C9.22812685,0.636363636 11.1168375,2.25177142 11.5737502,4.44325021 L11.5842746,4.50163636 L11.6335958,4.52125169 C12.9947944,5.09534487 13.9356156,6.44585801 13.9968246,7.99905299 L14,8.16042781 C14,10.3311727 12.2949704,12.0909091 10.1917098,12.0909091 C9.85118194,12.0909091 9.57512953,11.8059994 9.57512953,11.4545455 C9.57512953,11.1030915 9.85118194,10.8181818 10.1917098,10.8181818 C11.6139146,10.8181818 12.7668394,9.62826482 12.7668394,8.16042781 C12.7668394,6.99974908 12.0394719,5.98711253 10.9948271,5.63408188 L10.8729065,5.59630393 L10.4704891,5.48273419 L10.4229694,5.05495967 C10.2247798,3.27084899 8.75512838,1.90909091 7,1.90909091 C5.29226976,1.90909091 3.85491264,3.19825644 3.59619078,4.91123361 L3.57737842,5.05494421 L3.52991371,5.48286195 L3.12735575,5.59641601 C2.01759469,5.90945882 1.23316062,6.95505583 1.23316062,8.16042781 C1.23316062,9.62826482 2.38608539,10.8181818 3.80829016,10.8181818 C4.14881806,10.8181818 4.42487047,11.1030915 4.42487047,11.4545455 C4.42487047,11.8059994 4.14881806,12.0909091 3.80829016,12.0909091 C1.70502958,12.0909091 0,10.3311727 0,8.16042781 C0,6.53982126 0.958360642,5.11506416 2.36673733,4.52128609 L2.41510881,4.50163636 L2.42650167,4.44343195 C2.87247264,2.30284002 4.68471416,0.711815178 6.84510781,0.638971725 L7,0.636363636 Z",
                        id: "形状",
                        fill: "currentColor",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const closeIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "12px",
    height: "12px",
    viewBox: "0 0 12 12",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "20220814",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        opacity: "0.6",
        strokeLinecap: "square",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-76.000000, -330.000000)",
            stroke: "#000000",
            strokeWidth: "1.2",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "编组-3",
                transform: "translate(77.000000, 331.000000)",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M9.5,0.5 L0.5,9.5 M0.5,0.5 L9.5,9.5",
                    id: "形状结合"
                })
            })
        })
    })
});
const addIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "13px",
    height: "14px",
    viewBox: "0 0 13 14",
    version: "1.1",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: "形状结合"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "20220814",
            stroke: "none",
            strokeWidth: "1",
            fill: "currentColor",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "切图",
                transform: "translate(-46.000000, -273.000000)",
                fill: "currentColor",
                fillRule: "nonzero",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M56.8981,273 C58.0576062,273 59,273.942394 59,275.1019 L59,283.923272 C59,285.081205 58.0576062,286.023599 56.8981,286.023599 L48.1019,286.023599 C46.9423938,286.023599 46,285.081205 46,283.923272 L46,275.1019 C46,273.942394 46.9423938,273 48.1019,273 L56.8981,273 Z M56.8981,274.408084 L48.1019,274.408084 C47.7195934,274.408084 47.4080842,274.719593 47.4080842,275.1019 L47.4080842,283.923272 C47.4080842,284.305579 47.7195934,284.617088 48.1019,284.617088 L56.8981,284.617088 C57.2804066,284.617088 57.5919158,284.305579 57.5919158,283.923272 L57.5919158,275.1019 C57.5919158,274.719593 57.2804066,274.408084 56.8981,274.408084 Z M52.5306789,276.181169 C52.9192787,276.181169 53.2339403,276.495825 53.2339403,276.884425 L53.233,278.709 L55.0589374,278.709428 C55.4475372,278.709428 55.7621929,279.024083 55.7621929,279.412683 C55.7621929,279.801283 55.4475372,280.115939 55.0589374,280.115939 L53.233,280.115 L53.2339403,281.939368 C53.2355077,282.327968 52.9192787,282.642624 52.5306789,282.642624 C52.1420791,282.642624 51.8274235,282.327968 51.8274235,281.939368 L51.827,280.115 L50.0039937,280.115939 C49.6153939,280.115939 49.3007382,279.801283 49.3007382,279.412683 C49.3007382,279.024083 49.6153939,278.709428 50.0039937,278.709428 L51.827,278.709 L51.8274235,276.884425 C51.8274235,276.495825 52.1420791,276.181169 52.5306789,276.181169 Z",
                    id: "形状结合"
                })
            })
        })
    ]
});
const successIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 14 14",
    version: "1.1",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: "成功icon"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "页面-1",
            stroke: "none",
            strokeWidth: "1",
            fill: "none",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "所需icon",
                transform: "translate(-12.000000, -9.000000)",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                    id: "成功",
                    transform: "translate(12.000000, 9.000000)",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                            id: "椭圆形",
                            fill: "#40A291",
                            cx: "7",
                            cy: "7",
                            r: "7"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "M6.14630333,9.95510386 C5.96024123,9.95510386 5.78199687,9.88161715 5.65065892,9.7502792 L3.47732857,7.57694885 C3.20370784,7.30332812 3.20370784,6.86084432 3.47732857,6.58722359 C3.7509493,6.31360286 4.1934331,6.31360286 4.46705383,6.58722359 L6.14630333,8.26490954 L9.53294617,4.8782667 C9.8065669,4.60464597 10.2490507,4.60464597 10.5226714,4.8782667 C10.7962922,5.15188742 10.7962922,5.59437123 10.5226714,5.86799196 L6.64038419,9.7502792 C6.50904624,9.88161715 6.33236542,9.95510386 6.14630333,9.95510386 Z",
                            id: "路径",
                            fill: "#FFFFFF",
                            fillRule: "nonzero"
                        })
                    ]
                })
            })
        })
    ]
});
const pendingIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 14 14",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "所需icon",
            transform: "translate(-183.000000, -9.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-3",
                transform: "translate(183.000000, 9.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                        id: "椭圆形",
                        fill: "#000000",
                        opacity: "0.1",
                        cx: "7",
                        cy: "7",
                        r: "7"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M7,3.3 C7.35438271,3.3 7.64725823,3.56334362 7.69360983,3.90501415 L7.7,4 L7.699,6.798 L10.727887,6.79829608 C11.0822697,6.79829608 11.3751452,7.0616397 11.4214968,7.40331023 L11.427887,7.49829608 C11.427887,7.8526788 11.1645434,8.14555431 10.8228728,8.19190591 L10.727887,8.19829608 L7.6,8.19829608 C6.92690296,8.19829608 6.37328475,7.68674643 6.30671175,7.03121353 L6.3,6.89829608 L6.3,4 C6.3,3.61340068 6.61340068,3.3 7,3.3 Z",
                        id: "路径-5",
                        fill: "#FFFFFF",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const errorIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 14 14",
    version: "1.1",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: "失败icon"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "页面-1",
            stroke: "none",
            strokeWidth: "1",
            fill: "none",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "所需icon",
                transform: "translate(-72.000000, -62.000000)",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                    id: "失败icon",
                    transform: "translate(72.000000, 62.000000)",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                            id: "矩形",
                            fill: "#FFFFFF",
                            x: "0",
                            y: "0",
                            width: "14",
                            height: "14"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "M7,0 C10.86596,0 14,3.134005 14,7 C14,10.86596 10.86596,14 7,14 C3.134005,14 0,10.86596 0,7 C0,3.134005 3.134005,0 7,0 Z",
                            id: "路径",
                            fill: "#E15252",
                            fillRule: "nonzero"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "M7,6.10005455 L8.34991977,4.75011568 C8.59842933,4.50160261 9.00134579,4.50159976 9.24985886,4.75010932 C9.24986045,4.75011091 9.24986205,4.7501125 9.24986364,4.75011409 C9.49837735,4.99862957 9.49837771,5.40155079 9.24986443,5.6500667 L7.89994545,7 L7.89994545,7 L9.24986364,8.34991818 C9.49837671,8.59843126 9.49837671,9.00135056 9.24986364,9.24986364 C9.00135056,9.49837671 8.59843126,9.49837671 8.34991818,9.24986364 L7,7.89994545 L7,7.89994545 L5.6500667,9.24986443 C5.40155079,9.49837771 4.99862957,9.49837735 4.75011409,9.24986364 C4.50160189,9.0013532 4.50160047,8.59843674 4.75011091,8.34992455 C4.7501125,8.34992295 4.75011409,8.34992136 4.75011568,8.34991977 L6.10005455,7 L6.10005455,7 L4.75011489,5.65006511 C4.50160005,5.40155116 4.50159934,4.99862972 4.7501133,4.75011489 C4.75011356,4.75011462 4.75011383,4.75011436 4.75011409,4.75011409 C4.99862848,4.5015997 5.40154993,4.5015997 5.65006432,4.75011409 C5.65006458,4.75011436 5.65006485,4.75011462 5.65006511,4.75011489 L7,6.10005455 L7,6.10005455 Z",
                            id: "路径",
                            fill: "#FFFFFF",
                            fillRule: "nonzero"
                        })
                    ]
                })
            })
        })
    ]
});
const account_panel = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    height: "16",
    viewBox: "0 0 16 16",
    width: "16",
    fill: "currentColor",
    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "m9.56594136 5.6h2.46811724c.4230178 0 .7659414.34292363.7659414.76594136 0 .42301774-.3429236.76594137-.7659414.76594137h-2.46811724c-.42301773 0-.76594136-.34292363-.76594136-.76594137 0-.42301773.34292363-.76594136.76594136-.76594136zm.01090997 3.24629733h2.44629737c.4290431 0 .7768513.34780819.7768513.77685134 0 .42904313-.3478082.77685133-.7768513.77685133h-2.44629737c-.42904314 0-.77685133-.3478082-.77685133-.77685133 0-.42904315.34780819-.77685134.77685133-.77685134zm-3.97685133-3.24629733v2.4h2.4c0 1.32552-1.07448 2.4-2.4 2.4-1.32548 0-2.4-1.07448-2.4-2.4s1.07452-2.4 2.4-2.4z"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                height: "2.4",
                rx: ".77",
                width: "1.54",
                x: "7.2",
                y: "13.6"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "m13.6 2.4h-11.2c-1.3254834 0-2.4 1.0745166-2.4 2.4v7.2c0 1.3254834 1.0745166 2.4 2.4 2.4h11.2c1.3254834 0 2.4-1.0745166 2.4-2.4v-7.2c0-1.3254834-1.0745166-2.4-2.4-2.4zm-11.2 1.6h11.2c.4418278 0 .8.3581722.8.8v7.2c0 .4418278-.3581722.8-.8.8h-11.2c-.4418278 0-.8-.3581722-.8-.8v-7.2c0-.4418278.3581722-.8.8-.8z"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "m15.2 0c.4418278 0 .8.34474074.8.77 0 .3948836-.3088322.72034051-.7067031.76481965l-.0932969.00518035h-14.4c-.4418278 0-.8-.34474074-.8-.77 0-.3948836.30883215-.72034051.7067031-.76481965l.0932969-.00518035z"
            })
        ]
    })
});
const account_overview = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "16px",
    height: "16px",
    viewBox: "0 0 16 16",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "会员",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            id: "编组-6备份-2",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                    id: "矩形",
                    fill: "#FFFFFF",
                    opacity: "0",
                    x: "0",
                    y: "0",
                    width: "16",
                    height: "16"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M14.2256381,13.8363478 C14.657456,13.8363478 15.0075451,14.1805217 15.0075451,14.6050435 C15.0075451,15.0295652 14.6572791,15.3737391 14.2254612,15.3737391 L1.7768784,15.3737391 C1.34506053,15.3737391 0.994847108,15.0295652 0.994847108,14.6050435 C0.994847108,14.1805217 1.34506053,13.8363478 1.7768784,13.8363478 L14.2256381,13.8363478 Z M13.6852174,0 C14.9613913,0 16,1.03843478 16,2.3146087 L16,10.1532174 C16,11.4293913 14.9613913,12.468 13.6852174,12.468 L2.31478261,12.468 C1.0386087,12.468 0,11.4293913 0,10.1532174 L0,2.3146087 C0,1.03843478 1.0386087,0 2.31478261,0 L13.6852174,0 Z M13.6852174,1.5373913 L2.31478261,1.5373913 C1.88608696,1.53756522 1.5373913,1.88608696 1.5373913,2.31478261 L1.5373913,10.1533913 C1.5373913,10.582087 1.88608696,10.9307826 2.31478261,10.9307826 L13.6852174,10.9307826 C14.113913,10.9307826 14.4626087,10.582087 14.4626087,10.1533913 L14.4626087,2.3146087 C14.4626087,1.88591304 14.113913,1.5373913 13.6852174,1.5373913 Z M11.7175652,4.24052174 C12.017913,4.54034783 12.017913,5.02730435 11.7175652,5.32747826 L8.81808696,8.22730435 C8.67396109,8.37147632 8.47846606,8.45252174 8.2746087,8.45252174 C8.07078261,8.45252174 7.87530435,8.37147826 7.73113043,8.22730435 L6.30817391,6.80434783 L5.3693913,7.74313043 C5.06904348,8.04347826 4.5826087,8.04347826 4.28243478,7.74313043 C3.98208696,7.44278261 3.98208696,6.95634783 4.28243478,6.65617391 L5.76469565,5.17391304 C6.06504348,4.87356522 6.55147826,4.87356522 6.85165217,5.17391304 L8.2746087,6.59686957 L10.6306087,4.24052174 C10.9309565,3.94017391 11.4173913,3.94017391 11.7175652,4.24052174 Z",
                    id: "形状结合",
                    fill: "currentColor",
                    fillRule: "nonzero"
                })
            ]
        })
    })
});
const account_miners = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    height: "16",
    viewBox: "0 0 16 16",
    width: "16",
    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
        fill: "none",
        fillRule: "evenodd",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "m0 0h16v16h-16z",
                fill: "currentColor",
                opacity: "0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "m12.5775785 8.59372197c1.8869955 0 3.4224215 1.53542603 3.4224215 3.42242153s-1.535426 3.4224215-3.4206278 3.4224215h-9.15695068c-1.88699551 0-3.42242152-1.535426-3.42242152-3.4224215s1.53542601-3.42242153 3.42242152-3.42242153zm0 1.60179373h-9.15515698c-1.0044843 0-1.82242152.8179372-1.82242152 1.8224215s.81793722 1.8224215 1.82242152 1.8224215h9.15515698c1.0044843 0 1.8224215-.8179372 1.8224215-1.8224215s-.8179372-1.8224215-1.8224215-1.8224215zm-.0717489.7156951c.6102375 0 1.1049327.4946952 1.1049327 1.1049327s-.4946952 1.1049327-1.1049327 1.1049327-1.1049327-.4946952-1.1049327-1.1049327.4946952-1.1049327 1.1049327-1.1049327zm.0717489-10.1112108c1.8869955 0 3.4224215 1.53542601 3.4224215 3.42242152 0 1.88699552-1.535426 3.42242153-3.4206278 3.42242153h-9.15695068c-1.88699551 0-3.42242152-1.53542601-3.42242152-3.42242153 0-1.88699551 1.53542601-3.42242152 3.42242152-3.42242152zm0 1.60179372h-9.15515698c-1.0044843 0-1.82242152.81793722-1.82242152 1.82242153 0 1.0044843.81793722 1.82242152 1.82242152 1.82242152h9.15515698c1.0044843 0 1.8224215-.81793722 1.8224215-1.82242152 0-1.00448431-.8179372-1.82242153-1.8224215-1.82242153zm-9.11569509.7103139c.6102375 0 1.10493273.49469524 1.10493273 1.10493274s-.49469523 1.10493273-1.10493273 1.10493273-1.10493274-.49469523-1.10493274-1.10493273.49469524-1.10493274 1.10493274-1.10493274z",
                fill: "currentColor",
                fillRule: "nonzero"
            })
        ]
    })
});
const account_personal = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "16px",
    height: "16px",
    viewBox: "0 0 16 16",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "会员",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            id: "编组-7备份",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                    id: "矩形",
                    fill: "#FFFFFF",
                    opacity: "0",
                    x: "0",
                    y: "0",
                    width: "16",
                    height: "16"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M8.10303126,0 C11.2142915,0 13.7458804,2.53158895 13.7458804,5.64284916 C13.7458804,7.32979868 13.0016204,8.84633107 11.8242424,9.88130422 C13.5164132,10.3467299 14.8721868,11.6168748 15.3292417,13.2805546 C15.5027853,13.91211 15.3721803,14.5776585 14.9696308,15.1036565 C14.5420338,15.6654367 13.8532269,16 13.1268488,16 L3.07921375,16 C2.35104647,16 1.66223958,15.6654367 1.23464258,15.1054456 C0.832093098,14.5776585 0.701488155,13.9138991 0.875031709,13.2823437 C1.33217675,11.6169292 2.68839506,10.3463107 4.38116049,9.87912387 C3.20401776,8.84546619 2.46018211,7.32931766 2.46018211,5.64284916 C2.46018211,2.53158895 4.99177106,0 8.10303126,0 Z M10.3787777,11.2856983 L5.82549576,11.2856983 C4.20993051,11.2856983 2.80905832,12.2804428 2.41724349,13.7063625 C2.36535934,13.8960081 2.43692369,14.0445041 2.50669893,14.1357486 C2.63372566,14.3021357 2.84662961,14.4005367 3.07742464,14.4005367 L13.1268488,14.4005367 C13.3576438,14.4005367 13.5723369,14.3021357 13.6975745,14.1357486 C13.7673497,14.0445041 13.8389141,13.8960081 13.7870299,13.7063625 C13.3952151,12.2804428 11.9943429,11.2856983 10.3787777,11.2856983 Z M8.10303126,1.59946327 C5.8738017,1.59946327 4.06143448,3.41361959 4.06143448,5.64284916 C4.06143448,7.87207872 5.87559081,9.68444594 8.10303126,9.68444594 C10.3304717,9.68444594 12.1464172,7.87028961 12.1464172,5.64284916 C12.144628,3.41361959 10.3322608,1.59946327 8.10303126,1.59946327 Z M7.21742241,6.14558873 C7.39812239,6.46226099 7.73805307,6.66085206 8.10303126,6.66085206 C8.45906391,6.66085206 8.78468171,6.47836297 8.97253814,6.17421447 C9.20333317,5.79850162 9.69533809,5.67863133 10.0728401,5.91121548 C10.450342,6.14201051 10.5666341,6.63580454 10.335839,7.01151739 C9.85456878,7.79335793 9.01905497,8.26031533 8.10303126,8.26031533 C7.16553825,8.26031533 6.29245316,7.75399754 5.82728487,6.93816393 C5.60901359,6.55350554 5.74140765,6.06507883 6.12606604,5.84680756 C6.51072443,5.62853629 6.99915113,5.76093034 7.21742241,6.14558873 Z",
                    id: "形状结合",
                    fill: "currentColor",
                    fillRule: "nonzero"
                })
            ]
        })
    })
});
const account_logout = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "12px",
    height: "13px",
    viewBox: "0 0 12 13",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            id: "切图",
            transform: "translate(-882.000000, -464.000000)",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                    id: "矩形",
                    fill: "transparent",
                    x: "0",
                    y: "0",
                    width: "1507",
                    height: "1024"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M888.05,464 C888.139,464 888.224,464.034 888.288,464.097 C888.351,464.161 888.386,464.247 888.386,464.335 L888.386,464.335 L888.386,464.906 C888.386,464.994 888.351,465.081 888.289,465.143 C888.224,465.207 888.139,465.242 888.05,465.242 L888.05,465.242 L883.194,465.242 L883.243,474.906 L888.05,474.856 C888.139,474.856 888.224,474.891 888.288,474.955 C888.351,475.017 888.386,475.104 888.386,475.192 L888.386,475.192 L888.386,475.763 C888.386,475.851 888.351,475.938 888.288,476.001 C888.224,476.064 888.139,476.099 888.05,476.099 L888.05,476.099 L883.194,476.099 C882.557,476.099 882.033,475.601 882.002,474.965 L882.002,474.965 L882,465.192 C882,464.555 882.498,464.033 883.133,464.001 L883.133,464.001 Z M890.4557,466.8557 C890.5437,466.8557 890.6277,466.8907 890.6917,466.9547 L890.6917,466.9547 L893.1447,469.4077 C893.4817,469.7437 893.4987,470.2887 893.1867,470.6467 L893.1867,470.6467 L890.6917,473.1427 C890.6277,473.2067 890.5437,473.2417 890.4557,473.2417 C890.3657,473.2417 890.2817,473.2067 890.2177,473.1427 L890.2177,473.1427 L889.8137,472.7387 C889.6827,472.6087 889.6827,472.3957 889.8137,472.2647 L889.8137,472.2647 L891.4927,470.5857 L885.7647,470.6707 C885.6757,470.6707 885.5907,470.6357 885.5277,470.5727 C885.4637,470.5097 885.4297,470.4257 885.4297,470.3347 L885.4297,470.3347 L885.4297,469.7627 C885.4297,469.6737 885.4637,469.5897 885.5277,469.5257 C885.5907,469.4627 885.6747,469.4277 885.7647,469.4277 L885.7647,469.4277 L891.5277,469.4277 L889.8137,467.8327 C889.6827,467.7027 889.6827,467.4897 889.8137,467.3587 L889.8137,467.3587 L890.2177,466.9547 C890.2817,466.8907 890.3657,466.8557 890.4557,466.8557 Z",
                    id: "形状结合",
                    fill: "currentColor"
                })
            ]
        })
    })
});
const legendIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "20px",
    height: "8px",
    viewBox: "0 0 20 8",
    version: "1.1",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: "2"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "页面-1",
            stroke: "none",
            strokeWidth: "1",
            fill: "none",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "切图",
                transform: "translate(-302.000000, -130.000000)",
                fill: "currentColor",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                    id: "2",
                    transform: "translate(302.000000, 131.000000)",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("polygon", {
                            id: "矩形",
                            points: "-4.37150316e-16 2 20 2 20 3.5 -4.37150316e-16 3.5"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                            id: "椭圆形",
                            stroke: "#FFFFFF",
                            strokeWidth: "2",
                            cx: "10",
                            cy: "3",
                            r: "3"
                        })
                    ]
                })
            })
        })
    ]
});
const no_nodes = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "92px",
    height: "80px",
    viewBox: "0 0 92 80",
    version: "1.1",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: "形状结合"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                x1: "50%",
                y1: "0%",
                x2: "50%",
                y2: "100%",
                id: "linearGradient-1",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                        stopColor: "#000000",
                        offset: "0%"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                        stopColor: "#000000",
                        offset: "100%"
                    })
                ]
            })
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "20220814",
            stroke: "none",
            strokeWidth: "1",
            fill: "none",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "切图",
                transform: "translate(-144.000000, -214.000000)",
                fill: "currentColor",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M228.347553,214.043156 C231.329471,214.168236 233.529946,215.579465 234.888023,218.237834 C235.127941,218.7067 235.289594,219.24798 235.460756,219.820713 C235.529025,220.049416 235.599245,220.284702 235.676292,220.520232 L235.676292,228.886182 C235.640695,228.960059 235.605585,229.048322 235.580227,229.150726 C234.529851,233.408066 231.907324,235.478341 227.563184,235.479073 L196.861623,235.47956 L199.667015,237.276269 C202.126671,238.851346 203.991649,240.571496 205.535761,242.689072 C205.948792,243.25449 206.718287,243.298865 206.944552,243.298865 L208.262887,243.299353 C210.591855,243.299353 212.920822,243.296671 215.249547,243.293989 C217.577783,243.291307 219.90602,243.288625 222.234012,243.288625 C224.233092,243.288625 226.23144,243.290575 228.231007,243.296427 C230.115979,243.301547 231.828326,243.976441 233.319773,245.301602 C234.456949,246.312236 235.207427,247.665924 235.676292,249.556016 L235.676292,258.140428 C235.627528,258.234055 235.576326,258.35182 235.544142,258.49031 C234.638351,262.393135 231.702028,264.72893 227.689239,264.738683 C226.514759,264.741609 225.33979,264.743072 224.16531,264.743072 C222.96596,264.743072 221.766853,264.741609 220.567259,264.738683 C219.376443,264.736001 218.185382,264.732344 216.994566,264.728686 C214.591964,264.721372 212.189363,264.714057 209.786761,264.714057 C208.81075,264.714057 207.834983,264.715276 206.859215,264.718202 C206.242351,264.72064 205.645236,265.137572 205.326807,265.549628 C203.826095,267.493117 202.165194,269.044055 200.249501,270.291438 C200.076633,270.403839 199.948383,270.525993 199.812576,270.655705 C199.756253,270.709345 199.692129,270.770544 199.614106,270.840033 L197.712798,272.54214 L216.637857,272.539945 C220.401705,272.539945 224.16531,272.541164 227.929158,272.545553 C231.233406,272.549454 233.912743,274.279113 235.096732,277.172036 C235.263261,277.579459 235.388097,278.019798 235.520004,278.485738 C235.571206,278.666409 235.622408,278.847079 235.676292,279.027018 L235.676292,287.418569 C235.65825,287.462212 235.640939,287.510733 235.626553,287.563885 C234.375269,292.135021 231.934144,294 227.201112,294 L151.745915,294 C149.353798,294 147.419574,293.1498 145.833038,291.40088 C144.813871,290.27687 144.344518,288.885389 144,287.538284 L144,279.124302 C144.03194,279.055789 144.063881,278.974353 144.088019,278.881214 C145.209591,274.557068 147.817489,272.542627 152.295242,272.542383 L181.972515,272.54214 L179.793253,270.804435 C179.419477,270.506243 179.053747,270.225607 178.697282,269.952041 C177.944366,269.374187 177.2329,268.828031 176.604576,268.234329 C176.076462,267.73523 175.59638,267.182246 175.087528,266.597322 C174.717166,266.171125 174.334369,265.730542 173.928408,265.308978 C173.459786,264.822313 172.739055,264.74868 172.351137,264.747948 L169.747384,264.74551 L169.747384,264.74551 C168.15841,264.74551 166.568948,264.747704 164.979973,264.750142 C163.39173,264.752337 161.803731,264.754531 160.215976,264.754531 L158.960461,264.754013 C156.111709,264.751583 153.807931,264.740542 151.618397,264.719421 C148.434841,264.688456 146.086611,263.138005 144.63954,260.110981 C144.450823,259.716724 144.315503,259.27029 144.172381,258.797767 C144.115814,258.611976 144.059736,258.426429 144,258.242589 L144,249.655495 C144.04657,249.550652 144.098259,249.411675 144.12191,249.246852 C144.548107,246.27737 147.314488,243.270826 151.776637,243.270826 L151.84003,243.27107 C154.81829,243.290575 157.714871,243.293257 160.155508,243.293257 L166.637949,243.290575 C168.526334,243.290575 170.413744,243.292526 172.301642,243.299353 C173.131605,243.299353 173.716041,243.002624 174.208557,242.33724 C175.522503,240.562474 177.152195,239.026896 179.051796,237.77293 C179.218813,237.66248 179.353402,237.547153 179.509203,237.41354 C179.579423,237.353316 179.658177,237.285534 179.751803,237.208731 L181.857189,235.47956 L162.947978,235.481998 C159.213632,235.481998 155.479774,235.480779 151.745184,235.475903 C148.494089,235.472002 145.748677,233.698456 144.57956,230.847957 C144.412543,230.440778 144.287951,230.000927 144.155801,229.534987 C144.104599,229.35456 144.05364,229.174377 144,228.994682 L144,220.573385 C144.012679,220.540226 144.02487,220.504384 144.035842,220.466104 C145.367098,215.828406 147.759216,214.022188 152.567345,214.022188 L222.359823,214.022431 C222.963521,214.022431 223.567707,214.017067 224.171649,214.011216 C224.769739,214.005852 225.36783,214 225.96592,214 C226.889754,214 227.646571,214.013898 228.347553,214.043156 Z M227.500523,276.44399 L170.84238,276.443258 C164.529882,276.443258 158.219334,276.443746 151.906836,276.445697 C149.368427,276.446184 147.908921,277.907397 147.902094,280.454096 C147.898437,281.760727 147.899492,283.067846 147.900387,284.374721 L147.901119,285.758886 C147.90185,288.759578 149.234814,290.097906 152.222583,290.097906 L194.818168,290.09815 L211.317219,290.098637 C216.816577,290.098637 222.316423,290.09815 227.816026,290.096199 C230.288116,290.095468 231.767859,288.61353 231.774198,286.131687 C231.777612,284.839929 231.776619,283.547927 231.776619,282.256413 L231.775174,280.735708 C231.774198,277.807919 230.416121,276.444234 227.500523,276.44399 Z M163.65369,281.315293 L163.859718,281.317975 L163.859718,281.317975 C163.939447,281.319194 164.01942,281.320657 164.098906,281.320657 L178.857082,281.320413 C188.16954,281.320413 197.480292,281.320901 206.79275,281.322363 L207.116543,281.321388 C207.383769,281.321388 207.59955,281.32919 207.782415,281.366007 C208.752818,281.562038 209.434295,282.484653 209.334329,283.466272 C209.232412,284.467397 208.410739,285.202026 207.380844,285.212754 C206.44555,285.222751 205.430772,285.227627 204.187046,285.227627 C203.45705,285.227627 202.727053,285.226164 201.9973,285.224458 C201.266084,285.222995 200.534868,285.221532 199.803408,285.221532 L185.449973,285.221532 L173.473782,285.223482 C170.213422,285.223482 166.953549,285.222263 163.693433,285.216899 C162.913941,285.21568 162.244411,284.887498 161.856737,284.317204 C161.509294,283.805669 161.45029,283.189293 161.689965,282.581206 C161.990595,281.819512 162.528705,281.421354 163.383294,281.326996 C163.455465,281.319194 163.541289,281.315293 163.65369,281.315293 Z M154.814023,281.226786 C155.938033,281.227517 156.758,282.017982 156.765558,283.106394 C156.768971,283.625243 156.571234,284.112639 156.207942,284.478369 C155.838555,284.850438 155.340918,285.055247 154.807196,285.055247 L154.79208,285.055247 C153.741459,285.047688 152.888577,284.176763 152.89101,283.114196 C152.89321,282.020664 153.701961,281.226786 154.814023,281.226786 Z M216.323573,281.211937 C217.402964,281.233881 218.268525,282.09676 218.25292,283.135433 C218.236828,284.193855 217.353225,285.054539 216.283343,285.054539 L216.229703,285.053808 C215.170305,285.026012 214.353021,284.154112 214.368625,283.06887 C214.383742,282.010204 215.205415,281.21145 216.279442,281.21145 L216.323573,281.211937 Z M225.115013,281.211937 C226.23122,281.217789 227.062646,282.037268 227.059728,283.118609 C227.057039,284.178982 226.191965,285.047225 225.131593,285.053808 L225.117939,285.053808 C224.060735,285.053808 223.186153,284.204096 223.168355,283.159327 C223.159577,282.631701 223.349269,282.143086 223.703052,281.783207 C224.065368,281.414796 224.566662,281.211937 225.115013,281.211937 Z M189.726233,238.451969 C185.592266,238.451969 181.702607,240.068983 178.773598,243.004818 C175.845321,245.940167 174.232939,249.838116 174.233427,253.980372 C174.234402,262.525773 181.183758,269.478055 189.72477,269.478055 C193.871659,269.477323 197.768633,267.863235 200.702031,264.933983 C203.63616,262.003999 205.250735,258.11312 205.248786,253.97769 C205.244884,245.416929 198.28163,238.451969 189.726233,238.451969 Z M189.862748,243.284748 C190.899958,243.296939 191.741624,244.133973 191.779172,245.189957 C191.803067,245.870702 191.797946,246.57461 191.792826,247.255112 C191.790632,247.560374 191.788194,247.865637 191.788437,248.170899 L191.788681,252.061778 L192.763961,252.061778 C193.37156,252.061778 193.972576,252.059827 194.568716,252.057877 C195.153884,252.055926 195.734175,252.053976 196.312516,252.053976 C197.21465,252.053976 197.953912,252.058852 198.63929,252.068605 C199.549226,252.081771 200.265325,252.651822 200.507194,253.556394 C200.719561,254.34954 200.370411,255.226317 199.69503,255.596192 C199.330519,255.79588 198.814596,255.924617 198.315741,255.940953 C197.629631,255.963384 196.87574,255.973625 195.943373,255.973625 C195.433058,255.973625 194.919329,255.970699 194.398774,255.967773 C193.861394,255.964603 193.317432,255.961678 192.763961,255.961678 L191.788681,255.961678 L191.788681,261.344246 C191.788681,261.493952 191.789657,261.643657 191.790876,261.79385 C191.793314,262.13276 191.795752,262.452895 191.784536,262.771324 C191.744794,263.889482 190.908979,264.734319 189.84056,264.736513 L189.836903,264.736513 C188.767265,264.736513 187.91487,263.885338 187.896584,262.798632 C187.874152,261.480785 187.879273,260.174154 187.884393,258.790476 C187.886831,258.182633 187.889269,257.566013 187.889269,256.936957 L187.889269,255.961678 L182.798553,255.961434 C182.605691,255.961434 182.424289,255.96314 182.242887,255.964603 L181.716724,255.968017 L181.716724,255.968017 C181.442183,255.968017 181.219331,255.963872 181.01501,255.954607 C179.956832,255.90755 179.121261,255.061007 179.113147,254.027454 C179.104437,252.950258 179.945616,252.090549 181.027445,252.070312 C181.693073,252.057877 182.410879,252.052025 183.286437,252.052025 C183.863802,252.052025 184.446532,252.054219 185.038283,252.056901 C185.652465,252.059583 186.2764,252.062265 186.914965,252.062265 L187.890244,252.062265 L187.890244,251.086986 C187.890244,250.464026 187.887562,249.850087 187.88488,249.242244 C187.878785,247.844668 187.872689,246.524871 187.899022,245.18825 C187.919747,244.120563 188.771653,243.284504 189.838122,243.284504 L189.862748,243.284748 Z M220.056147,247.182692 L215.55069,247.182933 C215.46905,247.182966 215.386684,247.183 215.30373,247.183035 L213.271303,247.183952 C213.187856,247.183991 213.104935,247.184031 213.022679,247.18407 L211.247438,247.18495 C211.184726,247.184982 211.123792,247.185013 211.064776,247.185043 L209.998397,247.185599 L209.998397,247.185599 C209.819677,247.185599 209.655586,247.199496 209.481742,247.21437 C209.404451,247.220709 209.321553,247.228023 209.230364,247.234119 L208.031501,247.316774 L208.358952,248.472968 C209.401526,252.154405 209.397868,255.86632 208.348224,259.505576 L208.070513,260.466958 L209.039209,260.719799 C209.072125,260.728333 209.100408,260.737598 209.125278,260.7454 C209.232315,260.779291 209.393967,260.830249 209.598776,260.830249 L213.929018,260.834151 C215.963208,260.836345 217.997397,260.838539 220.031343,260.838539 L221.341911,260.838196 C223.899218,260.836823 226.08682,260.831329 228.143476,260.821716 C230.150114,260.811719 231.741526,259.194462 231.767128,257.13906 C231.789071,255.352835 231.782102,253.540034 231.775661,251.787212 L231.771272,250.547876 C231.767371,249.230516 231.073947,248.171607 229.868502,247.641786 C229.226036,247.359442 228.495796,247.202179 227.812368,247.199253 C225.489395,247.189615 223.039758,247.184276 220.056147,247.182692 Z M154.824142,247.177309 C153.57871,247.177309 152.558567,247.181698 151.614252,247.191207 C149.328197,247.214613 147.905508,248.660953 147.90185,250.966027 C147.898437,252.885865 147.898681,254.805947 147.90185,256.725785 C147.905751,259.337828 149.41329,260.836345 152.038012,260.83732 L155.578886,260.838417 L155.578886,260.838417 L159.119761,260.838783 C162.485208,260.838783 165.849923,260.837808 169.215369,260.836589 C169.437245,260.836345 169.646687,260.824154 169.868807,260.811719 C169.970236,260.805624 170.076054,260.799528 170.187723,260.794408 L171.342454,260.741255 L170.364005,256.26082 L169.829308,256.088927 C169.813703,256.084051 169.800781,256.078443 169.789077,256.074298 C169.700571,256.039676 169.535261,255.975795 169.317774,255.974819 C168.588021,255.972137 167.858755,255.971162 167.12949,255.970187 C166.002066,255.96848 164.874399,255.966773 163.746976,255.959703 C162.452048,255.951657 161.551865,255.1451 161.557961,253.998659 C161.564056,252.845878 162.454486,252.067361 163.773552,252.061997 C164.515252,252.058828 165.256709,252.058096 166.003042,252.058096 L170.294029,252.060291 L171.334408,247.183648 L159.363581,247.183648 C158.607739,247.183648 157.851654,247.182185 157.095812,247.180479 C156.338507,247.178772 155.581447,247.177309 154.824142,247.177309 Z M154.794957,252.074773 C155.367933,252.074773 155.869715,252.277144 156.232519,252.645068 C156.583376,253.000558 156.772336,253.482346 156.765509,254.001195 C156.75088,255.04962 155.857524,255.935662 154.814462,255.93615 C153.779934,255.93615 152.899257,255.046938 152.890967,253.99388 C152.882839,252.963102 153.624859,252.16564 154.640181,252.081919 L154.794957,252.074773 Z M225.105626,252.068678 C226.214519,252.068678 227.049114,252.880842 227.059842,253.958039 C227.064963,254.460795 226.852596,254.966478 226.476869,255.346105 C226.105287,255.721344 225.610089,255.936393 225.118061,255.936393 L225.09246,255.93615 C224.049154,255.921033 223.167989,255.022069 223.16872,253.973399 C223.169452,252.893765 224.002097,252.075017 225.105626,252.068678 Z M216.291048,252.067971 C217.379216,252.067971 218.238925,252.901347 218.252823,253.965378 C218.259406,254.448872 218.046064,254.946021 217.667655,255.32955 C217.28754,255.714786 216.790391,255.935686 216.30397,255.935686 L216.274224,255.935443 C215.201417,255.915693 214.363895,255.051839 214.368267,253.968791 C214.372429,252.869895 215.181423,252.070165 216.291048,252.067971 Z M170.879196,217.923306 C164.556946,217.923306 158.234695,217.923794 151.912444,217.925501 C149.371109,217.926232 147.909409,219.385495 147.902094,221.929024 C147.898193,223.224927 147.899407,224.52083 147.900387,225.816733 L147.901119,227.234058 C147.90185,230.237919 149.233351,231.57771 152.218194,231.577954 L191.522454,231.578198 L209.666558,231.578685 C215.714511,231.578685 221.762464,231.578198 227.810662,231.576247 C230.285678,231.575516 231.767615,230.095285 231.774198,227.616855 C231.777612,226.324853 231.776619,225.033096 231.776619,223.741094 L231.775174,222.220876 C231.774198,219.289429 230.41734,217.924038 227.505155,217.924038 L170.879196,217.923306 Z M154.867883,222.880873 C155.974826,222.910131 156.790159,223.739363 156.765046,224.809732 C156.739201,225.895218 155.909238,226.713234 154.833992,226.713234 L154.813999,226.713234 C153.739484,226.702994 152.894405,225.854744 152.890492,224.78218 C152.888797,224.26065 153.07922,223.7813 153.427395,223.431906 C153.781909,223.076172 154.272231,222.880141 154.808635,222.880141 L154.867883,222.880873 Z M216.285099,222.862854 C217.401062,222.87407 218.255164,223.715249 218.252488,224.77806 C218.249556,225.826729 217.350835,226.712771 216.290219,226.712771 L216.248282,226.712283 C215.163283,226.68912 214.355264,225.846966 214.368674,224.75319 C214.38184,223.675506 215.205708,222.862854 216.285099,222.862854 Z M225.10153,222.862586 L225.151025,222.863074 C226.257968,222.888919 227.078665,223.724002 227.060135,224.805831 C227.041605,225.874981 226.18726,226.712747 225.115184,226.712747 L225.101286,226.712747 C224.021164,226.705676 223.172183,225.86084 223.168511,224.789251 C223.166575,224.268939 223.36285,223.784469 223.720777,223.425566 C224.082362,223.062275 224.572684,222.862586 225.10153,222.862586 Z M166.085038,222.797535 C166.451743,222.798998 166.818692,222.800217 167.185641,222.800217 L178.624453,222.800217 C188.006888,222.800217 197.388591,222.800461 206.771269,222.802411 L207.138218,222.800705 C207.354487,222.800705 207.580995,222.805825 207.769468,222.842398 C208.707443,223.023556 209.396235,223.915693 209.338206,224.873174 C209.277738,225.866253 208.461429,226.663056 207.480054,226.687194 C206.808818,226.703774 206.079308,226.711576 205.183514,226.711576 C204.659545,226.711576 204.135332,226.708894 203.611363,226.706456 C203.084225,226.704018 202.557086,226.701336 202.029947,226.701336 L173.3616,226.70353 C170.145615,226.70353 166.930606,226.702311 163.714865,226.697435 C162.931471,226.696459 162.258528,226.372423 161.869148,225.808955 C161.518047,225.301322 161.45246,224.682019 161.684332,224.065155 C161.979842,223.279079 162.657905,222.819723 163.545166,222.805337 C164.026954,222.797047 164.50923,222.795097 164.991262,222.795097 C165.355773,222.795097 165.720284,222.796072 166.085038,222.797535 Z",
                    id: "形状结合"
                })
            })
        })
    ]
});
const editIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "20220814",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-41.000000, -393.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-4备份-2",
                transform: "translate(41.000000, 393.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M17.8221813,7.31303085 L20.6883098,10.1791594 C21.1324022,10.6232518 21.0977567,11.3807286 20.6111448,11.8673405 L18.6753706,13.8044691 C18.6664099,13.8146207 18.6570778,13.8245571 18.6473743,13.8342606 L13.7308616,18.7476238 C13.4473983,19.031087 13.0820457,19.2263617 12.7009451,19.2988023 L9.0552926,19.9854133 C8.99859995,19.9964369 8.9419073,20.0027361 8.88521464,20.0027361 C8.64899526,20.0027361 8.42222465,19.9113979 8.25687109,19.7444696 C8.05057282,19.5381713 7.96080946,19.2389601 8.01592732,18.9444733 L8.70253832,15.3003956 C8.77497893,14.9177202 8.97025362,14.5523675 9.25371688,14.2689043 L14.1605635,9.36214986 C14.1627168,9.3599352 14.1648889,9.35773222 14.16708,9.35554111 L16.1340001,7.38862105 C16.620612,6.90200912 17.3780888,6.86736361 17.8221813,7.31303085 Z M14.661,10.703 L10.1733977,15.1901599 C10.0726107,15.2909468 10.0048945,15.4153557 9.98127258,15.5429141 L9.40489729,18.5980182 L12.4600013,18.0216429 C12.5875598,17.9980209 12.7119686,17.9287299 12.8127556,17.8295178 L17.3,13.342 L14.661,10.703 Z M17.0190354,8.34767175 L15.58,9.783 L18.218,12.42 L19.6552437,10.9838801 L17.0190354,8.34767175 Z",
                        id: "形状结合",
                        fill: "currentColor",
                        fillRule: "nonzero"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形备份-2",
                        strokeOpacity: "0.2",
                        stroke: "currentColor",
                        strokeWidth: "0.5",
                        x: "0.25",
                        y: "0.25",
                        width: "27.5",
                        height: "27.5",
                        rx: "5"
                    })
                ]
            })
        })
    })
});
const downloadIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "12px",
    height: "12px",
    viewBox: "0 0 12 12",
    version: "1.1",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: "形状结合"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "20220814",
            stroke: "none",
            strokeWidth: "1",
            fill: "none",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "切图",
                transform: "translate(-80.000000, -226.000000)",
                fill: "currentColor",
                fillRule: "nonzero",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M91.4004672,233.168812 C91.7324936,233.168812 92,233.437659 92,233.768341 L92,235.43385 C92.0013408,236.362717 91.2082415,237.119522 90.232326,237.119522 L81.7690148,237.119522 C80.7930994,237.119522 80,236.362717 80,235.43385 L80,233.768341 C80,233.436315 80.2688472,233.168812 80.5995293,233.168812 C80.9302115,233.168812 81.1990587,233.437659 81.1990587,233.768341 L81.1990587,235.43385 C81.1990587,235.701353 81.4544636,235.919119 81.7690148,235.919119 L90.232326,235.919119 C90.545533,235.919119 90.8009379,235.701353 90.8009379,235.43385 L90.8009379,233.768341 C90.8009379,233.436315 91.0697851,233.168812 91.4004672,233.168812 Z M87.0357323,226 C87.8866338,226 88.5789155,226.754117 88.5789155,227.680295 L88.5789155,229.876777 L89.139462,229.876777 C89.5669291,229.876777 89.9406267,230.133526 90.1140332,230.546207 C90.300882,230.991149 90.209474,231.495238 89.8801361,231.832641 L87.0935344,234.678389 C86.8031794,234.974121 86.4241048,235.138118 86.0248667,235.138118 C86.0235224,235.139462 86.0235224,235.139462 86.0221782,235.139462 C85.6242843,235.139462 85.2452097,234.976809 84.9548546,234.682422 L82.1292701,231.817854 C81.798588,231.481795 81.7044915,230.976362 81.8913403,230.53142 C82.0647468,230.117395 82.4384445,229.860646 82.8659116,229.860646 L83.4210811,229.860646 L83.4210811,227.680295 C83.4210811,226.754117 84.1133628,226 84.9642643,226 L87.0357323,226 Z M87.0370765,227.200403 L84.9656085,227.200403 C84.7827924,227.200403 84.6228283,227.42489 84.6228283,227.680295 L84.6228283,230.458831 C84.6228283,230.790858 84.3539811,231.058361 84.023299,231.058361 L83.0648585,231.058361 L83.0648585,231.059705 L85.8097889,233.839586 C85.8743122,233.904109 85.946901,233.939059 86.0221782,233.939059 C86.0974554,233.939059 86.1713884,233.904109 86.2345675,233.839586 L88.9391708,231.078524 L87.9793861,231.078524 C87.6473598,231.078524 87.3798568,230.809677 87.3798568,230.478995 L87.3798568,227.680295 C87.3798568,227.42489 87.2198927,227.200403 87.0370765,227.200403 Z",
                    id: "形状结合"
                })
            })
        })
    ]
});
const dateArrowIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "10px",
    height: "4px",
    viewBox: "0 0 10 4",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "20220814",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-82.000000, -252.000000)",
            stroke: "currentColor",
            strokeWidth: "1.2",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("polyline", {
                id: "路径-5",
                points: "82 254.860465 90 254.860465 88.0668178 253"
            })
        })
    })
});
const dateIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "12px",
    height: "12px",
    viewBox: "0 0 12 12",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "20220814",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-46.000000, -248.000000)",
            fill: "currentColor",
            fillRule: "nonzero",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M54.5113689,248 C54.8426914,248 55.1113689,248.268677 55.1113689,248.6 L55.111,248.868 L55.7726218,248.868677 C56.7540603,248.868677 57.5531323,249.667749 57.5531323,250.649188 L57.5531323,258.21949 C57.5531323,259.200928 56.7540603,260 55.7726218,260 L47.7805104,260 C46.7990719,260 46,259.200928 46,258.21949 L46,250.649188 C46,249.667749 46.7990719,248.868677 47.7805104,248.868677 L48.586,248.868 L48.5865429,248.6 C48.5865429,248.268677 48.8552204,248 49.1865429,248 C49.5178654,248 49.7865429,248.268677 49.7865429,248.6 L49.786,248.868 L53.911,248.868 L53.9113689,248.6 C53.9113689,248.268677 54.1800464,248 54.5113689,248 Z M56.353,253.106 L47.2,253.106 L47.2,258.21949 C47.2,258.539675 47.4603248,258.8 47.7805104,258.8 L55.7726218,258.8 C56.0928074,258.8 56.3531323,258.539675 56.3531323,258.21949 L56.353,253.106 Z M52.0723898,256.287239 C52.4037123,256.287239 52.6723898,256.555916 52.6723898,256.887239 C52.6723898,257.218561 52.4037123,257.487239 52.0723898,257.487239 L51.4793503,257.487239 C51.1480278,257.487239 50.8793503,257.218561 50.8793503,256.887239 C50.8793503,256.555916 51.1480278,256.287239 51.4793503,256.287239 L52.0723898,256.287239 Z M49.2700696,256.287239 C49.6013921,256.287239 49.8700696,256.555916 49.8700696,256.887239 C49.8700696,257.218561 49.6013921,257.487239 49.2700696,257.487239 L48.6770302,257.487239 C48.3457077,257.487239 48.0770302,257.218561 48.0770302,256.887239 C48.0770302,256.555916 48.3457077,256.287239 48.6770302,256.287239 L49.2700696,256.287239 Z M52.0723898,254.218561 C52.4037123,254.218561 52.6723898,254.487239 52.6723898,254.818561 C52.6723898,255.149884 52.4037123,255.418561 52.0723898,255.418561 L51.4793503,255.418561 C51.1480278,255.418561 50.8793503,255.149884 50.8793503,254.818561 C50.8793503,254.487239 51.1480278,254.218561 51.4793503,254.218561 L52.0723898,254.218561 Z M49.2700696,254.218561 C49.6013921,254.218561 49.8700696,254.487239 49.8700696,254.818561 C49.8700696,255.149884 49.6013921,255.418561 49.2700696,255.418561 L48.6770302,255.418561 C48.3457077,255.418561 48.0770302,255.149884 48.0770302,254.818561 C48.0770302,254.487239 48.3457077,254.218561 48.6770302,254.218561 L49.2700696,254.218561 Z M54.8064965,254.218561 C55.137819,254.218561 55.4064965,254.487239 55.4064965,254.818561 C55.4064965,255.149884 55.1392111,255.418561 54.8064965,255.418561 L54.2134571,255.418561 C53.8821346,255.418561 53.6134571,255.149884 53.6134571,254.818561 C53.6134571,254.487239 53.8821346,254.218561 54.2134571,254.218561 L54.8064965,254.218561 Z M55.7726218,250.068677 L55.111,250.068 L55.1113689,250.334571 C55.1113689,250.667285 54.8426914,250.935963 54.5113689,250.935963 C54.1800464,250.935963 53.9113689,250.667285 53.9113689,250.335963 L53.911,250.068 L49.786,250.068 L49.7865429,250.334571 C49.7865429,250.667285 49.5178654,250.935963 49.1865429,250.935963 C48.8552204,250.935963 48.5865429,250.667285 48.5865429,250.335963 L48.586,250.068 L47.7805104,250.068677 C47.4603248,250.068677 47.2,250.329002 47.2,250.649188 L47.2,251.906 L56.353,251.906 L56.3531323,250.649188 C56.3531323,250.329002 56.0928074,250.068677 55.7726218,250.068677 Z",
                id: "形状结合"
            })
        })
    })
});
const openAllIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 14 14",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "节点仪表盘",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-53.000000, -439.000000)",
            fill: "currentColor",
            fillRule: "nonzero",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M60.0037631,447.731199 C60.3279685,447.731199 60.5901117,447.993342 60.5901117,448.317548 L60.59,451.432 L61.2866902,450.737046 C61.5154866,450.50825 61.8878596,450.50825 62.116656,450.737046 C62.3454524,450.965843 62.3445261,451.337289 62.1157297,451.566086 L61.157008,452.524808 C60.8454663,452.836349 60.4372819,452.994479 60.0276626,452.998864 C60.0201038,452.999743 60.0119535,452.999953 60.0037631,453 L59.9764596,452.998612 C59.5725745,452.990301 59.1711516,452.832473 58.8634863,452.524808 L57.9056909,451.567012 C57.6768946,451.338216 57.6768946,450.965843 57.9056909,450.737046 C58.1344873,450.50825 58.5068604,450.50825 58.7356568,450.737046 L59.417,451.418 L59.4174144,448.317548 C59.4174144,447.993342 59.680484,447.730273 60.0037631,447.731199 Z M65.5745382,443.898165 L66.5332599,444.856887 C66.8441991,445.167826 67.0018706,445.575034 67.0064953,445.983745 C67.0073031,445.992197 67.0075261,446.001602 67.0075261,446.011058 L67.0060541,446.044552 C66.9956879,446.44587 66.8377113,446.844104 66.5323336,447.149482 L65.5736119,448.108204 C65.3448156,448.337 64.9724425,448.337 64.7436461,448.108204 C64.5148497,447.879407 64.5148497,447.507034 64.7436461,447.278238 L65.425,446.596 L62.3139582,446.591849 C61.9897528,446.591849 61.7276095,446.327853 61.7276095,446.003647 C61.7276095,445.679442 61.9916054,445.417299 62.3148845,445.418225 L65.438,445.421 L64.7445724,444.728131 C64.515776,444.499334 64.515776,444.126961 64.7445724,443.898165 C64.9733688,443.669368 65.3457419,443.669368 65.5745382,443.898165 Z M55.2694378,443.891681 C55.4982342,444.120477 55.4982342,444.49285 55.2694378,444.721647 L54.581,445.409 L57.6898628,445.413594 C58.0140682,445.413594 58.2762114,445.677589 58.2762114,446.001795 C58.2762114,446.162971 58.210444,446.310253 58.1048457,446.415851 C57.9983211,446.522376 57.8510392,446.588143 57.6898628,446.588143 L54.582,446.583 L55.2694378,447.270827 C55.4982342,447.499624 55.4982342,447.871997 55.2694378,448.100793 C55.0406415,448.32959 54.6682684,448.32959 54.439472,448.100793 L53.4816766,447.142998 C53.1933838,446.854705 53.0364606,446.484282 53.0109068,446.10658 C53.0036924,446.070491 53,446.032861 53,445.994384 C53,445.955195 53.0038574,445.916912 53.0112108,445.879891 C53.0378506,445.504918 53.1946583,445.136494 53.4816766,444.849476 L54.439472,443.891681 C54.6682684,443.662884 55.0406415,443.662884 55.2694378,443.891681 Z M60.0037631,438.999884 L60.0174719,439.000056 C60.4281069,439.003468 60.8377607,439.161387 61.1505239,439.47415 L62.1092456,440.432872 C62.338042,440.661669 62.3371157,441.033115 62.1083193,441.261912 C61.8795229,441.490708 61.5071498,441.490708 61.2783535,441.261912 L60.59,440.574 L60.5901117,443.693452 C60.5901117,443.854629 60.5243443,444.001911 60.418746,444.107509 C60.3122214,444.214034 60.1658658,444.278875 60.0037631,444.279801 C59.6795577,444.279801 59.4174144,444.017658 59.4174144,443.693452 L59.417,440.573 L58.7282464,441.262838 C58.49945,441.491634 58.1270769,441.491634 57.8982805,441.262838 C57.6694841,441.034042 57.6694841,440.661669 57.8982805,440.432872 L58.8570022,439.47415 C59.1693075,439.161845 59.5787298,439.003705 59.9893596,439.000064 C59.994221,438.999941 59.9989853,438.999884 60.0037631,438.999884 Z",
                id: "形状结合"
            })
        })
    })
});
const deleteIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "节点仪表盘",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-89.000000, -393.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-4备份-6",
                transform: "translate(89.000000, 393.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形备份-2",
                        strokeOpacity: "0.2",
                        stroke: "currentColor",
                        strokeWidth: "0.5",
                        x: "0.25",
                        y: "0.25",
                        width: "27.5",
                        height: "27.5",
                        rx: "5"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M13.5040232,7 C14.8654293,7 15.9798656,8.07661043 16.0407426,9.42324165 L18.2525704,9.42355834 L18.284,9.425 L19.3039785,9.42512293 C19.6919982,9.42512293 20.0064819,9.73960662 20.0064819,10.1276263 C20.0064819,10.515646 19.6935628,10.8301296 19.3055431,10.8301296 L18.955,10.83 L18.9550754,18.459097 C18.9566384,19.8609745 17.8176129,21 16.4173,21 L10.5891819,21 C9.18886902,21 8.04984354,19.8609745 8.04984354,18.4606616 L8.049,10.83 L7.70250335,10.8301296 C7.31448368,10.8301296 7,10.515646 7,10.1276263 C7,9.73960662 7.31448368,9.42512293 7.70250335,9.42512293 L8.71985071,9.42429639 C8.73062127,9.42380613 8.74145511,9.42355834 8.75234689,9.42355834 L10.968,9.423 L10.970096,9.3726112 C11.0562249,8.04972588 12.1597228,7 13.5040232,7 Z M17.5500671,10.8301296 L9.45641484,10.8301296 L9.45641484,18.4606616 C9.45641484,19.0849352 9.96490836,19.5934287 10.5891819,19.5934287 L16.4173,19.5934287 C17.0415735,19.5934287 17.5500671,19.0849352 17.5500671,18.4606616 L17.5500671,10.8301296 Z M11.9894949,13.0925346 C12.3775145,13.0925346 12.692004,13.4070183 12.692004,13.795038 L12.692004,16.6598122 C12.6935628,17.0478319 12.3790791,17.3623156 11.9894949,17.3623156 C11.6014752,17.3623156 11.2869915,17.0478319 11.2869915,16.6598122 L11.2869915,13.795038 C11.2869915,13.4070183 11.6014752,13.0925346 11.9894949,13.0925346 Z M15.016987,13.0925346 C15.4050067,13.0925346 15.7194962,13.4070183 15.7194962,13.795038 L15.7194962,16.6598122 C15.721055,17.0478319 15.4065713,17.3623156 15.016987,17.3623156 C14.6289674,17.3623156 14.3144837,17.0478319 14.3144837,16.6598122 L14.3144837,13.795038 C14.3144837,13.4070183 14.6289674,13.0925346 15.016987,13.0925346 Z M13.5040232,8.4065713 C12.9173,8.4065713 12.43384,8.852481 12.3759499,9.42355834 L14.630532,9.42355834 C14.5726419,8.852481 14.0891819,8.4065713 13.5040232,8.4065713 Z",
                        id: "形状结合",
                        fill: "currentColor",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const tip = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    viewBox: "64 64 896 896",
    focusable: "false",
    "data-icon": "exclamation-circle",
    width: "1em",
    height: "1em",
    fill: "currentColor",
    "aria-hidden": "true",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372z"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M464 688a48 48 0 1096 0 48 48 0 10-96 0zm24-112h48c4.4 0 8-3.6 8-8V296c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v272c0 4.4 3.6 8 8 8z"
        })
    ]
});
const fileIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 14 14",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        opacity: "0.6",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "所需icon",
            transform: "translate(-33.000000, -62.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "文件icon",
                transform: "translate(33.000000, 62.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        x: "0",
                        y: "0",
                        width: "14",
                        height: "14"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M10.8181818,0.636363636 C11.8725436,0.636363636 12.7272727,1.49109275 12.7272727,2.54545455 L12.7272727,2.54545455 L12.7272727,11.4545455 C12.7272727,12.5089072 11.8725436,13.3636364 10.8181818,13.3636364 L10.8181818,13.3636364 L3.18181818,13.3636364 C2.12745639,13.3636364 1.27272727,12.5089072 1.27272727,11.4545455 L1.27272727,11.4545455 L1.27272727,2.54545455 C1.27272727,1.49109275 2.12745639,0.636363636 3.18181818,0.636363636 L3.18181818,0.636363636 Z M10.8181818,1.90909091 L3.18181818,1.90909091 C2.83036425,1.90909091 2.54545455,2.19400061 2.54545455,2.54545455 L2.54545455,2.54545455 L2.54545455,11.4545455 C2.54545455,11.8059994 2.83036425,12.0909091 3.18181818,12.0909091 L3.18181818,12.0909091 L10.8181818,12.0909091 C11.1696357,12.0909091 11.4545455,11.8059994 11.4545455,11.4545455 L11.4545455,11.4545455 L11.4545455,2.54545455 C11.4545455,2.19400061 11.1696357,1.90909091 10.8181818,1.90909091 L10.8181818,1.90909091 Z M8.90909091,8.90909091 C9.26054484,8.90909091 9.54545455,9.19400061 9.54545455,9.54545455 C9.54545455,9.89690848 9.26054484,10.1818182 8.90909091,10.1818182 L5.09090909,10.1818182 C4.73945516,10.1818182 4.45454545,9.89690848 4.45454545,9.54545455 C4.45454545,9.19400061 4.73945516,8.90909091 5.09090909,8.90909091 L8.90909091,8.90909091 Z M8.90909091,6.36363636 C9.26054484,6.36363636 9.54545455,6.64854607 9.54545455,7 C9.54545455,7.35145393 9.26054484,7.63636364 8.90909091,7.63636364 L5.09090909,7.63636364 C4.73945516,7.63636364 4.45454545,7.35145393 4.45454545,7 C4.45454545,6.64854607 4.73945516,6.36363636 5.09090909,6.36363636 L8.90909091,6.36363636 Z M7,3.81818182 C7.35145393,3.81818182 7.63636364,4.10309152 7.63636364,4.45454545 C7.63636364,4.80599939 7.35145393,5.09090909 7,5.09090909 L5.09090909,5.09090909 C4.73945516,5.09090909 4.45454545,4.80599939 4.45454545,4.45454545 C4.45454545,4.10309152 4.73945516,3.81818182 5.09090909,3.81818182 L7,3.81818182 Z",
                        id: "形状结合",
                        fill: "currentColor",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const outlook = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-840.000000, -204.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-10",
                transform: "translate(840.000000, 204.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        fill: "#FFFFFF",
                        x: "0",
                        y: "0",
                        width: "28",
                        height: "28",
                        rx: "5"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                        id: "邮件-(1)",
                        transform: "translate(6.000000, 8.000000)",
                        fill: "#222121",
                        fillRule: "nonzero",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                d: "M13.9397335,0.307183141 C14.1610283,0.138241429 14.1154582,0 13.8384666,0 L1.80604123,0 C1.52904963,0 1.48340846,0.138331502 1.70459668,0.307399328 L7.4163336,4.67312928 C7.63752181,4.84219711 7.99954207,4.84230521 8.22083687,4.6733635 L13.9397335,0.307183141 Z",
                                id: "路径"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                d: "M10.7495963,4.20171574 C10.5271454,4.36583374 10.5148406,4.64908914 10.7222542,4.83114688 L14.4089991,8.06740618 C14.6163949,8.24944642 14.5935712,8.27907762 14.358244,8.13321439 L9.9292461,5.38785642 C9.69391892,5.24199319 9.31941706,5.25695757 9.09694832,5.42105807 L8.22648601,6.0633008 C8.00403512,6.2274188 7.64012362,6.22731379 7.41777987,6.06307327 L6.53883455,5.41381216 C6.31649082,5.24957165 5.94209612,5.23464227 5.70685822,5.38061051 L1.27157398,8.13300436 C1.0363361,8.2790076 1.01403028,8.25000648 1.2220333,8.06857881 L4.92979812,4.83448979 C5.13778327,4.65307962 5.1260321,4.3702793 4.90368835,4.20603877 L0.404272692,0.882461061 C0.181928961,0.718220549 0,0.807096654 0,1.07997323 L0,10.7038655 C0,10.9767246 0.22780857,11.2 0.506247219,11.2 L15.1381972,11.2 C15.4166359,11.2 15.6444444,10.9767246 15.6444444,10.7038655 L15.6444444,1.08632652 C15.6444444,0.813449928 15.4624619,0.724468807 15.240011,0.888586823 L10.7495963,4.20171574 Z",
                                id: "路径"
                            })
                        ]
                    })
                ]
            })
        })
    })
});
const telegram = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-802.000000, -204.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-12",
                transform: "translate(802.000000, 204.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        fill: "#FFFFFF",
                        x: "0",
                        y: "0",
                        width: "28",
                        height: "28",
                        rx: "5"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                        id: "bxl-telegram",
                        transform: "translate(5.300000, 7.400000)",
                        fill: "#222121",
                        fillRule: "nonzero",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "M14.9200247,0.0882308616 L0.747101326,5.55355953 C-0.220142748,5.94205591 -0.214547115,6.48163421 0.569640018,6.72224617 L4.2083962,7.85735903 L12.6274165,2.54551041 C13.0255054,2.30329971 13.3892211,2.43359788 13.0902548,2.69899046 L6.26918563,8.85497936 L6.26758689,8.85497936 L6.26918563,8.85577874 L6.01818181,12.6064475 C6.38589443,12.6064475 6.54816761,12.4377793 6.75440642,12.2387348 L8.52182513,10.520078 L12.198152,13.2355558 C12.8760222,13.6088641 13.3628417,13.417014 13.5315099,12.6080462 L15.9448238,1.23453499 C16.1918308,0.244109038 15.5667193,-0.204340485 14.9200247,0.0882308616 Z",
                            id: "路径"
                        })
                    })
                ]
            })
        })
    })
});
const twitter = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-764.000000, -204.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-13",
                transform: "translate(764.000000, 204.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        fill: "#FFFFFF",
                        x: "0",
                        y: "0",
                        width: "28",
                        height: "28",
                        rx: "5"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M23,9.53509331 C22.4116092,9.78743741 21.7713015,9.9690487 21.1117654,10.0397815 C21.7924528,9.63641329 22.3096984,8.99981793 22.5538998,8.24278562 C21.9251292,8.61556668 21.2136762,8.88893946 20.4733806,9.0304051 C19.8734527,8.39380974 19.021632,8 18.0775147,8 C16.2604254,8 14.7990626,9.46436049 14.7990626,11.2613564 C14.7990626,11.5137005 14.8298281,11.7660446 14.8798221,12.0088302 C12.1589953,11.8673646 9.7323639,10.5750569 8.11909626,8.5964497 C7.83451508,9.08202094 7.67299603,9.63641329 7.67299603,10.2424215 C7.67299603,11.3741466 8.25177262,12.3720528 9.13435885,12.958944 C8.59596202,12.9379153 8.08833073,12.7868912 7.65184473,12.5441056 L7.65184473,12.5842513 C7.65184473,14.1690487 8.77863238,15.4823851 10.280375,15.7844333 C10.005408,15.8551661 9.71121259,15.8953118 9.41701719,15.8953118 C9.2035813,15.8953118 9.00168249,15.8742831 8.79786083,15.8456076 C9.21319553,17.1379153 10.4226655,18.0765589 11.8628771,18.1071461 C10.7360894,18.9846154 9.32472059,19.5007738 7.79221247,19.5007738 C7.51724552,19.5007738 7.26342988,19.4912153 7,19.4606281 C8.45367143,20.3878015 10.1784641,20.9230769 12.0359332,20.9230769 C18.0659776,20.9230769 21.3655811,15.9564861 21.3655811,11.6456076 C21.3655811,11.504142 21.3655811,11.3626764 21.3559668,11.2212107 C21.9943516,10.7566682 22.5538998,10.1812472 23,9.53509331 Z",
                        id: "路径",
                        fill: "#222121",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const block_chain = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "16px",
    height: "16px",
    viewBox: "0 0 16 16",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "统计—FIL相关备份",
            transform: "translate(-124.000000, -482.000000)",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "编组",
                transform: "translate(105.000000, 190.000000)",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                    id: "编组-5",
                    transform: "translate(19.000000, 292.000000)",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                            id: "矩形",
                            x: "0",
                            y: "0",
                            width: "16",
                            height: "16",
                            rx: "0.777777778"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                            id: "编组",
                            transform: "translate(1.500000, 2.000000)",
                            fill: "currentColor",
                            fillRule: "nonzero",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                d: "M0.65,0 L12.35,0 C12.708995,0 13,0.29848 13,0.666666667 L13,11.3333333 C13,11.7015333 12.708995,12 12.35,12 L0.65,12 C0.291018,12 0,11.7015333 0,11.3333333 L0,0.666666667 C0,0.29848 0.291018,0 0.65,0 Z M1.3,1.33333333 L1.3,10.6666667 L11.7,10.6666667 L11.7,1.33333333 L1.3,1.33333333 Z M3.25,6.66666667 L4.55,6.66666667 L4.55,9.33333333 L3.25,9.33333333 L3.25,6.66666667 Z M5.85,2.66666667 L7.15,2.66666667 L7.15,9.33333333 L5.85,9.33333333 L5.85,2.66666667 Z M8.45,4.66666667 L9.75,4.66666667 L9.75,9.33333333 L8.45,9.33333333 L8.45,4.66666667 Z",
                                id: "形状"
                            })
                        })
                    ]
                })
            })
        })
    })
});
const copyIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    height: "14",
    viewBox: "0 0 13 14",
    width: "13",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("filter", {
            id: "a",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feColorMatrix", {
                in: "SourceGraphic",
                type: "matrix",
                values: "0 0 0 0 0.141176 0 0 0 0 0.450980 0 0 0 0 0.980392 0 0 0 1.000000 0"
            })
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            fill: "none",
            fillRule: "evenodd",
            filter: "url(#a)",
            transform: "translate(-213 -138)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                fill: "currentColor",
                fillRule: "nonzero",
                transform: "translate(213 138)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "m9.38888889 1.94444444h-8.18518519c-.66445724.00080357-1.20290778.54443153-1.2037037 1.21527778v9.23611108c0 .6703473.54022222 1.2152778 1.2037037 1.2152778h8.18518519c.66396301 0 1.20370371-.5449305 1.20370371-1.2152778v-9.23611108c0-.66986111-.5397407-1.21527778-1.20370371-1.21527778zm.24074074 10.45138886c0 .1336806-.10833333.2430556-.24074074.2430556h-8.18518519c-.13295744 0-.24074074-.1088197-.24074074-.2430556v-9.23611108c0-.13423587.1077833-.24305555.24074074-.24305555h8.18518519c.13295744 0 .24074074.10881968.24074074.24305555z"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "m11.3148148 0h-8.18518517c-.26591488 0-.48148148.21763936-.48148148.48611111 0 .26847176.2155666.48611111.48148148.48611111h8.18518517c.1329575 0 .2407408.10881968.2407408.24305556v9.23611112c0 .2684717.2155666.4861111.4814814.4861111.2659149 0 .4814815-.2176394.4814815-.4861111v-9.23611112c0-.66986111-.5397407-1.21527778-1.2037037-1.21527778z"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "m7.7037037 5.58541667h-4.81481481c-.26591488 0-.48148148.21763935-.48148148.48611111 0 .26847175.2155666.48611111.48148148.48611111h4.81481481c.26591488 0 .48148149-.21763936.48148149-.48611111 0-.26847176-.21556661-.48611111-.48148149-.48611111zm-1.92592592 2.97402777h-2.88888889c-.26591488 0-.48148148.21763936-.48148148.48611112 0 .26847175.2155666.48611111.48148148.48611111h2.88888889c.26591488 0 .48148148-.21763936.48148148-.48611111 0-.26847176-.2155666-.48611112-.48148148-.48611112z"
                    })
                ]
            })
        })
    ]
});
const edit = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    height: "14",
    viewBox: "0 0 14 14",
    width: "14",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
        d: "m614.380141 274.356566 3.264812 3.264738c.505867.505855.466402 1.368679-.087899 1.922967l-2.240522 2.238678c-.094638.095818-.209559.159653-.330873.192017l-4.640086 4.635271c-.313869.313874-.71841.530098-1.140389.61031l-4.036697.760272c-.062774.012206-.125548.019181-.188321.019181-.261557 0-.512652-.101137-.695742-.285974-.228427-.22843-.327818-.559741-.266788-.885821l.760259-4.03502c.080211-.42373.296431-.828278.6103-1.142151l4.637383-4.637821c.032571-.120999.096247-.235292.19103-.330073l2.240522-2.240471c.554301-.554288 1.417144-.593752 1.923011-.086103zm-2.815141 3.155434-5.158477 5.159123c-.111597.111599-.186577.249355-.212733.390598l-.638199 3.382861 3.382805-.63821c.14124-.026156.278994-.102881.390592-.212737l5.158012-5.159635zm1.900276-1.976899-.993276.989899 3.004 3.004.992186-.991058z",
        transform: "translate(-604 -274)",
        fill: "currentColor"
    })
});
const search = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "15px",
    viewBox: "0 0 14 15",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "search",
            fill: "currentColor",
            fillRule: "nonzero",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M13.7936732,12.8829925 L11.0125641,10.1018833 C11.9075435,9.0008232 12.3962493,7.63676473 12.3962493,6.19812465 C12.3962493,4.54359043 11.7524922,2.98718991 10.5807758,1.8154735 C9.41102207,0.645719763 7.85462155,0 6.19812465,0 C4.54359043,0 2.98718991,0.643757089 1.8154735,1.8154735 C0.645719763,2.98522723 0,4.54162775 0,6.19812465 C0,7.85462155 0.643757089,9.4090594 1.8154735,10.5807758 C2.98522723,11.7505295 4.54162775,12.3962493 6.19812465,12.3962493 C7.5935859,12.3962493 8.92035356,11.9369836 10.0037496,11.0910711 L12.7946721,13.8819936 C12.9320593,14.0193807 13.1126253,14.0880743 13.295154,14.0880743 C13.4776827,14.0880743 13.656286,14.0193807 13.7956359,13.8819936 C14.0684476,13.6072192 14.0684476,13.1597295 13.7936732,12.8829925 Z M1.41508799,6.20008733 C1.41508799,3.5622534 3.56029073,1.41705066 6.19812465,1.41705066 C8.83595858,1.41705066 10.9811613,3.5622534 10.9811613,6.20008733 C10.9811613,8.83792125 8.83595858,10.983124 6.19812465,10.983124 C3.56029073,10.983124 1.41508799,8.83792125 1.41508799,6.20008733 Z",
                id: "形状"
            })
        })
    })
});
const fil_overview = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    height: "16",
    viewBox: "0 0 16 16",
    width: "16",
    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
        fill: "none",
        fillRule: "evenodd",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                height: "16",
                rx: ".583333",
                width: "16"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "m13.3333341 2c.3681996 0 .6666659.29848.6666659.66666667v10.66666663c0 .3682-.2984663.6666667-.6666659.6666667h-10.66666817c-.36819293 0-.66666593-.2984667-.66666593-.6666667v-10.66666663c0-.36818667.298473-.66666667.66666593-.66666667zm-.666666 1.33333333h-9.33333625v9.33333337h9.33333625zm-2.66667254 1.33333334c.36818494 0 .66666144.29847683.66666144.66666666 0 .36818984-.2984765.66666667-.66666144.66666667h-2.66666815v1.33333333h1.99999778c.36818942 0 .66667037.29847684.66667037.66666667s-.29848095.66666667-.66667037.66666667h-2.00066445l.00066667 2.00000003c0 .3681898-.2984765.6666666-.66666593.6666666-.36818942 0-.66666592-.2984768-.66666592-.6666666v-5.33333337c0-.36818983.2984765-.66666666.66666592-.66666666z",
                fill: "currentColor",
                fillRule: "nonzero"
            })
        ]
    })
});
const hot = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    height: "12",
    viewBox: "0 0 24 12",
    width: "24",
    children: [
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("defs", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                    id: "a",
                    x1: "0%",
                    x2: "97.050251%",
                    y1: "47.679407%",
                    y2: "53.98266%",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                            offset: "0",
                            stopColor: "#e73b3b"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                            offset: "1",
                            stopColor: "#f55520"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    id: "b",
                    d: "m5.37488914 9.2074191v-2.57734807h2.48980109v2.57734807h.9304447v-5.90055249h-.9304447v2.51933702h-2.48980109v-2.51933702h-.9304447v5.90055249zm7.00418096.04972376c.6547573 0 1.1975167-.22375691 1.619663-.62983426.5675915-.54598635.5857163-1.15804163.5858858-2.17471518l-.0000503-.19545056c0-1.13535912.0172305-1.79005525-.5858355-2.37016575-.4221463-.40607735-.9649057-.62983425-1.619663-.62983425-.6547574 0-1.1889016.2237569-1.6110478.62983425-.5321171.5118622-.5880117 1.08179281-.5937985 1.98874786v.76283577c.0057868.90695505.0616814 1.47688566.5937985 1.98874786.4221462.40607735.9562904.62983426 1.6110478.62983426zm0-.80386741c-.3618396 0-.6978336-.14088397-.9132143-.36464088-.2847811-.29742173-.3543943-.60962758-.3612502-1.641738l-.0005894-.18975371c0-1.18508288.0603066-1.51657459.3618396-1.83149172.2153807-.2237569.5513747-.36464088.9132143-.36464088s.6978335.14088398.9132142.36464088c.301533.31491713.3618396.64640884.3618396 1.83149172 0 1.18508287-.0603066 1.51657458-.3618396 1.83149171-.2153807.22375691-.5513746.36464088-.9132142.36464088zm5.4879006.75414365v-5.09668508h1.6885849v-.80386741h-4.3076144v.80386741h1.6885848v5.09668508z"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("filter", {
                    id: "c",
                    height: "266.7%",
                    width: "166.2%",
                    x: "-33.1%",
                    y: "-66.7%",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feOffset", {
                            dx: "0",
                            dy: "1",
                            in: "SourceAlpha",
                            result: "shadowOffsetOuter1"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feGaussianBlur", {
                            in: "shadowOffsetOuter1",
                            result: "shadowBlurOuter1",
                            stdDeviation: "1.5"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feColorMatrix", {
                            in: "shadowBlurOuter1",
                            type: "matrix",
                            values: "0 0 0 0 0.590750874   0 0 0 0 0.0496372439   0 0 0 0 0.0300789199  0 0 0 0.24182385 0"
                        })
                    ]
                })
            ]
        }),
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            fill: "none",
            fillRule: "evenodd",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "m2 0h16c3.3137085 0 6 2.6862915 6 6v4c0 1.1045695-.8954305 2-2 2h-16c-3.3137085 0-6-2.6862915-6-6v-4c0-1.1045695.8954305-2 2-2z",
                    fill: "url(#a)",
                    transform: "matrix(-1 0 0 1 24 0)"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                    fillRule: "nonzero",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("use", {
                            fill: "#000",
                            filter: "url(#c)",
                            xlinkHref: "#b"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("use", {
                            fill: "#fff",
                            xlinkHref: "#b"
                        })
                    ]
                })
            ]
        })
    ]
});
const newIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    height: "12",
    viewBox: "0 0 26 12",
    width: "26",
    children: [
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("defs", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                    id: "a",
                    x1: "0%",
                    x2: "97.050251%",
                    y1: "48.02269%",
                    y2: "53.393509%",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                            offset: "0",
                            stopColor: "#e73b3b"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                            offset: "1",
                            stopColor: "#f55520"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    id: "d",
                    d: "m6.00597015 9v-4.22191011l2.45522388 4.22191011h.73880597v-6h-.80597015v4.21348315l-2.45522388-4.21348315h-.73880597v6zm7.99402985 0v-.81741573h-2.4404396v-1.80337079h2.0817583v-.80898876h-2.0817583v-1.75280899h2.4404396v-.81741573h-3.2v6zm2.9107185 0 1.0855124-4.20505618 1.0930506 4.20505618h.7085984l1.4021201-6h-.859364l-.9347467 4.28932584-1.0779741-4.28932584h-.6558304l-1.0779741 4.28932584-.9347467-4.28932584h-.859364l1.4021201 6z"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("filter", {
                    id: "c",
                    height: "266.7%",
                    width: "162.5%",
                    x: "-31.2%",
                    y: "-66.7%",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feOffset", {
                            dx: "0",
                            dy: "1",
                            in: "SourceAlpha",
                            result: "shadowOffsetOuter1"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feGaussianBlur", {
                            in: "shadowOffsetOuter1",
                            result: "shadowBlurOuter1",
                            stdDeviation: "1.5"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feColorMatrix", {
                            in: "shadowBlurOuter1",
                            type: "matrix",
                            values: "0 0 0 0 0.590750874   0 0 0 0 0.0496372439   0 0 0 0 0.0300789199  0 0 0 0.24182385 0"
                        })
                    ]
                })
            ]
        }),
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            fill: "none",
            fillRule: "evenodd",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "m2 0h19c2.7614237 0 5 2.23857625 5 5v5c0 1.1045695-.8954305 2-2 2h-18c-3.3137085 0-6-2.6862915-6-6v-4c0-1.1045695.8954305-2 2-2z",
                    fill: "url(#a)",
                    transform: "matrix(-1 0 0 1 26 0)"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                    fillRule: "nonzero",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("use", {
                            fill: "#000",
                            filter: "url(#c)",
                            xlinkHref: "#d"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("use", {
                            fill: "#fff",
                            xlinkHref: "#d"
                        })
                    ]
                })
            ]
        })
    ]
});
const barLegend = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    height: "16",
    viewBox: "0 0 16 16",
    width: "16",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
        d: "m359 852h4c.552285 0 1 .447715 1 1v4c0 .552285-.447715 1-1 1h-4c-.552285 0-1-.447715-1-1v-4c0-.552285.447715-1 1-1z",
        fill: "currentColor",
        fillRule: "evenodd",
        transform: "translate(-350 -847)"
    })
});
const meta = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    height: "13",
    viewBox: "0 0 13 13",
    width: "13",
    fill: "currentColor",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
        d: "m4.36664104 1.35142438c.15363207.31166259.0250236.68861275-.28725507.84194173-1.71178983.84048967-2.81907918 2.5796638-2.81907918 4.51753184 0 2.77870012 2.25703428 5.03128165 5.04122716 5.03128165 1.92475966 0 3.65469708-1.0858016 4.50539075-2.77127574.1565667-.31020454.5354566-.43500305.8462743-.27874528.3108178.15625777.435863.5344002.2792963.84460474-1.062832 2.10578248-3.22557599 3.46323668-5.63096135 3.46323668-3.4802411 0-6.30153395-2.8157269-6.30153395-6.28910205 0-2.42180142 1.3842788-4.59603155 3.52303501-5.64616193.31227867-.15332898.68997395-.02497423.84360603.28668836zm2.80717792-1.35142438c3.09867234.25765748 5.56800754 2.72657396 5.82618104 5.82513172l-.0164727.20629333c-.1399534.56578827-.6483137.96857495-1.2380421.96857495h-4.4687107c-.70514309 0-1.2767745-.57162418-1.2767745-1.27675834v-4.4686542c0-.56717421.37296998-1.06138665.93913314-1.23105872l.02851855-.00705305zm.10231715 1.2932094.00063839 4.43003226 4.4291307-.00031919-.0350145-.23634375c-.3783985-2.19238008-2.15582149-3.90694569-4.37909473-4.19064632z"
    })
});
const power = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    height: "40",
    viewBox: "0 0 40 40",
    width: "40",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
        fill: "#1c6afd",
        fillRule: "evenodd",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                fillOpacity: ".05",
                height: "40",
                rx: "5",
                width: "40"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "m21.495421 10c1.0827404 0 1.9615216.8809471 1.9615216 1.9615176v3.2894477c.0021659 1.0805705-.8787812 1.9615175-1.9615216 1.9615175l-.914421-.0004828v1.768l3.6852816.0008864c.8874566 0 1.6100067.7225502 1.6100067 1.6100067l-.0002883 1.6481069.9029336.0009566c1.0827404 0 1.9615176.8809471 1.9615176 1.9615176v3.2655796c0 1.0805706-.8809471 1.9615176-1.9615176 1.9615176h-3.2655796c-1.0827404 0-1.9615176-.880947-1.9615176-1.9615176v-3.2655796c0-1.0827404.880947-1.9615176 1.9615176-1.9615176l.901646-.0009566.0009992-1.6481069c0-.084623-.0694342-.1518874-.1518874-.1518874h-8.7877724c-.084623 0-.1518874.0694343-.1518874.1518874l-.000452 1.6481069.9030972.0009566c1.0827404 0 1.9615176.8809471 1.9615176 1.9615176v3.2655796c0 1.0805706-.880947 1.9615176-1.9615176 1.9615176h-3.2655796c-1.0827404 0-1.9615176-.880947-1.9615176-1.9615176v-3.2655796c0-1.0827404.8809471-1.9615176 1.9615176-1.9615176l.9044824-.0009566.0003327-1.6481069c0-.8874565.7225502-1.6100067 1.6100067-1.6100067l3.6466606-.0008864v-1.768l-.9148568.0004828c-1.0827403 0-1.9615176-.880947-1.9615176-1.9615175v-3.2894477c0-1.0827404.8809471-1.9615176 1.9615176-1.9615176zm-8.5339034 14.1819458-.0195284 3.2829382 3.285108.0195284c.0108491 0 .0195284-.0086793.0195284-.0195284v-3.2634098zm10.5518364 0-.0195284 3.2829382 3.2829382.0195284c.0108491 0 .0195284-.0086793.0195284-.0195284v-3.2634098zm-5.3052108-12.2399566-.0195284 3.3089761 3.3068062.0195283c.0108491 0 .0195284-.0086792.0195284-.0195283v-3.2894477z",
                fillRule: "nonzero",
                opacity: ".5"
            })
        ]
    })
});
const reward = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    height: "40",
    viewBox: "0 0 40 40",
    width: "40",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
        fill: "#1c6afd",
        fillRule: "evenodd",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                fillOpacity: ".05",
                height: "40",
                rx: "5",
                width: "40"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "m28.652422 25.1176865c0 2.7844278-3.7961741 4.8823135-8.8272738 4.8823135-5.0310996 0-8.8251482-2.0978857-8.8251482-4.8823135v-9.2332475c0-2.7844278 3.7940486-4.884439 8.8251482-4.884439 4.9821778 0 8.7512463 2.0593692 8.8240753 4.803408.0020435.0265724.0031985.053666.0031985.081031zm-15.7523208-1.5198361.0001114 1.5198361c0 1.4092181 2.9608457 2.9842265 6.9249356 2.9842265 3.96409 0 6.9270612-1.5771339 6.9270612-2.9842265l.0002525-1.5192315c-1.5908746 1.1027065-4.0583005 1.7849212-6.9273137 1.7849212-2.8684231 0-5.3347331-.682625-6.925047-1.7855258zm6.925047-2.8289724c-2.8684231 0-5.3347331-.6826251-6.925047-1.7855259l.0001114 1.5177107c0 1.409218 2.9608457 2.9842264 6.9249356 2.9842264 3.96409 0 6.9270612-1.5771339 6.9270612-2.9842264l.0007887-1.5190368c-1.5904487 1.1036797-4.0582773 1.786852-6.9278499 1.786852zm0-7.8686654c-3.9640899 0-6.9249356 1.5750083-6.9249356 2.9842264 0 1.409218 2.9608457 2.9842264 6.9249356 2.9842264 3.96409 0 6.9249368-1.5750084 6.9249368-2.9842264.0021244-1.4092181-2.9608468-2.9842264-6.9249368-2.9842264z",
                fillRule: "nonzero",
                opacity: ".5"
            })
        ]
    })
});
const gas = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    height: "40",
    viewBox: "0 0 40 40",
    width: "40",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
        fill: "#1c6afd",
        fillRule: "evenodd",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                fillOpacity: ".05",
                height: "40",
                rx: "5",
                width: "40"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "m23.7985915 11c.515493 0 .9338108.4183099.9338108.9338028l-.0004023.4151972 1.4940563.001c1.5295775 0 2.7739437 1.2443662 2.7739437 2.7739437v11.7950704c0 1.5316901-1.2443662 2.7760563-2.7739437 2.7760563h-12.4521126c-1.5295775 0-2.7739437-1.2443662-2.7739437-2.7760563v-11.7950704c0-1.5295775 1.2443662-2.7739437 2.7739437-2.7739437l.9250563-.001.0002958-.4151972c0-.5154929.4183098-.9338028.9338028-.9338028.5154929 0 .9338028.4183099.9338028.9338028l-.0009014.4151972h6.298l.0007887-.4151972c0-.5154929.4183099-.9338028.9338028-.9338028zm-9.0995915 3.219-.9250563.0007183c-.4985916 0-.9042254.4056338-.9042254.9042254v11.7950704c0 .4985915.4056338.9042253.9042254.9042253h12.4521126c.4985916 0 .9042254-.4056338.9042254-.9042253v-11.7950704c0-.4985916-.4056338-.9042254-.9042254-.9042254l-1.4940563-.0007183.0004023.4190282c.0021047.5154929-.4162051.9338028-.9338108.9338028-.5154929 0-.9338028-.4183099-.9338028-.9338028l-.0007887-.4190282h-6.298l.0009014.4190282c0 .5154929-.4183099.9338028-.9338028.9338028-.515493 0-.9338028-.4183099-.9338028-.9338028zm8.1721268 3.2669155c.3654929.365493.3654929.9570422 0 1.3225352l-.8451268.8445493.3887887.0005211c.515493 0 .9338028.4183099.9338028.9338028 0 .515493-.4183098.9338029-.9338028.9338029l-1.4817887-.0001268v.9l1.4817887.0001268c.515493 0 .9338028.4183098.9338028.9338028 0 .5154929-.4183098.9338028-.9338028.9338028l-1.4817887-.0007324.0008028.8605915c0 .515493-.4183098.9338029-.9338028.9338029s-.9338028-.4183099-.9338028-.9338029l-.0001972-.8605915-1.4807887.0007324c-.515493 0-.9338028-.4183099-.9338028-.9338028 0-.515493.4183098-.9338028.9338028-.9338028l1.4807887-.0001268v-.9l-1.4807887.0001268c-.515493 0-.9338028-.4183099-.9338028-.9338029 0-.5154929.4183098-.9338028.9338028-.9338028l.3517887-.0005211-.8081268-.8086338c-.3654929-.365493-.3654929-.9570423 0-1.3225352.365493-.365493.9570423-.365493 1.3225353 0l1.5305915 1.530169 1.5665915-1.5660845c.365493-.365493.9570423-.365493 1.3225353 0z",
                fillRule: "nonzero",
                opacity: ".5"
            })
        ]
    })
});
const pledge = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    height: "40",
    viewBox: "0 0 40 40",
    width: "40",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
        fill: "#1c6afd",
        fillRule: "evenodd",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                fillOpacity: ".05",
                height: "40",
                rx: "5",
                width: "40"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "m11.3991828 23.5202281 8.5768491 3.7282855 8.6261415-3.7282855c.5063657-.2195745 1.095632.0134433 1.3152065.5220496.2195745.5063657-.0134434 1.095632-.5220496 1.3152065l-9.0227199 3.8985678c-.1277117.0537734-.2621451.0829006-.3965785.0829006-.1366739 0-.2711073-.0268867-.398819-.0829006l-8.9756681-3.9030489c-.5063657-.2195745-.73938359-.8088408-.5175685-1.3152065.2195745-.5063657.8088408-.7393836 1.3152065-.5175685zm0-4.2279296 8.5768491 3.7282856 8.6261415-3.7282856c.5063657-.2195745 1.095632.0134434 1.3152065.5220496.2195745.5063657-.0134434 1.095632-.5220496 1.3152065l-9.0227199 3.8963273c-.1277117.0560139-.2621451.0829006-.3965785.0829006-.1366739 0-.2711073-.0268867-.398819-.0829006l-8.9756681-3.9008084c-.5063657-.2195745-.73938359-.8088408-.5175685-1.3152065.2195745-.5063657.8088408-.7393835 1.3152065-.5175685zm8.5813303-8.2922985.4212245.1658012 8.8815649 3.8492755c.3831351.1658012.6295962.5466957.6318368.9656798 0 .4212245-.2464612.7998785-.6295963.9679202l-9.289346 4.0150768-.4324274-.1702823-8.8479565-3.8447945c-.3831351-.1658011-.6295963-.5466957-.6295963-.9679202 0-.4212246.2464612-.7998786.6295963-.9656798zm.020165 2.1688584-6.4886508 2.8141386 6.4640046 2.8096575 6.5065753-2.811898z",
                fillRule: "nonzero",
                opacity: ".5"
            })
        ]
    })
});
const balance = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    height: "40",
    viewBox: "0 0 40 40",
    width: "40",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
        fill: "#1c6afd",
        fillRule: "evenodd",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                fillOpacity: ".05",
                height: "40",
                rx: "5",
                width: "40"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "m24.6484201 11c1.5598576 0 2.8282154 1.2283044 2.8282154 2.7392078l-.0000298 1.6050855c1.4169657.1524262 2.5233943 1.3550284 2.5233943 2.811915v2.9127726c0 1.4548083-1.1064286 2.6572732-2.5233943 2.8096904l.0000298 2.2726416c0 1.5109034-1.270583 2.7392078-2.8304406 2.7392078h-11.8157543c-1.5598576 0-2.8304406-1.2283044-2.8304406-2.7392078v-12.4121051c0-1.5109034 1.270583-2.7392078 2.8304406-2.7392078zm0 2.000445h-11.8179795c-.458389 0-.8299956.3315532-.8299956.7387628v12.4121051c0 .4072096.3716066.7387628.8299956.7387628h11.8179795c.4561638 0 .8299956-.3315532.8299956-.7387628l-.0004157-2.2573129-4.9306035.0009711c-2.3609256 0-4.2834891-1.9225634-4.2834891-4.2834891s1.9225635-4.2834891 4.2834891-4.2834891l4.9306035-.0009929.0004157-1.5877922c0-.4072096-.3716066-.7387628-.8299956-.7387628zm2.5233645 4.3257677h-6.6243881c-1.259457 0-2.283044 1.023587-2.283044 2.2830441 0 1.259457 1.023587 2.283044 2.283044 2.283044h6.6243881c.4561638 0 .8277704-.3716065.8277704-.8277703v-2.9105474c0-.4561638-.3716066-.8277704-.8277704-.8277704zm-6.5932354 1.270583c.5603957 0 1.0146862.4542905 1.0146862 1.0146863 0 .5603957-.4542905 1.0146862-1.0146862 1.0146862-.5603958 0-1.0146863-.4542905-1.0146863-1.0146862 0-.5603958.4542905-1.0146863 1.0146863-1.0146863z",
                fillRule: "nonzero",
                opacity: ".5"
            })
        ]
    })
});
const monitor = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    height: "16",
    viewBox: "0 0 16 16",
    width: "16",
    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
        fill: "none",
        fillRule: "evenodd",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "m0 0h16v16h-16z"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                fillRule: "nonzero",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "m1.90800286 14.4v-4.8c0-3.534624 2.72747338-6.4 6.09200095-6.4 3.36452759 0 6.09198569 2.865376 6.09198569 6.4v4.8h.9614982c.4418278 0 .8.3581722.8.8s-.3581722.8-.8.8h-14.10698306c-.4418278 0-.8-.3581722-.8-.8s.3581722-.8.8-.8zm1.52299643 0h9.13799381v-4.8c0-2.65096-2.0456127-4.8-4.56898929-4.8-2.52339948 0-4.56900452 2.14904-4.56900452 4.8zm4.56900452-14.4c.42056385-0 .76149821.34093436.76149821.76149822v.87700356c0 .42056386-.34093436.76149822-.76149821.76149822s-.76149822-.34093436-.76149822-.76149822v-.87700356c0-.42056386.34093437-.76149822.76149822-.76149822zm6.46154079 2.811776c.3015804.31683294.3015798.8145425-.0000013 1.13137473l-.5384346.56566352c-.2830855.29740125-.753663.30900647-1.0510642.02592099-.0088462-.00842033-.0174835-.01705737-.0259041-.02590324-.3015968-.31682779-.3015992-.81455044-.0000054-1.13138107l.5384842-.56568887c.2830796-.29738108.753636-.3089747 1.0510171-.02589507.0088476.00842216.0174864.01706113.0259083.02590901zm-12.9230816 0c.2830726-.2973849.75362637-.30898733 1.05101128-.02591473.00884989.00842397.01749076.01706484.02591473.02591473l.53845539.56568c.30158366.31683191.30158366.81454409 0 1.131376-.2830726.2973849-.75362637.30898733-1.05101128.02591473-.00884989-.00842397-.01749076-.01706484-.02591473-.02591473l-.53845539-.56568c-.30158367-.31683191-.30158367-.81454409 0-1.131376z",
                        fill: "currentColor"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "m5.04457319 8.98416722c.5838517-1.78899766 1.56899271-2.68349649 2.955423-2.68349649",
                        stroke: "currentColor",
                        strokeLinecap: "round",
                        strokeWidth: "1.5"
                    })
                ]
            })
        ]
    })
});
const code = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "currentColor",
    height: "14",
    viewBox: "0 0 14 14",
    width: "14",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
        d: "m10.1111111 10.8888889v-.7777778h-2.33333332v-2.33333332h2.33333332v1.55555555h1.5555556v1.55555557h-.7777778v1.5555555h-1.55555557v1.5555556h-1.55555555v-2.3333333h1.55555555v-.7777778zm3.8888889 3.1111111h-3.1111111v-1.5555556h1.5555555v-1.5555555h1.5555556zm-14-14h6.22222222v6.22222222h-6.22222222zm1.55555556 1.55555556v3.11111111h3.11111111v-3.11111111zm6.22222222-1.55555556h6.22222222v6.22222222h-6.22222222zm1.55555555 1.55555556v3.11111111h3.11111107v-3.11111111zm-9.33333333 6.22222222h6.22222222v6.22222222h-6.22222222zm1.55555556 1.55555555v3.11111107h3.11111111v-3.11111107zm10.11111114-1.55555555h2.3333333v1.55555555h-2.3333333zm-9.33333337-5.44444445h1.55555556v1.55555556h-1.55555556zm0 7.77777777h1.55555556v1.5555556h-1.55555556zm7.77777777-7.77777777h1.5555556v1.55555556h-1.5555556z"
    })
});
const fevm = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    height: "14",
    fill: "currentColor",
    viewBox: "0 0 14 14",
    width: "14",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
        d: "m274.400006 288c3.092807 0 5.599994 2.507208 5.599994 5.599987 0 2.271224-1.352119 4.226677-3.295317 5.105318-.878569 1.942993-2.833807 3.294695-5.104675 3.294695-3.092807 0-5.600008-2.507194-5.600008-5.600008 0-2.270874 1.351713-4.226075 3.294435-5.10487.878912-1.943021 2.834353-3.295122 5.105571-3.295122zm-2.799998 4.200006c-2.319608 0-4.200009 1.880392-4.200009 4.199986 0 2.319593 1.880401 4.200006 4.200009 4.200006 2.319588 0 4.199996-1.880413 4.199996-4.200006 0-2.319594-1.880408-4.199986-4.199996-4.199986zm.240599 1.470766 2.488628 2.488628c.132886.132887.132886.348339 0 .481225l-2.488628 2.488628c-.132887.132887-.348339.132887-.481225 0l-2.488628-2.488628c-.132887-.132886-.132887-.348338 0-.481225l2.488628-2.488628c.132886-.132886.348338-.132886.481225 0zm-.2406 1.683189-1.045221 1.045222 1.045221 1.045221 1.045222-1.045221zm2.799999-5.953959c-1.248449 0-2.369708.544713-3.138979 1.409445.112483-.006062.22533-.009443.338981-.009443 3.092807 0 5.599995 2.507208 5.599995 5.599988 0 .11389-.00343.22701-.01008.33915.865199-.769091 1.410078-1.890493 1.410078-3.139155 0-2.319579-1.880408-4.199985-4.199995-4.199985z",
        transform: "translate(-266 -288)"
    })
});
const upIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    height: "12",
    fill: "currentColor",
    viewBox: "0 0 12 12",
    width: "12",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
        d: "m6.77143695 2.8713225v8.3572868c0 .4260273-.34536337.7713907-.77139067.7713907s-.77139066-.3453634-.77139066-.7713907v-8.3572868l-3.59229293 3.49265261c-.30369597.29527227-.78721258.29527222-1.09090849-.00000011-.29289107-.28476719-.29947678-.75305173-.0147096-1.0459428.00483362-.0049715.0097369-.0098748.0147084-.01470843l4.75749282-4.62555565c.38812758-.37736383 1.00607103-.37736145 1.3941957.00000538l4.75741158 4.625548c.2928904.28477227.2994715.75306044.0146993 1.0459509-.0048318.00496951-.0097332.00987086-.0147027.0147026-.3036926.29527118-.7872066.29526961-1.0908973-.00000356z"
    })
});
const reset = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "12px",
    height: "12px",
    viewBox: "0 0 12 12",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-6.000000, -10.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组备份",
                transform: "translate(6.000000, 10.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        x: "0",
                        y: "0",
                        width: "12",
                        height: "12",
                        rx: "6"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M2.4044135,1.837941 C3.368558,1.004284 4.625385,0.5 6,0.5 C9.03754,0.5 11.5,2.9624325 11.5,6 C11.5,7.174855 11.13161,8.26369 10.50406,9.15733 L8.75,6 L10.4,6 C10.4,3.569946 8.430065,1.6 6,1.6 C4.817401,1.6 3.7437735,2.0665485 2.9531265,2.825631 L2.4044135,1.837941 Z M9.59557,10.16207 C8.63142,10.995705 7.374615,11.5 6,11.5 C2.9624325,11.5 0.5,9.03754 0.5,6 C0.5,4.825123 0.8683845,3.736288 1.49594,2.842692 L3.25,6 L1.6,6 C1.6,8.430065 3.569946,10.4 6,10.4 C7.18261,10.4 8.25621,9.933435 9.04689,9.17438 L9.59557,10.16207 Z",
                        id: "形状",
                        fill: "currentColor",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const add = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "currentColor",
    height: "12",
    viewBox: "0 0 14 14",
    width: "12",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
        d: "m7 0c.55228475 0 1 .44771525 1 1v5h5c.5522847 0 1 .44771525 1 1s-.4477153 1-1 1h-5.001l.001 5c0 .5522847-.44771525 1-1 1s-1-.4477153-1-1l-.001-5h-4.999c-.55228475 0-1-.44771525-1-1s.44771525-1 1-1h5v-5c0-.55228475.44771525-1 1-1z"
    })
});
const cancel = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "12px",
    height: "2px",
    viewBox: "0 0 12 2",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "登录/资金穿透",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "余额管理-选择分组和节点后",
            transform: "translate(-875.000000, -338.000000)",
            fill: "currentColor",
            fillRule: "nonzero",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "编组-2",
                transform: "translate(821.000000, 323.000000)",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M66,16 C66,16.4733869 65.6162441,16.8571429 65.1428571,16.8571429 L54.8571429,16.8571429 C54.3837559,16.8571429 54,16.4733869 54,16 C54,15.5266131 54.3837559,15.1428571 54.8571429,15.1428571 L65.1428571,15.1428571 C65.6162441,15.1428571 66,15.5266131 66,16 Z",
                    id: "路径备份-2"
                })
            })
        })
    })
});
const memberVip = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "65px",
    height: "22px",
    viewBox: "0 0 65 22",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "会员",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        opacity: "0.15",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-883.000000, -74.000000)",
            fill: "currentColor",
            fillRule: "nonzero",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M883,74 L890.396871,74 L896.055477,93.8714286 L901.603129,74 L909,74 L901.714083,100 L890.396871,100 L883,74 Z M911,100 L911,74 L918,74 L918,100 L911,100 Z M929.287591,92.6085714 L929.287591,100 L922,100 L922,79.4971429 L928.945985,86.4057143 L937.448175,86.4057143 C938.435036,86.4057143 939.225791,86.1147619 939.820438,85.5328571 C940.415085,84.9509524 940.712409,84.1771429 940.712409,83.2114286 C940.712409,82.2457143 940.415085,81.5028571 939.820438,80.9828571 C939.225791,80.4628571 938.435036,80.2028571 937.448175,80.2028571 L927.313869,80.2028571 L922,74 L938.548905,74 C939.965937,74 941.256448,74.2228571 942.420438,74.6685714 C943.584428,75.1142857 944.577616,75.7457143 945.4,76.5628571 C946.222384,77.38 946.861314,78.3580952 947.316788,79.4971429 C947.772263,80.6361905 948,81.8990476 948,83.2857143 C948,84.6971429 947.772263,85.9785714 947.316788,87.13 C946.861314,88.2814286 946.222384,89.2595238 945.4,90.0642857 C944.577616,90.8690476 943.584428,91.4942857 942.420438,91.94 C941.256448,92.3857143 939.965937,92.6085714 938.548905,92.6085714 L929.287591,92.6085714 Z",
                id: "形状结合"
            })
        })
    })
});
const memberBg = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "254px",
    height: "240px",
    viewBox: "0 0 254 240",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "会员",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        opacity: "0.1",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-1108.000000, -342.000000)",
            fill: "currentColor",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M1198.33058,342 L1297.21558,513.271 L1250.83629,580.713971 C1250.77497,580.803134 1250.69973,580.881553 1250.61364,580.946339 L1250.52406,581.006473 C1250.04957,581.289096 1249.4358,581.133556 1249.15318,580.659064 L1249.15318,580.659064 L1107.90044,343.511734 C1107.80825,343.356958 1107.75958,343.180152 1107.75958,343 C1107.75958,342.447715 1108.2073,342 1108.75958,342 L1108.75958,342 L1198.33058,342 Z M1413.09866,342 C1413.301,342 1413.49858,342.061381 1413.6653,342.176035 C1414.12036,342.488982 1414.23557,343.111578 1413.92262,343.566641 L1413.92262,343.566641 L1343.89358,445.396 L1284.19858,342 Z",
                id: "形状结合"
            })
        })
    })
});
const member_active = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "16px",
    height: "16px",
    viewBox: "0 0 16 16",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-194.000000, -237.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-3",
                transform: "translate(194.000000, 237.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        x: "0",
                        y: "0",
                        width: "16",
                        height: "16"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M10.1818182,0 C11.7884647,0 13.0909091,1.30244436 13.0909091,2.90909091 C13.0909091,3.43923437 12.9490996,3.93625645 12.7013443,4.36429345 L15.2727273,4.36363636 C15.6743889,4.36363636 16,4.68924746 16,5.09090911 L16,5.13636361 C16,5.53802526 15.6743889,5.86363636 15.2727273,5.86363636 L14.519,5.86363636 L14.5191598,13 C14.5191598,14.1045695 13.6237293,15 12.5191598,15 L3.49922718,15 C2.39465768,15 1.49922718,14.1045695 1.49922718,13 L1.499,5.86363636 L0.727272749,5.86363636 C0.325611101,5.86363636 4.91893652e-17,5.53802526 0,5.13636361 L0,5.09090911 C-4.91893652e-17,4.68924746 0.325611101,4.36363636 0.727272749,4.36363636 L3.2986557,4.36429345 C3.05090041,3.93625645 2.90909091,3.43923437 2.90909091,2.90909091 C2.90909091,1.30244436 4.21153527,0 5.81818182,0 C6.68735126,0 7.4674919,0.381177617 8.00055602,0.985485132 C8.5325081,0.381177617 9.31264874,0 10.1818182,0 Z M7.249,5.86363636 L2.998,5.86363636 L2.99922718,13 C2.99922718,13.2454599 3.17610234,13.4496084 3.40935154,13.4919443 L3.49922718,13.5 L7.27920847,13.5001681 C7.26019719,13.435234 7.25,13.3665351 7.25,13.2954545 L7.249,5.86363636 Z M13.018,5.86363636 L8.749,5.86363636 L8.75,13.2954545 C8.75,13.3665351 8.73980281,13.435234 8.72079153,13.5001681 L12.5191598,13.5 C12.7646197,13.5 12.9687682,13.3231248 13.0111041,13.0898756 L13.0191598,13 L13.018,5.86363636 Z M5.81818182,1.5 C5.0399624,1.5 4.40909091,2.13087149 4.40909091,2.90909091 C4.40909091,3.64153272 4.96792517,4.24345179 5.68247696,4.3117314 L5.81818182,4.31818182 L7.227,4.318 L7.22727273,2.90909091 C7.22727273,2.22242671 6.7361098,1.65047977 6.08594191,1.52540802 L5.95388668,1.50645042 L5.81818182,1.5 Z M10.1818182,1.5 L10.0461133,1.50645042 L9.91405809,1.52540802 C9.2638902,1.65047977 8.77272727,2.22242671 8.77272727,2.90909091 L8.77272727,2.90909091 L8.77363636,4.318 L10.1818182,4.31818182 L10.317523,4.3117314 C11.0320748,4.24345179 11.5909091,3.64153272 11.5909091,2.90909091 C11.5909091,2.13087149 10.9600376,1.5 10.1818182,1.5 L10.1818182,1.5 Z",
                        id: "形状结合",
                        fill: "currentColor",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const member_icon_logo = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    height: "85",
    viewBox: "0 0 81 85",
    width: "81",
    children: [
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
            id: "member_icon_logo_a",
            x1: "61.001425%",
            x2: "43.98541%",
            y1: "88.215218%",
            y2: "8.36737%",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                    offset: "0",
                    "stop-color": "#1764ff",
                    "stop-opacity": "0"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                    offset: "1",
                    "stop-color": "#1c6afd"
                })
            ]
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "m49.2312407 75.0075567c.4652333.4798248.7432674 1.1188724.8340984 1.9171466-.859657-.229329-1.5667001-.2654898-2.1211289-.1084821-.8316434.2355111-1.1718026.5562093-2.1885638 1.534117-.6778409.6519385-1.1644827 1.3102561-1.4599258 1.9749529l-8.1749368 16.4875322 3.0208613 13.8215527c.434083 4.006395.216893 7.453979-.6515702 10.34275-1.3026946 4.333158-2.7470366 5.953586-5.2416845 9.02786-1.6630986 2.049517-3.8102632 3.839477-6.4414935 5.369881 1.2347066-.873037 2.1906254-2.62134 2.8677563-5.244911.2648633-1.026224.9327166-3.518609.1346197-6.69201-.8281744-3.292995-3.6695877-10.702705-8.5242402-22.22913l-9.4805578.58722c17.0243699-16.3738172 25.71669-24.7339778 26.0769609-25.0804816.5404061-.5197556 1.3895462-.8180602 2.1480583-1.044191.5056747-.1507538 1.2000972-.2231768 2.0832674-.217269 1.6651773-.8721368 3.0077875-1.3401845 4.0278301-1.404143 1.5300643-.0959377 2.3927892.2378781 3.0906491.9576053zm43.7959727-48.2434501c5.4955702 6.0645614 8.4727866 17.7709879 8.4727866 28.7358934 0 27.8976737-22.6168569 50.5-50.5 50.5-1.1911145 0-2.4146816-.089456-3.7751636-.253167l-1.5493698-.208234-1.8716296-.286203 2.4341211-15.8732615 2.334342.3503597c.1949786.0263812.3783627.0498681.5583228.0715233l1.3478939.123701c.1905041.0101779.3641998.0152108.5214832.0152108 19.0580425 0 34.4945355-15.4265756 34.4945355-34.4399293 0-6.9157874-1.8252019-14.4992996-3.9148317-17.4365679l-.3945234-.4949923zm13.4727866-26.7641066-19.702 19.891.714513.7221125-11.5520852 11.1158918c-.1454073-.1521461-.2920501-.3028402-.4399078-.4520709l-48.50252 48.9660666.3680359.362006-10.9306032 11.73163c-.2446371-.2294914-.48678-.4611738-.7264062-.6950073l-6.29843925 6.3583713-4.90582381-22.7142612c-2.62071398-6.1536929-4.02476344-12.859496-4.02476344-19.7857388 0-27.8976738 22.6168567-50.5 50.5-50.5 11.7663827 0 22.9015223 4.05193378 31.7759587 11.2468826zm-55.5 21.0600707c-19.0580426 0-34.4945355 15.4265754-34.4945355 34.4399293 0 1.9644919.1651413 3.9018786.4865262 5.7964275l51.6739838-35.3867855c-5.2534685-3.1338518-11.3179311-4.8495713-17.6659745-4.8495713z",
            fill: "url(#member_icon_logo_a)",
            opacity: ".1",
            transform: "translate(0 -36)"
        })
    ]
});
const freeVip = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    height: "22",
    viewBox: "0 0 43 22",
    width: "43",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    children: [
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
            id: "freeVip_a",
            x1: "0%",
            x2: "97.050251%",
            y1: "49.242255%",
            y2: "51.30046%",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                    offset: "0",
                    "stop-color": "#e73b3b"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                    offset: "1",
                    "stop-color": "#f55520"
                })
            ]
        }),
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("filter", {
            id: "freeVip_b",
            height: "366.7%",
            width: "151.6%",
            x: "-25.8%",
            y: "-133.3%",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feOffset", {
                    dx: "0",
                    dy: "1",
                    in: "SourceAlpha",
                    result: "shadowOffsetOuter1"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feGaussianBlur", {
                    in: "shadowOffsetOuter1",
                    result: "shadowBlurOuter1",
                    stdDeviation: "1.5"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feColorMatrix", {
                    in: "shadowBlurOuter1",
                    result: "shadowMatrixOuter1",
                    type: "matrix",
                    values: "0 0 0 0 0.590750874   0 0 0 0 0.0496372439   0 0 0 0 0.0300789199  0 0 0 0.24182385 0"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("feMerge", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feMergeNode", {
                            in: "shadowMatrixOuter1"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feMergeNode", {
                            in: "SourceGraphic"
                        })
                    ]
                })
            ]
        }),
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            fill: "none",
            "fill-rule": "evenodd",
            transform: "translate(0 3)",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "m2 0h34c3.3137085-0 6 2.6862915 6 6v4c0 1.1045695-.8954305 2-2 2h-34c-3.3137085 0-6-2.6862915-6-6v-4c-0-1.1045695.8954305-2 2-2z",
                    fill: "url(#freeVip_a)",
                    transform: "matrix(-1 0 0 1 42 0)"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                    fill: "#fff",
                    "fill-rule": "nonzero",
                    filter: "url(#freeVip_b)",
                    transform: "translate(6 3)",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "m0 0h3.75112285v.76716016h-2.87476882v1.83310902h2.57173051v.76716016h-2.57173051v2.54374159h-.87635403z"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "m6.51941876 1.62314939c.14196389 0 .27437252.01884253.39722589.0565276.12285337.03768506.21977103.08882907.29075297.15343203l-.31941876.65410498c-.12558344-.07537012-.26481726-.11305518-.41770145-.11305518-.31122853 0-.56376046.12651413-.75759577.37954239-.19383532.25302827-.29075297.61372813-.29075297 1.0820996v2.07537012h-.84359313v-4.19111709h.74531043c.0109203.25841184.02730075.4845222.04914135.67833109.12558344-.25841185.28529282-.45222073.47912814-.58142665.19383531-.12920592.41633641-.19380889.6675033-.19380889z"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "m9.5989432 1.62314939c.37129018 0 .6961691.08479139.9746367.25437416.2784677.16958278.4941436.40107672.6470278.69448183.1528842.29340512.2293262.6231494.2293262.98923284 0 .12382235-.0136503.2718708-.0409511.44414536h-2.98124172c.0327609.41991925.16380449.73620458.39313078.94885599s.51598415.31897712.85997358.31897712c.44773226 0 .77261116-.18304172.97463676-.54912517l.6306473.36339166c-.109203.29071332-.3166887.51547779-.6224571.6742934s-.6470278.23822342-1.02377808.23822342c-.38767063 0-.73985029-.08479139-1.05653897-.25437416s-.56922061-.42126514-.75759577-.75504711c-.18837517-.33378196-.28256275-.73216689-.28256275-1.19515477 0-.45222073.09418758-.84253029.28256275-1.17092867.18837516-.32839839.43954205-.57738896.75350066-.74697174.31395861-.16958277.65385293-.25437416 1.01968296-.25437416zm-.0327609.72678332c-.27846764 0-.52007926.08748317-.72483488.26244952-.20475561.17496636-.33443417.42934052-.38903566.76312248h2.11307794c-.0218406-.3230148-.1228534-.57469717-.3030383-.75504711-.180185-.18034993-.41224132-.27052489-.6961691-.27052489z"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "m14.1035667 1.62314939c.3712902 0 .6961691.08479139.9746367.25437416.2784677.16958278.4941436.40107672.6470278.69448183.1528842.29340512.2293263.6231494.2293263.98923284 0 .12382235-.0136504.2718708-.0409512.44414536h-2.9812417c.0327609.41991925.1638045.73620458.3931308.94885599s.5159841.31897712.8599736.31897712c.4477322 0 .7726111-.18304172.9746367-.54912517l.6306473.36339166c-.109203.29071332-.3166887.51547779-.6224571.6742934s-.6470277.23822342-1.0237781.23822342c-.3876706 0-.7398503-.08479139-1.0565389-.25437416-.3166887-.16958277-.5692206-.42126514-.7575958-.75504711-.1883752-.33378196-.2825628-.73216689-.2825628-1.19515477 0-.45222073.0941876-.84253029.2825628-1.17092867.1883752-.32839839.439542-.57738896.7535007-.74697174.3139586-.16958277.6538529-.25437416 1.0196829-.25437416zm-.0327609.72678332c-.2784676 0-.5200792.08748317-.7248349.26244952-.2047556.17496636-.3344341.42934052-.3890356.76312248h2.1130779c-.0218406-.3230148-.1228534-.57469717-.3030383-.75504711-.1801849-.18034993-.4122413-.27052489-.6961691-.27052489z"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "m19.4517834 0 1.8100396 4.72409152 1.7281374-4.72409152h.9091149l-2.2932629 5.91117093h-.7453104l-2.3915456-5.91117093z"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "m25.5207398 5.91117093h-.8763541v-5.91117093h.8763541z"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "m28.81321 0c.4258917 0 .8053721.07806191 1.1384413.23418573.3330691.15612383.5910612.37685061.7739762.66218035.182915.28532975.2743725.61103634.2743725.97711979 0 .36608344-.0914575.69044414-.2743725.9730821-.182915.28263795-.4395421.50201884-.7698811.65814266-.3303391.15612382-.7111845.23418574-1.1425364.23418574h-1.0401585v2.17227456h-.876354v-5.91117093zm-.1064729 2.98788694c.4313518 0 .765786-.10094212 1.0033025-.30282637.2375165-.20188426.3562748-.47240916.3562748-.8115747 0-.33916555-.1187583-.61103634-.3562748-.81561238-.2375165-.20457605-.5719507-.30686407-1.0033025-.30686407h-.9336856v2.23687752z"
                        })
                    ]
                })
            ]
        })
    ]
});
const svgTypes = {
    moon,
    sun,
    network,
    downIcon,
    uploadIcon,
    closeIcon,
    addIcon,
    account_panel,
    account_overview,
    account_miners,
    account_personal,
    account_logout,
    legendIcon,
    no_nodes,
    editIcon,
    downloadIcon,
    successIcon,
    pendingIcon,
    errorIcon,
    dateArrowIcon,
    dateIcon,
    openAllIcon,
    deleteIcon,
    fileIcon,
    tip,
    outlook,
    telegram,
    twitter,
    block_chain,
    edit,
    copyIcon,
    search,
    fil_overview,
    hot,
    newIcon,
    barLegend,
    meta,
    power,
    reward,
    gas,
    pledge,
    balance,
    monitor,
    code,
    fevm,
    upIcon,
    reset,
    cancel,
    add,
    memberVip,
    memberBg,
    member_active,
    member_icon_logo,
    freeVip
};
const getSvgIcon = (type)=>{
    return svgTypes[type] || "";
};


/***/ }),

/***/ 23495:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $h: () => (/* binding */ truncateDecimalAfterZeros),
/* harmony export */   D2: () => (/* binding */ unitConversionNum),
/* harmony export */   EA: () => (/* binding */ isIndent),
/* harmony export */   Fy: () => (/* binding */ formatNumberPercentage),
/* harmony export */   H_: () => (/* binding */ account_link),
/* harmony export */   IC: () => (/* binding */ getShowData),
/* harmony export */   Jh: () => (/* binding */ isEmail),
/* harmony export */   LH: () => (/* binding */ ellipsis),
/* harmony export */   Mn: () => (/* binding */ isPhone),
/* harmony export */   Mr: () => (/* binding */ max_name_length),
/* harmony export */   Nm: () => (/* binding */ formatFilNum),
/* harmony export */   P5: () => (/* binding */ pageLimit),
/* harmony export */   Qs: () => (/* binding */ titleCase),
/* harmony export */   Uk: () => (/* binding */ formatFil),
/* harmony export */   Uy: () => (/* binding */ get$Number),
/* harmony export */   aP: () => (/* binding */ isPositiveInteger),
/* harmony export */   dD: () => (/* binding */ parseQueryString),
/* harmony export */   dN: () => (/* binding */ unitConversion),
/* harmony export */   f: () => (/* binding */ convertStringToArray),
/* harmony export */   m$: () => (/* binding */ pageHomeLimit),
/* harmony export */   mr: () => (/* binding */ formatTime),
/* harmony export */   o0: () => (/* binding */ formatDateTime),
/* harmony export */   pf: () => (/* binding */ getCalcTime),
/* harmony export */   sQ: () => (/* binding */ formatNumberUnit),
/* harmony export */   uf: () => (/* binding */ formatNumber),
/* harmony export */   uo: () => (/* binding */ validatePassword)
/* harmony export */ });
/* unused harmony exports getClassName, validateCode, isMobile, saveToStorage, getFromStorage */
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8054);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(50785);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(49766);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([bignumber_js__WEBPACK_IMPORTED_MODULE_1__]);
bignumber_js__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 




const pageLimit = 15;
const pageHomeLimit = 10;
const max_name_length = 10;
// 账户类型
/*
account:一般账户

*/ function parseQueryString(queryString) {
    const params = new URLSearchParams(queryString);
    const obj = {};
    for (const [key, value] of params.entries()){
        if (obj[key]) {
            if (Array.isArray(obj[key])) {
                obj[key].push(value);
            } else {
                obj[key] = [
                    obj[key],
                    value
                ];
            }
        } else {
            obj[key] = value;
        }
    }
    return obj;
}
function getShowData(item, data) {
    let showData = data;
    const [first, second] = item.type || [];
    if (first) {
        if (second) {
            showData = data && data[first] && data[first][second];
        } else {
            showData = data && data[first];
        }
    }
    return showData;
}
function formatFil(number, unit = "FIL", len = 4, isAccount) {
    let returnValue;
    const num = Math.abs(Number(number));
    const flag = Number(number) < 0 ? "-" : "";
    if (unit.startsWith("FIL")) {
        const showNum = new bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"](num).dividedBy(Math.pow(10, 18));
        returnValue = Number(showNum);
    } else if (unit === "nanoFIL") {
        const showNum = new bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"](num).dividedBy(Math.pow(10, 9));
        returnValue = Number(showNum);
    } else {
        returnValue = Number(num);
    }
    if (isAccount) {
        //unit === 'FIL',len=4
        if (returnValue === 0) {
            return `0 ${unit}`;
        }
        if (returnValue < 0.0001) {
            return "<0.0001 FIL";
        }
        return len ? flag + Number(returnValue).toLocaleString("en", {
            maximumFractionDigits: len
        }) + " " + unit : flag + Number(returnValue);
    }
    return len ? flag + Number(returnValue).toFixed(len) : flag + Number(returnValue);
}
function formatFilNum(showNum, atto = false, pure = false, len = 4, toLocal = true) {
    let baseNum = Number(showNum);
    let num = baseNum;
    let flag = "";
    if (atto) {
        return num + (pure ? "" : " attoFIL");
    }
    if (baseNum < 0) {
        num = Math.abs(baseNum);
        flag = "-";
    }
    let dot = new bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"](Number(num)).dividedBy(Math.pow(10, 18)).toFixed().split(".")[1];
    const num1 = new bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"](Number(num)).dividedBy(Math.pow(10, 18)).toFixed().split(".")[0];
    const num2 = new bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"](Number(num)).dividedBy(Math.pow(10, 9)).toFixed(len).split(".")[0];
    let zero = 1;
    let res = num;
    let unit = " attoFIL";
    if (atto) {
        unit = " attoFIL";
        num = num;
    }
    if (dot) {
        for (let v of dot){
            if (Number(v) !== 0) {
                break;
            } else {
                zero++;
            }
        }
    }
    if (zero <= 5 && Number(num1) || num2.length > 6) {
        res = new bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"](Number(num)).dividedBy(Math.pow(10, 18)).toFixed(len);
        unit = " FIL";
    //return num + " FIL";
    } else if (zero <= 13 && Number(num) > Math.pow(10, 7)) {
        res = new bignumber_js__WEBPACK_IMPORTED_MODULE_1__["default"](Number(num)).dividedBy(Math.pow(10, 9)).toFixed(len);
        unit = " nanoFIL";
    } else {
        res = num;
        unit = " attoFIL";
    }
    if (res === 0 && unit === " attoFIL") {
        return "0 FIL";
    }
    return toLocal ? flag + formatNumber(res) + (pure ? "" : unit) : flag + res + (pure ? "" : unit);
}
const unitConversionNum = (str)=>{
    let sizes = [
        "Bytes",
        "KiB",
        "MiB",
        "GiB",
        "TiB",
        "PiB",
        "EiB",
        "ZiB",
        "YiB"
    ];
    return sizes.findIndex((v)=>v === str);
};
const unitConversion = (item, len, num = 0)=>{
    let showItem = Number(item);
    if (!showItem && showItem !== 0) {
        return "0 Byte";
    }
    let sizes = [
        "Bytes",
        "KiB",
        "MiB",
        "GiB",
        "TiB",
        "PiB",
        "EiB",
        "ZiB",
        "YiB"
    ];
    let positive = true;
    if (showItem == 0) {
        let unit = sizes[num];
        if (unit === "Bytes") {
            unit = "Byte";
        }
        return "0" + " " + unit;
    }
    if (showItem < 0) {
        positive = false;
        showItem = Math.abs(showItem);
    }
    let k = 1024;
    let c = num || Math.floor(Math.log(showItem) / Math.log(k));
    if (c < 0) {
        showItem = 0;
    } else {
        let units = sizes[c];
        if (!showItem && units === "Bytes") {
            units = "Byte";
        }
        showItem = (showItem / Math.pow(k, c)).toFixed(len) + " " + units;
    }
    return positive ? `${showItem}` : `-${showItem}`;
};
function formatNumber(v, len = 4) {
    if (Number(v) === 0) {
        return v;
    }
    return v ? Number(v).toLocaleString("en", {
        maximumFractionDigits: len
    }) : "--";
}
function formatDateTime(time, str = "YYYY-MM-DD HH:mm:ss") {
    if (!time) return "--";
    return typeof time === "number" ? dayjs__WEBPACK_IMPORTED_MODULE_2___default()(time * 1000).format(str) : dayjs__WEBPACK_IMPORTED_MODULE_2___default()(time).format(str);
}
function formatTime(from, to, ago = true) {
    let startTime = from || 0 // 开始时间
    ;
    let endTime = to || new Date().getTime() // 结束时间
    ;
    let usedTime = endTime - startTime // 相差的毫秒数
    ;
    //timeDifference(usedTime)
    // let days = Math.floor(usedTime / (24 * 3600 * 1000)); // 计算出天数
    // let leavel = usedTime % (24 * 3600 * 1000); // 计算天数后剩余的时间
    // let hours = Math.floor(leavel / (3600 * 1000)); // 计算剩余的小时数
    // let leavel2 = leavel % (3600 * 1000); // 计算剩余小时后剩余的毫秒数
    //  let minutes = Math.floor(leavel2 / (60 * 1000)); // 计算剩余的分钟数
    // let second = runTime % 60
    //计算出相差天数
    let days = Math.floor(usedTime / (24 * 3600 * 1000));
    //计算出小时数
    let leave1 = usedTime % (24 * 3600 * 1000);
    //计算天数后剩余的毫秒数
    let hours = Math.floor(leave1 / (3600 * 1000));
    //计算相差分钟数
    let leave2 = leave1 % (3600 * 1000 //计算小时数后剩余的毫秒数
    );
    let minutes = Math.floor(leave2 / (60 * 1000)) // 分
    ;
    //计算相差秒数
    let leave3 = leave2 % (60 * 1000 //计算分钟数后剩余的毫秒数
    );
    let seconds = Math.round(leave3 / 1000) // 秒
    ;
    //let second = runTime % 60
    return {
        days,
        hours,
        minutes,
        seconds
    };
}
function ellipsis(str, unit = 6) {
    const suffixNum = unit;
    return str && unit && str.length > suffixNum ? str?.slice(0, unit) + "..." : str;
}
function isIndent(str, unit = 6, unitNum) {
    const showUnit = unitNum ? unit + unitNum : unit * 2;
    const suffixNum = unitNum || unit;
    return str && unit && str.length > showUnit ? str?.slice(0, unit) + "..." + str?.slice(-suffixNum) : str;
}
function formatNumberUnit(number, len = 2) {
    const num = Number(number);
    if (num >= 1e9) {
        return Number(num / 1e9).toLocaleString("en", {
            maximumFractionDigits: len
        }) + "B";
    }
    if (num >= 1e6) {
        return Number(num / 1e6).toLocaleString("en", {
            maximumFractionDigits: len
        }) + "M";
    }
    // if (num >= 1e3) {
    //   return Number(num / 1e3).toLocaleString('en', { maximumFractionDigits: len }) +'K'
    // }
    return Number(num).toLocaleString("en", {
        maximumFractionDigits: len
    });
}
//连续0后保留几位
function truncateDecimalAfterZeros(num, decimalPlaces = 2) {
    const strNum = num.toString();
    const match = strNum.match(/0\.(0*)(\d{1,2})?/);
    if (!match) {
        return parseFloat(strNum).toFixed(decimalPlaces);
    }
    const leadingZeros = match[1];
    const digits = match[2] || "";
    return "0." + leadingZeros + digits;
}
// $ + number
function get$Number(str, len) {
    const showNum = Number(str);
    if (showNum === 0) return showNum;
    if (!showNum) return "--";
    let showStr = String(str);
    let flag = "";
    if (showStr.includes("-")) {
        showStr = showStr.split("-")[1];
        flag = "-";
    }
    if (str > "0" && str < "1") {
        return flag + "$" + truncateDecimalAfterZeros(showStr, 2);
    }
    const newNum = showNum < 0 ? "-$" + formatNumberUnit(Math.abs(showNum), len) : "$" + formatNumberUnit(showNum, len);
    return newNum;
}
//%
function formatNumberPercentage(num, decimalPlaces = 2) {
    return parseFloat((Number(num) * 100).toFixed(decimalPlaces));
}
function getClassName(str) {
    const showNum = Number(str);
    if (showNum === 0) return "";
    return showNum < 0 ? "text_red" : "text_green";
}
//获取当天的日期
function getCalcTime(startTime) {
    if (startTime) {
        return (new Date().getTime() - startTime * 24 * 60 * 60 * 1000) / 1000;
    }
    return new Date().getTime() / 1000;
}
//密码校验规则
function validatePassword(password, email) {
    // 8-20个字符
    if (password.length < 8 || password.length > 20) {
        return false;
    }
    // 需要同时包含数字、字母
    if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
        return false;
    }
    // 密码不能与邮箱地址相同
    if (password === email) {
        return false;
    }
    return true;
}
// 校验验证码
function validateCode(code) {
    // 六位验证码 9999 100000
    const newCode = Number(code);
    return newCode > 99999 && newCode < 1000000;
}
//校验邮箱
function isEmail(email) {
    // 判断字符串中是否包含@符号和至少一个.符号
    // if (email.includes('@') && email.includes('.')) {
    //   // 判断@符号是否在.符号之前，并且.符号不在末尾
    //   if (
    //     email.indexOf('@') < email.indexOf('.') &&
    //     email.indexOf('.') < email.length - 1
    //   ) {
    //     return true
    //   }
    // }
    // return false
    // 邮箱正则表达式
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    // 使用正则表达式进行匹配
    return emailRegex.test(email);
}
//校验手机号
function isPhone(phoneNumber) {
    const phoneNumberRegex = /^1[3456789]\d{9}$/;
    return phoneNumberRegex.test(phoneNumber);
}
//判断字符是否为正整数
function isPositiveInteger(s) {
    if (!s) {
        // 检查字符串是否为空
        return false;
    }
    if (!/^\d+$/.test(s)) {
        // 检查字符串是否只包含数字字符
        return false;
    }
    const n = parseInt(s, 10) // 将字符串转换为整数
    ;
    if (n > 0) {
        // 检查转换后的整数是否大于零
        return true;
    } else {
        return false;
    }
}
//首字母大写,其余不变
function titleCase(str) {
    const Str = String(str);
    const newStr = Str.slice(0, 1).toUpperCase() + Str.slice(1);
    return newStr;
}
//不同账户 ,
// export const get_account_type = (value: string = '', unit: number = 6) => {
//   return (
//     <>
//       <MobileView>
//         <span className="copy-row">
//           <span
//             className="text w-28"
//             onClick={() => {
//               account_link(value)
//             }}
//           >
//             {isIndent(value, unit)}
//           </span>
//           <Copy text={value} icon={<CopySvgMobile />} className="copy" />
//         </span>
//       </MobileView>
//       <BrowserView>
//         <span
//           className="link_text"
//           onClick={() => {
//             account_link(value)
//           }}
//         >
//           {isIndent(value, unit)}
//         </span>
//         {value && <Copy className="!w-[13px]" text={value} />}
//       </BrowserView>
//     </>
//   )
// }
const account_link = async (value)=>{
    let show_type;
    const result = await (0,_store_server__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_0__/* .apiUrl */ .JW.searchInfo, {
        input: value
    });
    show_type = result?.result_type;
    switch(show_type){
        case "miner":
            return next_router__WEBPACK_IMPORTED_MODULE_3___default().push(`/miner/${value}`, `/miner/${value}`, {
                scroll: true
            });
        case "storageminer":
            return next_router__WEBPACK_IMPORTED_MODULE_3___default().push(`/miner/${value}`, `/miner/${value}`, {
                scroll: true
            });
        default:
            return next_router__WEBPACK_IMPORTED_MODULE_3___default().push(`/address/${value}`, `/address/${value}`, {
                scroll: true
            });
    }
};
const isMobile = ()=>{
    try {
        return window.innerWidth <= 1000;
    } catch (error) {
        console.log("Error: Window does not exist!");
        return false;
    }
};
// save to storage
const saveToStorage = (key, value)=>{
    if (false) {}
};
// get from storage
const getFromStorage = (key)=>{
    if (false) {}
};
//'[1,2,4],[2,4,5]' 改为 [1,2,4] [2,4,5]
function convertStringToArray(str) {
    // 分割字符串为子数组字符串
    const subArraysStr = str.match(/\[([^\]]+)\]/g);
    // 将每个子数组字符串转换为数字数组
    const arrays = subArraysStr.map((subArrayStr)=>{
        // 去除方括号并分割为数字
        return subArrayStr.replace(/[\[\]]/g, "").split(",").map(Number);
    });
    return arrays;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 41387:
/***/ (() => {



/***/ }),

/***/ 57526:
/***/ (() => {



/***/ }),

/***/ 66333:
/***/ (() => {



/***/ }),

/***/ 86764:
/***/ (() => {



/***/ }),

/***/ 16836:
/***/ (() => {



/***/ }),

/***/ 32434:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./Cw.ts": 85166,
	"./account/index.ts": 48257,
	"./account/manage.ts": 51678,
	"./account/monitor.ts": 81829,
	"./account/overview.ts": 62154,
	"./account/type.ts": 68994,
	"./active.ts": 1736,
	"./analysis.ts": 56854,
	"./filscan.ts": 25572,
	"./home.ts": 60170,
	"./user.ts": 63414,
	"./wallet.ts": 46782,
	"store/modules/Cw.ts": 85166,
	"store/modules/account/index.ts": 48257,
	"store/modules/account/manage.ts": 51678,
	"store/modules/account/monitor.ts": 81829,
	"store/modules/account/overview.ts": 62154,
	"store/modules/account/type.ts": 68994,
	"store/modules/active.ts": 1736,
	"store/modules/analysis.ts": 56854,
	"store/modules/filscan.ts": 25572,
	"store/modules/home.ts": 60170,
	"store/modules/user.ts": 63414,
	"store/modules/wallet.ts": 46782
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 32434;

/***/ })

};
;
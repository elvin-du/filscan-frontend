exports.id = 3866;
exports.ids = [3866];
exports.modules = {

/***/ 5033:
/***/ ((module) => {

// Exports
module.exports = {
	"noData": "noData_noData__bkiNP"
};


/***/ }),

/***/ 5536:
/***/ ((module) => {

// Exports
module.exports = {
	"message_title": "message_message_title__XJ2Dr",
	"message_content": "message_message_content__L2VeY",
	"message_tab": "message_message_tab__hMb76",
	"message_card": "message_message_card__K_v_X",
	"message_label": "message_message_label__x8PfG",
	"message_ERC20Trans": "message_message_ERC20Trans__9YJY1",
	"message_event_log": "message_message_event_log__Rq_Lk",
	"message_event_log_wrap": "message_message_event_log_wrap__cmdKi",
	"message_content_loading": "message_message_content_loading__CghqZ"
};


/***/ }),

/***/ 9744:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9189);




const ImageWithFallback = (props)=>{
    const { src , fallbackSrc =_contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .fvmUrl */ .d + `/images/default.png` , ...rest } = props;
    const [imgSrc, setImgSrc] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(src);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        ...rest,
        src: imgSrc,
        onError: ()=>{
            setImgSrc(fallbackSrc);
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageWithFallback);


/***/ }),

/***/ 3552:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5033);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_1___default().noData),
        children: "No Data"
    });
});


/***/ }),

/***/ 7691:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(697);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9927);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_varible__WEBPACK_IMPORTED_MODULE_2__, _utils_utils__WEBPACK_IMPORTED_MODULE_4__]);
([_contants_varible__WEBPACK_IMPORTED_MODULE_2__, _utils_utils__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ dataSource , columns , current , onPage , className , onChange , loading , total =0 , rowKey  })=>{
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (loading) {
            setData([]);
        } else {
            setData(dataSource);
        }
    }, [
        dataSource,
        loading
    ]);
    if ((0,_utils_utils__WEBPACK_IMPORTED_MODULE_4__/* .isMobile */ .tq)()) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "mobile_table",
            children: data.map((dataSource, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mobile_table_card",
                    children: columns.map((item)=>{
                        const { title , dataIndex , render  } = item;
                        const showTitle = typeof item.title === "function" ? item.title() : item.title;
                        let showValue = dataSource[dataIndex];
                        if (render) {
                            showValue = render(dataSource[dataIndex], dataSource, index);
                        }
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mobile_table_card_item",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mobile_table_card_item_label",
                                    children: showTitle
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mobile_table_card_item_value",
                                    children: showValue
                                })
                            ]
                        });
                    })
                });
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Table, {
        className: `custom-table custom-border-table ${className}`,
        dataSource: [
            ...data
        ],
        columns: columns,
        rowKey: rowKey,
        loading: loading,
        onChange: (pagination, filters, sorter)=>{
            if (onChange) onChange(pagination, filters, sorter);
        },
        pagination: total > _contants_varible__WEBPACK_IMPORTED_MODULE_2__/* .pageLimit */ .P5 ? {
            position: [
                "bottomCenter"
            ],
            current: current,
            showQuickJumper: true,
            pageSize: _contants_varible__WEBPACK_IMPORTED_MODULE_2__/* .pageLimit */ .P5,
            showSizeChanger: false,
            total,
            onChange: (cur)=>{
                if (onPage) {
                    onPage(cur);
                }
            }
        } : false
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9638:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7987);
/* harmony import */ var _contants_detail__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9189);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1311);
/* harmony import */ var _packages_table__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7691);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _packages_card__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4304);
/* harmony import */ var _packages_main__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8266);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5536);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _packages_tabs___WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5943);
/* harmony import */ var _packages_noData__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3552);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_1__, _contants_detail__WEBPACK_IMPORTED_MODULE_2__, _store_server__WEBPACK_IMPORTED_MODULE_4__, _packages_table__WEBPACK_IMPORTED_MODULE_5__, _packages_card__WEBPACK_IMPORTED_MODULE_8__, _packages_main__WEBPACK_IMPORTED_MODULE_9__, _packages_tabs___WEBPACK_IMPORTED_MODULE_10__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_1__, _contants_detail__WEBPACK_IMPORTED_MODULE_2__, _store_server__WEBPACK_IMPORTED_MODULE_4__, _packages_table__WEBPACK_IMPORTED_MODULE_5__, _packages_card__WEBPACK_IMPORTED_MODULE_8__, _packages_main__WEBPACK_IMPORTED_MODULE_9__, _packages_tabs___WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 












/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ cid  })=>{
    var _message_overview_detail_title;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "detail"
        });
    };
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(true);
    const [TransferData, setTransfer] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(undefined);
    const [TransferNFTData, setTransferNft] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(undefined);
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)("detail");
    const [contentLoading, setContentLoad] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const [show_cid, setCid] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)("");
    const [trade, setTrade] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]);
    const [event, setEvent] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]);
    const [isF4, setIsF4] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const [swap, setSwap] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (cid) {
            (0,_store_server__WEBPACK_IMPORTED_MODULE_4__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl.detail_message */ .J.detail_message, {
                message_cid: cid
            }).then((res)=>{
                var _res_result, _res_result_MessageDetails, _res_result1, _res_result_MessageDetails1, _res_result_MessageDetails_message_basic, _res_result2;
                setLoading(false);
                if ((res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : (_res_result_MessageDetails = _res_result.MessageDetails) === null || _res_result_MessageDetails === void 0 ? void 0 : _res_result_MessageDetails.eth_message) && (res === null || res === void 0 ? void 0 : (_res_result1 = res.result) === null || _res_result1 === void 0 ? void 0 : (_res_result_MessageDetails1 = _res_result1.MessageDetails) === null || _res_result_MessageDetails1 === void 0 ? void 0 : (_res_result_MessageDetails_message_basic = _res_result_MessageDetails1.message_basic) === null || _res_result_MessageDetails_message_basic === void 0 ? void 0 : _res_result_MessageDetails_message_basic.cid)) {
                    var _res_result3, _res_result_MessageDetails2, _res_result_MessageDetails_message_basic1, _res_result4, _res_result_MessageDetails3, _res_result_MessageDetails_message_basic2, _res_result5, _res_result_MessageDetails4, _res_result_MessageDetails_message_basic3;
                    loadTrans(res === null || res === void 0 ? void 0 : (_res_result3 = res.result) === null || _res_result3 === void 0 ? void 0 : (_res_result_MessageDetails2 = _res_result3.MessageDetails) === null || _res_result_MessageDetails2 === void 0 ? void 0 : (_res_result_MessageDetails_message_basic1 = _res_result_MessageDetails2.message_basic) === null || _res_result_MessageDetails_message_basic1 === void 0 ? void 0 : _res_result_MessageDetails_message_basic1.cid);
                    setCid(res === null || res === void 0 ? void 0 : (_res_result4 = res.result) === null || _res_result4 === void 0 ? void 0 : (_res_result_MessageDetails3 = _res_result4.MessageDetails) === null || _res_result_MessageDetails3 === void 0 ? void 0 : (_res_result_MessageDetails_message_basic2 = _res_result_MessageDetails3.message_basic) === null || _res_result_MessageDetails_message_basic2 === void 0 ? void 0 : _res_result_MessageDetails_message_basic2.cid);
                    setIsF4(res === null || res === void 0 ? void 0 : (_res_result5 = res.result) === null || _res_result5 === void 0 ? void 0 : (_res_result_MessageDetails4 = _res_result5.MessageDetails) === null || _res_result_MessageDetails4 === void 0 ? void 0 : (_res_result_MessageDetails_message_basic3 = _res_result_MessageDetails4.message_basic) === null || _res_result_MessageDetails_message_basic3 === void 0 ? void 0 : _res_result_MessageDetails_message_basic3.to.startsWith("f4"));
                }
                // if (!res?.result?.MessageDetails) {
                //   //return Router.push('/404')
                // }
                setData((res === null || res === void 0 ? void 0 : (_res_result2 = res.result) === null || _res_result2 === void 0 ? void 0 : _res_result2.MessageDetails) || {});
            });
        }
    }, [
        cid
    ]);
    const loadTrans = (id)=>{
        (0,_store_server__WEBPACK_IMPORTED_MODULE_4__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl.contract_transferInMessage */ .J.contract_transferInMessage, {
            cid: id
        }).then((res)=>{
            var _res_result;
            setTransfer((res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.items) || []);
        });
        (0,_store_server__WEBPACK_IMPORTED_MODULE_4__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl.contract_transferInMessageNft */ .J.contract_transferInMessageNft, {
            cid: id
        }).then((res)=>{
            var _res_result;
            setTransferNft((res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.items) || []);
        });
        (0,_store_server__WEBPACK_IMPORTED_MODULE_4__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl.contract_swap */ .J.contract_swap, {
            cid: id
        }).then((res)=>{
            var _res_result;
            setSwap(res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.swap_info);
        });
    };
    const load = (type)=>{
        if (type === "event_log" && show_cid) {
            setContentLoad(true);
            (0,_store_server__WEBPACK_IMPORTED_MODULE_4__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl.detail_message_event */ .J.detail_message_event, {
                cid: show_cid
            }).then((res)=>{
                var _res_result;
                setContentLoad(false);
                setEvent((res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.logs) || []);
            });
        } else if (type === "trade" && show_cid) {
            setContentLoad(true);
            (0,_store_server__WEBPACK_IMPORTED_MODULE_4__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl.detail_message_trans */ .J.detail_message_trans, {
                cid: show_cid
            }).then((res)=>{
                var _res_result;
                setContentLoad(false);
                setTrade((res === null || res === void 0 ? void 0 : (_res_result = res.result) === null || _res_result === void 0 ? void 0 : _res_result.internal_transfers) || []);
            });
        }
    };
    const handleChange = (item)=>{
        setActive(item.value);
        load(item.value);
    };
    const renderItem = ()=>{
        if (contentLoading) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_content_loading),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_7__.LoadingOutlined, {
                    style: {
                        fontSize: 16
                    },
                    rev: undefined
                })
            });
        }
        if (active === "event_log") {
            if (!contentLoading && event.length === 0) {
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_noData__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {});
            }
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_event_log),
                children: event.map((itemData, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_main__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        warpClassName: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_event_log_wrap),
                        content: _contants_detail__WEBPACK_IMPORTED_MODULE_2__/* .message_event_log */ .L6,
                        data: itemData,
                        ns: "detail"
                    }, index);
                })
            });
        } else if (active === "trade") {
            if (!contentLoading && trade.length === 0) {
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_noData__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {});
            }
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_card__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                ns: "detail",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_table__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    className: "custom-table",
                    dataSource: [
                        ...trade
                    ],
                    columns: _contants_detail__WEBPACK_IMPORTED_MODULE_2__/* .message_overview_trade.map */ .XW.map((v)=>{
                        return {
                            ...v,
                            title: tr(v.title)
                        };
                    }),
                    loading: contentLoading
                })
            });
        }
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_content),
            children: _contants_detail__WEBPACK_IMPORTED_MODULE_2__/* .message_overview_detail.content.map */ .ZF.content.map((itemContent)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_main__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    content: itemContent,
                    data: {
                        ...data,
                        message_ERC20Trans: TransferData,
                        swap_info: swap,
                        nftTrans: TransferNFTData
                    },
                    ns: "detail"
                });
            })
        });
    };
    if (!loading && !data || !loading && Object.keys(data).length === 0) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_noData__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {});
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message),
        children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            style: {
                margin: "20% 45%"
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_7__.LoadingOutlined, {
                style: {
                    fontSize: 36
                },
                rev: undefined
            })
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_title),
                    children: tr(_contants_detail__WEBPACK_IMPORTED_MODULE_2__/* .message_overview_detail */ .ZF === null || _contants_detail__WEBPACK_IMPORTED_MODULE_2__/* .message_overview_detail */ .ZF === void 0 ? void 0 : (_message_overview_detail_title = _contants_detail__WEBPACK_IMPORTED_MODULE_2__/* .message_overview_detail.title */ .ZF.title) === null || _message_overview_detail_title === void 0 ? void 0 : _message_overview_detail_title.label)
                }),
                isF4 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tabs___WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().message_tab),
                    data: _contants_detail__WEBPACK_IMPORTED_MODULE_2__/* .message_list.tabs */ .Xd.tabs,
                    defaultValue: active,
                    ns: "detail",
                    border: true,
                    onChange: (item)=>{
                        handleChange(item);
                    }
                }),
                renderItem()
            ]
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
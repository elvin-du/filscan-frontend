exports.id = 6113;
exports.ids = [6113];
exports.modules = {

/***/ 2533:
/***/ ((module) => {

// Exports
module.exports = {
	"statis": "statistics_statis__D_ZSz",
	"fil": "statistics_fil__M1NJj",
	"fil_chart": "statistics_fil_chart__AB3cD",
	"fil_ul": "statistics_fil_ul__hQwYq",
	"fil_ul_li": "statistics_fil_ul_li___KSLm",
	"fil_ul_li_label": "statistics_fil_ul_li_label__8ZNlH",
	"fil_ul_li_value": "statistics_fil_ul_li_value__7d4Rq",
	"fil_ul_li_des": "statistics_fil_ul_li_des__L4IuY",
	"fil_chart_pie": "statistics_fil_chart_pie__iGZyX",
	"charts": "statistics_charts__sRoot",
	"statis_trend": "statistics_statis_trend__04iTi",
	"statis_trend_title": "statistics_statis_trend_title__PeRcf",
	"statis_chart": "statistics_statis_chart__cDiL3",
	"gas_header": "statistics_gas_header__lw6BR",
	"gas_header_left": "statistics_gas_header_left__xHW95",
	"gas_header_left_IconSvg": "statistics_gas_header_left_IconSvg__9Gdym"
};


/***/ }),

/***/ 6113:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5063);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2533);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _packages_tips__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4950);
/* harmony import */ var _packages_tabs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5943);
/* harmony import */ var _svgUtils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3775);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _packages_tabs__WEBPACK_IMPORTED_MODULE_5__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _packages_tabs__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ title , defaultValue , onChange  })=>{
    var _title_right;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "static"
        });
    };
    const rightTitle = title === null || title === void 0 ? void 0 : (_title_right = title.right) === null || _title_right === void 0 ? void 0 : _title_right.title;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default().gas_header),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default().gas_header_left),
                children: [
                    (title === null || title === void 0 ? void 0 : title.icon) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default().gas_header_left_IconSvg),
                        children: (0,_svgUtils__WEBPACK_IMPORTED_MODULE_6__/* .getSvgIcon */ .a)(title.label)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default().statis_trend_title)} font_18`,
                        children: tr(title.label)
                    }),
                    (title === null || title === void 0 ? void 0 : title.tip) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tips__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        context: tr(title.tip)
                    })
                ]
            }),
            title.right && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "right",
                children: [
                    rightTitle && title.right.link ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: title.right.link,
                        className: "right-item link_item",
                        children: [
                            tr(title.right.title),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__.RightOutlined, {
                                rev: undefined
                            })
                        ]
                    }) : rightTitle && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "right-item",
                        children: tr(title.right.title)
                    }),
                    title.right && title.right.opt && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tabs__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        className: "right-opt right-content",
                        data: title.right.opt,
                        defaultValue: defaultValue,
                        ns: "static",
                        border: true,
                        onChange: (value)=>onChange(value)
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
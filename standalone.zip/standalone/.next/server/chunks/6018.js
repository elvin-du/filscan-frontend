exports.id = 6018;
exports.ids = [6018];
exports.modules = {

/***/ 9198:
/***/ ((module) => {

// Exports
module.exports = {
	"indicators_wrap": "style_indicators_wrap__1gVg_",
	"indicators_header": "style_indicators_header__qYRnP"
};


/***/ }),

/***/ 6491:
/***/ ((module) => {

// Exports
module.exports = {
	"owner_overview": "style_owner_overview__Ok28t",
	"owner_overview_chart": "style_owner_overview_chart__B4nBK",
	"owner_overview_chart_overview": "style_owner_overview_chart_overview__65ndw",
	"owner_overview_chart_balance": "style_owner_overview_chart_balance__Qtl2V",
	"owner_overview_chart_balance_value": "style_owner_overview_chart_balance_value__lWJt0",
	"owner_overview_chart_item": "style_owner_overview_chart_item__7IO9z",
	"owner_overview_chart_item_mark": "style_owner_overview_chart_item_mark__eaKcp",
	"owner_overview_power": "style_owner_overview_power__YAtoP",
	"power_content": "style_power_content__XsA0F",
	"power_content_header": "style_power_content_header__fe2qD",
	"power_content_header_item": "style_power_content_header_item__5JZxj",
	"power_content_header_item_value": "style_power_content_header_item_value__LbMka",
	"power_content_content": "style_power_content_content__tp93x",
	"power_content_content_item": "style_power_content_content_item__1Digs",
	"power_content_value": "style_power_content_value__z3gy7",
	"power_content_listValue": "style_power_content_listValue__UrscN"
};


/***/ }),

/***/ 8391:
/***/ ((module) => {

// Exports
module.exports = {
	"account_content": "style_account_content__UvHnP"
};


/***/ }),

/***/ 3909:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7003);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9189);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(697);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8194);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1311);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9927);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_echarts__WEBPACK_IMPORTED_MODULE_1__, _contants_varible__WEBPACK_IMPORTED_MODULE_3__, _store_server__WEBPACK_IMPORTED_MODULE_5__, _utils_utils__WEBPACK_IMPORTED_MODULE_6__, react_i18next__WEBPACK_IMPORTED_MODULE_9__]);
([_components_echarts__WEBPACK_IMPORTED_MODULE_1__, _contants_varible__WEBPACK_IMPORTED_MODULE_3__, _store_server__WEBPACK_IMPORTED_MODULE_5__, _utils_utils__WEBPACK_IMPORTED_MODULE_6__, react_i18next__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_8__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z);
    const { address , type , list , interval  } = props;
    const color = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return (0,_contants_varible__WEBPACK_IMPORTED_MODULE_3__/* .getColor */ .Lq)(filscanStore.filscan.theme);
    }, [
        filscanStore.filscan.theme
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return {
            ...(0,_contants_varible__WEBPACK_IMPORTED_MODULE_3__/* .defaultOpt */ .Re)("line", filscanStore.filscan.theme),
            yAxis: [
                {
                    type: "value",
                    scale: true,
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        lineStyle: {
                            color: color.lineStyle
                        },
                        textStyle: {
                            color: color.textStyle
                        },
                        formatter (v) {
                            return v + " TiB";
                        }
                    },
                    splitLine: {
                        lineStyle: {
                            type: "dashed",
                            color: color.splitLine
                        }
                    },
                    // name: vm.tr("chart.title"),
                    nameTextStyle: {
                        color: color.textStyle,
                        align: "left"
                    }
                }
            ],
            tooltip: {
                trigger: "axis",
                position: "right",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (p) {
                    let result = p[0].name;
                    p.forEach((item, index)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + item.seriesName + ": " + item.data.amount + " " + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    }, [
        filscanStore.filscan.theme
    ]);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_9__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "detail"
        });
    };
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({});
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (address) {
            (0,_store_server__WEBPACK_IMPORTED_MODULE_5__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .apiUrl.account_trend */ .J.account_trend, {
                account_id: address,
                filters: {
                    interval: interval,
                    account_type: type
                }
            }).then((res)=>{
                const seriesObj = {
                    power: [],
                    power_increase: []
                };
                let newOpt = {
                    ...defaultOptions
                };
                newOpt.series = [];
                const timeData = [];
                res?.result?.power_trend_by_account_id_list?.reverse().forEach((value)=>{
                    const { block_time , power , power_increase  } = value;
                    let showTime = "";
                    showTime = dayjs__WEBPACK_IMPORTED_MODULE_7___default()(block_time * 1000).format("YYYY-MM-DD HH:mm");
                    timeData.push(showTime);
                    //y轴
                    const [powerValue, powerUnit] = power ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(power, 4, 4).split(" ") : [];
                    const [increaseValue, increaseUnit] = power_increase ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(power_increase, 4, 4)?.split(" ") : [];
                    //amount
                    const [powerValue_amount, powerValue_unit] = power ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(power, 4)?.split(" ") : [];
                    const [power_increase_amount, power_increase_unit] = power_increase ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(power_increase, 4)?.split(" ") : [];
                    seriesObj.power.push({
                        value: powerValue,
                        unit: powerValue_unit,
                        amount: powerValue_amount
                    });
                    seriesObj.power_increase.push({
                        value: increaseValue,
                        unit: power_increase_unit,
                        amount: power_increase_amount
                    });
                });
                const legendList = [];
                list.forEach((item)=>{
                    legendList.push(tr(item.label));
                    newOpt.series.push({
                        type: item.type,
                        smooth: true,
                        data: seriesObj[item.label],
                        name: tr(item.label),
                        symbol: "circle",
                        barMaxWidth: "30",
                        backgroundStyle: {
                            color: item?.backgroundColor || ""
                        }
                    });
                });
                newOpt.legend.data = legendList;
                newOpt.xAxis.data = timeData;
                setOptions(newOpt);
            });
        }
    }, [
        address,
        interval,
        filscanStore.filscan.theme
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        className: "chart_content",
        propsOption: {
            ...options
        }
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 542:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_detail__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2448);
/* harmony import */ var _packages_custom_card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3625);
/* harmony import */ var _packages_tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5943);
/* harmony import */ var _packages_main__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8266);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9198);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1311);
/* harmony import */ var _contants_apiUrl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9189);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_detail__WEBPACK_IMPORTED_MODULE_1__, _packages_custom_card__WEBPACK_IMPORTED_MODULE_2__, _packages_tabs__WEBPACK_IMPORTED_MODULE_3__, _packages_main__WEBPACK_IMPORTED_MODULE_4__, _store_server__WEBPACK_IMPORTED_MODULE_6__, react_i18next__WEBPACK_IMPORTED_MODULE_8__]);
([_contants_detail__WEBPACK_IMPORTED_MODULE_1__, _packages_custom_card__WEBPACK_IMPORTED_MODULE_2__, _packages_tabs__WEBPACK_IMPORTED_MODULE_3__, _packages_main__WEBPACK_IMPORTED_MODULE_4__, _store_server__WEBPACK_IMPORTED_MODULE_6__, react_i18next__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { accountId  } = props;
    const [interval, setInterVal] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("24h");
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({});
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_8__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "detail"
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        if (accountId) {
            load_Indicators();
        } else {
            setData({});
        }
    }, [
        accountId
    ]);
    const load_Indicators = (time)=>{
        const intervals = time || interval;
        (0,_store_server__WEBPACK_IMPORTED_MODULE_6__/* .postAxios */ .xW)(_contants_apiUrl__WEBPACK_IMPORTED_MODULE_7__/* .apiUrl.detail_Indicators */ .J.detail_Indicators, {
            account_id: accountId,
            filters: {
                interval: intervals
            }
        }, {
            timeout: undefined
        }).then((res)=>{
            setData(res?.result?.miner_indicators || {});
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        bgColor: true,
        ns: "detail",
        header: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default().indicators_header),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: tr(_contants_detail__WEBPACK_IMPORTED_MODULE_1__/* .indicators_overview.title.label */ .Hd.title.label)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tabs__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    data: _contants_detail__WEBPACK_IMPORTED_MODULE_1__/* .indicators_overview.title.list */ .Hd.title.list,
                    ns: "detail",
                    className: "tabs-right",
                    defaultValue: interval,
                    border: true,
                    onChange: (value)=>{
                        setInterVal(value.value);
                        load_Indicators(value.value);
                    }
                })
            ]
        }),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_main__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            warpClassName: (_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default().indicators_wrap),
            content: _contants_detail__WEBPACK_IMPORTED_MODULE_1__/* .indicators_overview.content */ .Hd.content,
            data: data,
            ns: "detail",
            ItemClassName: (_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default().indicators_list_item)
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6082:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7987);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6491);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _packages_tips__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4950);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9927);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_1__, _utils_utils__WEBPACK_IMPORTED_MODULE_3__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_1__, _utils_utils__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ list , data , type  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "detail"
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().power_content),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().power_content_header),
                children: list?.header?.map((item)=>{
                    const { dataIndex , render  } = item;
                    const value = render ? render(data[item.dataIndex], data) : data[item.dataIndex];
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().power_content_header_item),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: tr(item.label)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `${(_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().power_content_header_item_value)} font-22`,
                                children: value && value !== "--" ? value : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_4__.Skeleton.Input, {
                                    style: {
                                        height: 20
                                    },
                                    active: true,
                                    size: "default",
                                    block: false
                                })
                            })
                        ]
                    });
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().power_content_content),
                children: list?.content?.map((item, index)=>{
                    if (type === "owner" && item.label === "sector_size") {
                        return "";
                    }
                    const { dataIndex , render  } = item;
                    let value = data[item.dataIndex];
                    if (item.renderList) {
                        value = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: item.renderList.map((listItem, index)=>{
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    style: {
                                        color: listItem.color
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: data[listItem.value]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().power_content_value),
                                            children: tr(listItem.label)
                                        })
                                    ]
                                }, index);
                            })
                        });
                    }
                    if (render) {
                        value = render(value, data);
                    }
                    const ItemStyle = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_3__/* .isMobile */ .tq)() ? {} : {
                        width: item?.width,
                        justifyContent: index % 2 || item?.width ? "flex-end" : "flex-start"
                    };
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().power_content_content_item),
                        style: {
                            ...ItemStyle
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    tr(item.label),
                                    " ",
                                    item.label_tip && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tips__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        context: tr(item.label_tip)
                                    }),
                                    " :"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: `${item.renderList ? (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().power_content_listValue) : (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().power_content_value)}`,
                                style: {
                                    justifyContent: index % 2 ? "end" : "start"
                                },
                                children: value === "--" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_4__.Skeleton.Input, {
                                    style: {
                                        height: 20
                                    },
                                    active: true,
                                    size: "default",
                                    block: false
                                }) : value
                            })
                        ]
                    });
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6574:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7003);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_content__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8194);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9927);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7987);
/* harmony import */ var _contants_varible__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(697);
/* harmony import */ var _contants_detail__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2448);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_echarts__WEBPACK_IMPORTED_MODULE_1__, _utils_utils__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_5__, _contants_varible__WEBPACK_IMPORTED_MODULE_6__, _contants_detail__WEBPACK_IMPORTED_MODULE_7__]);
([_components_echarts__WEBPACK_IMPORTED_MODULE_1__, _utils_utils__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_5__, _contants_varible__WEBPACK_IMPORTED_MODULE_6__, _contants_detail__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 







function Overview({ data  }) {
    const filscanStore = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_store_content__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "detail"
        });
    };
    const color = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return (0,_contants_varible__WEBPACK_IMPORTED_MODULE_6__/* .getColor */ .Lq)(filscanStore.filscan.theme);
    }, [
        filscanStore.filscan.theme
    ]);
    const defaultOtions = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return {
            grid: {
                width: "100%",
                height: "100%",
                top: 50,
                left: 100,
                right: 0,
                bottom: 0,
                containLabel: true
            },
            tooltip: {
                trigger: "item",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    const { name , value  } = v;
                    return `${v.marker} ${name}`;
                },
                position: "right"
            },
            legend: {
                top: "40%",
                orient: "",
                width: 400,
                right: "10%",
                textStyle: {
                    fontSize: 16,
                    color: color.textStyle
                }
            },
            series: [
                {
                    type: "pie",
                    radius: [
                        "26%",
                        "48%"
                    ],
                    avoidLabelOverlap: false,
                    label: {
                        show: false,
                        fontSize: 16,
                        rich: {
                            dark: {
                                color: "#000"
                            },
                            color: {
                                color: "#309cfe"
                            }
                        }
                    },
                    data: [],
                    center: [
                        "40%",
                        "45%"
                    ]
                }
            ]
        };
    }, [
        filscanStore.filscan
    ]);
    const options = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        const seriesData = [];
        const legendData = [];
        _contants_detail__WEBPACK_IMPORTED_MODULE_7__/* .pool_overview.list.content.forEach */ .fs.list.content.forEach((item)=>{
            const showData = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_4__/* .getShowData */ .IC)(item, data);
            const value = showData && showData[item.dataIndex] ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_4__/* .formatFil */ .Uk)(showData[item.dataIndex]) : "--";
            const name = `${tr(item.label)}: ${value !== "--" ? (0,_utils_utils__WEBPACK_IMPORTED_MODULE_4__/* .formatFil */ .Uk)(value, "FIL", 3) : "--"} FIL`;
            // legendData.push(name);
            seriesData.push({
                value,
                name,
                itemStyle: {
                    color: item.color
                }
            });
        });
        const newOpt = {
            ...defaultOtions
        };
        newOpt.series[0].data = seriesData;
        newOpt.legend.data = legendData;
        return {
            ...newOpt
        };
    }, [
        data,
        filscanStore.filscan
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        style: {
            height: 260
        },
        propsOption: {
            ...options
        }
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Overview);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4032:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_detail__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2448);
/* harmony import */ var _packages_custom_card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3625);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9927);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7987);
/* harmony import */ var _Power__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6082);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6491);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _View__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6574);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_detail__WEBPACK_IMPORTED_MODULE_1__, _packages_custom_card__WEBPACK_IMPORTED_MODULE_2__, _utils_utils__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_5__, _Power__WEBPACK_IMPORTED_MODULE_6__, _View__WEBPACK_IMPORTED_MODULE_7__]);
([_contants_detail__WEBPACK_IMPORTED_MODULE_1__, _packages_custom_card__WEBPACK_IMPORTED_MODULE_2__, _utils_utils__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_5__, _Power__WEBPACK_IMPORTED_MODULE_6__, _View__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "detail"
        });
    };
    const { title , data  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        title: title.label,
        ns: "detail",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_8___default().owner_overview),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_8___default().owner_overview_chart),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_8___default().owner_overview_chart_overview),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_View__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                data: data
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_8___default().owner_overview_chart_balance),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: tr(_contants_detail__WEBPACK_IMPORTED_MODULE_1__/* .pool_overview.list.title */ .fs.list.title)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `${(_style_module_scss__WEBPACK_IMPORTED_MODULE_8___default().owner_overview_chart_balance_value)} font-22`,
                                    children: data?.account_indicator?.balance ? `${Number((0,_utils_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatFil */ .Uk)(data?.account_indicator?.balance, "FIL", 3)).toLocaleString()} FIL` : "--"
                                }),
                                _contants_detail__WEBPACK_IMPORTED_MODULE_1__/* .pool_overview.list.content */ .fs.list.content?.map((item)=>{
                                    const showData = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_3__/* .getShowData */ .IC)(item, data);
                                    const value = showData && showData[item.dataIndex] ? showData[item.dataIndex] : "--";
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_8___default().owner_overview_chart_item),
                                        style: {
                                            textAlign: item?.align
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_8___default().owner_overview_chart_item_mark),
                                                style: {
                                                    background: item?.color
                                                }
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                children: [
                                                    tr(item.label),
                                                    ":"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: value !== "--" ? Number((0,_utils_utils__WEBPACK_IMPORTED_MODULE_3__/* .formatFil */ .Uk)(value, "FIL", 3)).toLocaleString() + "FIL" : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_4__.Skeleton.Input, {
                                                    style: {
                                                        height: 20
                                                    },
                                                    active: true,
                                                    size: "default",
                                                    block: false
                                                })
                                            })
                                        ]
                                    });
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_8___default().owner_overview_power),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Power__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        type: props.type,
                        list: _contants_detail__WEBPACK_IMPORTED_MODULE_1__/* .pool_overview.power_list */ .fs.power_list,
                        data: data?.account_indicator || {}
                    })
                })
            ]
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5608:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contants_detail__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2448);
/* harmony import */ var _components_accountChange__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4620);
/* harmony import */ var _components_powerTrend__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3909);
/* harmony import */ var _packages_custom_card__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3625);
/* harmony import */ var _packages_tabs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5943);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8391);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contants_detail__WEBPACK_IMPORTED_MODULE_1__, _components_accountChange__WEBPACK_IMPORTED_MODULE_2__, _components_powerTrend__WEBPACK_IMPORTED_MODULE_3__, _packages_custom_card__WEBPACK_IMPORTED_MODULE_4__, _packages_tabs__WEBPACK_IMPORTED_MODULE_5__]);
([_contants_detail__WEBPACK_IMPORTED_MODULE_1__, _components_accountChange__WEBPACK_IMPORTED_MODULE_2__, _components_powerTrend__WEBPACK_IMPORTED_MODULE_3__, _packages_custom_card__WEBPACK_IMPORTED_MODULE_4__, _packages_tabs__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)("7d");
    const { accountId , type  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_7___default().account_content),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                title: _contants_detail__WEBPACK_IMPORTED_MODULE_1__/* .account_change.title.label */ .UW.title.label,
                ns: "detail",
                bgColor: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_accountChange__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    address: accountId,
                    type: type,
                    list: _contants_detail__WEBPACK_IMPORTED_MODULE_1__/* .account_change.list */ .UW.list,
                    interval: "30d"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_custom_card__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                title: _contants_detail__WEBPACK_IMPORTED_MODULE_1__/* .power_trend.title.label */ .wO.title.label,
                bgColor: true,
                ns: "detail",
                headerRight: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tabs__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    data: _contants_detail__WEBPACK_IMPORTED_MODULE_1__/* .power_trend.title.list */ .wO.title.list,
                    ns: "detail",
                    className: "tabs-right",
                    defaultValue: interval,
                    border: true,
                    onChange: (value)=>{
                        setInterval(value.value);
                    }
                }),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_powerTrend__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    address: accountId,
                    type: type,
                    list: _contants_detail__WEBPACK_IMPORTED_MODULE_1__/* .power_trend.list */ .wO.list,
                    interval: interval
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
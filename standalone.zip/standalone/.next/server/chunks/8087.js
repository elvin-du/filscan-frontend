"use strict";
exports.id = 8087;
exports.ids = [8087];
exports.modules = {

/***/ 38087:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   H: () => (/* binding */ useHash)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


// 自定义Hook，用于获取hash
function useHash() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
    const [hash, setHash] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [lastHashParams, setLastHashParams] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    function checkUrl(url) {
        /*
    匹配/xxx#hash
    /xxx/?name=xxx#xxx
    /xxx#xxx?xxx=xxx

    */ const regex = /\/[^\/#?]*?(#[^#\/?]*|\?name=[^#]*#[^#\/]*|#[^#\/?]*\?[^#]*=[^#\/]*)$/;
        return regex.test(url);
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (false) {}
    }, [
        router
    ]);
    return {
        hash,
        hashParams: lastHashParams
    };
}


/***/ })

};
;